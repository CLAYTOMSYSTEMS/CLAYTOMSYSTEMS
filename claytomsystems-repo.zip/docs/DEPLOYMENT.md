# Deployment Guide
kubectl apply -f k8s/
