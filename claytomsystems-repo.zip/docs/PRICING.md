# Pricing (summary)
Starter €299 | Business €1,490 | Enterprise €4,900. Minutes from €0.06/min.
