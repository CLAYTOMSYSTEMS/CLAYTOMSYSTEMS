const express = require('express'); const cors=require('cors'); const fetch=require('node-fetch')
const app = express(); app.use(cors()); app.use(express.json())
const PROFILES_URL = process.env.PROFILES_URL || 'http://profiles-service:8080'
app.get('/health', (_,res)=>res.json({ok:true}))
app.get('/pricing', (_,res)=>res.json({plans:[{name:'Starter',price:299},{name:'Business',price:1490},{name:'Enterprise',price:4900}]}))
app.get('/chatbots', async (_,res)=>{ const r=await fetch(`${PROFILES_URL}/chatbots`); res.json(await r.json()) })
app.post('/sessions', async (req,res)=>{ res.json({room:'voice-ai', token:'REPLACE', model:process.env.OPENAI_REALTIME_MODEL, botId:req.body.botId}) })
app.listen(8081, ()=>console.log('API Gateway :8081'))
