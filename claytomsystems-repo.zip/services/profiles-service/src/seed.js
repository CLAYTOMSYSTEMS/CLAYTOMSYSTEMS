const { Client } = require('pg'); const fs=require('fs')
const data = JSON.parse(fs.readFileSync('/app/data/chatbots.json','utf-8'))
;(async()=>{
  const client = new Client({ host:process.env.PGHOST||'localhost', port:+(process.env.PGPORT||5432),
    user:process.env.PGUSER||'postgres', password:process.env.PGPASSWORD||'postgres', database:process.env.PGDATABASE||'claytomsys' })
  await client.connect()
  await client.query(`CREATE TABLE IF NOT EXISTS chatbots(
    id TEXT PRIMARY KEY, category TEXT, display_name TEXT, model TEXT)`)
  for (const b of data){
    await client.query(`INSERT INTO chatbots(id,category,display_name,model) VALUES($1,$2,$3,$4)
      ON CONFLICT (id) DO NOTHING`, [b.id,b.category,b.displayName,b.model])
  }
  console.log('Seeded', data.length); process.exit(0)
})()
