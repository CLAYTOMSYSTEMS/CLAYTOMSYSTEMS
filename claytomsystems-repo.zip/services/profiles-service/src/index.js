const Fastify = require('fastify')
const cors = require('cors')
const { Client } = require('pg')
const fs = require('fs')
const app = Fastify({ logger:true })
app.use(cors())
const client = new Client({
  host: process.env.PGHOST||'localhost', port: +(process.env.PGPORT||5432),
  user: process.env.PGUSER||'postgres', password: process.env.PGPASSWORD||'postgres',
  database: process.env.PGDATABASE||'claytomsys'
})
client.connect()
app.get('/health', async ()=>({ok:true}))
app.get('/chatbots', async ()=>{
  const { rows } = await client.query('SELECT id, category, display_name FROM chatbots ORDER BY id')
  return rows
})
app.listen({port:8080, host:'0.0.0.0'})
