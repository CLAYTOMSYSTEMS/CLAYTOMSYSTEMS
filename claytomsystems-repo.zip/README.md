# ClayTomSystems – Voice AI Platform (LiveKit + OpenAI Realtime + Microservices)
See docs/DEPLOYMENT.md for step‑by‑step deploy.
