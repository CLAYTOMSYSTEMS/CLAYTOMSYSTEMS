# Sandra IA 7.0 — Ecosistema Completo (Guests Valencia)

Monorepo listo con:
- **backend/** API unificada + WS proxy Realtime + HeyGen endpoints + auth + SQLite
- **web/** Landing corporativa (Next.js) + sección Sandra + Admin
- **sandra-app/** App conversacional PROTECH (Next.js)
- **pwa/** PWA instalable con offline + push (demo VAPID)
- **desktop/** Electron (panel escritorio) cargando sandra-app
- **packages/shared/** Componentes y utilidades comunes (TS)

## Puesta en marcha (DEV)
```bash
npm i
cp .env.example .env
cp apps/web/.env.example apps/web/.env.local
cp apps/sandra-app/.env.example apps/sandra-app/.env.local
cp apps/pwa/.env.example apps/pwa/.env.local
npm run dev
```

- Backend: http://localhost:4000
- Web:     http://localhost:3000
- Sandra:  http://localhost:3001
- PWA:     http://localhost:3002

## Producción
- Backend: `npm run start -w @gv/backend` (configurar `.env`)
- Web/Sandra/PWA: construir (`npm run build`) y servir con `next start` o desplegar a Vercel/SSR.

## Dominios / CORS / CSP
- Permitidos: `https://app.guestsvalencia.es`, `https://sandra.guestsvalencia.es`
- CSP ya configurado para permitir `frame-src https://app.heygen.com` y conexiones WS al backend.

## Notas Push (PWA)
- Genera VAPID y setéalos en `.env` del backend para `/push/test`.
