import 'dotenv/config'
import fetch from 'node-fetch'

const API = process.env.API_URL || 'http://localhost:4000'
const AUTO = process.env.AUTO_EXECUTE === 'true'

async function run(){
  if (!AUTO){ console.log('[agent] AUTO_EXECUTE=false (solo lectura)'); return }
  // 1) Envía posts sociales programados (simulado ya hecho por backend worker)
  // 2) Revisa outreach y dispara "send" de los que están en cola sin fecha
  const token = process.env.ADMIN_TOKEN || ''
  const h = { Authorization: 'Bearer ' + token, 'Content-Type':'application/json' }
  const q = await fetch(API + '/outreach', { headers: h }).then(r=>r.json()) as any[]
  for (const item of q.filter(x=>x.status!=='sent')){
    await fetch(API + '/outreach/' + item.id + '/send', { method:'POST', headers: h })
    console.log('[agent] outreach sent', item.id)
  }
  // 3) Recalcula KPIs (placeholder -> podríamos pedir summary y cachear)
  console.log('[agent] cycle done')
}

run().catch(e=>{ console.error(e) })
