import 'dotenv/config'
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
const ENC = (process.env.BACKUP_KEY||'').padEnd(32,'0').slice(0,32)
const inFile = process.argv[2]
if (!inFile) throw new Error('Usage: node ops/backup/restore.js <backup.db.enc>')
const blob = fs.readFileSync(inFile)
const iv = blob.subarray(0,12); const tag = blob.subarray(12,28); const ct = blob.subarray(28)
const decipher = crypto.createDecipheriv('aes-256-gcm', Buffer.from(ENC), iv)
decipher.setAuthTag(tag)
const db = Buffer.concat([decipher.update(ct), decipher.final()])
fs.writeFileSync('apps/backend/data/sandra.db', db)
console.log('DB restored')
