# Uso con menores (orientación no médica)
- Contenidos y actividades con **tiempos de pantalla máximos** por centro.
- Requiere **consentimiento informado** del tutor/centro (tabla `consents`).
- No sustituye servicios médicos, psicológicos o educativos profesionales.
- Para hospitales: coordinación con equipo clínico y protocolos del hospital.
