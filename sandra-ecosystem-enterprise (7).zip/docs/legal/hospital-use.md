# Uso en hospitales infantiles
- Finalidad: entretenimiento y apoyo lúdico **no médico**.
- En coordinación con psico-oncología/psicología hospitalaria.
- Sin captación de biometría ni datos sensibles sin consentimiento explícito.
- Políticas de privacidad y RGPD reforzadas.
