'use client'
import { useEffect, useState } from 'react'
export default function Guests(){
  const [rows,setRows]=useState<any[]>([])
  const [name,setName]=useState(''); const [email,setEmail]=useState(''); const [phone,setPhone]=useState(''); const [tags,setTags]=useState('')
  const token = typeof window!=='undefined'?localStorage.getItem('token'):''
  async function load(){ const r=await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/guests',{headers:{Authorization:'Bearer '+token}}); setRows(await r.json()) }
  async function add(){ await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/guests',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({name,email,phone,tags:tags.split(',').map(s=>s.trim())})}); setName('');setEmail('');setPhone('');setTags(''); load() }
  useEffect(()=>{ load() },[])
  return <div className="max-w-4xl mx-auto p-8 space-y-4">
    <h2 className="text-2xl font-bold">Huéspedes</h2>
    <div className="grid grid-cols-4 gap-2">
      <input placeholder="Nombre" className="px-2 py-2 bg-white/10 rounded" value={name} onChange={e=>setName(e.target.value)} />
      <input placeholder="Email" className="px-2 py-2 bg-white/10 rounded" value={email} onChange={e=>setEmail(e.target.value)} />
      <input placeholder="Teléfono" className="px-2 py-2 bg-white/10 rounded" value={phone} onChange={e=>setPhone(e.target.value)} />
      <input placeholder="tags (vip,local…)" className="px-2 py-2 bg-white/10 rounded" value={tags} onChange={e=>setTags(e.target.value)} />
      <button onClick={add} className="col-span-4 px-4 py-2 bg-white text-black rounded">Añadir</button>
    </div>
    <table className="w-full text-sm"><thead><tr><th className="text-left">Nombre</th><th>Email</th><th>Tel</th><th>Tags</th></tr></thead><tbody>
      {rows.map(r=><tr key={r.id}><td>{r.name}</td><td>{r.email}</td><td>{r.phone}</td><td>{r.tags}</td></tr>)}
    </tbody></table>
  </div>
}
