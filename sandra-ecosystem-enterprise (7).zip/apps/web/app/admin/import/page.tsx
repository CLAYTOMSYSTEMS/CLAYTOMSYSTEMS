'use client'
import { useState } from 'react'
export default function ImportCSV(){
  const token=typeof window!=='undefined'?localStorage.getItem('token'):''
  const [file,setFile]=useState<File|null>(null)
  const [report,setReport]=useState<any>(null)
  async function upload(){
    if(!file) return
    const text = await file.text()
    const base64 = btoa(text)
    const mapping = { email:'email', name:'name', phone:'phone', property:'property', date:'date', nights:'nights' }
    const r = await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/import/csv',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({base64, mapping})})
    setReport(await r.json())
  }
  return <div className="max-w-xl mx-auto p-8 space-y-4">
    <h2 className="text-2xl font-bold">Importar CSV (4 años)</h2>
    <input type="file" accept=".csv" onChange={e=>setFile(e.target.files?.[0]||null)} />
    <button onClick={upload} className="px-4 py-2 bg-white text-black rounded">Importar</button>
    {report && <pre className="text-xs opacity-80">{JSON.stringify(report,null,2)}</pre>}
  </div>
}
