
'use client'
import { useEffect, useState } from 'react'
export default function KPIs(){
  const token=typeof window!=='undefined'?localStorage.getItem('token'):''
  const [data,setData]=useState<any>(null)
  useEffect(()=>{ fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/analytics/summary',{headers:{Authorization:'Bearer '+token}}).then(r=>r.json()).then(setData) },[])
  if (!data) return <div className="p-8">Cargando…</div>
  // Calcular ADR/RevPAR (demo): precio medio y RevPAR simplificado (reservas/7 * precio medio)
  const days = Math.max(1, data.reservations_last7?.length||7)
  const totalRes = data.totals.reservations||0
  const avgDailyBookings = totalRes / 30
  return <div className="max-w-3xl mx-auto p-8 space-y-4">
    <h2 className="text-2xl font-bold">KPIs hoteleros</h2>
    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
      <div className="glass p-4 rounded-xl"><div className="text-xs opacity-70">Reservas (30d aprox)</div><div className="text-3xl font-bold">{Math.round(avgDailyBookings*30)}</div></div>
      <div className="glass p-4 rounded-xl"><div className="text-xs opacity-70">Ocupación (demo)</div><div className="text-3xl font-bold">{Math.min(95, Math.round(avgDailyBookings*5))}%</div></div>
      <div className="glass p-4 rounded-xl"><div className="text-xs opacity-70">RevPAR (demo)</div><div className="text-3xl font-bold">{Math.round((data.totals.tokens||0)*2)}€</div></div>
    </div>
    <p className="text-xs opacity-60">* KPIs de ejemplo; cuando quieras los conectamos a tus tarifas, inventario y ocupación real.</p>
  </div>
}
