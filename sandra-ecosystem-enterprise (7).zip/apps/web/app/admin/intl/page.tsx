
'use client'
import { useEffect, useState } from 'react'
export default function Intl(){
  const token=typeof window!=='undefined'?localStorage.getItem('token'):''
  const [rows,setRows]=useState<any[]>([])
  useEffect(()=>{ fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/intl/segments',{headers:{Authorization:'Bearer '+token}}).then(r=>r.json()).then(setRows) },[])
  return <div className="max-w-xl mx-auto p-8 space-y-4">
    <h2 className="text-2xl font-bold">Segmentación Internacional</h2>
    <ul className="space-y-2">{rows.map(x=>(<li key={x.country} className="glass p-3 rounded-xl flex justify-between"><span>{x.country.toUpperCase()}</span><span>{x.count}</span></li>))}</ul>
    <p className="text-xs opacity-60">Tip: crea campañas en /admin/campanas filtrando por país/idioma.</p>
  </div>
}
