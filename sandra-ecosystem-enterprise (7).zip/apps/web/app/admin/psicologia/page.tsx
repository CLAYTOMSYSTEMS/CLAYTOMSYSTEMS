
'use client'
export default function Psicologia(){
  const tips = [
    'Respira 4-4-6 durante 1 minuto.',
    'Pon nombre a lo que sientes, sin juzgar.',
    'Prueba grounding 5‑4‑3‑2‑1 (ver, tocar, oír, oler, saborear).',
    'Recuerda: esto pasará. Pide ayuda si lo necesitas.'
  ]
  return <div className="max-w-3xl mx-auto p-8 space-y-4">
    <h2 className="text-2xl font-bold">Psicología · Apoyo emocional</h2>
    <div className="glass p-4 rounded-xl">
      <p className="text-white/80">Sandra ofrece apoyo emocional general (no médico). En crisis o riesgo real, contacta **112** inmediatamente.</p>
      <ul className="mt-3 list-disc ml-6 text-white/80 space-y-2">{tips.map(t=><li key={t}>{t}</li>)}</ul>
      <a className="inline-block mt-3 px-4 py-2 bg-white text-black rounded" href="/admin/sos">Botón SOS</a>
    </div>
  </div>
}
