import { google } from 'googleapis'
import axios from 'axios'
export async function uploadYouTube(opts:{title:string, description?:string, privacyStatus?:'public'|'unlisted'|'private', fileUrl:string}){
  const oauth2Client = new google.auth.OAuth2(process.env.GOOGLE_CLIENT_ID, process.env.GOOGLE_CLIENT_SECRET)
  oauth2Client.setCredentials({ refresh_token: process.env.GOOGLE_REFRESH_TOKEN })
  const youtube = google.youtube({ version: 'v3', auth: oauth2Client })
  const resp = await axios.get(opts.fileUrl, { responseType: 'stream' })
  const res = await youtube.videos.insert({
    part: ['snippet','status'],
    requestBody: {
      snippet: { title: opts.title, description: opts.description||'' },
      status: { privacyStatus: opts.privacyStatus||'unlisted' }
    },
    media: { body: resp.data as any }
  } as any)
  return res.data
}
