import express from 'express'
import { GuarderiasModels, MayoresModels, DocendoModels, HospitalsModels, MallsModels, LibrariesModels, MunicipModels, CruisesParksModels, estimateROI, Pricing } from './models.js'
export const router = express.Router()

router.get('/catalog', (_req,res)=>{
  res.json({ guarderias: GuarderiasModels, mayores: MayoresModels, docendo: DocendoModels, hospitales: HospitalsModels, centrosComerciales: MallsModels, bibliotecas: LibrariesModels, ayuntamientos: MunicipModels, crucerosParques: CruisesParksModels, pricing: Pricing })
})

router.post('/roi', (req,res)=>{
  const { oneoff, subscription, activeCenters, months, convRate, extraRevenuePerCenter } = req.body||{}
  const r = estimateROI({
    oneoff: Number(oneoff||Pricing.oneoff.min),
    subscription: Number(subscription||Pricing.subscription.min),
    activeCenters: Number(activeCenters||10),
    months: Number(months||12),
    convRate: Number(convRate||0.6),
    extraRevenuePerCenter: Number(extraRevenuePerCenter||300)
  })
  res.json(r)
})

router.post('/lead', (req,res)=>{
  const { name, email, phone, sector, note } = req.body||{}
  // store as lead with sector tag
  req.app.locals.db.prepare('INSERT INTO leads (owner_id, source, property, status, last_contact) VALUES (NULL, ?, ?, ?, CURRENT_TIMESTAMP)').run('sector:'+String(sector||'generic'), String(note||name||''), 'new')
  res.json({ ok:true })
})
