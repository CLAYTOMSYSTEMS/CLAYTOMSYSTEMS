export function sectorTemplate(sector:string, lang:'es'|'en'='es', vars:any={}){
  const name = vars.name || 'equipo directivo'
  const offer = vars.offer || 'aumento de reservas y reducción de comisiones'
  const base = lang==='es'
    ? `Hola ${name},

Soy Sandra (IA) de Claytom System. Ayudo a ${sector} a lograr ${offer} con un asistente conversacional + avatar y un CRM listo.
¿Te muestro una demo de 10 minutos?`
    : `Hi ${name},

I’m Sandra (AI) from Claytom System. We help ${sector} achieve ${offer} with a conversational avatar and an out‑of‑the‑box CRM.
Would you like a 10‑minute demo?`
  return `🚀 ${base}

✅ Ahorro comisiones
✅ Reservas directas
✅ Automatización 24/7

— Sandra`
}
