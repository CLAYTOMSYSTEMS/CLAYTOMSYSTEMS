export function buildICS({summary='Claytom System Demo', startISO, durationMin=30, url='https://claytom.system'}:{summary?:string, startISO:string, durationMin?:number, url?:string}){
  const dt = (s:string)=> s.replace(/[-:]/g,'').replace(/\.\d{3}Z$/,'Z')
  const start = new Date(startISO); const end = new Date(start.getTime()+durationMin*60000)
  return `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Claytom System//Sandra IA 7.0//ES
BEGIN:VEVENT
DTSTAMP:${dt(new Date().toISOString())}
DTSTART:${dt(start.toISOString())}
DTEND:${dt(end.toISOString())}
SUMMARY:${summary}
DESCRIPTION:Demo automatizada con Sandra. ${url}
END:VEVENT
END:VCALENDAR`
}
