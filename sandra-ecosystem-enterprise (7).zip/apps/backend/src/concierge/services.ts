import { Database } from 'better-sqlite3'

export function ensureTables(db: Database){
  db.exec(`
    CREATE TABLE IF NOT EXISTS providers (id INTEGER PRIMARY KEY, type TEXT, name TEXT, phone TEXT, email TEXT, price REAL, city TEXT, notes TEXT);
    CREATE TABLE IF NOT EXISTS service_bookings (id INTEGER PRIMARY KEY, provider_id INTEGER, guest_name TEXT, guest_phone TEXT, date TEXT, status TEXT DEFAULT 'pending', notes TEXT);
  `)
}
