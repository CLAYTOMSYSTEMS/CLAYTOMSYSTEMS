import fetch from 'node-fetch'

type Leg = { mode: 'flight'|'train'|'metro'|'bus'|'walk'|'taxi'|'car', from: string, to: string, etaMin?: number, cost?: number, notes?: string, link?: string }
export type Itinerary = { guest: string, daysAhead: number, legs: Leg[], summary: string }

function mapsLink(origin:string, dest:string){
  return `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(origin)}&destination=${encodeURIComponent(dest)}&travelmode=transit`
}

export async function buildItinerary(params:{guest:string, origin:string, destination:string, arrivalISO:string}) : Promise<Itinerary> {
  const { guest, origin, destination } = params
  const legs: Leg[] = []
  // High-level template; API integrations (Google/EMT/MetroValencia) plug-in later
  legs.push({ mode:'flight', from: origin, to: 'VLC (Valencia Airport)', notes:'Llegada estimada según tu reserva' })
  legs.push({ mode:'metro', from: 'VLC (Aeroport)', to: 'Xátiva (L3/L5)', etaMin: 22, cost: 4.8, notes:'Frecuencia ~7–10min', link: mapsLink('Valencia Airport','Xátiva Metro, Valencia') })
  legs.push({ mode:'walk', from: 'Xátiva', to: destination, etaMin: 10, notes:'Paseo urbano, evita atascos' , link: mapsLink('Xátiva, Valencia', destination)})
  const cost = (legs.map(l=>l.cost||0).reduce((a,b)=>a+b,0)).toFixed(2)
  const summary = `Hola ${guest}, aquí tienes tu itinerario optimizado desde ${origin} hasta ${destination}. Coste aprox transporte público: €${cost}. Abre los links para guiarte paso a paso.`
  return { guest, daysAhead: 3, legs, summary }
}

export async function sendItinerary(send:{channel:'email'|'whatsapp', to:string}, it: Itinerary){
  // Plug real senders: SendGrid/SMTP y WhatsApp Cloud (ya integrado)
  const lines = [it.summary, '', ...it.legs.map(l=>`• ${l.mode.toUpperCase()}: ${l.from} → ${l.to} ${l.etaMin?`(${l.etaMin} min)`:''} ${l.cost?`€${l.cost}`:''} ${l.link?`→ ${l.link}`:''}`)]
  return { ok:true, channel: send.channel, to: send.to, text: lines.join('\n') }
}
