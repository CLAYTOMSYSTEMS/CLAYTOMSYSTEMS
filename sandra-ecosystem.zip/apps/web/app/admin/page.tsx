'use client'
import { useState } from 'react'
export default function Admin(){
  const [email,setEmail]=useState('admin@guestsvalencia.es')
  const [password,setPassword]=useState('admin')
  const [token,setToken]=useState('')
  async function login(){
    const res = await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL + '/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password})})
    const data = await res.json()
    if (data?.token){ setToken(data.token); localStorage.setItem('token', data.token) }
  }
  return <div className="max-w-xl mx-auto p-8 space-y-4">
    <h2 className="text-3xl font-bold">Panel Admin</h2>
    {!token ? (<div className="space-y-3">
      <input className="w-full px-3 py-2 rounded bg-white/10" value={email} onChange={e=>setEmail(e.target.value)} placeholder="email" />
      <input className="w-full px-3 py-2 rounded bg-white/10" value={password} onChange={e=>setPassword(e.target.value)} type="password" placeholder="password" />
      <button onClick={login} className="px-4 py-2 rounded bg-white text-black font-semibold">Entrar</button>
    </div>) : (<div className="space-y-3">
      <p className="text-white/80">Token OK. Aquí iría la gestión de conversaciones, métricas, etc.</p>
    </div>)}
  </div>
}
