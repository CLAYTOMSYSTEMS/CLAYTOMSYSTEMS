import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import { createServer } from 'http'
import { WebSocketServer, WebSocket } from 'ws'
import Database from 'better-sqlite3'
import jwt from 'jsonwebtoken'
import bcrypt from 'bcryptjs'
import webpush from 'web-push'

const app = express()
app.use(express.json({ limit: '2mb' }))

// --- CORS allowlist ---
const allowed = (process.env.ALLOWED_ORIGINS || '').split(',').map(s=>s.trim()).filter(Boolean)
app.use(cors({
  origin: (origin, cb) => {
    if (!origin) return cb(null, true)
    if (allowed.includes(origin)) return cb(null, true)
    return cb(new Error('CORS blocked for origin: '+origin))
  },
  credentials: true
}))

// --- Helmet + CSP ---
const csp = {
  useDefaults: true,
  directives: {
    "default-src": ["'self'"],
    "script-src": ["'self'", "'unsafe-inline'"],
    "style-src": ["'self'", "'unsafe-inline'"],
    "img-src": ["'self'", "data:", "https:"],
    "connect-src": ["'self'", "https://api.openai.com", ...(allowed.length?allowed:[])],
    "frame-src": ["'self'", "https://app.heygen.com"],
    "frame-ancestors": [...(allowed.length?allowed:[]),"https://app.guestsvalencia.es","https://sandra.guestsvalencia.es"]
  }
}
app.use(helmet({ contentSecurityPolicy: csp as any }))

// --- ENV ---
const PORT = Number(process.env.PORT) || 4000
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || ''
const OPENAI_REALTIME_MODEL = process.env.OPENAI_REALTIME_MODEL || 'gpt-4o-realtime-preview-2024-12-17'
const HEYGEN_EMBED_URL = process.env.HEYGEN_EMBED_URL || 'https://app.heygen.com/guest-valencia-sandra'
const JWT_SECRET = process.env.JWT_SECRET || 'change_me_for_prod'

// --- DB ---
const db = new Database('data/sandra.db')
db.exec(`
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, email TEXT UNIQUE, password_hash TEXT, role TEXT DEFAULT 'admin');
CREATE TABLE IF NOT EXISTS conversations (id INTEGER PRIMARY KEY, title TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY, conversation_id INTEGER, role TEXT, content TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS push_subs (id INTEGER PRIMARY KEY, data TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`)
const upsertAdmin = db.prepare('INSERT OR IGNORE INTO users (email, password_hash, role) VALUES (?, ?, ?)')
const adminPass = bcrypt.hashSync(process.env.ADMIN_PASSWORD || 'admin', 8)
upsertAdmin.run(process.env.ADMIN_EMAIL || 'admin@guestsvalencia.es', adminPass, 'admin')

// --- Auth ---
function auth(req, res, next){
  const hdr = req.headers.authorization || ''
  const token = hdr.startsWith('Bearer ') ? hdr.slice(7) : null
  if (!token) return res.status(401).json({ error: 'No token' })
  try{
    const payload = jwt.verify(token, JWT_SECRET) as any
    ;(req as any).user = payload
    next()
  }catch(e){ return res.status(401).json({ error: 'Invalid token' }) }
}

app.post('/auth/login', (req, res) => {
  const { email, password } = req.body || {}
  if (!email || !password) return res.status(400).json({ error: 'Missing credentials' })
  const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email)
  if (!row) return res.status(401).json({ error: 'User not found' })
  const ok = bcrypt.compareSync(password, row.password_hash)
  if (!ok) return res.status(401).json({ error: 'Bad password' })
  const token = jwt.sign({ sub: row.id, email: row.email, role: row.role }, JWT_SECRET, { expiresIn: '7d' })
  res.json({ token })
})

// --- Conversations ---
app.get('/conversations', auth, (_req, res)=>{
  const rows = db.prepare('SELECT * FROM conversations ORDER BY created_at DESC').all()
  res.json(rows)
})
app.post('/conversations', auth, (req, res)=>{
  const { title } = req.body || {}
  const info = db.prepare('INSERT INTO conversations (title) VALUES (?)').run(title || 'Nueva conversación')
  res.json({ id: info.lastInsertRowid, title: title || 'Nueva conversación' })
})
app.get('/conversations/:id/messages', auth, (req, res)=>{
  const rows = db.prepare('SELECT * FROM messages WHERE conversation_id=? ORDER BY id').all(Number(req.params.id))
  res.json(rows)
})
app.post('/messages', auth, (req, res)=>{
  const { conversation_id, role, content } = req.body || {}
  if (!conversation_id || !role) return res.status(400).json({ error:'Missing fields' })
  const info = db.prepare('INSERT INTO messages (conversation_id, role, content) VALUES (?, ?, ?)').run(conversation_id, role, content || '')
  res.json({ id: info.lastInsertRowid })
})

// --- Push (optional) ---
if (process.env.VAPID_PUBLIC && process.env.VAPID_PRIVATE){
  webpush.setVapidDetails(process.env.VAPID_SUBJECT || 'mailto:admin@guestsvalencia.es', process.env.VAPID_PUBLIC!, process.env.VAPID_PRIVATE!)
}
app.post('/push/subscribe', (req, res)=>{
  const data = JSON.stringify(req.body || {})
  db.prepare('INSERT INTO push_subs (data) VALUES (?)').run(data)
  res.json({ ok: true })
})
app.post('/push/test', async (_req, res)=>{
  if (!process.env.VAPID_PUBLIC || !process.env.VAPID_PRIVATE) return res.status(400).json({ error:'No VAPID' })
  const subs = db.prepare('SELECT * FROM push_subs').all()
  for (const s of subs){
    try { await webpush.sendNotification(JSON.parse(s.data), JSON.stringify({ title:'Sandra IA', body:'Hola desde Guests Valencia' })) } catch {}
  }
  res.json({ sent: subs.length })
})

// --- HeyGen endpoints ---
app.post('/heygen/session/new', (_req, res)=> res.json({ url: HEYGEN_EMBED_URL }))
app.post('/heygen/session/close', (_req, res)=> res.json({ ok: true }))

// --- Health ---
app.get('/healthz', (_req, res)=> res.json({ ok: true }))

// --- HTTP server + WS proxy ---
const server = createServer(app)
const wss = new WebSocketServer({ server, path: '/openai/session' })

wss.on('connection', (client, req) => {
  if (!OPENAI_API_KEY){ client.close(1011, 'Server missing OPENAI_API_KEY'); return }
  const url = `wss://api.openai.com/v1/realtime?model=${encodeURIComponent(OPENAI_REALTIME_MODEL)}`
  const upstream = new WebSocket(url, { headers: { 'Authorization': `Bearer ${OPENAI_API_KEY}`, 'OpenAI-Beta': 'realtime=v1' } })

  upstream.on('open', ()=>{})
  upstream.on('message', (data)=>{ try{ client.readyState===WebSocket.OPEN && client.send(data) }catch{} })
  upstream.on('close', (c,r)=>{ try{ client.close(c, r.toString()) }catch{} })
  upstream.on('error', ()=>{ try{ client.close(1011, 'Upstream error') }catch{} })

  client.on('message', (data)=>{ try{ upstream.readyState===WebSocket.OPEN && upstream.send(data) }catch{} })
  client.on('close', ()=>{ try{ upstream.close() }catch{} })
  client.on('error', ()=>{ try{ upstream.close() }catch{} })
})

server.listen(PORT, ()=> console.log(`[Backend] http://localhost:${PORT}`))
