
const { execSync } = require('child_process'); const path = require('path'); 
const plan = { mega_production: { rapid_creation_specialists: 35000, quality_control_managers: 20000, delivery_automation: 35000, performance_optimization: 10000 } };
const out = process.argv.includes('--out') ? process.argv[process.argv.indexOf('--out')+1] : './out';
function gen(role, count){ const cmd = `node ${path.resolve(__dirname,'../../reference_generate_shards.js')} --stream mega_production --role ${role} --count ${count} --out ${out}`; console.log('[GEN]', cmd); execSync(cmd, { stdio: 'inherit' }); }
const fs = require('fs'); const ref = path.resolve(__dirname, '../../reference_generate_shards.js');
if (!fs.existsSync(ref)){ fs.writeFileSync(ref, `require('fs').writeFileSync('WARNING.txt','Mount the 700k package to use the generator.');`); }
for (const [role,count] of Object.entries(plan.mega_production)){ gen(role, count); } console.log('[ADD-ON DONE] Generated 100k extra agents');
