# Board Addendum — Round to 1,000,000 Capacity
Date: 2025-09-05 (Europe/Madrid)
Mandate: Provision +100,000 agents to present 1,000,000/month capability.
