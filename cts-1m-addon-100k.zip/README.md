# 1M Capacity Add‑On (100k)
Make capacity presentations round at 1,000,000/month. Includes Cron and generator.
