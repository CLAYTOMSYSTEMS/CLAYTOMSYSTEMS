
# CLAYTOMSYSTEMS — Despliegue de 30+ subdominios con Kubernetes Ingress + TLS

Este paquete habilita:
- 30+ subdominios *.claytomsystems.com con enrutado por servicio/sector
- Sticky sessions (NGINX Ingress) para llamadas/voz
- Métricas por subdominio/sector vía `metrics-service`
- Auto-activación de chatbots por Host vía `sector-router` + NATS
- Certificados TLS (dos opciones): HTTP-01 multi-host SAN **o** wildcard DNS-01

## Pasos rápidos

```bash
kubectl create ns clay || true

# Opción A: Certificados con HTTP-01 y lista de hosts (rápido)
kubectl apply -n clay -f k8s/cert-manager/issuer-http01.yaml
kubectl apply -n clay -f k8s/cert-manager/certificate-multihost.yaml

# Opción B: Wildcard con DNS-01 (Cloudflare) — edita las credenciales secretas
kubectl apply -n clay -f k8s/cert-manager/issuer-dns01-cloudflare.yaml
kubectl apply -n clay -f k8s/cert-manager/certificate-wildcard.yaml

# Ingress Controller (si no lo tienes)
kubectl apply -n ingress-nginx -f k8s/ingress/nginx-ingress-controller.yaml

# Servicios base
kubectl apply -n clay -f k8s/profiles-service.yaml
kubectl apply -n clay -f k8s/metrics-service.yaml
kubectl apply -n clay -f k8s/api-gateway.yaml
kubectl apply -n clay -f k8s/orchestrator.yaml

# Router sectorial (activa bots por Host)
kubectl apply -n clay -f k8s/sector-router.yaml

# Ingress con 30+ subdominios
kubectl apply -n clay -f k8s/ingress/subdomains.yaml

# Cargar chatbots (710 base) + generar hasta 1,110
kubectl create configmap chatbots --from-file=chatbots.json=chatbots-710.json -n clay --dry-run=client -o yaml | kubectl apply -f -
node scripts/generate-bots.ts registry/prototypes registry/hosts.json > chatbots-1110.json
kubectl create configmap chatbots-1110 --from-file=chatbots.json=chatbots-1110.json -n clay --dry-run=client -o yaml | kubectl apply -f -
kubectl set env deploy/profiles CHATBOTS_CONFIGMAP=chatbots-1110 -n clay

# Verifica
kubectl get certificate -n clay
kubectl get ingress -n clay
```

## Sticky sessions

Activadas para `voice`, `calls`, `chat` con anotaciones de NGINX Ingress:
```
nginx.ingress.kubernetes.io/affinity: cookie
nginx.ingress.kubernetes.io/session-cookie-name: route
nginx.ingress.kubernetes.io/session-cookie-hash: sha1
```
