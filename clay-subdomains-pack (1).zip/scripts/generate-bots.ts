
#!/usr/bin/env -S node --no-warnings
import fs from "fs";
import path from "path";
const protoDir = process.argv[2] || "registry/prototypes";
const hostsPath = process.argv[3] || "registry/hosts.json";
const prototypes = JSON.parse(fs.readFileSync(path.join(protoDir, "prototypes.json"), "utf8"));
const hosts = JSON.parse(fs.readFileSync(hostsPath, "utf8"));

function slug(s){ return s.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,""); }
function makeBot(sector, role, idx, proto){
  const id = `${slug(sector)}-${slug(role)}-${idx.toString().padStart(3,"0")}`;
  return {
    id, sector, role, voice: proto.voice, skills: proto.skills,
    promptRef: `prompts/${role}.txt`,
    routing: { natsSubject: `bot.${sector}.${role}`, concurrency: 1 },
    meta: { generated: true }
  };
}
const out = [];
const roles = Object.keys(prototypes);
for (const [host, info] of Object.entries(hosts)){
  const sector = info.sector;
  let idx = 1;
  for (const role of roles){
    const proto = prototypes[role];
    const count = Math.ceil(info.target / roles.length);
    for (let i=0;i<count;i++) out.push(makeBot(sector, role, idx++, proto));
  }
}
while (out.length < 1110){
  const proto = prototypes["ops-manager"];
  out.push(makeBot("generic","ops_manager", out.length+1, proto));
}
process.stdout.write(JSON.stringify(out, null, 2));
