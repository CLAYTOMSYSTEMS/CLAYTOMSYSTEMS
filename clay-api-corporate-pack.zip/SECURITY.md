# Security Hardening
- Rotate `JWT_SECRET`; store in K8s Secret.
- Rate-limit & WAF on ingress.
- SIEM logging; PII scrubbing.
- mTLS inside cluster (optional).
