import express from 'express'
import { connect, StringCodec, NatsConnection, Subscription } from 'nats'

const PORT = process.env.PORT || 8080
const NATS_URL = process.env.NATS_URL || 'nats://nats:4222'

const sc = StringCodec()
let nc: NatsConnection
let subs: Subscription[] = []

const app = express()
app.get('/health', (_req,res)=>res.json({ok:true, service:'orchestrator', time: Date.now()}))

const handlers: Record<string,(payload:any)=>Promise<void>> = {
  'activate': async (p) => {
    nc.publish('bot.activate', sc.encode(JSON.stringify({ ...p, ts: Date.now() })))
    nc.publish('ceo.events', sc.encode(JSON.stringify({ type:'activate.ack', ok:true, details:p })))
  },
  'scale': async (p) => {
    nc.publish('bot.scale', sc.encode(JSON.stringify({ ...p, ts: Date.now() })))
    nc.publish('ceo.events', sc.encode(JSON.stringify({ type:'scale.ack', ok:true, details:p })))
  },
  'train': async (p) => {
    nc.publish('bot.train', sc.encode(JSON.stringify({ ...p, ts: Date.now() })))
    nc.publish('ceo.events', sc.encode(JSON.stringify({ type:'train.ack', ok:true, details:p })))
  }
}

async function main(){
  nc = await connect({ servers: NATS_URL })
  console.log('[orchestrator] NATS connected', NATS_URL)
  const sub = nc.subscribe('ceo.command')
  subs.push(sub)
  ;(async () => {
    for await (const m of sub){
      try{
        const msg = JSON.parse(sc.decode(m.data))
        const { cmd, ...payload } = msg
        const h = handlers[cmd]
        if(h){ await h(payload) }
        else { nc.publish('ceo.events', sc.encode(JSON.stringify({ type:'unknown.cmd', cmd }))) }
      }catch(e){
        nc.publish('ceo.events', sc.encode(JSON.stringify({ type:'error', error:(e as Error).message })))
      }
    }
  })();

  app.listen(PORT, ()=> console.log(`[orchestrator] listening on :${PORT}`))
}

main().catch(err=>{ console.error('boot failed', err); process.exit(1) })
