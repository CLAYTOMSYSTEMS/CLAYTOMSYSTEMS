import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import morgan from 'morgan'
import rateLimit from 'express-rate-limit'
import jwt from 'jsonwebtoken'
import fetch from 'node-fetch'
import { connect, NatsConnection, StringCodec } from 'nats'
import { WebSocketServer } from 'ws'
import http from 'http'

const PORT = process.env.PORT || 8080
const JWT_SECRET = process.env.JWT_SECRET || 'change-me'
const PROFILES_URL = process.env.PROFILES_URL || 'http://profiles:8080'
const NATS_URL = process.env.NATS_URL || 'nats://nats:4222'

const app = express()
app.use(helmet())
app.use(cors())
app.use(express.json({ limit: '1mb' }))
app.use(morgan('tiny'))
app.use(rateLimit({ windowMs: 60_000, max: 600 }))

function auth(req, res, next){
  const h = req.headers['authorization'] || ''
  const token = (h.startsWith('Bearer ') ? h.slice(7) : null)
  if(!token){ return res.status(401).json({error:'missing bearer token'}) }
  try{
    req.user = jwt.verify(token, JWT_SECRET)
    next()
  }catch(e){
    return res.status(403).json({error:'invalid token'})
  }
}

let nc: NatsConnection | null = null
const sc = StringCodec()
async function ensureNats(){
  if(!nc){ nc = await connect({ servers: NATS_URL }); console.log('[api-gateway] NATS connected', NATS_URL) }
  return nc
}

app.get('/health', (_req, res)=> res.json({ ok:true, service:'api-gateway', time: Date.now() }))

app.get('/chatbots', auth, async (_req, res) => {
  try{
    const r = await fetch(`${PROFILES_URL}/chatbots`)
    const data = await r.json()
    res.json(data)
  }catch(e){
    res.status(502).json({ error:'profiles-service unreachable', detail: (e as Error).message })
  }
})

app.post('/commands', auth, async (req, res) => {
  const { cmd, host, sector, count, payload } = req.body || {}
  if(!cmd){ return res.status(400).json({error:'cmd required'}) }
  try{
    const n = await ensureNats()
    n.publish('ceo.command', sc.encode(JSON.stringify({ cmd, host, sector, count, payload, ts: Date.now() })))
    res.status(202).json({ accepted: true })
  }catch(e){
    res.status(500).json({ error:'nats error', detail: (e as Error).message })
  }
})

const server = http.createServer(app)
const wss = new WebSocketServer({ server, path: '/ws' })
wss.on('connection', async (ws) => {
  try{
    const n = await ensureNats()
    const sub = n.subscribe('ceo.events')
    ;(async () => { for await (const m of sub){ ws.send(sc.decode(m.data)) } })();
    ws.on('message', (msg) => {
      try{
        const j = JSON.parse(msg.toString())
        n.publish('ceo.command', sc.encode(JSON.stringify({ ...j, ts: Date.now() })))
      }catch{ /* ignore */ }
    })
  }catch(e){
    ws.send(JSON.stringify({ error:'nats connection failed', detail: (e as Error).message }))
  }
})

server.listen(PORT, ()=> console.log(`[api-gateway] listening on :${PORT}`))
