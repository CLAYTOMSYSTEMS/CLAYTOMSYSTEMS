import express from 'express'
import fs from 'fs'
import path from 'path'

const PORT = process.env.PORT || 8080
const DATA_PATH = process.env.CHATBOTS_PATH || '/data/chatbots.json'
const PROMPTS_DIR = process.env.PROMPTS_DIR || '/prompts'

const app = express()
app.get('/health', (_req,res)=>res.json({ok:true, service:'profiles', time: Date.now()}))

function loadJson(p:string){ return JSON.parse(fs.readFileSync(p, 'utf8')) }

app.get('/chatbots', (req,res)=>{
  try{
    let bots = loadJson(DATA_PATH)
    const { group, q, limit } = req.query as any
    if(group){ bots = bots.filter((b:any)=>b.group===group) }
    if(q){
      const s = (q as string).toLowerCase()
      bots = bots.filter((b:any)=> (b.id+b.title+b.skills).toLowerCase().includes(s) )
    }
    const n = limit? parseInt(String(limit),10): bots.length
    res.json(bots.slice(0, n))
  }catch(e){
    res.status(500).json({ error:'cannot load chatbots', detail: (e as Error).message })
  }
})

app.get('/prompts/:id', (req,res)=>{
  const id = req.params.id
  const p = path.join(PROMPTS_DIR, `${id}.txt`)
  if(!fs.existsSync(p)) return res.status(404).send('not found')
  res.type('text/plain').send(fs.readFileSync(p, 'utf8'))
})

app.listen(PORT, ()=> console.log(`[profiles] listening on :${PORT}`, {DATA_PATH, PROMPTS_DIR}))
