# Clay Corporate API Pack (CIO Delivery)

**3 core services** (TypeScript/Node.js) + **K8s manifests** + **400 API expert chatbots**.

## Services
- `api-gateway` — JWT-protected REST + WebSocket; proxies to profiles; publishes CEO commands to NATS.
- `orchestrator` — Listens `ceo.command` → emits `bot.activate|bot.scale|bot.train` and acks to `ceo.events`.
- `profiles` — Serves `chatbots.json` and prompt files; query by `?group=&q=&limit=`.

## Quickstart (Kubernetes)
```bash
kubectl apply -f k8s/00-namespace.yaml
kubectl apply -f k8s/nats.yaml -f k8s/secrets.yaml
kubectl apply -f k8s/configmap.chatbots.yaml -f k8s/configmap.prompts.yaml
kubectl apply -f k8s/profiles.yaml -f k8s/orchestrator.yaml -f k8s/api-gateway.yaml
kubectl apply -f k8s/ingress-api.yaml
```
Set `JWT_SECRET` in `k8s/secrets.yaml`.

## Local dev
Each service:
```bash
cd services/api-gateway && npm i && npm run dev
```

## Extend
- Add more roles in `config/prompts/` and regenerate the JSON.
