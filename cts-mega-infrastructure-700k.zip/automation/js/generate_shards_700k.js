
const fs = require('fs'), path = require('path');
const args = require('minimist')(process.argv.slice(2));
const stream = args.stream || 'mega_production';
const role = args.role || 'rapid_creation_specialists';
const count = Number(args.count || 1000);
const outdir = path.resolve(args.out || './out');
if (!fs.existsSync(outdir)) fs.mkdirSync(outdir, { recursive: true });
function* seq(n){ for (let i=1;i<=n;i++) yield i; }
const prefix = 'org.claytom.mega';
const ts = new Date().toISOString().replace(/[-:T.Z]/g,'');
const file = path.resolve(outdir, `${stream}-${role}-${ts}.jsonl`);
const fd = fs.openSync(file, 'w');
let written = 0;
for (const i of seq(count)){
  const id = `${stream}-${role}-${String(i).padStart(7,'0')}`;
  const subject = `${prefix}.${stream}.${role}.${id}`;
  const level = role.match(/architect|planner|leader/i) ? 'L4' : role.match(/manager|coordinator/i) ? 'L3' : 'L2';
  const rec = { id, stream, role, level, subject, kpis: ["throughput_per_day","quality_score","sla_met_pct","innovation_landings_mo","training_hours_w"] };
  fs.writeSync(fd, JSON.stringify(rec) + '\n');
  written++;
}
fs.closeSync(fd);
console.log('[SHARD]', file, 'records=', written);
