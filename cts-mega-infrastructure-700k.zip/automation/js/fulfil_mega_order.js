
const { execSync } = require('child_process');
const args = require('minimist')(process.argv.slice(2));
const order = Number(args.order || 300000);
const out = args.out || './out';
const spec = [
  ['mega_production','rapid_creation_specialists', 150000],
  ['mega_production','quality_control_managers', 100000],
  ['mega_production','delivery_automation', 100000],
  ['mega_production','performance_optimization',  50000],
  ['github_infrastructure','senior_architects',  60000],
  ['github_infrastructure','full_stack_developers', 80000],
  ['github_infrastructure','devops_specialists',   60000],
  ['cio_autonomous_team','strategic_planners',     30000],
  ['cio_autonomous_team','client_relationship_managers', 25000],
  ['cio_autonomous_team','board_coordinators',     20000],
  ['cio_autonomous_team','innovation_leaders',     25000],
];
let produced = 0;
for (const [stream, role, cap] of spec){
  if (produced >= order) break;
  const remaining = Math.min(order - produced, cap);
  if (remaining <= 0) continue;
  const cmd = `node ${__dirname}/generate_shards_700k.js --stream ${stream} --role ${role} --count ${remaining} --out ${out}`;
  console.log('[GEN]', cmd);
  execSync(cmd, { stdio: 'inherit' });
  produced += remaining;
}
console.log('[ORDER-FULFILLED] produced=', produced);
