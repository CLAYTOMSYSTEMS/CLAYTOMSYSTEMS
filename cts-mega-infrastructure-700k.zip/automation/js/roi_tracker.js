
const args = require('minimist')(process.argv.slice(2));
const rev = Number(args.revenue || 0);
const cost = Number(args.cost || 0);
const stake = Number(args.stake || 0.15);
const profit = rev - cost;
const shareholder_return = profit * stake;
console.log(JSON.stringify({ revenue: rev, cost, profit, stake, shareholder_return }, null, 2));
