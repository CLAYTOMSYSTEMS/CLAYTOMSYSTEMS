'use client'
import Link from 'next/link'
export default function Page(){
  return (
    <main className="min-h-screen bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-900 via-black to-black">
      <div className="max-w-6xl mx-auto px-6 pt-16 pb-24">
        <header className="flex items-center justify-between">
          <h1 className="text-2xl font-bold tracking-tight">Guests Valencia · PROTECH</h1>
          <nav className="flex gap-6 text-white/80">
            <Link href="/sandra" className="hover:text-white">Sandra IA 7.0</Link>
            <Link href="/servicios" className="hover:text-white">Servicios</Link>
            <Link href="/admin" className="hover:text-white">Admin</Link><Link href="/reserva" className="hover:text-white">Reserva</Link>
          </nav>
        </header>

        <section className="mt-16 grid md:grid-cols-2 gap-10">
          <div className="space-y-6">
            <h2 className="text-5xl font-black leading-tight">La recepción <span className="text-white/70">que nunca duerme</span></h2>
            <p className="text-white/80 text-lg">Sandra IA 7.0 atiende a tus huéspedes por voz y avatar en tiempo real. Sin fricción. Sin colas. Con cariño valenciano.</p>
            <div className="flex gap-3">
              <Link href="/sandra" className="px-6 py-3 rounded-2xl bg-white text-black font-semibold">Probar demo</Link>
              <Link href="/servicios" className="px-6 py-3 rounded-2xl border border-white/30">Ver servicios</Link>
            </div>
          </div>
          <div className="glass p-6">
            <div className="aspect-video rounded-xl bg-white/5 grid place-items-center">Hero visual / video</div>
          </div>
        </section>
      </div>
    </main>
  )
}
