
'use client'
import { useEffect, useState } from 'react'
export default function SOS(){
  const token = typeof window!=='undefined'?localStorage.getItem('token'):''
  const [cfg,setCfg]=useState<any>({contact_name:'Recepción Guests Valencia',phone:'+34...',email:'seguridad@guestsvalencia.es',note:'Contacto 24/7'})
  const [loc,setLoc]=useState<any>(null)
  useEffect(()=>{ fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/sos/config',{headers:{Authorization:'Bearer '+token}}).then(r=>r.json()).then(c=>c && setCfg(c)) },[])
  async function save(){ await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/sos/config',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify(cfg)}); alert('Guardado') }
  function getLoc(){ if(navigator.geolocation){ navigator.geolocation.getCurrentPosition(p=>setLoc({lat:p.coords.latitude,lng:p.coords.longitude})) } }
  async function trigger(){ const r=await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/sos/trigger',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({lat:loc?.lat,lng:loc?.lng,note:'Prueba SOS desde admin'})}); if(r.ok) alert('SOS enviado (push si configurado)') }
  return <div className="max-w-xl mx-auto p-8 space-y-3">
    <h2 className="text-2xl font-bold">SOS</h2>
    <p className="text-white/70">No sustituye emergencia real. En peligro, llama al <a className="underline" href="tel:112">112</a>.</p>
    <input className="w-full px-3 py-2 bg-white/10 rounded" placeholder="Nombre contacto" value={cfg.contact_name||''} onChange={e=>setCfg({...cfg,contact_name:e.target.value})} />
    <input className="w-full px-3 py-2 bg-white/10 rounded" placeholder="Teléfono" value={cfg.phone||''} onChange={e=>setCfg({...cfg,phone:e.target.value})} />
    <input className="w-full px-3 py-2 bg-white/10 rounded" placeholder="Email" value={cfg.email||''} onChange={e=>setCfg({...cfg,email:e.target.value})} />
    <textarea className="w-full px-3 py-2 bg-white/10 rounded" placeholder="Nota" value={cfg.note||''} onChange={e=>setCfg({...cfg,note:e.target.value})} />
    <div className="flex gap-2">
      <button onClick={save} className="px-4 py-2 bg-white text-black rounded">Guardar</button>
      <button onClick={getLoc} className="px-4 py-2 border rounded">Obtener ubicación</button>
      <button onClick={trigger} className="px-4 py-2 border rounded">Enviar SOS</button>
    </div>
    {loc && <p className="text-xs opacity-70">Ubicación: {loc.lat.toFixed(5)}, {loc.lng.toFixed(5)}</p>}
  </div>
}
