
'use client'
import { useEffect, useState } from 'react'
export default function Protect(){
  const token = typeof window!=='undefined'?localStorage.getItem('token'):''
  const [family,setFamily]=useState<any[]>([])
  const [devices,setDevices]=useState<any[]>([])
  const [f,setF]=useState({name:'',relation:'',face_ref:'',voice_ref:''})
  const [d,setD]=useState({name:'TV Salón',type:'tv',location:'salón'})
  const [cmd,setCmd]=useState({device_id:0,command:'on',payload:''})
  const [sos,setSos]=useState<any>(null)
  function load(){
    fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/family',{headers:{Authorization:'Bearer '+token}}).then(r=>r.json()).then(setFamily)
    fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/devices',{headers:{Authorization:'Bearer '+token}}).then(r=>r.json()).then(rs=>{setDevices(rs); if(rs[0]) setCmd(c=>({...c,device_id:rs[0].id}))})
    fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/sos/config',{headers:{Authorization:'Bearer '+token}}).then(r=>r.json()).then(setSos)
  }
  useEffect(()=>{ load() },[])
  async function addF(){ await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/family',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify(f)}); setF({name:'',relation:'',face_ref:'',voice_ref:''}); load() }
  async function addD(){ await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/devices',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify(d)}); setD({name:'',type:'tv',location:'salón'}); load() }
  async function sendCmd(){ await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/domotics/command',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({...cmd,payload:cmd.payload?JSON.parse(cmd.payload):{}})}); alert('Comando enviado (simulado)') }
  return <div className="max-w-6xl mx-auto p-8 space-y-6">
    <h2 className="text-2xl font-bold">Protect Hogar</h2>
    <p className="text-white/70">Respeta privacidad y consentimiento. La detección de rostro/voz es placeholder (no subas datos sensibles sin consentimiento).</p>
    <div className="grid md:grid-cols-2 gap-4">
      <div className="glass p-4 rounded-xl">
        <h3 className="font-semibold mb-2">Familia</h3>
        <div className="grid grid-cols-2 gap-2">
          <input className="px-2 py-2 bg-white/10 rounded" placeholder="Nombre" value={f.name} onChange={e=>setF({...f,name:e.target.value})} />
          <input className="px-2 py-2 bg-white/10 rounded" placeholder="Relación" value={f.relation} onChange={e=>setF({...f,relation:e.target.value})} />
          <input className="px-2 py-2 bg-white/10 rounded col-span-2" placeholder="Face ref (URL/ID)" value={f.face_ref} onChange={e=>setF({...f,face_ref:e.target.value})} />
          <input className="px-2 py-2 bg-white/10 rounded col-span-2" placeholder="Voice ref (URL/ID)" value={f.voice_ref} onChange={e=>setF({...f,voice_ref:e.target.value})} />
          <button onClick={addF} className="col-span-2 px-4 py-2 bg-white text-black rounded">Añadir</button>
        </div>
        <ul className="mt-3 text-sm space-y-1">{family.map(m=><li key={m.id}><strong>{m.name}</strong> — {m.relation}</li>)}</ul>
      </div>
      <div className="glass p-4 rounded-xl">
        <h3 className="font-semibold mb-2">Dispositivos</h3>
        <div className="grid grid-cols-3 gap-2">
          <input className="px-2 py-2 bg-white/10 rounded" placeholder="Nombre" value={d.name} onChange={e=>setD({...d,name:e.target.value})} />
          <input className="px-2 py-2 bg-white/10 rounded" placeholder="Tipo" value={d.type} onChange={e=>setD({...d,type:e.target.value})} />
          <input className="px-2 py-2 bg-white/10 rounded" placeholder="Ubicación" value={d.location} onChange={e=>setD({...d,location:e.target.value})} />
          <button onClick={addD} className="col-span-3 px-4 py-2 bg-white text-black rounded">Añadir dispositivo</button>
        </div>
        <ul className="mt-3 text-sm space-y-1">{devices.map(d=><li key={d.id}><strong>{d.name}</strong> — {d.type} ({d.location})</li>)}</ul>
      </div>
    </div>
    <div className="glass p-4 rounded-xl">
      <h3 className="font-semibold mb-2">Domótica (comando)</h3>
      <div className="grid md:grid-cols-4 gap-2">
        <select className="px-2 py-2 bg-white/10 rounded" value={cmd.device_id} onChange={e=>setCmd({...cmd,device_id:Number(e.target.value)})}>
          {devices.map(d=><option key={d.id} value={d.id}>{d.name}</option>)}
        </select>
        <input className="px-2 py-2 bg-white/10 rounded" placeholder="Comando" value={cmd.command} onChange={e=>setCmd({...cmd,command:e.target.value})} />
        <input className="px-2 py-2 bg-white/10 rounded" placeholder='Payload JSON' value={cmd.payload} onChange={e=>setCmd({...cmd,payload:e.target.value})} />
        <button onClick={sendCmd} className="px-4 py-2 bg-white text-black rounded">Enviar</button>
      </div>
    </div>
    <div className="glass p-4 rounded-xl">
      <h3 className="font-semibold mb-2">SOS (contacto)</h3>
      <p className="text-white/70 text-sm">No sustituye a emergencias (112). Para peligro real, llama al 112.</p>
      <div className="text-sm">{sos ? (<div><div>Contacto: <strong>{sos.contact_name}</strong></div><div>Tel: {sos.phone} · Email: {sos.email}</div></div>) : 'Sin configurar'}</div>
      <a className="inline-block mt-2 px-4 py-2 border rounded" href="/admin/sos">Configurar</a>
    </div>
  </div>
}
