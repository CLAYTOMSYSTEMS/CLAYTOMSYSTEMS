# Hierarchy 1,500 — ClayTom Systems
- 35 dominios × 30 por dominio = 1,050 + Consejo Ejecutivo (corporate) opcional → total operativo base **1,500**.
- Subjects NATS: `org.claytom.<domain>.<role>.<id>`
