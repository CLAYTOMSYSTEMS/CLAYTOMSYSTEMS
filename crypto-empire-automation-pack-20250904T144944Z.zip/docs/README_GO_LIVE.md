# CRYPTO EMPIRE AUTOMATION PACK
1) Completa credenciales oficiales (YouTube/TikTok) y activa revisión humana antes de publicar.
2) Programa cron: fetchNews → writeScript → (debate opcional) → queuePublish.
3) Usa disclaimers y valida campañas ante CNMV si procede.
