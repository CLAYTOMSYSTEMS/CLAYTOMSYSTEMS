export async function writeScript(items:any[], opts:{tone:'neutral'|'didactic'}){
  return { title: 'Mercado cripto hoy (educativo)', bullets: items.slice(0,5).map((i:any)=>`• ${i.title}`)};
}
