import Parser from 'rss-parser';
export async function fetchNews(feeds:string[]){
  const parser = new Parser(); const items:any[]=[];
  for (const f of feeds){ try{const r=await parser.parseURL(f); items.push(...(r.items||[]));}catch(e){}}
  return items.slice(0,50);
}
