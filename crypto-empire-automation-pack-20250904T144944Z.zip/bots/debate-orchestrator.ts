export function buildDebate(points:string[]){ return [
 {role:'Moderador', text:'Aviso: contenido educativo. No es asesoramiento.'},
 {role:'Tecnico', text:`Patrones: ${'${points[0]||""'}`} `},
 {role:'Fundamental', text:`Regulación/adopción: ${'${points[1]||""'}`} `},
 {role:'Moderador', text:'Riesgos: volatilidad, regulación, ciberseguridad.'}
]}
