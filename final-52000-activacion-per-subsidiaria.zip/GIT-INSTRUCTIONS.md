# Git — Instrucciones para publicar los documentos de activación
```bash
# Crear rama de trabajo
git checkout -b activation/board-docs

# Ubicación sugerida en el repo
mkdir -p docs/activation
cp -R docs/activation/* <RAIZ_REPO>/docs/activation/

# Añadir y commitear
git add docs/activation
git commit -m "Board: Activación FINAL-52000 — documentos por subsidiaria"

# Push y PR
git push origin activation/board-docs
# Crear Pull Request hacia main (revisión de la Junta)
```
