CGF L0-L3 + auditorías + ROI gates.
