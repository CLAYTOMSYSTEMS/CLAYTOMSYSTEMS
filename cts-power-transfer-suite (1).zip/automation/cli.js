// assign|train|exam|certify
