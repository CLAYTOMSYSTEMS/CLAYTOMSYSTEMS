
# ClayTomSystems Holding — Galaxy Package
Ver `prompts/PROMPT-HOLDING-INFRAESTRUCTURA-JERARQUICA-COMPLETA.md` para el marco completo.
Sigue `infrastructure/*` para DNS/K8s/ArgoCD y `automation/js` para automatizaciones.
