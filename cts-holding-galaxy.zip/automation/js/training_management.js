const fs = require('fs'), path = require('path');
const subs = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../../data/subsidiaries.json'),'utf-8'));
for (const s of subs) {
  const cohorts=[];
  for (let i=0;i<500;i++){
    const trainer=`trainer-${s.slug}-${String(i+1).padStart(3,'0')}`;
    const operators=[`operator-${s.slug}-${String(i*2+1).padStart(4,'0')}`,`operator-${s.slug}-${String(i*2+2).padStart(4,'0')}`];
    cohorts.push({trainer, operators, syllabus:["standards","SOPs","QA","observability"]});
  }
  fs.writeFileSync(path.resolve(__dirname,`../../data/cohorts-${s.slug}.json`), JSON.stringify(cohorts,null,2));
  console.log(`[TMS] ${s.slug} OK`);
}
