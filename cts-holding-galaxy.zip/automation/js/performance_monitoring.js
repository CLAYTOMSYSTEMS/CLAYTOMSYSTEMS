const fs = require('fs'), path = require('path');
function rnd(a,b){ return Math.random()*(b-a)+a; }
const subs = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../../data/subsidiaries.json'),'utf-8'));
for (const s of subs) {
  const m = {
    ts: new Date().toISOString(), subsidiary: s.slug, role: "coordinator",
    kpis: { throughput_per_day: Math.round(rnd(80,220)), quality_score: Math.round(rnd(88,99)*10)/10,
            sla_met_pct: Math.round(rnd(92,99)*10)/10, innovation_landings_mo: Math.round(rnd(2,7)),
            training_hours_w: Math.round(rnd(5,12)*10)/10 },
    okrs: { O1: "Crecimiento eficiente", KR1: Math.random(), KR2: Math.random() }
  };
  console.log(JSON.stringify(m));
}
