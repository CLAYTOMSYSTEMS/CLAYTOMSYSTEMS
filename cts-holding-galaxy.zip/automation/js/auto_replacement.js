const fs = require('fs'), path = require('path');
const subs = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../../data/subsidiaries.json'),'utf-8'));
function mk(sub, role, i){
  const id = `${sub}-auto-${role}-${i}`;
  return { id, domain: sub, role, level: role==='Director'?'L4':role==='Coordinator'?'L3':'L2',
    subject:`org.claytom.${sub}.${role.toLowerCase()}.${id}`, prompt:`You are ${role} for ${sub}.` };
}
for (const s of subs) {
  const current = 1500; // TODO: replace with live count
  if (current < s.min_headcount) {
    const need = s.min_headcount - current, out=[];
    for (let i=1;i<=need;i++){
      const r = (i%30<5)?'Director':(i%30<15)?'Coordinator':(i%30<25)?'Specialist':'Innovator';
      out.push(mk(s.slug, r, i));
    }
    fs.writeFileSync(path.resolve(__dirname,`../../data/replacements-${s.slug}.json`), JSON.stringify(out,null,2));
    console.log(`[REPOP] ${s.slug}: +${need}`);
  } else console.log(`[OK] ${s.slug}`);
}
