const fs = require('fs'), path = require('path');
const APPLY = process.argv.includes('--apply');
const subs = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../../data/subsidiaries.json'),'utf-8'));
for (const s of subs) {
  const rec = { type: "A", name: s.subdomain, content: "INGRESS_IP", proxied: true, ttl: 300 };
  console.log((APPLY?'[APPLY]':'[DRY]'), s.subdomain, rec);
  // TODO: provider.createRecord(rec)
}
