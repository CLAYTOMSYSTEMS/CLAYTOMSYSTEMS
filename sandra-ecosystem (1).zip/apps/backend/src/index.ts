import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import { createServer } from 'http'
import { WebSocketServer, WebSocket } from 'ws'
import Database from 'better-sqlite3'
import jwt from 'jsonwebtoken'
import bcrypt from 'bcryptjs'
import webpush from 'web-push'

const app = express()
app.use(express.json({ limit: '2mb' }))

// --- CORS allowlist ---
const allowed = (process.env.ALLOWED_ORIGINS || '').split(',').map(s=>s.trim()).filter(Boolean)
app.use(cors({
  origin: (origin, cb) => {
    if (!origin) return cb(null, true)
    if (allowed.includes(origin)) return cb(null, true)
    return cb(new Error('CORS blocked for origin: '+origin))
  },
  credentials: true
}))

// --- Helmet + CSP ---
const csp = {
  useDefaults: true,
  directives: {
    "default-src": ["'self'"],
    "script-src": ["'self'", "'unsafe-inline'"],
    "style-src": ["'self'", "'unsafe-inline'"],
    "img-src": ["'self'", "data:", "https:"],
    "connect-src": ["'self'", "https://api.openai.com", ...(allowed.length?allowed:[])],
    "frame-src": ["'self'", "https://app.heygen.com"],
    "frame-ancestors": [...(allowed.length?allowed:[]),"https://app.guestsvalencia.es","https://sandra.guestsvalencia.es"]
  }
}
app.use(helmet({ contentSecurityPolicy: csp as any }))

// --- ENV ---
const PORT = Number(process.env.PORT) || 4000
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || ''
const OPENAI_REALTIME_MODEL = process.env.OPENAI_REALTIME_MODEL || 'gpt-4o-realtime-preview-2024-12-17'
const HEYGEN_EMBED_URL = process.env.HEYGEN_EMBED_URL || 'https://app.heygen.com/guest-valencia-sandra'
const JWT_SECRET = process.env.JWT_SECRET || 'change_me_for_prod'

// --- DB ---
const db = new Database('data/sandra.db')
db.exec(`
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, email TEXT UNIQUE, password_hash TEXT, role TEXT DEFAULT 'admin');
CREATE TABLE IF NOT EXISTS conversations (id INTEGER PRIMARY KEY, title TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY, conversation_id INTEGER, role TEXT, content TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS push_subs (id INTEGER PRIMARY KEY, data TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS guests (
  id INTEGER PRIMARY KEY,
  name TEXT,
  email TEXT UNIQUE,
  phone TEXT,
  tags TEXT DEFAULT '' -- comma separated
);
CREATE TABLE IF NOT EXISTS reservations (
  id INTEGER PRIMARY KEY,
  guest_id INTEGER,
  property TEXT,
  check_in TEXT,
  check_out TEXT,
  price REAL,
  status TEXT DEFAULT 'pending',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS tokens (
  id INTEGER PRIMARY KEY,
  guest_id INTEGER UNIQUE,
  balance INTEGER DEFAULT 0,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS campaigns (
  id INTEGER PRIMARY KEY,
  name TEXT,
  season TEXT, -- 'summer' | 'winter' | 'custom'
  channel TEXT, -- 'email' | 'social' | 'push'
  content TEXT,
  status TEXT DEFAULT 'draft',
  scheduled_at TEXT
);
CREATE TABLE IF NOT EXISTS social_queue (
  id INTEGER PRIMARY KEY,
  platform TEXT, -- 'instagram' | 'facebook' | 'tiktok'
  content TEXT,
  image_url TEXT,
  scheduled_at TEXT,
  status TEXT DEFAULT 'queued'
);
CREATE TABLE IF NOT EXISTS analytics_events (
  id INTEGER PRIMARY KEY,
  ts TEXT DEFAULT CURRENT_TIMESTAMP,
  type TEXT,
  guest_id INTEGER,
  props TEXT
);
`)
const upsertAdmin = db.prepare('INSERT OR IGNORE INTO users (email, password_hash, role) VALUES (?, ?, ?)')
const adminPass = bcrypt.hashSync(process.env.ADMIN_PASSWORD || 'admin', 8)
upsertAdmin.run(process.env.ADMIN_EMAIL || 'admin@guestsvalencia.es', adminPass, 'admin')
// Seed seasonal campaigns if empty
const countCamp = db.prepare('SELECT COUNT(*) as c FROM campaigns').get() as any
if (!countCamp.c) {
  const seed = db.prepare('INSERT INTO campaigns (name, season, channel, content, status) VALUES (?, ?, ?, ?, ?)')
  seed.run('Verano · Early Beach','summer','social','🌞 Oferta verano: -12% en estancias + paella de bienvenida', 'draft')
  seed.run('Invierno · Termal Relax','winter','push','❄️ Termas Montanejos incluidas + -10% entre semana', 'draft')
  seed.run('Local Lovers','custom','email','🍽️ Ruta gastro valenciana + late checkout gratis', 'draft')
}


// --- Auth ---
function auth(req, res, next){
  const hdr = req.headers.authorization || ''
  const token = hdr.startsWith('Bearer ') ? hdr.slice(7) : null
  if (!token) return res.status(401).json({ error: 'No token' })
  try{
    const payload = jwt.verify(token, JWT_SECRET) as any
    ;(req as any).user = payload
    next()
  }catch(e){ return res.status(401).json({ error: 'Invalid token' }) }
}

app.post('/auth/login', (req, res) => {
  const { email, password } = req.body || {}
  if (!email || !password) return res.status(400).json({ error: 'Missing credentials' })
  const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email)
  if (!row) return res.status(401).json({ error: 'User not found' })
  const ok = bcrypt.compareSync(password, row.password_hash)
  if (!ok) return res.status(401).json({ error: 'Bad password' })
  const token = jwt.sign({ sub: row.id, email: row.email, role: row.role }, JWT_SECRET, { expiresIn: '7d' })
  res.json({ token })
})

// --- Conversations ---
app.get('/conversations', auth, (_req, res)=>{
  const rows = db.prepare('SELECT * FROM conversations ORDER BY created_at DESC').all()
  res.json(rows)
})
app.post('/conversations', auth, (req, res)=>{
  const { title } = req.body || {}
  const info = db.prepare('INSERT INTO conversations (title) VALUES (?)').run(title || 'Nueva conversación')
  res.json({ id: info.lastInsertRowid, title: title || 'Nueva conversación' })
})
app.get('/conversations/:id/messages', auth, (req, res)=>{
  const rows = db.prepare('SELECT * FROM messages WHERE conversation_id=? ORDER BY id').all(Number(req.params.id))
  res.json(rows)
})
app.post('/messages', auth, (req, res)=>{
  const { conversation_id, role, content } = req.body || {}
  if (!conversation_id || !role) return res.status(400).json({ error:'Missing fields' })
  const info = db.prepare('INSERT INTO messages (conversation_id, role, content) VALUES (?, ?, ?)').run(conversation_id, role, content || '')
  res.json({ id: info.lastInsertRowid })
})

// --- Push (optional) ---
if (process.env.VAPID_PUBLIC && process.env.VAPID_PRIVATE){
  webpush.setVapidDetails(process.env.VAPID_SUBJECT || 'mailto:admin@guestsvalencia.es', process.env.VAPID_PUBLIC!, process.env.VAPID_PRIVATE!)
}
app.post('/push/subscribe', (req, res)=>{
  const data = JSON.stringify(req.body || {})
  db.prepare('INSERT INTO push_subs (data) VALUES (?)').run(data)
  res.json({ ok: true })
})
app.post('/push/test', async (_req, res)=>{
  if (!process.env.VAPID_PUBLIC || !process.env.VAPID_PRIVATE) return res.status(400).json({ error:'No VAPID' })
  const subs = db.prepare('SELECT * FROM push_subs').all()
  for (const s of subs){
    try { await webpush.sendNotification(JSON.parse(s.data), JSON.stringify({ title:'Sandra IA', body:'Hola desde Guests Valencia' })) } catch {}
  }
  res.json({ sent: subs.length })
})

// --- HeyGen endpoints ---
app.post('/heygen/session/new', (_req, res)=> res.json({ url: HEYGEN_EMBED_URL }))
app.post('/heygen/session/close', (_req, res)=> res.json({ ok: true }))

// --- Health ---
app.get('/healthz', (_req, res)=> res.json({ ok: true }))

// --- HTTP server + WS proxy ---
const server = createServer(app)
const wss = new WebSocketServer({ server, path: '/openai/session' })

wss.on('connection', (client, req) => {
  if (!OPENAI_API_KEY){ client.close(1011, 'Server missing OPENAI_API_KEY'); return }
  const url = `wss://api.openai.com/v1/realtime?model=${encodeURIComponent(OPENAI_REALTIME_MODEL)}`
  const upstream = new WebSocket(url, { headers: { 'Authorization': `Bearer ${OPENAI_API_KEY}`, 'OpenAI-Beta': 'realtime=v1' } })

  upstream.on('open', ()=>{})
  upstream.on('message', (data)=>{ try{ client.readyState===WebSocket.OPEN && client.send(data) }catch{} })
  upstream.on('close', (c,r)=>{ try{ client.close(c, r.toString()) }catch{} })
  upstream.on('error', ()=>{ try{ client.close(1011, 'Upstream error') }catch{} })

  client.on('message', (data)=>{ try{ upstream.readyState===WebSocket.OPEN && upstream.send(data) }catch{} })
  client.on('close', ()=>{ try{ upstream.close() }catch{} })
  client.on('error', ()=>{ try{ upstream.close() }catch{} })
})


// ---- CRM Guests ----
app.get('/guests', auth, (_req, res)=>{
  const rows = db.prepare('SELECT * FROM guests ORDER BY id DESC').all()
  res.json(rows)
})
app.post('/guests', auth, (req, res)=>{
  const { name, email, phone, tags } = req.body || {}
  const info = db.prepare('INSERT INTO guests (name,email,phone,tags) VALUES (?,?,?,?)').run(name||'', email||'', phone||'', (tags||[]).join(','))
  res.json({ id: info.lastInsertRowid })
})
app.put('/guests/:id', auth, (req, res)=>{
  const { name, email, phone, tags } = req.body || {}
  db.prepare('UPDATE guests SET name=?, email=?, phone=?, tags=? WHERE id=?').run(name||'', email||'', phone||'', (tags||[]).join(','), Number(req.params.id))
  res.json({ ok: true })
})

// ---- Reservations ----
app.get('/reservations', auth, (_req,res)=>{
  const rows = db.prepare(`SELECT r.*, g.name as guest_name, g.email as guest_email FROM reservations r LEFT JOIN guests g ON g.id=r.guest_id ORDER BY r.created_at DESC`).all()
  res.json(rows)
})
app.post('/reservations', (req, res)=>{
  const { name, email, phone, property, check_in, check_out, price } = req.body || {}
  // upsert guest by email
  let guest = db.prepare('SELECT * FROM guests WHERE email = ?').get(email||'')
  if (!guest){
    const info = db.prepare('INSERT INTO guests (name,email,phone,tags) VALUES (?,?,?,?)').run(name||'', email||'', phone||'', '')
    guest = { id: info.lastInsertRowid }
  }
  const info = db.prepare('INSERT INTO reservations (guest_id, property, check_in, check_out, price, status) VALUES (?,?,?,?,?,?)').run(guest.id, property||'', check_in||'', check_out||'', Number(price||0), 'pending')
  // award tokens: 1 token por cada 20€
  const tokens = Math.floor((Number(price||0))/20)
  const row = db.prepare('SELECT balance FROM tokens WHERE guest_id=?').get(guest.id) as any
  if (row) db.prepare('UPDATE tokens SET balance = balance + ?, updated_at=CURRENT_TIMESTAMP WHERE guest_id=?').run(tokens, guest.id)
  else db.prepare('INSERT INTO tokens (guest_id, balance) VALUES (?, ?)').run(guest.id, tokens)
  // event
  db.prepare('INSERT INTO analytics_events (type, guest_id, props) VALUES (?,?,?)').run('reservation_created', guest.id, JSON.stringify({ reservation_id: info.lastInsertRowid, property, price }))
  res.json({ id: info.lastInsertRowid, tokens_awarded: tokens })
})
app.put('/reservations/:id/status', auth, (req, res)=>{
  const { status } = req.body || {}
  db.prepare('UPDATE reservations SET status=? WHERE id=?').run(status||'pending', Number(req.params.id))
  res.json({ ok: true })
})

// ---- Tokens ----
app.get('/tokens/:guest_id', auth, (req,res)=>{
  const row = db.prepare('SELECT balance FROM tokens WHERE guest_id=?').get(Number(req.params.guest_id))
  res.json({ balance: row?.balance || 0 })
})
app.post('/tokens/award', auth, (req,res)=>{
  const { guest_id, amount } = req.body || {}
  const row = db.prepare('SELECT balance FROM tokens WHERE guest_id=?').get(Number(guest_id))
  if (row) db.prepare('UPDATE tokens SET balance=balance+?, updated_at=CURRENT_TIMESTAMP WHERE guest_id=?').run(Number(amount||0), Number(guest_id))
  else db.prepare('INSERT INTO tokens (guest_id, balance) VALUES (?, ?)').run(Number(guest_id), Number(amount||0))
  res.json({ ok: true })
})

// ---- Campaigns ----
app.get('/campaigns', auth, (_req,res)=>{
  const rows = db.prepare('SELECT * FROM campaigns ORDER BY scheduled_at DESC NULLS LAST, id DESC').all()
  res.json(rows)
})
app.post('/campaigns', auth, (req,res)=>{
  const { name, season, channel, content, scheduled_at } = req.body || {}
  const info = db.prepare('INSERT INTO campaigns (name, season, channel, content, status, scheduled_at) VALUES (?,?,?,?,?,?)').run(name||'', season||'custom', channel||'social', content||'', 'draft', scheduled_at||null)
  res.json({ id: info.lastInsertRowid })
})
app.post('/campaigns/:id/activate', auth, (req,res)=>{
  db.prepare('UPDATE campaigns SET status=? WHERE id=?').run('active', Number(req.params.id))
  res.json({ ok: true })
})

// ---- Social CM ----
app.get('/social/queue', auth, (_req,res)=>{
  const rows = db.prepare('SELECT * FROM social_queue ORDER BY scheduled_at ASC').all()
  res.json(rows)
})
app.post('/social/queue', auth, (req,res)=>{
  const { platform, content, image_url, scheduled_at } = req.body || {}
  const info = db.prepare('INSERT INTO social_queue (platform, content, image_url, scheduled_at, status) VALUES (?,?,?,?,?)').run(platform||'instagram', content||'', image_url||'', scheduled_at||null, 'queued')
  res.json({ id: info.lastInsertRowid })
})
app.post('/social/queue/:id/send', auth, (req,res)=>{
  // En producción, aquí llamarías a APIs reales de cada plataforma.
  db.prepare('UPDATE social_queue SET status=? WHERE id=?').run('sent', Number(req.params.id))
  res.json({ ok: true })
})

// ---- Analytics ----
app.post('/analytics/events', (_req,res)=>{
  const { type, guest_id, props } = _req.body || {}
  db.prepare('INSERT INTO analytics_events (type, guest_id, props) VALUES (?,?,?)').run(type||'custom', guest_id||null, JSON.stringify(props||{}))
  res.json({ ok: true })
})
app.get('/analytics/summary', auth, (_req,res)=>{
  const reservations = db.prepare('SELECT COUNT(*) as c FROM reservations').get() as any
  const guests = db.prepare('SELECT COUNT(*) as c FROM guests').get() as any
  const tokens = db.prepare('SELECT SUM(balance) as s FROM tokens').get() as any
  const last7 = db.prepare("SELECT date(created_at) d, COUNT(*) c FROM reservations GROUP BY date(created_at) ORDER BY d DESC LIMIT 7").all()
  res.json({ totals: { reservations: reservations.c||0, guests: guests.c||0, tokens: tokens.s||0 }, reservations_last7: last7 })
})

// ---- Push personalized by tag ----
app.post('/push/send', auth, async (req,res)=>{
  if (!process.env.VAPID_PUBLIC || !process.env.VAPID_PRIVATE) return res.status(400).json({ error:'No VAPID' })
  const { title, body, tag } = req.body || {}
  const subs = db.prepare('SELECT * FROM push_subs').all()
  let sent = 0
  for (const s of subs){
    try{
      // In a real system, filter by guest tags; for demo we send to all
      await webpush.sendNotification(JSON.parse(s.data), JSON.stringify({ title: title||'Sandra', body: body||'' }))
      sent++
    }catch(e){}
  }
  res.json({ sent })
})

// ---- Background worker (demo) ----
setInterval(()=>{
  // mark due social posts as 'sent' (simulation)
  const due = db.prepare("SELECT * FROM social_queue WHERE status='queued' AND (scheduled_at IS NULL OR datetime(scheduled_at) <= datetime('now'))").all()
  for (const row of due){
    try{ db.prepare("UPDATE social_queue SET status='sent' WHERE id=?").run(row.id) }catch{}
  }
}, 30000)

server.listen(PORT, ()=> console.log(`[Backend] http://localhost:${PORT}`))
