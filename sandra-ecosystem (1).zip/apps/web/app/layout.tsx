export const metadata = { title: 'Guests Valencia — PROTECH', description: 'Sandra IA 7.0 Ecosistema' }
export default function Root({children}:{children:React.ReactNode}){ return <html lang="es"><body>{children}</body></html> }
