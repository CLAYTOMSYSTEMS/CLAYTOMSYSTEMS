'use client'
import { useState } from 'react'
export default function Reserva(){
  const [name,setName]=useState(''); const [email,setEmail]=useState(''); const [phone,setPhone]=useState('')
  const [property,setProperty]=useState('Altea Hills'); const [checkIn,setCheckIn]=useState(''); const [checkOut,setCheckOut]=useState(''); const [price,setPrice]=useState(120)
  const [ok,setOk]=useState<any>(null)
  async function reservar(){
    const r = await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL + '/reservations',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,email,phone,property,check_in:checkIn,check_out:checkOut,price})})
    setOk(await r.json())
  }
  return <div className="max-w-xl mx-auto p-8 space-y-3">
    <h2 className="text-2xl font-bold">Reserva directa · Guests Valencia</h2>
    <input className="w-full px-3 py-2 bg-white/10 rounded" placeholder="Nombre" value={name} onChange={e=>setName(e.target.value)} />
    <input className="w-full px-3 py-2 bg-white/10 rounded" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
    <input className="w-full px-3 py-2 bg-white/10 rounded" placeholder="Teléfono" value={phone} onChange={e=>setPhone(e.target.value)} />
    <input className="w-full px-3 py-2 bg-white/10 rounded" placeholder="Propiedad" value={property} onChange={e=>setProperty(e.target.value)} />
    <div className="grid grid-cols-2 gap-2">
      <input className="px-3 py-2 bg-white/10 rounded" placeholder="Entrada (YYYY-MM-DD)" value={checkIn} onChange={e=>setCheckIn(e.target.value)} />
      <input className="px-3 py-2 bg-white/10 rounded" placeholder="Salida (YYYY-MM-DD)" value={checkOut} onChange={e=>setCheckOut(e.target.value)} />
    </div>
    <input className="w-full px-3 py-2 bg-white/10 rounded" type="number" placeholder="Precio €" value={price} onChange={e=>setPrice(Number(e.target.value))} />
    <button onClick={reservar} className="px-4 py-2 bg-white text-black rounded">Reservar</button>
    {ok && <p className="text-sm opacity-80">Reserva #{ok.id} creada. Tokens otorgados: <strong>{ok.tokens_awarded}</strong></p>}
  </div>
}
