'use client'
import { useEffect, useState } from 'react'
export default function Social(){
  const [rows,setRows]=useState<any[]>([])
  const [platform,setPlatform]=useState('instagram')
  const [content,setContent]=useState('')
  const [image,setImage]=useState('')
  const [scheduled,setScheduled]=useState('')
  const token = typeof window!=='undefined'?localStorage.getItem('token'):''
  async function load(){ const r=await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/social/queue',{headers:{Authorization:'Bearer '+token}}); setRows(await r.json()) }
  async function add(){ await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/social/queue',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({platform,content,image_url:image,scheduled_at:scheduled||null})}); setContent(''); setImage(''); setScheduled(''); load() }
  async function send(id:number){ await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+`/social/queue/${id}/send`,{method:'POST',headers:{Authorization:'Bearer '+token}}); load() }
  useEffect(()=>{ load() },[])
  return <div className="max-w-4xl mx-auto p-8 space-y-4">
    <h2 className="text-2xl font-bold">Social CM</h2>
    <div className="grid md:grid-cols-5 gap-2">
      <select className="px-2 py-2 bg-white/10 rounded" value={platform} onChange={e=>setPlatform(e.target.value)}>
        <option value="instagram">Instagram</option>
        <option value="facebook">Facebook</option>
        <option value="tiktok">TikTok</option>
      </select>
      <input placeholder="Imagen (URL)" className="px-2 py-2 bg-white/10 rounded" value={image} onChange={e=>setImage(e.target.value)} />
      <input placeholder="Programar YYYY-MM-DD hh:mm" className="px-2 py-2 bg-white/10 rounded" value={scheduled} onChange={e=>setScheduled(e.target.value)} />
      <input placeholder="Contenido" className="px-2 py-2 bg-white/10 rounded md:col-span-1 col-span-2" value={content} onChange={e=>setContent(e.target.value)} />
      <button onClick={add} className="px-4 py-2 bg-white text-black rounded">Añadir</button>
    </div>
    <ul className="space-y-2">{rows.map(r=>(<li key={r.id} className="glass p-3 rounded-xl">
      <div className="flex items-center justify-between"><strong>{r.platform}</strong><span className="text-xs opacity-70">{r.status}</span></div>
      <p className="opacity-80">{r.content}</p>
      <div className="text-xs opacity-60">Programada: {r.scheduled_at||'—'}</div>
      {r.status!=='sent' && <button onClick={()=>send(r.id)} className="mt-2 px-3 py-1 border rounded">Enviar ahora</button>}
    </li>))}</ul>
  </div>
}
