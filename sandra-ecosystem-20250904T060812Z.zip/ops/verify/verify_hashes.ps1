Param([string]$Path='sandra-ecosystem',[string]$File='franchises\sectorial\docendo\valencia\branding.json')
(Get-FileHash -Algorithm SHA256 (Join-Path $Path $File))
