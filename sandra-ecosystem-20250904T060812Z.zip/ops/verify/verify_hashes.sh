#!/usr/bin/env bash
ROOT=${1:-./sandra-ecosystem}; FILE=${2:-franchises/sectorial/docendo/valencia/branding.json}; sha256sum "$ROOT/$FILE" 2>/dev/null || shasum -a 256 "$ROOT/$FILE"
