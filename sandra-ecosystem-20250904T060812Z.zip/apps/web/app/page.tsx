export default function Home(){return <main>Guests Valencia · Sandra IA 7.0</main>}
