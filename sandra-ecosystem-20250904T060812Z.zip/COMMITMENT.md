Cero hype, 100% verificable — rutas + hashes.
