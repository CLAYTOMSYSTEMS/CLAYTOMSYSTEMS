
# 🤖 ClaytomSystems — PACK 110 Chatbots (Call Center, Sales, WebChat, Soporte, Sector, Administrativo)

**Fecha:** 20250904T205151Z

Este paquete contiene **110 chatbots** listos para cablear a tus canales (WhatsApp, Web, Call Center/Twilio, etc.).  
Incluye prompts/personas, configuración por canal, y endpoints serverless de ejemplo (Netlify Functions) para **despacho**.

## Estructura
- `chatbots/` → bots por categoría, cada uno con `persona.json`, `prompt.txt`, `tools.json`, `channels.json`
- `registry.csv` y `registry.json` → catálogo maestro (IDs, categorías, descripciones, idioma, voz por defecto)
- `web/chatbots/` → UI simple de exploración + tester (llama al dispatcher)
- `netlify/functions/` → `bot-dispatcher.js` (envía al modelo si hay `OPENAI_API_KEY`, o dry‑run si no)
- `docs/CHATBOTS-DEPLOY.md` → guía de despliegue e integración
- `quality-assurance/testing-checklist.md` → lista de verificación
- `SHA-256-MANIFEST.txt` → hash del ZIP

## Uso rápido
1. Sube todo al repo de tu web (Netlify).
2. Añade `OPENAI_API_KEY` como env var si quieres que el dispatcher hable con OpenAI; si no, funcionará en **modo demo**.
3. Abre `/chatbots/` para listar y probar; o llama al endpoint `/.netlify/functions/bot-dispatcher` con `{ "bot_id": "wc-01", "message": "hola" }`.

> Para producción con voz/Realtime, reusa vuestro **brand-switcher** y los endpoints de Realtime; este pack se centra en **prompts + routing** y **texto** con opción a TTS si defines `OPENAI_TTS_VOICE` (placeholder).
