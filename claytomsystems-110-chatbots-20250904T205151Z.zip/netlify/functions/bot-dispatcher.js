
import fs from 'node:fs';

const REG = JSON.parse(fs.readFileSync('registry.json','utf-8'));

function findBot(id){ return REG.find(x => x.bot_id === id) }

export async function handler(event){
  if (event.httpMethod !== 'POST') return { statusCode:405, body:'Method Not Allowed' };
  let body = {}; try { body = JSON.parse(event.body||'{}') } catch {}
  const { bot_id, message } = body;
  const bot = findBot(bot_id);
  if(!bot) return { statusCode:404, body:`unknown bot_id: ${bot_id}` };

  const prompt = fs.readFileSync(`chatbots/${bot.category}/${bot.bot_id}/prompt.txt`, 'utf-8');
  const persona = JSON.parse(fs.readFileSync(`chatbots/${bot.category}/${bot.bot_id}/persona.json`, 'utf-8'));

  const key = process.env.OPENAI_API_KEY;
  if(!key){
    const demo = `[DEMO] ${bot.name}: Entendido. Para ayudarte con "${(message||'tu consulta')}", te propongo este siguiente paso: ¿prefieres que te llame un agente o agendamos una cita ahora?`;
    return { statusCode:200, body: JSON.stringify({ bot, persona, output: demo, mode: "dry-run" }) };
  }

  const sys = `${prompt}\n\nResponde SOLO en español (es-ES).`;
  const r = await fetch("https://api.openai.com/v1/responses", {
    method:"POST",
    headers: { "Authorization": `Bearer ${key}`, "Content-Type":"application/json" },
    body: JSON.stringify({
      model: "o4-mini",
      input: [
        { role:"system", content: sys },
        { role:"user", content: String(message||"Hola, ¿qué puedes hacer por mí?") }
      ]
    })
  });
  const data = await r.json();
  const text = data?.output_text || "[error: no output]";
  return { statusCode:200, body: JSON.stringify({ bot, output: text, mode: "live" }) };
}
