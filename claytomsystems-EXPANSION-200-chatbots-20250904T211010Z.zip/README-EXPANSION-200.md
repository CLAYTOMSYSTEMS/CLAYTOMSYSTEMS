
# 🤖 ClaytomSystems — EXPANSIÓN **200 Chatbots** (Paquete I+D)
**Fecha:** 20250904T211010Z

Este paquete añade **200 bots** adicionales a tu flota (IDs únicos con prefijos `*-e`).  
Diseñado para integrarse con tu pack previo de **110 chatbots**.

## Estructura
- `expansion/chatbots/` → 200 nuevos bots (`persona.json`, `prompt.txt`, `tools.json`, `channels.json`)
- `expansion/registry-expansion.json` y `.csv` → catálogo de la expansión
- `netlify/functions/registry-merged.js` → endpoint que combina *registry.json* (base) + *expansion/registry-expansion.json*
- `training-center/` → UI simple para explorar/filtrar y planificar entrenamiento de bots
- `scripts/merge-registries.js` → script para generar `registry-all.json` en build
- `docs/EXPANSION-DEPLOY.md` → guía de despliegue

> Nota: Los IDs llevan sufijo `e` (p.ej. `cce-01`) para evitar colisiones con tus bots existentes (`cc-01`, `sa-07`, etc.).
