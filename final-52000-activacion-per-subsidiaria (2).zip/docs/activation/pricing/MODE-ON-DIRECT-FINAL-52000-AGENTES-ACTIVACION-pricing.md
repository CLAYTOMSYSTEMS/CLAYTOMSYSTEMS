Pricing copy
