import checkout from '@paypal/checkout-server-sdk'
function client(){
  const env = (process.env.PAYPAL_ENV||'sandbox')==='live'
    ? new checkout.core.LiveEnvironment(process.env.PAYPAL_CLIENT_ID||'', process.env.PAYPAL_CLIENT_SECRET||'')
    : new checkout.core.SandboxEnvironment(process.env.PAYPAL_CLIENT_ID||'', process.env.PAYPAL_CLIENT_SECRET||'')
  return new checkout.core.PayPalHttpClient(env)
}
export async function createOrder(amount:number, currency='EUR'){
  const c = client()
  const req = new checkout.orders.OrdersCreateRequest()
  req.requestBody({ intent:'CAPTURE', purchase_units:[{ amount:{ currency_code: currency, value: amount.toFixed(2) } }] })
  const r = await c.execute(req); return { id: r.result.id }
}
export async function captureOrder(orderId:string){
  const c = client()
  const req = new checkout.orders.OrdersCaptureRequest(orderId)
  req.requestBody({})
  const r = await c.execute(req); return r.result
}
