'use client'
import { useEffect, useState } from 'react'
export default function Campanas(){
  const [rows,setRows]=useState<any[]>([])
  const [name,setName]=useState(''); const [season,setSeason]=useState('custom'); const [channel,setChannel]=useState('social'); const [content,setContent]=useState(''); const [scheduled,setScheduled]=useState('')
  const token = typeof window!=='undefined'?localStorage.getItem('token'):''
  async function load(){ const r=await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/campaigns',{headers:{Authorization:'Bearer '+token}}); setRows(await r.json()) }
  async function add(){ await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/campaigns',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({name,season,channel,content,scheduled_at:scheduled||null})}); setName('');setContent('');setScheduled(''); load() }
  async function activate(id:number){ await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+`/campaigns/${id}/activate`,{method:'POST',headers:{Authorization:'Bearer '+token}}); load() }
  useEffect(()=>{ load() },[])
  return <div className="max-w-5xl mx-auto p-8 space-y-4">
    <h2 className="text-2xl font-bold">Campañas</h2>
    <div className="grid md:grid-cols-5 gap-2">
      <input placeholder="Nombre" className="px-2 py-2 bg-white/10 rounded" value={name} onChange={e=>setName(e.target.value)} />
      <select className="px-2 py-2 bg-white/10 rounded" value={season} onChange={e=>setSeason(e.target.value)}><option value="summer">Verano</option><option value="winter">Invierno</option><option value="custom">Custom</option></select>
      <select className="px-2 py-2 bg-white/10 rounded" value={channel} onChange={e=>setChannel(e.target.value)}><option value="social">Social</option><option value="email">Email</option><option value="push">Push</option></select>
      <input placeholder="YYYY-MM-DD hh:mm" className="px-2 py-2 bg-white/10 rounded" value={scheduled} onChange={e=>setScheduled(e.target.value)} />
      <button onClick={add} className="px-4 py-2 bg-white text-black rounded">Crear</button>
    </div>
    <ul className="space-y-2">{rows.map(r=>(<li key={r.id} className="glass p-3 rounded-xl"><div className="flex items-center justify-between"><strong>{r.name}</strong><span className="text-xs opacity-70">{r.season} · {r.channel} · {r.status}</span></div><p className="opacity-80">{r.content}</p><div className="text-xs opacity-60">Programada: {r.scheduled_at||'—'}</div><button onClick={()=>activate(r.id)} className="mt-2 px-3 py-1 border rounded">Activar</button></li>))}</ul>
  </div>
}
