'use client'
import Link from 'next/link'
import { useEffect, useState } from 'react'
export default function Admin(){
  const [token,setToken]=useState<string|undefined>(undefined)
  useEffect(()=>{ setToken(localStorage.getItem('token')||undefined) },[])
  return <div className="max-w-4xl mx-auto p-8 space-y-4">
    <h2 className="text-3xl font-bold">Panel Admin</h2>
    {!token ? <p className="opacity-80">Primero identifícate en <Link className="underline" href="/admin/login">/admin/login</Link></p> :
    <nav className="grid grid-cols-2 md:grid-cols-3 gap-3">
      <Link href="/admin/guests" className="glass p-4 rounded-xl">Huéspedes</Link>
      <Link href="/admin/reservas" className="glass p-4 rounded-xl">Reservas</Link>
      <Link href="/admin/campanas" className="glass p-4 rounded-xl">Campañas</Link>
      <Link href="/admin/tokens" className="glass p-4 rounded-xl">Tokens</Link>
      <Link href="/admin/analytics" className="glass p-4 rounded-xl">Analytics</Link>
      <Link href="/admin/social" className="glass p-4 rounded-xl">Social CM</Link>
    <Link href="/admin/sandrita" className="glass p-4 rounded-xl">Sandrita</Link>
<Link href="/admin/protect-hogar" className="glass p-4 rounded-xl">Protect Hogar</Link>
<Link href="/admin/psicologia" className="glass p-4 rounded-xl">Psicología Apoyo</Link>
<Link href="/admin/wellness" className="glass p-4 rounded-xl">Wellness</Link>
<Link href="/admin/sos" className="glass p-4 rounded-xl">SOS</Link>
<Link href="/admin/sales" className="glass p-4 rounded-xl">Sales</Link>
</nav}
  </div>
}
