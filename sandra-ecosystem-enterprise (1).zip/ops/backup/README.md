Programar cron: `0 3 * * * node ops/backup/backup.js` con `BACKUP_KEY` en `.env`.
