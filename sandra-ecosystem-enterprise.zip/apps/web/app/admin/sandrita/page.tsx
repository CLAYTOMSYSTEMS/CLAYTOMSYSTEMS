
'use client'
import { useEffect, useState } from 'react'
export default function Sandrita(){
  const token = typeof window!=='undefined'?localStorage.getItem('token'):''
  const [tpls,setTpls]=useState<any[]>([])
  const [videos,setVideos]=useState<any[]>([])
  const [vars,setVars]=useState({ tema:'colores', minutos:5, beneficio:10, descuento:12, extra:'helado' })
  const [script,setScript]=useState('')
  const [title,setTitle]=useState('Sandrita aprende los colores')
  const [when,setWhen]=useState('')
  useEffect(()=>{ 
    fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/content/templates',{headers:{Authorization:'Bearer '+token}}).then(r=>r.json()).then(setTpls)
    loadVideos()
  },[])
  function loadVideos(){ fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/videos',{headers:{Authorization:'Bearer '+token}}).then(r=>r.json()).then(setVideos) }
  async function gen(id:number){
    const r = await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/content/generate',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({template_id:id, vars})})
    const d = await r.json(); setScript(d.script||'')
  }
  async function queue(){
    await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/videos',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({title,audience:'kids',avatar:'Sandrita',script,platform:'youtube',scheduled_at:when||null})})
    setTitle(''); setScript(''); setWhen(''); loadVideos()
  }
  async function publish(id:number){ await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+`/videos/${id}/publish`,{method:'POST',headers:{Authorization:'Bearer '+token}}); loadVideos() }
  return <div className="max-w-5xl mx-auto p-8 space-y-4">
    <h2 className="text-2xl font-bold">Sandrita · Canal Infantil</h2>
    <p className="text-white/70">Contenido educativo y seguro. No sustituye supervisión adulta. Evita datos personales de menores.</p>
    <div className="grid md:grid-cols-3 gap-3">
      <div className="glass p-3 rounded-xl">
        <h3 className="font-semibold mb-2">Plantillas</h3>
        <ul className="space-y-2">{tpls.filter(t=>t.category!=='promo').map((t:any)=>(<li key={t.id} className="flex justify-between items-center"><span>{t.name}</span><button onClick={()=>gen(t.id)} className="px-2 py-1 border rounded text-xs">Generar</button></li>))}</ul>
      </div>
      <div className="glass p-3 rounded-xl md:col-span-2">
        <h3 className="font-semibold mb-2">Nuevo vídeo</h3>
        <input className="w-full px-2 py-2 bg-white/10 rounded mb-2" placeholder="Título" value={title} onChange={e=>setTitle(e.target.value)} />
        <textarea className="w-full px-2 py-2 bg-white/10 rounded mb-2 h-32" placeholder="Script" value={script} onChange={e=>setScript(e.target.value)} />
        <input className="w-full px-2 py-2 bg-white/10 rounded mb-2" placeholder="Programación (YYYY-MM-DD hh:mm)" value={when} onChange={e=>setWhen(e.target.value)} />
        <button onClick={queue} className="px-4 py-2 bg-white text-black rounded">Añadir a cola</button>
      </div>
    </div>
    <div className="glass p-3 rounded-xl">
      <h3 className="font-semibold mb-2">Cola de vídeos</h3>
      <ul className="space-y-2">{videos.map((v:any)=>(<li key={v.id} className="flex items-center justify-between"><div><strong>{v.title}</strong> <span className="text-xs opacity-60">({v.status}) · {v.platform}</span></div>{v.status!=='published' && <button onClick={()=>publish(v.id)} className="px-3 py-1 border rounded">Publicar</button>}</li>))}</ul>
    </div>
  </div>
}
