import HeatCapture from './_components/HeatCapture'
import GA from './_components/GA'
export const metadata = { title: 'Guests Valencia — PROTECH', description: 'Sandra IA 7.0 Ecosistema' }
export default function Root({children}:{children:React.ReactNode}){ return <html lang="es"><body><GA /><HeatCapture />{children}</body></html> }
