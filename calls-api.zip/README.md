# ClaytomSystems Calls API — Bidirectional Voice (Twilio ↔ OpenAI Realtime)

A production-ready Node/TypeScript API that turns *any phone call* into a realtime, interruptible conversation with your AI.

## Quick start
```bash
cp .env.example .env
npm i
npm run dev
```
Then point your Twilio Voice webhook to `POST {BASE_URL}/twilio/voice?bot=ayuntamientos-modelo-01`.
