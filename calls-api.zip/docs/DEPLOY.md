# Deploy Guide
1) Put this API behind HTTPS (Traefik or Cloudflare tunnel).
2) Twilio number webhook → POST {BASE_URL}/twilio/voice?bot=default
3) Outbound test (after setting .env):
curl -X POST {BASE_URL}/api/calls/outbound -H "Content-Type: application/json" -d '{ "to":"+34600111222","botId":"ayuntamientos-modelo-01" }'
