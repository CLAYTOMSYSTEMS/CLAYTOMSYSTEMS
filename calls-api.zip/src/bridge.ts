import { WebSocketServer } from "ws";
import pino from "pino";
import { TwilioRealtimeTransportLayer } from "@openai/agents-extensions";
import fs from "fs";
import path from "path";

const logger = pino({ level: process.env.LOG_LEVEL || "info" });

export function attachTwilioBridge(server: any, wssPath = "/ws/twilio") {
  const wss = new WebSocketServer({ server, path: wssPath });
  logger.info({ wssPath }, "WS server ready");

  wss.on("connection", async (twilioWS, req) => {
    const url = new URL(req.url || "", "http://localhost");
    const botId = url.searchParams.get("bot") || "guestsvalencia";

    // Load bot persona
    const botsPath = path.join(process.cwd(), "src", "bots", "registry.json");
    const bots = JSON.parse(fs.readFileSync(botsPath, "utf-8"));
    const persona = bots[botId] || bots["guestsvalencia"];

    const apiKey = process.env.OPENAI_API_KEY;
    const model = process.env.OPENAI_REALTIME_MODEL || "gpt-4o-realtime-preview-2024-12-17";
    if (!apiKey) {
      twilioWS.close(1011, "Missing OPENAI_API_KEY");
      return;
    }

    try {
      const transport = new TwilioRealtimeTransportLayer({ twilioWebSocket: twilioWS });
      await transport.connect({
        apiKey,
        model,
        session: {
          instructions: persona.prompt,
          voice: persona.voice || "alloy",
          input_audio_format: { type: "twilio" },
          output_audio_format: { type: "twilio" }
        }
      });
      logger.info({ botId, model }, "OpenAI Realtime session connected");
      twilioWS.on("close", () => {
        transport.close();
        logger.info({ botId }, "WS closed");
      });
    } catch (err:any) {
      logger.error({ err: err?.message }, "Bridge error");
      twilioWS.close(1011, "Bridge error");
    }
  });
}
