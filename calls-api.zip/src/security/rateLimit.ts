export function rateLimit(perMinute: number) {
  const tokens: Record<string, { t: number; c: number }> = {};
  const windowMs = 60_000;
  return (ip: string) => {
    const now = Date.now();
    const bucket = tokens[ip] ?? { t: now, c: perMinute };
    const elapsed = now - bucket.t;
    if (elapsed > windowMs) { bucket.t = now; bucket.c = perMinute; }
    if (bucket.c <= 0) return false;
    bucket.c -= 1; tokens[ip] = bucket; return true;
  };
}
