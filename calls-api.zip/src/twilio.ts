import type { Request, Response } from "express";
import twilio from "twilio";

export function voiceWebhook(req: Request, res: Response) {
  const bot = (req.query.bot as string) || "guestsvalencia";
  const base = process.env.BASE_URL;
  if (!base) return res.status(500).send("Missing BASE_URL");

  const twiml = new twilio.twiml.VoiceResponse();
  const connect = twiml.connect();
  connect.stream({
    url: `${base.replace(/^http/,'ws')}/ws/twilio?bot=${encodeURIComponent(bot)}`,
    track: "both_tracks"
  });
  res.type("text/xml").send(twiml.toString());
}

export async function startOutboundCall(to: string, botId: string) {
  const { TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_NUMBER, BASE_URL } = process.env as any;
  if (!TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN || !TWILIO_NUMBER || !BASE_URL) {
    throw new Error("Missing Twilio env or BASE_URL");
  }
  const client = twilio(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);
  const url = `${BASE_URL}/twilio/voice?bot=${encodeURIComponent(botId)}`;
  const call = await client.calls.create({ to, from: TWILIO_NUMBER, url, machineDetection: "Enable" });
  return call.sid;
}
