import "dotenv/config";
import express from "express";
import http from "http";
import pino from "pino";
import pinoHttp from "pino-http";
import helmet from "helmet";
import cors from "cors";
import { rateLimit } from "./security/rateLimit.js";
import { voiceWebhook, startOutboundCall } from "./twilio.js";
import { attachTwilioBridge } from "./bridge.js";
import fs from "fs";
import path from "path";

const app = express();
const logger = pino({ level: process.env.LOG_LEVEL || "info" });
app.use(pinoHttp({ logger }));

app.use(helmet({ crossOriginEmbedderPolicy: false }));
app.use(cors({ origin: (_o, cb) => cb(null, true) }));
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

const allow = rateLimit(parseInt(process.env.RATE_LIMIT_PER_MIN || "120", 10));
app.use((req, res, next) => {
  const ip = (req.headers["x-forwarded-for"] as string) || req.socket.remoteAddress || "local";
  if (!allow(ip)) return res.status(429).json({ error: "Too Many Requests" });
  next();
});

app.get("/health", (_req, res) => res.json({ ok: true }));

app.get("/api/bots", (_req, res) => {
  const p = path.join(process.cwd(), "src", "bots", "registry.json");
  const bots = JSON.parse(fs.readFileSync(p, "utf-8"));
  res.json({ bots });
});

app.post("/twilio/voice", voiceWebhook);

app.post("/api/calls/outbound", async (req, res) => {
  try {
    const { to, botId } = req.body || {};
    if (!to || !botId) return res.status(400).json({ error: "Missing to or botId" });
    const sid = await startOutboundCall(to, botId);
    res.json({ ok: true, callSid: sid });
  } catch (e: any) {
    req.log.error(e);
    res.status(500).json({ error: e?.message || "Internal error" });
  }
});

const port = parseInt(process.env.PORT || "8080", 10);
const server = http.createServer(app);
attachTwilioBridge(server, "/ws/twilio");
server.listen(port, () => logger.info({ port }, "Calls API listening"));
