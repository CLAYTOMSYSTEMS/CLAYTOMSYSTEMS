
import express from 'express'
import cors from 'cors'
import { connect } from 'nats'
import fs from 'fs'

const PORT = process.env.PORT || 8080
const NATS_URL = process.env.NATS_URL || 'nats://nats:4222'
const CHATBOTS_PATH = process.env.CHATBOTS_PATH || '/app/data/chatbots.json'

const app = express()
app.use(cors())
app.use(express.json())

let nc
;(async () => { nc = await connect({ servers: NATS_URL }) })().catch(console.error)

const chatbots = JSON.parse(fs.readFileSync(CHATBOTS_PATH, 'utf-8'))

app.get('/health', (req,res)=> res.json({ok:true, service:'api-gateway'}))
app.get('/pricing', (req,res)=> res.json({
  plans:[
    { name:'Starter', price:299, minutes:2000, extraPerMin:0.08, bots:5 },
    { name:'Business', price:1490, minutes:15000, extraPerMin:0.06, bots:50 },
    { name:'Enterprise', price:4900, minutes:60000, extraPerMin:0.045, bots:310 }
  ]
}))
app.get('/chatbots', (req,res)=> res.json(chatbots))

// Placeholder: create session (LiveKit token issuing should be added here)
app.post('/sessions', async (req,res)=>{
  const { botId, room } = req.body || {}
  if(!botId) return res.status(400).json({error:'botId required'})
  await nc?.publish('bot.activate', new TextEncoder().encode(JSON.stringify({ botId, room })))
  return res.json({ ok:true, room: room||`room-${Date.now()}`, token:"REPLACE_WITH_LIVEKIT_TOKEN" })
})

app.post('/commands', async (req,res)=>{
  const cmd = req.body
  if(!cmd || !cmd.command) return res.status(400).json({error:'invalid command'})
  await nc?.publish('ceo.command', new TextEncoder().encode(JSON.stringify(cmd)))
  res.json({ok:true})
})

app.listen(PORT, ()=> console.log(`[api-gateway] listening on ${PORT}`))
