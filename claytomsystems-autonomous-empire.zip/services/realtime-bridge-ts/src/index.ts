
import WebSocket from 'ws'

const OPENAI_API_KEY = process.env.OPENAI_API_KEY || ''
const OPENAI_URL = process.env.OPENAI_REALTIME_URL || 'wss://api.openai.com/v1/realtime?model=gpt-4o-realtime-preview-2024-12-17'
const PORT = parseInt(process.env.PORT || '8090', 10)

// Minimal WS server that proxies audio frames to OpenAI Realtime and back
import http from 'http'
const server = http.createServer()
const wss = new WebSocket.Server({ server })

wss.on('connection', (client) => {
  console.log('[bridge] client connected')
  const upstream = new WebSocket(OPENAI_URL, {
    headers: { 'Authorization': `Bearer ${OPENAI_API_KEY}`, 'OpenAI-Beta': 'realtime=v1' }
  })

  upstream.on('open', ()=> console.log('[bridge] upstream open'))
  upstream.on('message', (data)=> { try { client.send(data) } catch{} })
  upstream.on('close', ()=> client.close())
  upstream.on('error', (e)=> console.error('[bridge] upstream error', e))

  client.on('message', (data)=> { try { upstream.send(data) } catch{} })
  client.on('close', ()=> upstream.close())
  client.on('error', (e)=> console.error('[bridge] client error', e))
})

server.listen(PORT, ()=> console.log(`[bridge] listening on ${PORT}`))
