
import express from 'express'
import cors from 'cors'
import fs from 'fs'
const PORT = process.env.PORT || 8081
const CHATBOTS_PATH = process.env.CHATBOTS_PATH || '/app/data/chatbots.json'

const app = express()
app.use(cors())

const bots = JSON.parse(fs.readFileSync(CHATBOTS_PATH,'utf-8'))

app.get('/chatbots', (req,res)=> res.json(bots))
app.get('/chatbots/:id', (req,res)=>{
  const b = bots.find(x=>x.id===req.params.id)
  if(!b) return res.status(404).json({error:'not found'})
  res.json(b)
})
app.listen(PORT, ()=> console.log(`[profiles] listening on ${PORT}`))
