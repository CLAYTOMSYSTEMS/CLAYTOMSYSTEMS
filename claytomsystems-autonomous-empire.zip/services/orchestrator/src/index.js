
import { connect, StringCodec } from 'nats'

const NATS_URL = process.env.NATS_URL || 'nats://nats:4222'
const sc = StringCodec()

async function main(){
  const nc = await connect({ servers: NATS_URL })
  console.log('[orchestrator] connected to NATS')

  const subCmd = nc.subscribe('ceo.command')
  ;(async () => {
    for await (const m of subCmd) {
      try {
        const cmd = JSON.parse(sc.decode(m.data))
        console.log('[orchestrator] CEO command:', cmd)
        // naive reactions:
        if(cmd.command === 'scale'){
          // publish scaling instruction
          await nc.publish('bot.scale', sc.encode(JSON.stringify({ role:cmd.target, count:cmd.count||1 })))
        }
        if(cmd.command === 'activate'){
          await nc.publish('bot.batch.activate', sc.encode(JSON.stringify({ role:cmd.target, count:cmd.count||1 })))
        }
        if(cmd.command === 'train'){
          await nc.publish('bot.train', sc.encode(JSON.stringify({ role:cmd.target, botId:cmd.botId })))
        }
      } catch(e){ console.error('cmd error', e) }
    }
  })()

  const subActivate = nc.subscribe('bot.activate')
  ;(async () => {
    for await (const m of subActivate) {
      const payload = sc.decode(m.data)
      console.log('[orchestrator] activate request:', payload)
      // TODO: talk to K8s API or scale worker deployments
    }
  })()

}
main().catch(console.error)
