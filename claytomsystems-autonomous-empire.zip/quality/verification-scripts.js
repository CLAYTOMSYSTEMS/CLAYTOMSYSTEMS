
#!/usr/bin/env node
const fs = require('fs')
const bots = JSON.parse(fs.readFileSync(require('path').join(__dirname, '..','data','chatbots.json'),'utf8'))
const total = bots.length
if(total !== 710){ console.error('Expected 710 bots, got', total); process.exit(1) }
console.log('OK: 710 chatbots present')
