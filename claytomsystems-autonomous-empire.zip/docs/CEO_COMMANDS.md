
# CEO Command Center — High-Level Orders

All commands hit `POST /commands` on `api-gateway` with shape:
```json
{ "command": "scale", "target": "autonomous_sales_manager", "count": 25 }
```

Supported:
- `scale` — increase pools for a role
- `activate` — spin up N new sessions with given role
- `pause` — drain role
- `train` — trigger training for role or botId
- `report` — compile status report and email to CEO
