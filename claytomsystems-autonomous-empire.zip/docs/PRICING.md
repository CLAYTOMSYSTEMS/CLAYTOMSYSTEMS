
# Pricing (Public)

Plans:
- Starter €299/m — 2,000 min incl., €0.08/min extra, 5 chatbots
- Business €1,490/m — 15,000 min incl., €0.06/min extra, 50 chatbots
- Enterprise €4,900/m — 60,000 min incl., €0.045/min extra, 310+ chatbots, SSO/SLAs
Add-ons: White-label, priority support, custom training.
