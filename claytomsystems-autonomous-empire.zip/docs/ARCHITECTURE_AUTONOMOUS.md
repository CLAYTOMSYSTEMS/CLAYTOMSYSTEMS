
# ClayTomSystems Autonomous Empire — Architecture

## Event Bus
- NATS used for low-latency pub/sub between services: `bot.activate`, `bot.scale`, `bot.train`, `bot.metrics.*`.

## Core Services
- **api-gateway**: REST entrypoint; issues LiveKit tokens (plug your signer), orchestrates sessions.
- **profiles-service**: Chatbot registry backed by Postgres; seeded from `data/chatbots.json`.
- **realtime-bridge**: Bridges LiveKit ↔ OpenAI Realtime WS; supports VAD/barge-in; emits `bot.metrics.rtt`.
- **orchestrator**: Listens to CEO commands; scales bot worker pools; triggers training/updates.
- **ceo-console (Next.js)**: Command Center UI; dashboards; triggers high-level orders.

## Scaling
- Horizontal Pod Autoscaler (HPA) per service based on CPU and custom metrics via `/metrics` endpoints or NATS counters.
- Room-per-session with SFU (LiveKit); workers pool sized by concurrent sessions × 1.2 headroom.

## Autonomy Protocols
- Wake-up: bots publish `bot.activate` with desired specialty; orchestrator ensures capacity.
- Self-Training: training jobs published to `bot.train`; training-service consumes.
- Guardrails: api-gateway enforces rate limits; orchestrator applies circuit breakers.
