
# Deployment Guide (Kubernetes)

1) Apply base (Postgres, Redis, NATS):
```
kubectl apply -f k8s/namespaces.yaml
kubectl -n clay apply -f k8s/base/postgres.yaml
kubectl -n clay apply -f k8s/base/redis.yaml
kubectl -n clay apply -f k8s/base/nats.yaml
```

2) Secrets:
```
kubectl -n clay create secret generic openai --from-literal=OPENAI_API_KEY=sk-...
kubectl -n clay create secret generic livekit --from-literal=LIVEKIT_URL=wss://livekit.example --from-literal=LIVEKIT_BOT_TOKEN=...
kubectl -n clay create secret generic stripe --from-literal=STRIPE_KEY=sk_live_...
kubectl -n clay create secret generic pg --from-literal=PGPASSWORD=postgres
```

3) Services:
```
kubectl -n clay apply -f k8s/livekit/
kubectl -n clay apply -f k8s/profiles/
kubectl -n clay apply -f k8s/api-gateway/
kubectl -n clay apply -f k8s/realtime-bridge/
kubectl -n clay apply -f k8s/orchestrator/
kubectl -n clay apply -f k8s/ingress/
```

4) Website:
```
# Build and deploy Next.js (or serve via static export)
```

5) Verify:
```
curl https://api.claytomsystems.com/health
curl https://api.claytomsystems.com/chatbots | jq length  # → 710
```
