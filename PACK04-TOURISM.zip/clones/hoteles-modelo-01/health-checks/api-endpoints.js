export async function ping(u){const r=await fetch(u,{cache:'no-store'});return{ok:r.ok,status:r.status};}
