Uso en hospitales: coordinación clínica, no médico, RGPD reforzado.
