Uso con menores: consentimiento, límites de pantalla, no médico.
