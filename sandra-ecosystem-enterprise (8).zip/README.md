# Sandra Ecosystem (Guests Valencia · Sandra IA 7.0)

Monorepo con:
- **apps/backend**: API Express + WS + Concierge + Sectorial + Seguridad (Helmet/HSTS/CSP), RBAC, API Keys, Prometheus
- **apps/web**: Next.js + Tailwind · Admin (Observability, Concierge, ROI, Docendo) + Landings sectoriales
- **ops**: Traefik + CrowdSec + Monitoring (Prometheus/Grafana/Alertmanager) + Seeds (97+ franquicias) + Scripts
- **docs**: Decks (HTML → PDF) + Legales

## Arranque local (desarrollo)
```bash
npm i
cp .env.example .env
npm run dev
```

## Producción con docker-compose (Traefik/TLS)
```bash
cd ops
cp .env.example .env
docker compose up -d
```
