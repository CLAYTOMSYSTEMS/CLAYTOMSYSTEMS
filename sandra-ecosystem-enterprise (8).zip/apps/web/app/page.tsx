export default function Home(){
  return <main className="max-w-5xl mx-auto p-12 space-y-6">
    <h1 className="text-4xl font-bold">Guests Valencia · Sandra IA 7.0</h1>
    <p className="opacity-80">PropTech conversacional · Concierge premium · Seguridad enterprise</p>
    <nav className="grid md:grid-cols-3 gap-4 mt-6">
      <a className="glass p-4 rounded-xl block" href="/admin">Panel Admin</a>
      <a className="glass p-4 rounded-xl block" href="/sectors/docendo">Docendo</a>
      <a className="glass p-4 rounded-xl block" href="/sectors/hoteles">Hoteles</a>
    </nav>
  </main>
}
