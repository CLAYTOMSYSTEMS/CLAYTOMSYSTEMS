'use client'
import { useState } from 'react'
export default function ROI(){
  const [r,setR]=useState<any>(null)
  const [v,setV]=useState({oneoff:2999, subscription:199, activeCenters:10, months:12, convRate:0.6, extraRevenuePerCenter:300})
  async function calc(){ const res=await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/sectors/roi',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(v)}); setR(await res.json()) }
  return <div className="max-w-3xl mx-auto p-8 space-y-4">
    <h2 className="text-2xl font-bold">ROI por sector</h2>
    <div className="grid grid-cols-2 gap-2 text-black">
      {Object.keys(v).map(k=>(<input key={k} className="px-2 py-2 rounded" defaultValue={(v as any)[k]} onChange={e=>setV({...v,[k]:Number(e.target.value)})}/>))}
    </div>
    <button onClick={calc} className="px-4 py-2 bg-white text-black rounded">Calcular</button>
    {r && <div className="glass p-4 rounded-xl text-xs"><pre>{JSON.stringify(r,null,2)}</pre></div>}
  </div>
}
