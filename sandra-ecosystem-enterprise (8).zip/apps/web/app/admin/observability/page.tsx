'use client'
import { useEffect,useState } from 'react'
export default function Observability(){
  const [health,setHealth]=useState<any>(null); const [metrics,setMetrics]=useState('')
  useEffect(()=>{ fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/healthz').then(r=>r.json()).then(setHealth); fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/metrics').then(r=>r.text()).then(setMetrics) },[])
  return <div className="max-w-5xl mx-auto p-8 space-y-6">
    <h2 className="text-2xl font-bold">Observabilidad</h2>
    <div className="glass p-4 rounded-xl"><pre className="text-xs whitespace-pre-wrap">{JSON.stringify(health,null,2)}</pre></div>
    <div className="glass p-4 rounded-xl"><pre className="text-xs overflow-auto max-h-[40vh]">{metrics}</pre></div>
  </div>
}
