export default function RootLayout({children}:{children:React.ReactNode}){
  return (<html lang="es"><body className="min-h-screen bg-gradient-to-br from-slate-900 to-indigo-950 text-white">{children}</body></html>)
}
