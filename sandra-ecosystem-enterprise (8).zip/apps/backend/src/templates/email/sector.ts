export function sectorTemplate(sector:string, lang:'es'|'en'='es', vars:any={}){
  const name = vars.name || 'equipo directivo'
  const offer = vars.offer || 'aumento de reservas y reducción de comisiones'
  const base = lang==='es'
    ? `Hola ${name},\n\nSoy Sandra (IA). Ayudo a ${sector} a lograr ${offer} con un asistente conversacional + avatar y CRM.\n¿Te muestro una demo de 10 minutos?`
    : `Hi ${name},\n\nI’m Sandra (AI). We help ${sector} achieve ${offer} with a conversational avatar and CRM.\nWould you like a 10‑minute demo?`
  return `🚀 ${base}\n\n✅ Ahorro comisiones\n✅ Reservas directas\n✅ Automatización 24/7\n\n— Sandra`
}
