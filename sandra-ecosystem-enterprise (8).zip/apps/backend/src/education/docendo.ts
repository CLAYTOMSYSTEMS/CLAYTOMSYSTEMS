import type { Database } from 'better-sqlite3'
export function ensureEducationTables(db: Database){
  db.exec(`
    CREATE TABLE IF NOT EXISTS partners (id INTEGER PRIMARY KEY, name TEXT, kind TEXT, email TEXT, phone TEXT, meta TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS education_centers (id INTEGER PRIMARY KEY, partner_id INTEGER, name TEXT, city TEXT, region TEXT, contact TEXT, policy_screen_min INTEGER DEFAULT 90);
    CREATE TABLE IF NOT EXISTS programs (id INTEGER PRIMARY KEY, center_id INTEGER, title TEXT, age_min INTEGER, age_max INTEGER, lang TEXT, notes TEXT);
    CREATE TABLE IF NOT EXISTS program_sessions (id INTEGER PRIMARY KEY, program_id INTEGER, day TEXT, start TEXT, end TEXT, content TEXT, status TEXT DEFAULT 'scheduled');
    CREATE TABLE IF NOT EXISTS consents (id INTEGER PRIMARY KEY, center_id INTEGER, guardian TEXT, child TEXT, signed_at TEXT);
  `)
}
export function getRemainingScreenMinutes(db: Database, center_id:number, dayISO:string){
  const row = db.prepare('SELECT policy_screen_min FROM education_centers WHERE id=?').get(center_id) as any
  const policy = row?.policy_screen_min ?? 90
  const day = dayISO.slice(0,10)
  const sessions = db.prepare('SELECT start,end FROM program_sessions WHERE program_id IN (SELECT id FROM programs WHERE center_id=?) AND day=?').all(center_id, day) as any[]
  let used=0; for(const s of sessions){ const [sh,sm]=String(s.start||'00:00').split(':').map(Number); const [eh,em]=String(s.end||'00:00').split(':').map(Number); used+=(eh*60+em)-(sh*60+sm) }
  return Math.max(0, policy-used)
}
