export type Leg = { mode: 'flight'|'train'|'metro'|'bus'|'walk'|'taxi'|'car', from: string, to: string, etaMin?: number, cost?: number, link?: string }
export type Itinerary = { guest: string, daysAhead: number, legs: Leg[], summary: string }
function mapsLink(origin:string, dest:string){ return `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(origin)}&destination=${encodeURIComponent(dest)}&travelmode=transit` }
export async function buildItinerary(p:{guest:string, origin:string, destination:string, arrivalISO:string}):Promise<Itinerary>{
  const legs: Leg[] = [
    { mode:'flight', from:p.origin, to:'VLC (Valencia Airport)' },
    { mode:'metro', from:'VLC (Aeroport)', to:'Xátiva (L3/L5)', etaMin:22, cost:4.8, link:mapsLink('Valencia Airport','Xátiva Metro, Valencia') },
    { mode:'walk', from:'Xátiva', to:p.destination, etaMin:10, link:mapsLink('Xátiva, Valencia', p.destination) }
  ]
  const cost = legs.reduce((a,b)=> a + (b.cost||0), 0)
  const summary = `Hola ${p.guest}, itinerario optimizado desde ${p.origin} → ${p.destination}. Coste aprox: €${cost.toFixed(2)}.`
  return { guest:p.guest, daysAhead:3, legs, summary }
}
export async function sendItinerary(send:{channel:'email'|'whatsapp', to:string}, it: Itinerary){
  return { ok:true, channel: send.channel, to: send.to, text: [it.summary, ...it.legs.map(l=>`• ${l.mode}: ${l.from} → ${l.to}`)].join('\n') }
}
