import 'dotenv/config'
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
const ENC = (process.env.BACKUP_KEY||'').padEnd(32,'0').slice(0,32)
const SRC = path.resolve('apps/backend/data/sandra.db')
const OUT = path.resolve('ops/backup/out')
fs.mkdirSync(OUT, { recursive: true })
const raw = fs.readFileSync(SRC)
const iv = crypto.randomBytes(12)
const cipher = crypto.createCipheriv('aes-256-gcm', Buffer.from(ENC), iv)
const ct = Buffer.concat([cipher.update(raw), cipher.final()])
const tag = cipher.getAuthTag()
const blob = Buffer.concat([iv, tag, ct])
const name = `backup-${new Date().toISOString().slice(0,19).replace(/[:T]/g,'-')}.db.enc`
fs.writeFileSync(path.join(OUT, name), blob)
console.log('Encrypted backup:', name)
