
'use client'
import { useEffect } from 'react'
export default function HeatCapture(){
  useEffect(()=>{
    function handler(e: MouseEvent){
      fetch((process.env.NEXT_PUBLIC_SANDRA_API_URL||'http://localhost:4000')+'/analytics/events',{
        method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({type:'heat_click', props:{x:e.clientX, y:e.clientY, path:location.pathname, vw:innerWidth, vh:innerHeight}})
      })
    }
    document.addEventListener('click', handler)
    return ()=>document.removeEventListener('click', handler)
  },[])
  return null
}
