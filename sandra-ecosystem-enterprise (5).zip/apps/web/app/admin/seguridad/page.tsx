'use client'
import { useEffect, useState } from 'react'
export default function Seguridad(){
  const token = typeof window!=='undefined'?localStorage.getItem('token'):''
  const [svg,setSvg]=useState<string>(''); const [base32,setBase32]=useState<string>(''); const [code,setCode]=useState('')
  async function setup(){ const r=await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/auth/2fa/setup',{method:'POST',headers:{Authorization:'Bearer '+token}}); const d=await r.json(); setSvg(d.svg); setBase32(d.base32) }
  async function enable(){ const r=await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/auth/2fa/enable',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({token:code})}); if(r.ok) alert('2FA activado'); }
  return <div className="max-w-xl mx-auto p-8 space-y-4">
    <h2 className="text-2xl font-bold">Seguridad · 2FA</h2>
    <button onClick={setup} className="px-4 py-2 bg-white text-black rounded">Generar QR</button>
    {svg && <div className="p-3 bg-white rounded" dangerouslySetInnerHTML={{__html:svg}} />}
    {base32 && <p className="text-xs break-all">Secreto: {base32}</p>}
    <input className="w-full px-3 py-2 bg-white/10 rounded" placeholder="Código 6 dígitos" value={code} onChange={e=>setCode(e.target.value)} />
    <button onClick={enable} className="px-4 py-2 border rounded">Activar 2FA</button>
  </div>
}
