'use client'
import { useEffect, useState } from 'react'
export default function Reservas(){
  const [rows,setRows]=useState<any[]>([])
  const token = typeof window!=='undefined'?localStorage.getItem('token'):''
  async function load(){ const r=await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/reservations',{headers:{Authorization:'Bearer '+token}}); setRows(await r.json()) }
  async function setStatus(id:number, status:string){ await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+`/reservations/${id}/status`,{method:'PUT',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({status})}); load() }
  useEffect(()=>{ load() },[])
  return <div className="max-w-5xl mx-auto p-8 space-y-4">
    <h2 className="text-2xl font-bold">Reservas</h2>
    <table className="w-full text-sm">
      <thead><tr><th>ID</th><th>Huésped</th><th>Propiedad</th><th>Entrada</th><th>Salida</th><th>Precio</th><th>Status</th><th>Acciones</th></tr></thead>
      <tbody>{rows.map(r=>(<tr key={r.id}><td>{r.id}</td><td>{r.guest_name} ({r.guest_email})</td><td>{r.property}</td><td>{r.check_in}</td><td>{r.check_out}</td><td>{r.price}€</td><td>{r.status}</td><td className="space-x-2"><button onClick={()=>setStatus(r.id,'confirmed')} className="px-2 py-1 bg-white text-black rounded">Confirmar</button><button onClick={()=>setStatus(r.id,'cancelled')} className="px-2 py-1 border rounded">Cancelar</button></td></tr>))}</tbody>
    </table>
  </div>
}
