import fetch from 'node-fetch'
const ACCESS = process.env.TIKTOK_ACCESS_TOKEN||''
const ACCOUNT = process.env.TIKTOK_BUSINESS_ACCOUNT_ID||''

export async function uploadTikTok(caption:string, video_url:string){
  if (!ACCESS || !ACCOUNT) throw new Error('TikTok not configured')
  // Simplified: direct post via Business API (pseudo endpoint — update with the latest spec if needed)
  const res = await fetch(`https://open.tiktokapis.com/v2/video/upload/`, {
    method:'POST',
    headers:{ 'Authorization': `Bearer ${ACCESS}`, 'Content-Type':'application/json' },
    body: JSON.stringify({ business_account_id: ACCOUNT, video_url, caption })
  })
  const js = await res.json()
  if (!res.ok) throw new Error(JSON.stringify(js))
  return js
}
