import twilio from 'twilio'
const sid = process.env.TWILIO_ACCOUNT_SID||''
const token = process.env.TWILIO_AUTH_TOKEN||''
const fromNum = process.env.TWILIO_FROM_NUMBER||''
const client = sid && token ? twilio(sid, token) : null

export async function placeCall(to:string, script:string){
  if (!client) throw new Error('Twilio not configured')
  const twiml = `<Response><Say voice="Polly.Conchita">${script}</Say></Response>`
  const call = await client.calls.create({ to, from: fromNum, twiml })
  return { sid: call.sid }
}
