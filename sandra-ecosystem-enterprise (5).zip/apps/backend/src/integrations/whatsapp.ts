import fetch from 'node-fetch'
const WA_ID = process.env.WA_PHONE_NUMBER_ID||''
const WA_TOKEN = process.env.WA_ACCESS_TOKEN||''
export async function sendWhatsApp(to:string, text:string){
  if (!WA_ID || !WA_TOKEN) throw new Error('WhatsApp Cloud not configured')
  const url = `https://graph.facebook.com/v18.0/${WA_ID}/messages`
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${WA_TOKEN}`, 'Content-Type':'application/json' },
    body: JSON.stringify({ messaging_product:'whatsapp', to, type:'text', text:{ body: text } })
  })
  if (!res.ok) throw new Error(`WA error ${res.status}`)
  return await res.json()
}
