export type SectorKind = 'guarderias'|'mayores'|'hoteles'|'booking'|'airbnb'|'realestate'|'hostales'|'aparthoteles'
export const GuarderiasModels = [
  { code:'valencia',   name:'Sandra Educa · Valencia',   locale:'es-ES', city:'Valencia' },
  { code:'madrid',     name:'Sandra Educa · Madrid',     locale:'es-ES', city:'Madrid' },
  { code:'barcelona',  name:'Sandra Educa · Barcelona',  locale:'es-ES', city:'Barcelona' },
  { code:'sevilla',    name:'Sandra Educa · Sevilla',    locale:'es-ES', city:'Sevilla' },
  { code:'malaga',     name:'Sandra Educa · Málaga',     locale:'es-ES', city:'Málaga' },
  { code:'alicante',   name:'Sandra Educa · Alicante',   locale:'es-ES', city:'Alicante' },
  { code:'valldalba',  name:'Sandra Educa · Castellón',  locale:'es-ES', city:'Castellón' },
  { code:'zaragoza',   name:'Sandra Educa · Zaragoza',   locale:'es-ES', city:'Zaragoza' },
  { code:'murcia',     name:'Sandra Educa · Murcia',     locale:'es-ES', city:'Murcia' },
  { code:'santander',  name:'Sandra Educa · Cantabria',  locale:'es-ES', city:'Santander' },
  { code:'vitoria',    name:'Sandra Educa · Euskadi',    locale:'es-ES', city:'Vitoria' },
  { code:'coruna',     name:'Sandra Educa · Galicia',    locale:'es-ES', city:'A Coruña' },
  { code:'valladolid', name:'Sandra Educa · Castilla',   locale:'es-ES', city:'Valladolid' },
  { code:'baleares',   name:'Sandra Educa · Baleares',   locale:'es-ES', city:'Palma' },
  { code:'canarias',   name:'Sandra Educa · Canarias',   locale:'es-ES', city:'Las Palmas' },
]
export const MayoresModels = [
  { code:'compan-urbana',     name:'Sandra Mayores · Compañía Urbana', locale:'es-ES' },
  { code:'compan-rural',      name:'Sandra Mayores · Compañía Rural',  locale:'es-ES' },
  { code:'apoyo-cognitivo',   name:'Sandra Mayores · Apoyo Cognitivo', locale:'es-ES' },
  { code:'mindfulness',       name:'Sandra Mayores · Mindfulness',     locale:'es-ES' },
  { code:'recordatorios-salud',name:'Sandra Mayores · Recordatorios',  locale:'es-ES' },
  { code:'movilidad',         name:'Sandra Mayores · Movilidad',       locale:'es-ES' },
  { code:'familia',           name:'Sandra Mayores · Familia',         locale:'es-ES' },
  { code:'salud-emocional',   name:'Sandra Mayores · Salud Emocional', locale:'es-ES' },
  { code:'ocio-cultural',     name:'Sandra Mayores · Ocio Cultural',   locale:'es-ES' },
  { code:'llamadas-diarias',  name:'Sandra Mayores · Llamadas Diarias',locale:'es-ES' },
]

export const Pricing = {
  oneoff: { min: 2999, max: 4999 },
  subscription: { min: 199, max: 399, period:'month' },
  support: { price: 99, period:'month' },
  setup: { price: 499 }
}

export function estimateROI({oneoff, subscription, activeCenters, months, convRate, extraRevenuePerCenter}:{oneoff:number, subscription:number, activeCenters:number, months:number, convRate:number, extraRevenuePerCenter:number}){
  const upfront = oneoff * activeCenters * convRate
  const mrr = subscription * activeCenters
  const added = extraRevenuePerCenter * activeCenters
  const revenue = upfront + (mrr*months) + (added*months)
  return { upfront, mrr, addedMonthly: added, revenue, months }
}
