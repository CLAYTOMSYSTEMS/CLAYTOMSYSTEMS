# Sandra Brand-Switcher — Go-Live Kit (2 subdominios)

Este paquete levanta Traefik con TLS automático (Let's Encrypt) y sirve una página estática
con el mic 3-en-1 bajo dos subdominios de ejemplo:

- docendo-valencia.guestsvalencia.es
- hospital-modelo-01.guestsvalencia.es

## Arranque
docker compose -f docker-compose.brand-switcher.yml up -d

## Generar rutas para 97 clones desde manifest.csv
python3 scripts/generate_traefik_routes.py ./franchises/manifest.csv ./traefik/dynamic.yml