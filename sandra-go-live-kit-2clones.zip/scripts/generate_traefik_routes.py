#!/usr/bin/env python3
import sys, csv, yaml
def main(csv_path, out_path):
    with open(csv_path, newline='', encoding='utf-8') as f:
        rows = list(csv.DictReader(f))
    routers = {}
    for r in rows:
        host = r.get("domain") or ""
        if not host:
            sector = r.get("sector","").strip()
            modelo = r.get("modelo","").strip()
            if sector and modelo:
                host = f"{sector}-{modelo}.guestsvalencia.es"
        name = host.replace(".","-")
        routers[name] = {"rule": f"Host(`{host}`)", "entryPoints": ["websecure"], "tls": {"certResolver": "le"}, "service":"sandra-site"}
    cfg = {"http":{"routers": routers}}
    import yaml as _y; open(out_path,"w",encoding="utf-8").write(_y.safe_dump(cfg, sort_keys=True, allow_unicode=True))
    print(f"Wrote {out_path} with {len(routers)} routers.")
if __name__ == "__main__":
    if len(sys.argv)<3:
        print("Usage: generate_traefik_routes.py <manifest.csv> <out.yml>"); sys.exit(1)
    main(sys.argv[1], sys.argv[2])