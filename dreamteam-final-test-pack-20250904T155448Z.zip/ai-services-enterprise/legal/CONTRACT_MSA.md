# MSA (resumen)
