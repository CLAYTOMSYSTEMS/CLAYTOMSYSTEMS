# PROPOSAL — Sandra for Hotels (Pilot 30 días)
Precio: €5.000
