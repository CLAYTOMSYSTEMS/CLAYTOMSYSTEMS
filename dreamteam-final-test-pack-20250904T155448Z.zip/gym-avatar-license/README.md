# Gym Avatar — Licencia mensual objetivo €2K
