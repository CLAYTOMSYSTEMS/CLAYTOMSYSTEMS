# Guion Daily (ES, educativo)
