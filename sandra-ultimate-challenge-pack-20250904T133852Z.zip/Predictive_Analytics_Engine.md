# Predictive Analytics Engine
- Forecast MRR/churn/CAC; entradas desde Excel; salida CSV y panel admin
