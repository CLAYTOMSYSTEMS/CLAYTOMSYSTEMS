# Business Model Canvas — Commerce

- Key Partners: Integradores, proveedores de datos, cloud, OpenAI/HeyGen
- Key Activities: Conversación voz con barge‑in, soporte, integraciones
- Value Prop: IA de voz interrumpible, verticalizada, despliegue <10min
- Relationships: Onboarding guiado, CSM, formación
- Segments: decisores del sector Commerce
- Resources: modelos en tiempo real, prompts, devops
- Channels: partners, demo en vivo, redes
- Costs: infra, soporte, ventas/marketing, R&D
- Revenues: suscripción, implantación, consumo por minutos, add‑ons
