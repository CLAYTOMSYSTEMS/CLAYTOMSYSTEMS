# Mobile PWA Specs
- Conversación barge‑in, push, panel conversaciones, métricas rápidas, roles
- Tech: React/Next, Tailwind, WebSocket seguro, PWA
