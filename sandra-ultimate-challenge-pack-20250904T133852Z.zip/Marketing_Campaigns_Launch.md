# 30-Day Launch Plan
W1: Video demo + LinkedIn + Email#1
W2: Webinar sectorial + casos ROI + Email#2
W3: Oferta lanzamiento + SDR + Email#3
W4: Partners + Ads performance
