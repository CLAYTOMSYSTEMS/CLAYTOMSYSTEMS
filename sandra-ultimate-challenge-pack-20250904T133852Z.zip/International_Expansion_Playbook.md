# International Expansion — EU · LatAm · US
- EU: ES/FR/DE/IT/PT, GDPR, SEPA, partners sectoriales
- LatAm: ES/PT-BR, pagos locales (PIX/SPEI), bundles y embajadores
- US: HIPAA-lite (Healthcare), CCPA, demos ROI y ferias
- KPIs: Payback <=6m, NRR >110%, win-rate >25%
