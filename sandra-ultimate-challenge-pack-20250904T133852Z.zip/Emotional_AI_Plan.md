# Emotional AI Plan
- Prosodia + sentimiento → estado; adaptar tono/ritmo; escalación humana si estrés alto
