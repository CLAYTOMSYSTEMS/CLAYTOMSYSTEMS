# AI Competitors (Voice & CX)
- Suites CX: Cognigy, LivePerson, Kore.ai
- Cloud: Dialogflow CX, AWS Lex, Azure Bot Service
- Voice-first: PolyAI, SoundHound
- Tooling/UI: Intercom, Zendesk bots
DIF: barge‑in + avatar + verticalización + deploy <10min
