# Blockchain Integration
- Token de fidelización no especulativo; ownership de activos; wallets light; provider-agnostic
