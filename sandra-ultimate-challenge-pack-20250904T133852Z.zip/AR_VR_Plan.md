# AR/VR Plan
- WebXR para tours; overlays de conversación; hooks para Unity/Unreal
