'use client'
import Script from 'next/script'
export default function GA(){
  const mid = process.env.NEXT_PUBLIC_GA_MEASUREMENT_ID
  if (!mid) return null
  return (<>
    <Script src={`https://www.googletagmanager.com/gtag/js?id=${mid}`} strategy="afterInteractive" />
    <Script id="ga-init" strategy="afterInteractive">
      {`
       window.dataLayer = window.dataLayer || [];
       function gtag(){dataLayer.push(arguments);}
       gtag('js', new Date());
       gtag('config', '${mid}');
      `}
    </Script>
  </>)
}
