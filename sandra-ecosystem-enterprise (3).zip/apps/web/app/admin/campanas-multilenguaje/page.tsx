'use client'
export default function Campanas(){
  const token=typeof window!=='undefined'?localStorage.getItem('token'):''
  async function seed(){
    await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/campaigns/seed-multilang',{method:'POST',headers:{Authorization:'Bearer '+token}})
    alert('Plantillas EN/DE/FR/IT creadas')
  }
  return <div className="max-w-xl mx-auto p-8 space-y-4">
    <h2 className="text-2xl font-bold">Campañas multilenguaje</h2>
    <button onClick={seed} className="px-4 py-2 bg-white text-black rounded">Crear plantillas EN/DE/FR/IT</button>
  </div>
}
