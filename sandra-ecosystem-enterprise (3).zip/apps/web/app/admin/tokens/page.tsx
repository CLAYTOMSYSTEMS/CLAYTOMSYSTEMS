'use client'
import { useEffect, useState } from 'react'
export default function Tokens(){
  const [guestId,setGuestId]=useState<number>(1)
  const [balance,setBalance]=useState<number>(0)
  const [amount,setAmount]=useState<number>(10)
  const token = typeof window!=='undefined'?localStorage.getItem('token'):''
  async function load(){ const r=await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+`/tokens/${guestId}`,{headers:{Authorization:'Bearer '+token}}); const d=await r.json(); setBalance(d.balance||0) }
  async function award(){ await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/tokens/award',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({guest_id:guestId, amount})}); load() }
  useEffect(()=>{ load() },[guestId])
  return <div className="max-w-xl mx-auto p-8 space-y-3">
    <h2 className="text-2xl font-bold">Programa de Tokens</h2>
    <div className="flex gap-2"><input className="px-2 py-2 bg-white/10 rounded w-28" type="number" value={guestId} onChange={e=>setGuestId(Number(e.target.value))} /><button onClick={load} className="px-3 py-2 border rounded">Consultar</button></div>
    <p className="opacity-80">Saldo: <strong>{balance}</strong> tokens</p>
    <div className="flex gap-2"><input className="px-2 py-2 bg-white/10 rounded w-28" type="number" value={amount} onChange={e=>setAmount(Number(e.target.value))} /><button onClick={award} className="px-3 py-2 bg-white text-black rounded">Añadir</button></div>
  </div>
}
