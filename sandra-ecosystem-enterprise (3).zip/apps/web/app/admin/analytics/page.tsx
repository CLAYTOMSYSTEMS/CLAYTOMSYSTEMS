'use client'
import { useEffect, useState } from 'react'
export default function Analytics(){
  const [data,setData]=useState<any>(null)
  const token = typeof window!=='undefined'?localStorage.getItem('token'):''
  async function load(){ const r=await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/analytics/summary',{headers:{Authorization:'Bearer '+token}}); setData(await r.json()) }
  useEffect(()=>{ load() },[])
  if (!data) return <div className="p-8">Cargando…</div>
  return <div className="max-w-3xl mx-auto p-8 space-y-4">
    <h2 className="text-2xl font-bold">Analytics</h2>
    <div className="grid grid-cols-3 gap-3">
      <div className="glass p-4 rounded-xl"><div className="text-xs opacity-70">Reservas</div><div className="text-3xl font-bold">{data.totals.reservations}</div></div>
      <div className="glass p-4 rounded-xl"><div className="text-xs opacity-70">Huéspedes</div><div className="text-3xl font-bold">{data.totals.guests}</div></div>
      <div className="glass p-4 rounded-xl"><div className="text-xs opacity-70">Tokens</div><div className="text-3xl font-bold">{data.totals.tokens||0}</div></div>
    </div>
    <div className="glass p-4 rounded-xl">
      <div className="text-sm opacity-70 mb-2">Reservas últimos 7 días</div>
      <ul className="text-sm space-y-1">
        {data.reservations_last7.map((r:any)=>(<li key={r.d} className="flex justify-between"><span>{r.d}</span><span>{r.c}</span></li>))}
      </ul>
    </div>
  </div>
}
