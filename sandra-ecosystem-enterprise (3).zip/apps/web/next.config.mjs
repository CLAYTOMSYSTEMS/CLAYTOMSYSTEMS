export default {
  reactStrictMode: true,
  async headers() {
    return [{
      source: '/(.*)',
      headers: [
        { key: 'X-Frame-Options', value: 'ALLOW-FROM https://app.heygen.com' },
        { key: 'Content-Security-Policy', value: "default-src 'self'; img-src 'self' data: https:; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; frame-src 'self' https://app.heygen.com; connect-src 'self' https://api.openai.com http://localhost:4000 https://app.guestsvalencia.es https://sandra.guestsvalencia.es ws://localhost:4000 wss://api.openai.com" }
      ]
    }]
  },
}
