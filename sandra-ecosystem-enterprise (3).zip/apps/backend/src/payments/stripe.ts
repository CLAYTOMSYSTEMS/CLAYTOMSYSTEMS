import Stripe from 'stripe'
const stripe = new Stripe(process.env.STRIPE_SECRET||'', { apiVersion: '2024-06-20' } as any)
export async function createCheckoutSession(params:{amount:number,currency:string,success_url:string,cancel_url:string,customer_email?:string}){
  const s = await stripe.checkout.sessions.create({
    mode: 'payment',
    payment_method_types: ['card'],
    line_items: [{ price_data: { currency: params.currency, product_data:{ name:'Reserva Guests Valencia' }, unit_amount: Math.round(params.amount*100) }, quantity: 1 }],
    success_url: params.success_url, cancel_url: params.cancel_url,
    customer_email: params.customer_email,
    // Connect ready: transfer_group or on_behalf_of si procede
  })
  return { id: s.id, url: s.url }
}
export function verifyWebhook(sig:string, raw:string){
  const secret = process.env.STRIPE_WEBHOOK_SECRET||''
  return stripe.webhooks.constructEvent(raw, sig, secret)
}
