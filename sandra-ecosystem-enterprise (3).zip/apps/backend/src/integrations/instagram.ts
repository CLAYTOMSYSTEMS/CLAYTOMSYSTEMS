import fetch from 'node-fetch'
const IG_ID = process.env.IG_BUSINESS_ID||''
const IG_TOKEN = process.env.IG_ACCESS_TOKEN||''

async function igCreateContainer(body:any){
  const url = `https://graph.facebook.com/v18.0/${IG_ID}/media`
  const res = await fetch(url, { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body: new URLSearchParams(body as any) })
  const js = await res.json()
  if (!res.ok) throw new Error(JSON.stringify(js))
  return js
}
async function igPublish(id:string){
  const res = await fetch(`https://graph.facebook.com/v18.0/${IG_ID}/media_publish`, { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body: new URLSearchParams({ creation_id: id, access_token: IG_TOKEN }) })
  const js = await res.json()
  if (!res.ok) throw new Error(JSON.stringify(js))
  return js
}

export async function publishImage(caption:string, image_url:string){
  if (!IG_ID || !IG_TOKEN) throw new Error('IG not configured')
  const { id } = await igCreateContainer({ image_url, caption, access_token: IG_TOKEN })
  return await igPublish(id)
}
export async function publishVideo(caption:string, video_url:string, cover_url?:string){
  if (!IG_ID || !IG_TOKEN) throw new Error('IG not configured')
  const { id } = await igCreateContainer({ media_type:'REELS', video_url, caption, thumb_offset: 0, access_token: IG_TOKEN })
  return await igPublish(id)
}
