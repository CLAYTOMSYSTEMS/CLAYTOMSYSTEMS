export type Tier = 'basic' | 'pro' | 'enterprise' | 'ultimate'
export function allow(feature:string){
  const tier = (process.env.LICENSE_TIER||'enterprise') as Tier
  const matrix: Record<Tier, string[]> = {
    basic: ['chat','reservations'],
    pro: ['chat','reservations','analytics','pwa'],
    enterprise: ['chat','reservations','analytics','pwa','payments','social','outreach','calls','autopilot'],
    ultimate: ['chat','reservations','analytics','pwa','payments','social','outreach','calls','autopilot','franchise']
  }
  return matrix[tier].includes(feature)
}
