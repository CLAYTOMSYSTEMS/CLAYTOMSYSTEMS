
'use client'
import { useEffect, useState } from 'react'
export default function SOS(){
  const [loc,setLoc]=useState<any>(null)
  const [sent,setSent]=useState(false)
  function getLoc(){ if(navigator.geolocation){ navigator.geolocation.getCurrentPosition(p=>setLoc({lat:p.coords.latitude,lng:p.coords.longitude})) } }
  async function trigger(){
    const r = await fetch((process.env.NEXT_PUBLIC_SANDRA_API_URL||'http://localhost:4000')+'/sos/trigger',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({lat:loc?.lat,lng:loc?.lng,note:'SOS desde PWA'})})
    if(r.ok) setSent(true)
  }
  useEffect(()=>{ getLoc() },[])
  return <main className="p-8 space-y-4">
    <h1 className="text-3xl font-bold">SOS</h1>
    <p className="opacity-80">Si estás en peligro o ves una emergencia, llama al <a className="underline" href="tel:112">112</a>. Este envío sólo notifica a Guests Valencia.</p>
    {loc ? <p className="text-sm opacity-70">Ubicación: {loc.lat.toFixed(5)}, {loc.lng.toFixed(5)}</p> : <button onClick={getLoc} className="px-4 py-2 border rounded">Permitir ubicación</button>}
    <button onClick={trigger} className="px-4 py-3 bg-white text-black rounded text-lg">ENVIAR SOS</button>
    {sent && <p className="text-green-400">Enviado. Te contactaremos.</p>}
  </main>
}
