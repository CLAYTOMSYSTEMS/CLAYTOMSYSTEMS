import fs from 'node:fs'
import path from 'node:path'

const brands = [
  { code:'london',  city:'London',  ai:'Julia', domain:'claytom.london' },
  { code:'paris',   city:'Paris',   ai:'Marie', domain:'claytom.paris' },
  { code:'berlin',  city:'Berlin',  ai:'Anna',  domain:'claytom.berlin' },
  { code:'rome',    city:'Rome',    ai:'Lucia', domain:'claytom.roma' },
  { code:'nyc',     city:'New York',ai:'Sarah', domain:'claytom.nyc' },
  { code:'tokyo',   city:'Tokyo',   ai:'Yuki',  domain:'claytom.tokyo' },
  { code:'dubai',   city:'Dubai',   ai:'Aisha', domain:'claytom.dubai' },
]

const base = path.resolve('.')
const out = path.join(base,'franchises')
fs.mkdirSync(out, { recursive:true })

for (const b of brands){
  const dir = path.join(out, b.code)
  fs.mkdirSync(dir, { recursive: true })
  fs.writeFileSync(path.join(dir, '.env'), `BRAND_CITY=${b.city}\nBRAND_AI_NAME=${b.ai}\nPRIMARY_DOMAIN=${b.domain}\nLICENSE_TIER=enterprise\n`)
  fs.writeFileSync(path.join(dir, 'branding.json'), JSON.stringify({ name: `Claytom ${b.city}`, ai: b.ai, primaryColor: '#0ea5e9' }, null, 2))
  console.log('Created franchise', b.code)
}
