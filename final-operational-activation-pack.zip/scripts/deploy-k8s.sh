#!/usr/bin/env bash
set -euo pipefail
NS=${1:-clay}
kubectl create ns "$NS" || true
kubectl apply -n "$NS" -f k8s/nats.yaml
kubectl create configmap chatbots --from-file=chatbots.json=chatbots-710.json -n "$NS" --dry-run=client -o yaml | kubectl apply -f -
for f in profiles-service metrics-service api-gateway orchestrator simulation-worker command-center; do
  kubectl apply -n "$NS" -f "k8s/$f.yaml"
done
echo "✅ Deploy solicitado. Usa: kubectl get pods -n $NS"
