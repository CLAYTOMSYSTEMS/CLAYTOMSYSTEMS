#!/usr/bin/env bash
API=${API:-http://localhost:8081}
MET=${MET:-http://localhost:8082}
set -e
curl -s $API/health && echo
curl -s $API/chatbots?limit=3 | jq '.count'
curl -s -X POST $API/commands -H 'content-type: application/json' -d '{"command":"/activate sales 25"}' && echo
sleep 3
curl -s $API/leads && echo
curl -s $API/performance && echo
