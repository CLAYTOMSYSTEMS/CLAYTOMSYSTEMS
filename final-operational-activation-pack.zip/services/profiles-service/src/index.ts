import express from "express";
import cors from "cors";
import fs from "fs";

const PORT = process.env.PORT || 8080;
const CHATBOTS_PATH = process.env.CHATBOTS_PATH || "/config/chatbots.json";

const app = express();
app.use(cors());

let chatbots:any[] = [];
try {
  chatbots = JSON.parse(fs.readFileSync(CHATBOTS_PATH, "utf-8"));
  console.log(`[profiles] loaded ${chatbots.length} chatbots from`, CHATBOTS_PATH);
} catch (e:any){ console.error("Failed to load chatbots:", e.message); }

app.get("/health", (_req,res)=>res.json({ok:true, service:"profiles"}));

app.get("/chatbots", (req,res)=>{
  const { role, limit } = req.query as any;
  let data = chatbots;
  if (role) data = data.filter(b => b.role===role);
  const n = parseInt(limit || "0", 10);
  if (n>0) data = data.slice(0, n);
  res.json({ count: data.length, items: data });
});

app.listen(PORT, ()=>console.log(`[profiles] listening on ${PORT}`));