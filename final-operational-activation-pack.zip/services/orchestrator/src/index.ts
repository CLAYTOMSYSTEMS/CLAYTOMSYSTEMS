import { connect } from "nats";
import axios from "axios";

const NATS_URL = process.env.NATS_URL || "nats://nats.clay.svc.cluster.local:4222";
const PROFILES_URL = process.env.PROFILES_URL || "http://profiles:8080";
const METRICS_URL = process.env.METRICS_URL || "http://metrics:8082";

function parseCommand(cmd: any){
  const s = (cmd?.command || "").trim();
  const parts = s.split(/\s+/);
  const keyword = parts[0]?.replace(/^\//,"");
  return { keyword, parts };
}

(async () => {
  const nc = await connect({ servers: NATS_URL });
  console.log("[orchestrator] NATS connected", NATS_URL);

  const sub = nc.subscribe("ceo.command");
  console.log("[orchestrator] listening ceo.command");

  for await (const m of sub) {
    const payload = JSON.parse(new TextDecoder().decode(m.data));
    const { keyword, parts } = parseCommand(payload);
    console.log("[orchestrator] cmd:", keyword, parts);

    if (keyword === "activate") {
      const sector = parts[1] || "sales";
      const count = parseInt(parts[2] || "10", 10);
      await nc.publish("bot.activate", new TextEncoder().encode(JSON.stringify({ sector, count })));
    }
    if (keyword === "status") {
      await axios.post(`${METRICS_URL}/event`, { type: "status.requested", ts: Date.now() }).catch(()=>{});
    }
    if (keyword === "leads") {
      await axios.post(`${METRICS_URL}/event`, { type: "leads.requested", ts: Date.now() }).catch(()=>{});
    }
    if (keyword === "revenue") {
      await axios.post(`${METRICS_URL}/event`, { type: "revenue.requested", ts: Date.now() }).catch(()=>{});
    }
    if (keyword === "performance") {
      await axios.post(`${METRICS_URL}/event`, { type: "performance.requested", ts: Date.now() }).catch(()=>{});
    }
  }
})().catch(err => {
  console.error(err); process.exit(1);
});