import express from "express";
import cors from "cors";

const PORT = process.env.PORT || 8082;

const app = express();
app.use(cors());
app.use(express.json());

let counters:any = {
  leads: 0, calls: 0, chats: 0, revenueCents: 0,
  startedAt: Date.now()
};

app.get("/health", (_req,res)=>res.json({ok:true, service:"metrics"}));
app.get("/status", (_req,res)=>res.json({ up: true, since: counters.startedAt }));
app.get("/leads", (_req,res)=>res.json({ leads: counters.leads }));
app.get("/revenue", (_req,res)=>res.json({ revenueCents: counters.revenueCents }));
app.get("/performance", (_req,res)=>res.json({ calls: counters.calls, chats: counters.chats }));

app.post("/event", (req,res)=>{
  const { type, amountCents=0 } = req.body || {};
  if (type === "lead.generated") counters.leads++;
  if (type === "call.completed") counters.calls++;
  if (type === "chat.answered") counters.chats++;
  if (type === "payment.captured") counters.revenueCents += amountCents;
  res.json({ ok: true, counters });
});

app.listen(PORT, ()=>console.log(`[metrics] listening on ${PORT}`));