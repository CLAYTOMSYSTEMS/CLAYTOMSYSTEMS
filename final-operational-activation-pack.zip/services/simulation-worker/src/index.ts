import { connect } from "nats";
import fetch from "node-fetch";

const NATS_URL = process.env.NATS_URL || "nats://nats.clay.svc.cluster.local:4222";
const METRICS_URL = process.env.METRICS_URL || "http://metrics:8082";
const SIMULATE = process.env.SIMULATE === "1";

(async () => {
  const nc = await connect({ servers: NATS_URL });
  console.log("[simulation] NATS connected", NATS_URL);

  const sub = nc.subscribe("bot.activate");
  console.log("[simulation] listening bot.activate");

  for await (const m of sub) {
    const payload = JSON.parse(new TextDecoder().decode(m.data));
    const { sector, count } = payload;
    console.log("[simulation] activating", sector, count);

    if (!SIMULATE) continue;
    for (let i=0;i<count;i++){
      await fetch(`${METRICS_URL}/event`, { method:"POST", headers:{ "content-type":"application/json" },
        body: JSON.stringify({ type:"lead.generated" }) });
      await fetch(`${METRICS_URL}/event`, { method:"POST", headers:{ "content-type":"application/json" },
        body: JSON.stringify({ type:"call.completed" }) });
      await fetch(`${METRICS_URL}/event`, { method:"POST", headers:{ "content-type":"application/json" },
        body: JSON.stringify({ type:"chat.answered" }) });
    }
  }
})().catch(err => { console.error(err); process.exit(1); });