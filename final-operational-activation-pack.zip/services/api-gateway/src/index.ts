import express from "express";
import cors from "cors";
import { connect } from "nats";
import { createServer } from "http";
import { Server } from "socket.io";
import axios from "axios";

const PORT = process.env.PORT || 8081;
const NATS_URL = process.env.NATS_URL || "nats://nats.clay.svc.cluster.local:4222";
const PROFILES_URL = process.env.PROFILES_URL || "http://profiles:8080";
const METRICS_URL = process.env.METRICS_URL || "http://metrics:8082";

const app = express();
app.use(cors());
app.use(express.json());

const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: "*" } });

let nc: any;
(async () => {
  nc = await connect({ servers: NATS_URL });
  console.log("[gateway] NATS connected", NATS_URL);
})().catch(err => {
  console.error("NATS connection error:", err);
  process.exit(1);
});

io.on("connection", (socket) => {
  console.log("[gateway] WS client connected", socket.id);
  socket.on("command", async (payload) => {
    if (!nc) return;
    await nc.publish("ceo.command", new TextEncoder().encode(JSON.stringify(payload)));
    socket.emit("ack", { ok: true });
  });
});

app.get("/health", (_req, res) => res.json({ ok: true, service: "api-gateway" }));

app.get("/chatbots", async (_req, res) => {
  try {
    const { data } = await axios.get(`${PROFILES_URL}/chatbots`);
    res.json(data);
  } catch (e:any) { res.status(500).json({ error: e.message }); }
});

app.post("/commands", async (req, res) => {
  const payload = req.body || {};
  if (!nc) return res.status(503).json({ error: "NATS not connected" });
  await nc.publish("ceo.command", new TextEncoder().encode(JSON.stringify(payload)));
  res.json({ ok: true });
});

app.get("/status", async (_req, res) => {
  try {
    const { data } = await axios.get(`${METRICS_URL}/status`);
    res.json(data);
  } catch (e:any) { res.status(500).json({ error: e.message }); }
});

app.get("/leads", async (_req, res) => {
  try {
    const { data } = await axios.get(`${METRICS_URL}/leads`);
    res.json(data);
  } catch (e:any) { res.status(500).json({ error: e.message }); }
});

app.get("/revenue", async (_req, res) => {
  try {
    const { data } = await axios.get(`${METRICS_URL}/revenue`);
  res.json(data);
  } catch (e:any) { res.status(500).json({ error: e.message }); }
});

app.get("/performance", async (_req, res) => {
  try {
    const { data } = await axios.get(`${METRICS_URL}/performance`);
    res.json(data);
  } catch (e:any) { res.status(500).json({ error: e.message }); }
});

httpServer.listen(PORT, () => console.log(`[gateway] listening on ${PORT}`));