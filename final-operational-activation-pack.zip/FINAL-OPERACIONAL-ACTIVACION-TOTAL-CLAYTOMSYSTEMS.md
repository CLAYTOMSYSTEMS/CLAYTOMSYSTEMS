# 🚀 FINAL-OPERACIONAL-ACTIVACION-TOTAL-CLAYTOMSYSTEMS

Este paquete deja listo el ecosistema para activar **1,110+ chatbots** y el **Centro de Comando del CEO** con métricas en tiempo real.

## Componentes
- `chatbots-710.json` → 400 nuevos + 310 base (plantillas) para completar 710 (roles de autonomía).
- `services/` → **api-gateway**, **orchestrator**, **profiles-service**, **metrics-service**, **simulation-worker** (Node.js/TS).
- `command-center/` → UI web del CEO con comandos `/activate`, `/status`, `/leads`, `/revenue`, `/performance`.
- `k8s/` → Manifiestos Kubernetes (NATS, Deployments, Services, Ingress placeholders).
- `scripts/` → Comandos de activación en 2 horas (smoke tests y simulación opcional).

## Métricas objetivo (2h)
- 50+ plantillas web sector (developers)
- 100+ leads (comerciales)
- 200+ llamadas simuladas (si no hay trunk real)
- 500+ chats respondidos (simulación controlada)
> **Nota**: Este pack incluye modo **SIMULACIÓN** para validación sin fuentes externas. Para leads reales, conecte APIs de CRM & telephony.

## Arranque rápido
```bash
kubectl create ns clay || true
# NATS para coordinación
kubectl apply -n clay -f k8s/nats.yaml

# Seed de chatbots
kubectl create configmap chatbots --from-file=chatbots.json=chatbots-710.json -n clay --dry-run=client -o yaml | kubectl apply -f -

# Servicios
kubectl apply -n clay -f k8s/profiles-service.yaml
kubectl apply -n clay -f k8s/metrics-service.yaml
kubectl apply -n clay -f k8s/api-gateway.yaml
kubectl apply -n clay -f k8s/orchestrator.yaml
kubectl apply -n clay -f k8s/simulation-worker.yaml  # solo si SIMULATE=1

# Centro de comando (ingress placeholder)
kubectl apply -n clay -f k8s/command-center.yaml
```

### Variables de entorno clave
- `NATS_URL` (por defecto: `nats://nats.clay.svc.cluster.local:4222`)
- `PROFILES_URL` (por defecto: `http://profiles:8080`)
- `METRICS_URL` (por defecto: `http://metrics:8082`)
- `SIMULATE` (`0|1` en simulation-worker)
- `LIVEKIT_URL` / credenciales → para el puente de voz (no obligatorio para este paquete)

## Comandos del CEO
- `/activate [sector] [count]`
- `/status`
- `/leads`
- `/revenue`
- `/performance`

Cada comando se publica en NATS (`ceo.command`) y lo ejecuta `orchestrator`.
