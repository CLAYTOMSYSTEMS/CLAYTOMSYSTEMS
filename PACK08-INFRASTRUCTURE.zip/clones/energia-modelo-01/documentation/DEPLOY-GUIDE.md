# Deploy Guide
1) `docker compose build`
2) Traefik: `Host(...)` → `sandra-site`
3) Verificar TLS y latencia
