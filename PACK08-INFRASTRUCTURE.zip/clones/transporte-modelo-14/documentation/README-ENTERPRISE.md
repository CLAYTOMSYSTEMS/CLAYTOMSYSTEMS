# Sandra Infrastructure · transporte modelo-14 — Enterprise Pack

Dominio objetivo: `transporte-modelo-14.guestsvalencia.es`
Fecha: 2025-09-04 13:09:52Z

## Arranque rápido
```
docker compose up -d --build
# visita http://localhost:8080
```

## Producción (Traefik)
Router `Host(transporte-modelo-14.guestsvalencia.es)` → service `sandra-site`.

## Mic 3-en-1
- HTTPS obligatorio
- VAD por defecto: 0.045
- Barge-in: hablar interrumpe locución
