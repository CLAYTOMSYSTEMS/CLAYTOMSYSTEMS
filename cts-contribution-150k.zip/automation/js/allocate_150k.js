const fs = require('fs'), path = require('path');
const args = require('minimist')(process.argv.slice(2));
const plan = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../../data/contribution_150k_plan.json'),'utf-8'));
const subs = args.subs || 'pricing';
const out = path.resolve(args.out || path.resolve(__dirname, '../../out'));
const DRY = !!args['dry-run'];
if (!fs.existsSync(out)) fs.mkdirSync(out, { recursive: true });

const rec = plan.allocation.find(x => x.subsidiary === subs);
if (!rec){ console.error('Subsidiary not found:', subs); process.exit(1); }

function rolesForBlock(){ return Array(5).fill('Director').concat(Array(10).fill('Coordinator'), Array(10).fill('Specialist'), Array(5).fill('Innovator')); }

let produced = 0;
for (let b = 1; b <= rec.blocks_30; b++){
  const shard = [];
  const roles = rolesForBlock();
  roles.forEach((role, i) => {
    const id = `${subs}-b${String(b).padStart(3,'0')}-${role.slice(0,3).toLowerCase()}-${String(i+1).padStart(3,'0')}`;
    shard.push({ id, subsidiary: subs, role, level: role==='Director'?'L4':(role==='Coordinator'?'L3':'L2'),
      subject: `org.claytom.${subs}.${role.toLowerCase()}.${id}` });
  });
  const file = path.resolve(out, `shard-${subs}-b${String(b).padStart(3,'0')}.jsonl`);
  fs.writeFileSync(file, shard.map(x=>JSON.stringify(x)).join('\n'));
  produced += shard.length;
  console.log('[SHARD]', file, shard.length);
  if (!DRY){
    // TODO: publicar a NATS o pipeline de ingestión
  }
}
console.log('[DONE]', subs, 'agents generated:', produced);
