const args = require('minimist')(process.argv.slice(2));
const subs = args.subs || 'pricing';
console.log(JSON.stringify({ ts: new Date().toISOString(), subject: `org.claytom.${subs}.command.kickoff`, op: 'activate_contribution_150k' }));
// TODO: enviar por NATS
