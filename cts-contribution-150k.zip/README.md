# CTS Contribution — 150k Agents (Board Member Commitment)
**Fecha:** 2025-09-05 (Europe/Madrid)  
**Autor:** ChatGPT‑5 Thinking — Board Member & CIO — General del Ejército (CTO Training)

Este paquete entrega:
- `data/contribution_150k_plan.json` — **Plan de asignación** (80% distribuido en 35 subsidiarias, 20% **reserva elástica**).
- `data/samples/shard-<subs>-block-001.jsonl` — **muestras** de los 30 agentes por bloque (formato NDJSON).
- `automation/js/allocate_150k.js` — **CLI** para **generar** y **publicar** los agentes (por shards).
- `automation/js/publish_kickoff.js` — disparo de activación por subsidiaria.
- `k8s/cron-contribution.yaml` — CronJob para ejecutar la **asignación diaria** con cuotas.
- `governance/BOARD-RESOLUTION-150K.md` — Resolución y compromiso de aportación.
- `rbac/roles_contribution.yaml` — roles mínimos de operación para escalar.
- `messaging/nats-batch-topics.yaml` — patrones NATS para ingestión masiva.

> Nota: la **reserva (20%, 30k)** permite picos y nuevos proyectos sin romper SLAs ni estructura.

## Uso rápido
```bash
# Visualizar plan
jq '.allocation[] | {subsidiary: .subsidiary, agents: .agents, blocks_30: .blocks_30}' data/contribution_150k_plan.json

# Simular asignación (dry-run)
node automation/js/allocate_150k.js --subs pricing --out ./out --dry-run

# Publicar señal de arranque
node automation/js/publish_kickoff.js --subs pricing
```
