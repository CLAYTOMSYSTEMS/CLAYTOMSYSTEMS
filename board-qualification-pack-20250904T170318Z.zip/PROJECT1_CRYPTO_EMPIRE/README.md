# P1 — Crypto Empire
⚠️ Educativo/técnico. No es asesoramiento. Complete .env.template con credenciales reales.
