# P2 — Gym Avatares
⚠️ Educativo/técnico. No es asesoramiento. Complete .env.template con credenciales reales.
