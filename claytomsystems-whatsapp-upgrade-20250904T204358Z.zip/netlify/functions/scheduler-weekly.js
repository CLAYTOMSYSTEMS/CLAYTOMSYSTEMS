
import fs from 'node:fs';
export async function handler(){
  try {
    const raw = fs.readFileSync('web/data/salon-campaigns.json', 'utf-8');
    const cfg = JSON.parse(raw);
    const whatsapp = process.env.OWNER_WHATSAPP || '34XXXXXXXXX';
    const template = cfg.weekly?.[0]?.template || 'Campaña semanal';
    const txt = template.replaceAll('{{whatsapp}}', whatsapp);
    // Publica en Facebook (si hay credenciales); si no, dry‑run
    const resp = await fetch(`/.netlify/functions/social-post`);
    return { statusCode:200, body: JSON.stringify({ ok:true, text: txt, social: await resp.text() }) };
  } catch(e){
    return { statusCode:200, body:'weekly done (dry‑run)' };
  }
}
