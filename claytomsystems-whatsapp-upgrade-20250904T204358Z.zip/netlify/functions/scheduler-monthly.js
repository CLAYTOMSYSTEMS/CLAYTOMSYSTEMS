
import fs from 'node:fs';
export async function handler(){
  try {
    const raw = fs.readFileSync('web/data/salon-campaigns.json', 'utf-8');
    const cfg = JSON.parse(raw);
    const whatsapp = process.env.OWNER_WHATSAPP || '34XXXXXXXXX';
    const template = cfg.monthly?.[0]?.template || 'Campaña mensual';
    const txt = template.replaceAll('{{whatsapp}}', whatsapp);
    const resp = await fetch(`/.netlify/functions/social-post`);
    return { statusCode:200, body: JSON.stringify({ ok:true, text: txt, social: await resp.text() }) };
  } catch(e){
    return { statusCode:200, body:'monthly done (dry‑run)' };
  }
}
