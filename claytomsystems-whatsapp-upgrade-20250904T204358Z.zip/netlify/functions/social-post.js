
export async function handler(){
  const page = process.env.FB_PAGE_ID;
  const token = process.env.FB_ACCESS_TOKEN;
  if(!page || !token) return { statusCode:200, body:'dry-run: missing FB creds' };
  // Ejemplo: publicar un texto simple. Para imágenes o IG Graph, extender.
  const msg = `Post automático (Salon): recuerda pedir tu cita por WhatsApp`;
  const r = await fetch(`https://graph.facebook.com/v20.0/${page}/feed`, {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ message: msg, access_token: token })
  });
  return { statusCode: r.ok?200:500, body: await r.text() };
}
