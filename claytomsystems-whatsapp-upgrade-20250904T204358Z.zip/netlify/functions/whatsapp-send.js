
const GRAPH = "https://graph.facebook.com/v20.0";
export async function handler(event){
  if (event.httpMethod !== 'POST') return { statusCode: 405, body:'Method Not Allowed' };
  const { to, body } = JSON.parse(event.body||'{}');
  const token = process.env.WHATSAPP_ACCESS_TOKEN;
  const pnid = process.env.WHATSAPP_PHONE_NUMBER_ID;
  if(!to || !body) return { statusCode: 400, body:'missing to/body' };
  if(!token || !pnid) return { statusCode: 500, body:'missing env' };
  const r = await fetch(`${GRAPH}/${pnid}/messages`, {
    method:'POST', headers:{ 'Authorization':`Bearer ${token}`, 'Content-Type':'application/json' },
    body: JSON.stringify({ messaging_product:'whatsapp', to, type:'text', text:{ body } })
  });
  return { statusCode: r.ok?200:500, body: await r.text() };
}
