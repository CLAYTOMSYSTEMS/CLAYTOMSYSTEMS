
export async function handler(event){
  if(event.httpMethod!=='POST') return { statusCode:405, body:'Method Not Allowed' };
  const token = process.env.NETLIFY_ACCESS_TOKEN;
  const site = process.env.SITE_ID;
  if(!token || !site) return { statusCode:200, body:'Falta NETLIFY_ACCESS_TOKEN o SITE_ID en el entorno — configura manualmente en Netlify → Environment.' };
  const updates = JSON.parse(event.body||'{}');
  // Netlify env var API (per-site) — endpoint per variable
  let results = {};
  for (const [k,v] of Object.entries(updates)) {
    const r = await fetch(`https://api.netlify.com/api/v1/sites/${site}/env/${encodeURIComponent(k)}`, {
      method: 'PUT',
      headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ value: String(v), context: 'all' })
    });
    results[k] = r.status;
  }
  return { statusCode:200, body: JSON.stringify(results) };
}
