
const GRAPH = "https://graph.facebook.com/v20.0";

async function send(to, body) {
  const token = process.env.WHATSAPP_ACCESS_TOKEN;
  const pnid = process.env.WHATSAPP_PHONE_NUMBER_ID;
  if (!token || !pnid) return { ok:false, reason: 'missing token/pnid' };
  const r = await fetch(`${GRAPH}/${pnid}/messages`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${token}`, 'Content-Type':'application/json' },
    body: JSON.stringify({ messaging_product: 'whatsapp', to, type: 'text', text: { body } })
  });
  return { ok: r.ok, status: r.status, text: await r.text() };
}

export async function handler(event) {
  // GET — verification
  if (event.httpMethod === 'GET') {
    const v = new URLSearchParams(event.rawQuery || '');
    const mode = v.get('hub.mode'); const token = v.get('hub.verify_token'); const challenge = v.get('hub.challenge');
    if (mode === 'subscribe' && token === process.env.WHATSAPP_VERIFY_TOKEN) {
      return { statusCode: 200, body: challenge || '' };
    }
    return { statusCode: 403, body: 'Forbidden' };
  }

  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };

  try {
    const data = JSON.parse(event.body || '{}');
    const entry = data.entry?.[0]; const change = entry?.changes?.[0];
    const msg = change?.value?.messages?.[0];
    const from = msg?.from; const text = msg?.text?.body?.trim().toLowerCase();
    if (!from || !text) return { statusCode: 200, body: 'no-op' };

    // Simple NLU
    if (/(hola|buenas)/.test(text)) {
      await send(from, "¡Hola! Soy tu asistente. Escribe *cita* para reservar o *menu* para ver opciones.");
    } else if (/menu/.test(text)) {
      await send(from, "Menú rápido: *cita* (reservar), *promo* (ofertas), *ayuda* (contacto).");
    } else if (/(cita|reservar)/.test(text)) {
      const owner = process.env.OWNER_WHATSAPP;
      await send(from, "Genial. Dime *día* y *hora* aproximados y tu *nombre*. Te confirmamos por aquí.");
      if (owner) {
        await send(owner, `Solicitud de CITA desde WhatsApp\nCliente: ${from}\nMensaje: "${msg.text.body}"`);
      }
    } else if (/promo/.test(text)) {
      await send(from, "Esta semana: 10% en color. Pide tu cita aquí mismo.");
    } else if (/ayuda|contacto/.test(text)) {
      await send(from, "Te atiende el equipo en horario comercial. También puedes escribirnos por este canal 24/7.");
    } else {
      await send(from, "No he entendido. Escribe *menu* para ver opciones.");
    }
    return { statusCode: 200, body: 'ok' };
  } catch (e) {
    return { statusCode: 200, body: 'ignored' };
  }
}
