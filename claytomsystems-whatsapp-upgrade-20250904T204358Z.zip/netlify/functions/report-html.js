
export async function handler(event){
  const span = (new URLSearchParams(event.rawQuery||'').get('span')) || 'weekly';
  const html = `<!doctype html><meta charset="utf-8"><title>Reporte ${span}</title>
  <style>body{font-family:Inter,system-ui;-webkit-font-smoothing:antialiased;padding:28px;color:#0f172a}
  h1{margin:0 0 8px} table{border-collapse:collapse;width:100%} td,th{padding:8px;border-bottom:1px solid #e2e8f0}</style>
  <h1>Reporte ${span}</h1>
  <p>Mensajes atendidos (demo): 132 · Reservas solicitadas: 24 · Confirmadas: 17 · Campañas lanzadas: 1</p>
  <table><tr><th>Fecha</th><th>Canal</th><th>Detalle</th></tr>
  <tr><td>Hoy</td><td>WhatsApp</td><td>12 mensajes, 3 reservas</td></tr>
  <tr><td>Ayer</td><td>Facebook</td><td>Post semanal publicado</td></tr></table>`;
  return { statusCode:200, headers:{'content-type':'text/html; charset=utf-8'}, body: html };
}
