
# 📱 ClaytomSystems — SALON WhatsApp + Marketing Automation UPGRADE

Este paquete añade **integración WhatsApp Business**, **bookings por WhatsApp**, **marketing limitado (IG + FB)**, páginas nuevas y **funciones programadas** para Netlify, listo para claytomsystems.com / .es.

## Qué incluye
- Páginas nuevas (web/):
  - `/whatsapp-salon/` — One‑click setup (con Netlify API opcional) y guía del webhook
  - `/salon-packages/` — Paquetes listos para vender (Basic/Pro)
  - `/training-center/` — Centro de entrenamiento (overview + CTA)
- Datos: `web/data/salon-campaigns.json` (plantillas de campañas semanal/mensual)
- Funciones Netlify (serverless):
  - `whatsapp-webhook.js` — Verificación + recepción de mensajes y **auto‑respuesta/booking**
  - `whatsapp-send.js` — Envío de mensajes (API WhatsApp Cloud)
  - `netlify-set-env.js` — (opcional) Graba variables de entorno vía Netlify API
  - `social-post.js` — Publicación simple a **Facebook** (stub para IG Graph)
  - `scheduler-weekly.js` — Programa 1 campaña semanal (lee salon-campaigns.json)
  - `scheduler-monthly.js` — Programa 1 campaña mensual
  - `report-html.js` — Reporte HTML (daily/weekly) para enviar por WhatsApp o email
- `netlify.toml` con **crons** para campañas semanales/mensuales (ajusta horas si quieres).

## Variables de entorno (Netlify → Site settings → Environment)
- `WHATSAPP_VERIFY_TOKEN` — Token de verificación del webhook
- `WHATSAPP_ACCESS_TOKEN` — Token permanente/bearer del Business App
- `WHATSAPP_PHONE_NUMBER_ID` — Phone Number ID (Graph)
- `OWNER_WHATSAPP` — Teléfono del propietario con código país (ej. 34XXXXXXXXX)
- `FB_PAGE_ID` — ID de tu página de Facebook (para `social-post.js`)
- `FB_ACCESS_TOKEN` — Token con permisos `pages_manage_posts`
- `NETLIFY_ACCESS_TOKEN` y `SITE_ID` — *(opcionales)* para **one‑click setup** desde `/whatsapp-salon/`

> Webhook URL (en Meta Developers): `https://TU_DOMINIO/.netlify/functions/whatsapp-webhook`

## Despliegue
1. Copia el contenido de este paquete encima de tu repo actual (respeta estructura).
2. Commit & push. Netlify se encarga del build (estático) + deploy de funciones.
3. Configura env vars (manual o desde `/whatsapp-salon/` con tu **NETLIFY_ACCESS_TOKEN**).
4. En **Meta Developers**: valida el webhook (GET con `hub.verify_token`) y apunta a la URL.
5. Prueba enviando "hola" al número de WhatsApp Business.

## Límites / Notas
- Instagram Graph **requiere flujo adicional** (containers + publish). Aquí publicamos en **Facebook** y dejamos stub para IG.
- Bookings: se registran como **evento provisional** (mensaje a Owner + confirmación al cliente). Si quieres persistencia, conectamos Google Sheets/DB en un siguiente paso.
