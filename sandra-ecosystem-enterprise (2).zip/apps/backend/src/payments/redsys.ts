import crypto from 'node:crypto'
export function createRedsysForm(amount:number, order:string, merchantUrl:string, currency='978'){
  const params = {
    DS_MERCHANT_AMOUNT: String(Math.round(amount*100)),
    DS_MERCHANT_ORDER: order,
    DS_MERCHANT_MERCHANTCODE: process.env.REDSYS_MERCHANT_CODE||'',
    DS_MERCHANT_CURRENCY: currency,
    DS_MERCHANT_TRANSACTIONTYPE: '0',
    DS_MERCHANT_TERMINAL: process.env.REDSYS_TERMINAL||'1',
    DS_MERCHANT_MERCHANTNAME: process.env.REDSYS_MERCHANT_NAME||'Guests Valencia',
    DS_MERCHANT_URLOK: merchantUrl + '?ok=1',
    DS_MERCHANT_URLKO: merchantUrl + '?ok=0',
    DS_MERCHANT_MERCHANTURL: merchantUrl,
  }
  const json = Buffer.from(JSON.stringify(params)).toString('base64')
  const key = Buffer.from(process.env.REDSYS_SECRET_KEY||'', 'base64')
  const hmac = crypto.createHmac('sha256', key).update(json).digest('base64')
  return { Ds_SignatureVersion:'HMAC_SHA256_V1', Ds_MerchantParameters: json, Ds_Signature: hmac, url: process.env.REDSYS_URL||'https://sis.redsys.es/sis/realizarPago' }
}
