
# Brand-Switcher — Integración rápida
1) Despliega Traefik con `traefik-dynamic-categories.yml` (websecure + Let's Encrypt).
2) Configura servicio `brand-switcher` (tu gateway Express/Netlify adapter).
3) El gateway lee `brand-config.json` y resuelve `category` por prefijo de subdominio.
4) El gateway llama a `/.netlify/functions/registry-merged` para obtener `bot_id` por categoría (elegir default/rotación).
