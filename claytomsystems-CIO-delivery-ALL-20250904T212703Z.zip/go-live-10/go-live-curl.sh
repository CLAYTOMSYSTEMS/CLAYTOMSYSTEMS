# GO-LIVE quick test
# Variables
BASE="https://YOUR_DOMAIN"   # e.g., https://claytomsystems.com
FN="$BASE/.netlify/functions/bot-dispatcher"

# Test each bot
curl -s -X POST "$FN" -H "content-type: application/json" -d '{"bot_id":"cce-01","message":"Hola, quiero reservar para este fin de semana."}'
curl -s -X POST "$FN" -H "content-type: application/json" -d '{"bot_id":"sae-01","message":"Preséntame vuestra propuesta para hoteles."}'
curl -s -X POST "$FN" -H "content-type: application/json" -d '{"bot_id":"wce-01","message":"Tengo dudas en el checkout."}'
curl -s -X POST "$FN" -H "content-type: application/json" -d '{"bot_id":"tse-01","message":"Mi acceso no funciona."}'
curl -s -X POST "$FN" -H "content-type: application/json" -d '{"bot_id":"sse-01","message":"Quiero optimizar la recepción 24/7 del hotel."}'
curl -s -X POST "$FN" -H "content-type: application/json" -d '{"bot_id":"ade-01","message":"Agenda una reunión mañana a las 10."}'
curl -s -X POST "$FN" -H "content-type: application/json" -d '{"bot_id":"cce-02","message":"Atiende en inglés y español, por favor."}'
curl -s -X POST "$FN" -H "content-type: application/json" -d '{"bot_id":"sae-02","message":"Necesito una demo y precio."}'
curl -s -X POST "$FN" -H "content-type: application/json" -d '{"bot_id":"wce-02","message":"Guíame en mis primeros pasos."}'
curl -s -X POST "$FN" -H "content-type: application/json" -d '{"bot_id":"tse-02","message":"Tengo un error intermitente."}'
