
// /.netlify/functions/bot-dispatcher
import fs from 'node:fs';
export async function handler(event){
  try{
    const { bot_id, message } = JSON.parse(event.body||"{}");
    if(!bot_id) return { statusCode:400, body:"bot_id requerido" };
    // Resolve prompt (demo: search in current repo)
    function findPrompt(base){
      const p = `./${base}/${bot_id}/prompt.txt`;
      return fs.existsSync(p)? fs.readFileSync(p,'utf-8'): null;
    }
    const paths = [
      `chatbots/*/${bot_id}/prompt.txt`,
      `expansion/chatbots/*/${bot_id}/prompt.txt`,
      `expansion-100/chatbots/*/${bot_id}/prompt.txt`,
      `go-live-10/bots/${bot_id}/prompt.txt`
    ];
    let prompt = null;
    for(const pat of paths){
      const direct = pat.replace("/*/","/"); // naive attempt first
      if(fs.existsSync(direct)){ prompt = fs.readFileSync(direct,'utf-8'); break; }
    }
    if(!prompt){ prompt = "Eres un bot ClaytomSystems (demo). Responde en es-ES de forma breve."; }

    // Simulation mode if no API key
    if(!process.env.OPENAI_API_KEY){
      const demo = `🤖 [DEMO] ${bot_id}: ${message||"Hola"} — (respuesta simulada)`;
      return { statusCode:200, headers:{'content-type':'application/json'}, body: JSON.stringify({ bot_id, mode:"demo", reply: demo }) };
    }
    // Real call (pseudocode placeholder)
    // const resp = await fetch("https://api.openai.com/v1/chat/completions", { ... });
    return { statusCode:200, headers:{'content-type':'application/json'}, body: JSON.stringify({ bot_id, mode:"live", note:"Implementa llamada OpenAI aquí." }) };
  }catch(e){ return { statusCode:500, body:String(e) } }
}
