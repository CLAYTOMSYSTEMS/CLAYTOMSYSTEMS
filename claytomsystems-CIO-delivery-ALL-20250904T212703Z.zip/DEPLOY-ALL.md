
# DEPLOY TODO (A+B+C) — ClaytomSystems CIO Pack
Fecha: 20250904T212703Z

## 1) Subir al repo
- Copia **go-live-10/**, **expansion-100/**, **brand-switcher/** y **netlify/functions/** al repo principal.
- Mantén también el pack de **110** y el de **200** previo.

## 2) Netlify
- Variables:
  - `OPENAI_API_KEY` (opcional: live), si no → modo demo.
- Build (opcional): `node scripts/merge-registries.js` → genera `registry-all.json`.
- Endpoints:
  - `/.netlify/functions/registry-merged`
  - `/.netlify/functions/bot-dispatcher`

## 3) Traefik (Brand-switcher)
- Usa `brand-switcher/traefik-dynamic-categories.yml` para prefijos `cc|sales|web|tech|sector|admin` en **.com** y **.es**.
- O para 10 pilotos: `go-live-10/traefik-dynamic-10.yml`.
- Apunta servicios a tu `brand-switcher` gateway (o directamente a Netlify via TCP/HTTP if needed).

## 4) Go‑Live (10)
- Publica `go-live-10/go-live.html` para test.
- Ejecuta `go-live-10/go-live-curl.sh` (sustituye `YOUR_DOMAIN`).

## 5) Flota total
- 110 (original) + 200 (expansión) + **100 (este pack)** = **410** capacidad.
- UI de inventario: `/training-center/` (si lo incluyes del pack de 200).

## 6) Marketing/Revenue (resumen operativo)
- WhatsApp + IG/Facebook (limitado) → conectar tus tokens a dispatcher para activar campañas automáticas por categoría.
- Stripe/PayPal: vende licencias por bot o paquetes sectoriales (usa tu e‑commerce base ya integrado).
