import dotenv from "dotenv";
import { connect as natsConnect, StringCodec } from "nats";
dotenv.config();
const NATS_URL = process.env.NATS_URL || "nats://nats:4222";
const sc = StringCodec(); const state = { active:0, scaled:0, trained:0 };
function stamp(t,msg){ return JSON.stringify({ type:t, state, msg, ts: Date.now() }); }
(async () => {
  const nc = await natsConnect({ servers: NATS_URL }); console.log("[orchestrator] NATS", NATS_URL);
  const pub = (t,m)=>nc.publish("orchestrator.status", sc.encode(stamp(t,m)));
  pub("status","orchestrator-online");
  const commands = await nc.subscribe("ceo.command");
  for await (const m of commands) {
    const { type, payload } = JSON.parse(sc.decode(m.data));
    if (type==="bot.activate") state.active += (payload?.count||1);
    if (type==="bot.scale")    state.scaled += (payload?.count||1);
    if (type==="bot.train")    state.trained += (payload?.count||1);
    pub("status",`handled ${type}`);
  }
})().catch(err=>{console.error(err);process.exit(1)});
