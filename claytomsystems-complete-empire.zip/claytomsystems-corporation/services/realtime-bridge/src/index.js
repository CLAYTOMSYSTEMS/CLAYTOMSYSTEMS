// Placeholder for LiveKit <-> OpenAI Realtime bridge (minimal health endpoint)
import express from "express"; import cors from "cors"; import dotenv from "dotenv"; dotenv.config();
const app = express(); const PORT = process.env.PORT || 8090; app.use(cors());
app.get("/health",(req,res)=>res.json({ok:true, service:"realtime-bridge"}));
app.listen(PORT,()=>console.log(`[realtime-bridge] :${PORT}`));
