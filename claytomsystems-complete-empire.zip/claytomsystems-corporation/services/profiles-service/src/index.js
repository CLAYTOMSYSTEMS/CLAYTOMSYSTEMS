import express from "express";
import cors from "cors";
import morgan from "morgan";
import dotenv from "dotenv";
import fs from "fs";
dotenv.config();
const PORT = process.env.PORT || 8082;
const DATA_DIR = process.env.DATA_DIR || "/data/chatbots";
const app = express();
app.use(cors()); app.use(express.json({ limit:"1mb" })); app.use(morgan("dev"));
function load(file){ try{ return JSON.parse(fs.readFileSync(`${DATA_DIR}/${file}`,'utf-8')); }catch(e){ return []; } }
function catalog(){ return [...load('army-1710-specialists.json'), ...load('api-400-experts.json'), ...load('security-900-experts.json')]; }
app.get("/health",(req,res)=>res.json({ok:true,service:"profiles-service"}));
app.get("/chatbots",(req,res)=>res.json({ok:true, count: catalog().length, items: catalog().slice(0,1000)}));
app.get("/prompt/:ref",(req,res)=>res.type("text/plain").send(`# Prompt for ${req.params.ref}\n\nActúa como ${req.params.ref} y ayuda al usuario con precisión.`));
app.listen(PORT,()=>console.log(`[profiles-service] :${PORT}`));
