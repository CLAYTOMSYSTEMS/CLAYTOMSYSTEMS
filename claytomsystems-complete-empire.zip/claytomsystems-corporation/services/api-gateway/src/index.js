import express from "express";
import cors from "cors";
import morgan from "morgan";
import dotenv from "dotenv";
import { WebSocketServer } from "ws";
import { connect as natsConnect, StringCodec } from "nats";
import axios from "axios";

dotenv.config();
const PORT = process.env.PORT || 8080;
const PROFILES_URL = process.env.PROFILES_URL || "http://profiles-service:8082";
const NATS_URL = process.env.NATS_URL || "nats://nats:4222";

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(morgan("dev"));

app.get("/health", (req, res) => res.json({ ok: true, service: "api-gateway", time: new Date().toISOString() }));

app.get("/chatbots", async (req, res) => {
  try { const r = await axios.get(`${PROFILES_URL}/chatbots`); res.json(r.data); }
  catch (e) { res.status(502).json({ ok:false, error: e.message }); }
});

let nc; const sc = StringCodec();
(async () => { nc = await natsConnect({ servers: NATS_URL }); console.log("[api-gateway] NATS", NATS_URL); })().catch(err=>{console.error(err);process.exit(1)});

app.post("/commands", async (req, res) => {
  try {
    const { type, payload } = req.body || {};
    if (!type) return res.status(400).json({ ok:false, error:"Missing command type" });
    await nc.publish("ceo.command", sc.encode(JSON.stringify({ type, payload, ts: Date.now() })));
    res.json({ ok:true, published:true });
  } catch (e) { res.status(500).json({ ok:false, error:e.message }); }
});

const server = app.listen(PORT, () => console.log(`[api-gateway] :${PORT}`));
const wss = new WebSocketServer({ server, path: "/ws" });
wss.on("connection", (ws) => ws.send(JSON.stringify({ ok:true, msg:"ws-connected", service:"api-gateway" })));

(async () => {
  const sub = await nc.subscribe("orchestrator.status");
  for await (const m of sub) {
    const text = sc.decode(m.data);
    [...wss.clients].forEach((ws) => { if (ws.readyState === 1) ws.send(text); });
  }
})();
