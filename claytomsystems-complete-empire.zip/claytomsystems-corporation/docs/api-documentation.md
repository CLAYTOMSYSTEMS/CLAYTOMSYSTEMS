# ClayTomSystems — API Documentation (Resumen)

## api-gateway
- GET /health -> { ok, service, time }
- GET /chatbots -> proxy a profiles-service
- POST /commands { type, payload } -> publica en NATS "ceo.command"
- WS /ws -> stream de "orchestrator.status"

## orchestrator
- Suscribe "ceo.command"
- Emite "orchestrator.status" con métricas
- Tipos soportados: bot.activate, bot.scale, bot.train

## profiles-service
- GET /health
- GET /chatbots -> catálogo (merge 1710+400+900)
- GET /prompt/:ref -> prompt base (placeholder)
