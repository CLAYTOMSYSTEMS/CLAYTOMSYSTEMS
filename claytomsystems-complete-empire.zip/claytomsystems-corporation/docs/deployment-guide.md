# ClayTomSystems — Deployment Guide (Kubernetes)

## Prerequisitos
- Kubernetes cluster (>=1.26)
- NGINX Ingress + cert-manager (Let's Encrypt)
- GHCR credentials para images
- NATS (incluido en manifests)
- DNS apuntando a tu Ingress IP
- Secrets: KUBECONFIG_BASE64 en GitHub Actions

## Pasos
1) Namespace y NATS
   kubectl apply -f infrastructure/kubernetes/00-namespace.yaml
   kubectl apply -f infrastructure/kubernetes/01-nats.yaml

2) Servicios
   kubectl apply -f infrastructure/kubernetes/10-api-gateway.yaml
   kubectl apply -f infrastructure/kubernetes/11-orchestrator.yaml
   kubectl apply -f infrastructure/kubernetes/12-profiles-service.yaml

3) Ingress + TLS
   kubectl apply -f infrastructure/kubernetes/20-ingress.yaml

4) Montar datos (ejemplo con ConfigMap)
   kubectl create configmap chatbots-data --from-file=chatbots/ -n claytomsystems

5) Verificación
   curl https://api.claytomsystems.com/health
   curl https://profiles.claytomsystems.com/health

## CI/CD
- GitHub Actions: infrastructure/ci-cd/github-actions.yml

## SSL
- cert-manager con ClusterIssuer letsencrypt-production
- TLS wildcard recomendado *.claytomsystems.com
