import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import { createServer } from 'http'
import { WebSocketServer, WebSocket } from 'ws'
import Database from 'better-sqlite3'
import jwt from 'jsonwebtoken'
import bcrypt from 'bcryptjs'
import webpush from 'web-push'
import { buildItinerary, sendItinerary } from './concierge/itineraries.js'
import * as Resto from './concierge/restaurants.js'
import * as Srv from './concierge/services.js'
import * as CheckIn from './concierge/checkin.js'

const app = express()
app.use(express.json({ limit: '2mb' }))
import { secureHeaders } from './security/headers.js'
app.use(secureHeaders)
// --- Tracing / Error tracking ---
import * as Sentry from '@sentry/node'
import dd from 'dd-trace'
if (process.env.DD_TRACE_ENABLED === 'true') { dd.init({ service: process.env.DD_SERVICE || 'sandra-backend' }) }
if (process.env.SENTRY_DSN) { Sentry.init({ dsn: process.env.SENTRY_DSN }) }

// --- Rate limiting ---
import rateLimit from 'express-rate-limit'
function countryWeight(code?:string){const c=(code||'').toUpperCase(); if (['ES','GB','FR','DE','IT','US','AE','JP'].includes(c)) return 1; return 0.5}

const limiter = rateLimit({
  keyGenerator: (req:any)=> (req.ip||'') + ':' + (req.headers['cf-ipcountry']||''),
  max: (req:any, res:any)=>{ const base=Number(process.env.RATE_LIMIT_MAX||120); const w=countryWeight(req.headers['cf-ipcountry'] as string); return Math.ceil(base*w) },
  windowMs: Number(process.env.RATE_LIMIT_WINDOW_MS || 60000),
  max: Number(process.env.RATE_LIMIT_MAX || 120),
  standardHeaders: true,
  legacyHeaders: false
})
app.use(limiter)

// --- Field encryption (AES-256-GCM) ---
import crypto from 'node:crypto'
const ENC_KEY = (process.env.ENC_KEY||'').padEnd(32,'0').slice(0,32)
function enc(plain: string){ const iv=crypto.randomBytes(12); const cipher=crypto.createCipheriv('aes-256-gcm', Buffer.from(ENC_KEY), iv); const ct=Buffer.concat([cipher.update(plain,'utf8'), cipher.final()]); const tag=cipher.getAuthTag(); return Buffer.concat([iv,tag,ct]).toString('base64') }
function dec(token: string){ try{ const b=Buffer.from(token,'base64'); const iv=b.subarray(0,12); const tag=b.subarray(12,28); const ct=b.subarray(28); const decipher=crypto.createDecipheriv('aes-256-gcm', Buffer.from(ENC_KEY), iv); decipher.setAuthTag(tag); const pt=Buffer.concat([decipher.update(ct), decipher.final()]); return pt.toString('utf8') }catch{ return '' }}

// --- Audit logs ---
db.exec(`CREATE TABLE IF NOT EXISTS audit_logs (id INTEGER PRIMARY KEY, ts TEXT DEFAULT CURRENT_TIMESTAMP, user_id INTEGER, method TEXT, path TEXT, ip TEXT, ua TEXT, status INTEGER, meta TEXT)`)
app.use((req,res,next)=>{
  const start=Date.now()
  const end = res.end
  ;(res as any).end = function(...args:any[]){
    try{
      const status = res.statusCode
      db.prepare('INSERT INTO audit_logs (user_id, method, path, ip, ua, status, meta) VALUES (?,?,?,?,?,?,?)').run(
        (req as any).user?.sub || null, req.method, req.path, req.ip || (req.headers['x-forwarded-for'] as string)||'', (req.headers['user-agent']||'') as string, status, JSON.stringify({duration_ms:Date.now()-start})
      )
    }catch{}
    // @ts-ignore
    return end.apply(this, args)
  }
  next()
})


// --- CORS allowlist ---
const allowed = (process.env.ALLOWED_ORIGINS || '').split(',').map(s=>s.trim()).filter(Boolean)
app.use(cors({
  origin: (origin, cb) => {
    if (!origin) return cb(null, true)
    if (allowed.includes(origin)) return cb(null, true)
    return cb(new Error('CORS blocked for origin: '+origin))
  },
  credentials: true
}))

// --- Helmet + CSP ---
const csp = {
  useDefaults: true,
  directives: {
    "default-src": ["'self'"],
    "script-src": ["'self'", "'unsafe-inline'"],
    "style-src": ["'self'", "'unsafe-inline'"],
    "img-src": ["'self'", "data:", "https:"],
    "connect-src": ["'self'", "https://api.openai.com", ...(allowed.length?allowed:[])],
    "frame-src": ["'self'", "https://app.heygen.com"],
    "frame-ancestors": [...(allowed.length?allowed:[]),"https://app.guestsvalencia.es","https://sandra.guestsvalencia.es"]
  }
}
app.use(helmet({ contentSecurityPolicy: csp as any }))

// --- ENV ---
const PORT = Number(process.env.PORT) || 4000
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || ''
const OPENAI_REALTIME_MODEL = process.env.OPENAI_REALTIME_MODEL || 'gpt-4o-realtime-preview-2024-12-17'
const HEYGEN_EMBED_URL = process.env.HEYGEN_EMBED_URL || 'https://app.heygen.com/guest-valencia-sandra'
const JWT_SECRET = process.env.JWT_SECRET || 'change_me_for_prod'

// --- DB ---
const db = new Database('data/sandra.db')
db.exec(`
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, email TEXT UNIQUE, password_hash TEXT, role TEXT DEFAULT 'admin');
CREATE TABLE IF NOT EXISTS conversations (id INTEGER PRIMARY KEY, title TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY, conversation_id INTEGER, role TEXT, content TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS push_subs (id INTEGER PRIMARY KEY, data TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS guests (
  id INTEGER PRIMARY KEY,
  name TEXT,
  email TEXT UNIQUE,
  phone TEXT,
  tags TEXT DEFAULT '' -- comma separated
);
CREATE TABLE IF NOT EXISTS reservations (
  id INTEGER PRIMARY KEY,
  guest_id INTEGER,
  property TEXT,
  check_in TEXT,
  check_out TEXT,
  price REAL,
  status TEXT DEFAULT 'pending',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS tokens (
  id INTEGER PRIMARY KEY,
  guest_id INTEGER UNIQUE,
  balance INTEGER DEFAULT 0,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS campaigns (
  id INTEGER PRIMARY KEY,
  name TEXT,
  season TEXT, -- 'summer' | 'winter' | 'custom'
  channel TEXT, -- 'email' | 'social' | 'push'
  content TEXT,
  status TEXT DEFAULT 'draft',
  scheduled_at TEXT
);
CREATE TABLE IF NOT EXISTS social_queue (
  id INTEGER PRIMARY KEY,
  platform TEXT, -- 'instagram' | 'facebook' | 'tiktok'
  content TEXT,
  image_url TEXT,
  scheduled_at TEXT,
  status TEXT DEFAULT 'queued'
);
CREATE TABLE IF NOT EXISTS analytics_events (
  id INTEGER PRIMARY KEY,
  ts TEXT DEFAULT CURRENT_TIMESTAMP,
  type TEXT,
  guest_id INTEGER,
  props TEXT
);
`)
const upsertAdmin = db.prepare('INSERT OR IGNORE INTO users (email, password_hash, role) VALUES (?, ?, ?)')
try{ db.prepare("ALTER TABLE users ADD COLUMN twofa_enabled INTEGER DEFAULT 0").run() }catch{}
try{ db.prepare("ALTER TABLE users ADD COLUMN twofa_secret TEXT").run() }catch{}

const adminPass = bcrypt.hashSync(process.env.ADMIN_PASSWORD || 'admin', 8)
upsertAdmin.run(process.env.ADMIN_EMAIL || 'admin@guestsvalencia.es', adminPass, 'admin')
// Seed seasonal campaigns if empty
// Seed sales policy if empty
const polCount = db.prepare('SELECT COUNT(*) as c FROM sales_policies').get() as any
if (!polCount.c){
  const p = { airbnb_commission_pct: 15, booking_commission_pct: 15, extra_margin_pct: 3, default_currency: 'EUR', locales: ['es-ES','en-GB','fr-FR','de-DE','it-IT'] }
  db.prepare('INSERT INTO sales_policies (name, json) VALUES (?,?)').run('default', JSON.stringify(p))
}

// Seed content templates if empty
const countTpl = db.prepare('SELECT COUNT(*) as c FROM content_templates').get() as any
if (!countTpl.c) {
  const ins = db.prepare('INSERT INTO content_templates (category,name,template) VALUES (?,?,?)')
  ins.run('kids','Sandrita · Buenos días','Hola peques, soy Sandrita 🌞 Hoy aprenderemos sobre {tema} en {minutos} minutos. ¿Listos?')
  ins.run('promo','Promo · Verano playas','🌊 Verano en Valencia: {beneficio}. Reserva ahora con {descuento}% y regalo {extra}.')
  ins.run('wellness','Mindfulness 3 minutos','Respira conmigo: 3 ciclos de 4-4-6. Imagina una luz azul calmante. {afirmacion}')
}

const countCamp = db.prepare('SELECT COUNT(*) as c FROM campaigns').get() as any
if (!countCamp.c) {
  const seed = db.prepare('INSERT INTO campaigns (name, season, channel, content, status) VALUES (?, ?, ?, ?, ?)')
  seed.run('Verano · Early Beach','summer','social','🌞 Oferta verano: -12% en estancias + paella de bienvenida', 'draft')
  seed.run('Invierno · Termal Relax','winter','push','❄️ Termas Montanejos incluidas + -10% entre semana', 'draft')
  seed.run('Local Lovers','custom','email','🍽️ Ruta gastro valenciana + late checkout gratis', 'draft')
}


// --- Auth ---
function auth(req, res, next){
  const hdr = req.headers.authorization || ''
  const token = hdr.startsWith('Bearer ') ? hdr.slice(7) : null
  if (!token) return res.status(401).json({ error: 'No token' })
  try{
    const payload = jwt.verify(token, JWT_SECRET) as any
    ;(req as any).user = payload
    next()
  }catch(e){ return res.status(401).json({ error: 'Invalid token' }) }
}

// --- 2FA (TOTP) ---
import speakeasy from 'speakeasy'
import QRCode from 'qrcode'

app.post('/auth/2fa/setup', auth, async (req,res)=>{
  const secret = speakeasy.generateSecret({ name: 'Sandra IA · Guests Valencia' })
  const otpauth = secret.otpauth_url || ''
  const svg = await QRCode.toString(otpauth, { type:'svg' })
  db.prepare('UPDATE users SET twofa_secret=? WHERE id=?').run(enc(secret.base32), (req as any).user.sub)
  res.json({ svg, base32: secret.base32 })
})
app.post('/auth/2fa/enable', auth, (req,res)=>{
  const { token } = req.body || {}
  const row = db.prepare('SELECT twofa_secret FROM users WHERE id=?').get((req as any).user.sub) as any
  if (!row?.twofa_secret) return res.status(400).json({ error:'No setup' })
  const secret = dec(row.twofa_secret)
  const ok = speakeasy.totp.verify({ secret, encoding:'base32', token })
  if (!ok) return res.status(400).json({ error:'Invalid TOTP' })
  db.prepare('UPDATE users SET twofa_enabled=1 WHERE id=?').run((req as any).user.sub)
  res.json({ ok: true })
})

app.post('/auth/login', (req, res) => {
  const { email, password } = req.body || {}
  if (!email || !password) return res.status(400).json({ error: 'Missing credentials' })
  const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email)
  if (!row) return res.status(401).json({ error: 'User not found' })
  const ok = bcrypt.compareSync(password, row.password_hash)
  if (!ok) return res.status(401).json({ error: 'Bad password' })
  if (row.twofa_enabled){
    const totp = (req.body && req.body.totp) || ''
    const secretRow = db.prepare('SELECT twofa_secret FROM users WHERE id=?').get(row.id) as any
    const secret = secretRow?.twofa_secret ? dec(secretRow.twofa_secret) : ''
    const valid = secret && require('speakeasy').totp.verify({ secret, encoding:'base32', token: totp })
    if (!valid) return res.status(401).json({ error: '2FA required', need_2fa: true })
  }
  const token = jwt.sign({ sub: row.id, email: row.email, role: row.role }, JWT_SECRET, { expiresIn: '1h' })
  const refresh = crypto.randomBytes(24).toString('hex')
  db.prepare('INSERT INTO refresh_tokens (user_id, token, expires_at) VALUES (?,?, datetime("now", "+30 days"))').run(row.id, refresh)
  res.json({ token, refresh })
})

// --- Conversations ---
app.get('/conversations', auth, (_req, res)=>{
  const rows = db.prepare('SELECT * FROM conversations ORDER BY created_at DESC').all()
  res.json(rows)
})
app.post('/conversations', auth, (req, res)=>{
  const { title } = req.body || {}
  const info = db.prepare('INSERT INTO conversations (title) VALUES (?)').run(title || 'Nueva conversación')
  res.json({ id: info.lastInsertRowid, title: title || 'Nueva conversación' })
})
app.get('/conversations/:id/messages', auth, (req, res)=>{
  const rows = db.prepare('SELECT * FROM messages WHERE conversation_id=? ORDER BY id').all(Number(req.params.id))
  res.json(rows)
})
app.post('/messages', auth, (req, res)=>{
  const { conversation_id, role, content } = req.body || {}
  if (!conversation_id || !role) return res.status(400).json({ error:'Missing fields' })
  const info = db.prepare('INSERT INTO messages (conversation_id, role, content) VALUES (?, ?, ?)').run(conversation_id, role, content || '')
  res.json({ id: info.lastInsertRowid })
})

// --- Push (optional) ---
if (process.env.VAPID_PUBLIC && process.env.VAPID_PRIVATE){
  webpush.setVapidDetails(process.env.VAPID_SUBJECT || 'mailto:admin@guestsvalencia.es', process.env.VAPID_PUBLIC!, process.env.VAPID_PRIVATE!)
}
app.post('/push/subscribe', (req, res)=>{
  const data = JSON.stringify(req.body || {})
  db.prepare('INSERT INTO push_subs (data) VALUES (?)').run(enc(data))
  res.json({ ok: true })
})
app.post('/push/test', async (_req, res)=>{
  if (!process.env.VAPID_PUBLIC || !process.env.VAPID_PRIVATE) return res.status(400).json({ error:'No VAPID' })
  const subs = db.prepare('SELECT * FROM push_subs').all()
  for (const s of subs){
    try { const payload = JSON.parse(dec(s.data)); await webpush.sendNotification(payload, JSON.stringify({ title:'Sandra IA', body:'Hola desde Guests Valencia' })) } catch {}
  }
  res.json({ sent: subs.length })
})

// --- HeyGen endpoints ---
app.post('/heygen/session/new', (_req, res)=> res.json({ url: HEYGEN_EMBED_URL }))
app.post('/heygen/session/close', (_req, res)=> res.json({ ok: true }))

// --- Health ---
app.get('/healthz', (_req, res)=> res.json({ ok: true }))
import prom from 'prom-client'
if (process.env.PROMETHEUS_ENABLED==='true'){
  const collectDefaultMetrics = prom.collectDefaultMetrics
  collectDefaultMetrics()
  app.get('/metrics', (_req,res)=>{ res.setHeader('Content-Type', prom.register.contentType); prom.register.metrics().then(m=>res.send(m)) })
}

// ===== Integrations: Twilio, WhatsApp, YouTube, Instagram, TikTok =====
import { placeCall } from './integrations/twilio.js'
import { sendWhatsApp } from './integrations/whatsapp.js'
import { uploadYouTube } from './integrations/youtube.js'
import { publishImage, publishVideo } from './integrations/instagram.js'
import { uploadTikTok } from './integrations/tiktok.js'

app.post('/integrations/twilio/call', auth, async (req,res)=>{
  const { to, script } = req.body || {}
  try{ const r = await placeCall(String(to||''), String(script||'')); res.json(r) } catch(e){ res.status(400).json({ error: (e as Error).message }) }
})
app.post('/integrations/whatsapp/send', auth, async (req,res)=>{
  const { to, text } = req.body || {}
  try{ const r = await sendWhatsApp(String(to||''), String(text||'')); res.json(r) } catch(e){ res.status(400).json({ error: (e as Error).message }) }
})
app.post('/integrations/youtube/upload', auth, async (req,res)=>{
  const { title, description, privacyStatus, fileUrl } = req.body || {}
  try{ const r = await uploadYouTube({ title, description, privacyStatus, fileUrl }); res.json(r) } catch(e){ res.status(400).json({ error: (e as Error).message }) }
})
app.post('/integrations/instagram/publish', auth, async (req,res)=>{
  const { caption, image_url, video_url } = req.body || {}
  try{
    const r = image_url ? await publishImage(caption, image_url) : await publishVideo(caption, video_url)
    res.json(r)
  } catch(e){ res.status(400).json({ error: (e as Error).message }) }
})
app.post('/integrations/tiktok/upload', auth, async (req,res)=>{
  const { caption, video_url } = req.body || {}
  try{ const r = await uploadTikTok(caption, video_url); res.json(r) } catch(e){ res.status(400).json({ error: (e as Error).message }) }
})

// ===== CSV Import (guests & reservations) =====
import { parse } from 'csv-parse/sync'
app.post('/import/csv', auth, express.json({limit:'10mb'}), async (req,res)=>{
  const { base64, mapping } = req.body || {} // {base64:'...', mapping:{email:'Email', name:'Name', phone:'Phone', property:'Property', date:'CheckIn', nights:'Nights'}}
  if (!base64) return res.status(400).json({ error:'Missing base64' })
  const csv = Buffer.from(String(base64),'base64').toString('utf8')
  const rows = parse(csv, { columns: true, skip_empty_lines: true })
  let guests=0, reservations=0
  for (const r of rows){
    const email = r[mapping?.email||'email']?.trim()
    if (!email) continue
    const name = r[mapping?.name||'name']||''
    const phone = r[mapping?.phone||'phone']||''
    let g = db.prepare('SELECT * FROM guests WHERE email=?').get(email) as any
    if (!g){
      const info = db.prepare('INSERT INTO guests (name,email,phone,tags) VALUES (?,?,?,?)').run(name,email,phone,'import')
      g = { id: info.lastInsertRowid }; guests++
    }
    // Reservation
    const prop = r[mapping?.property||'property']||'N/A'
    const dt = r[mapping?.date||'date']||new Date().toISOString().slice(0,10)
    const nights = Number(r[mapping?.nights||'nights']||1)
    db.prepare('INSERT INTO reservations (guest_id, property, status, created_at) VALUES (?,?,?,?)').run(g.id, prop, 'imported', dt)
    reservations++
  }
  res.json({ guests, reservations })
})

// ===== Multilingual campaign seeds =====
app.post('/campaigns/seed-multilang', auth, (_req,res)=>{
  const ins = db.prepare('INSERT INTO campaigns (name, channel, payload, status) VALUES (?,?,?,?)')
  const langs = [
    ['EN','Welcome to Valencia! Enjoy {benefit}. Book direct and save fees.'],
    ['DE','Willkommen in Valencia! Genieße {benefit}. Direkt buchen und Gebühren sparen.'],
    ['FR','Bienvenue à Valence ! Profitez de {benefit}. Réservez direct et évitez les frais.'],
    ['IT','Benvenuti a Valencia! Godetevi {benefit}. Prenota diretto e risparmia.']
  ]
  for (const [lang, text] of langs){
    ins.run(`Summer · ${lang}`, 'social', JSON.stringify({ text, lang }), 'draft')
  }
  res.json({ ok: true, count: 4 })
})

// --- Payments API ---
import { createCheckoutSession, verifyWebhook } from './payments/stripe.js'
import { createOrder, captureOrder } from './payments/paypal.js'
import { createRedsysForm } from './payments/redsys.js'

app.post('/pay/stripe/session', async (req,res)=>{
  const { amount, currency='EUR', success_url, cancel_url, customer_email } = req.body || {}
  try{ const s = await createCheckoutSession({ amount:Number(amount||0), currency, success_url, cancel_url, customer_email }); res.json(s) }
  catch(e){ res.status(400).json({ error: (e as Error).message }) }
})
app.post('/pay/stripe/webhook', express.raw({type:'application/json'}), (req,res)=>{
  try{ const evt = verifyWebhook(req.headers['stripe-signature'] as string, (req as any).body.toString()) ; res.json({ received:true }) }
  catch(e){ res.status(400).send('invalid') }
})

app.post('/pay/paypal/order', async (req,res)=>{
  const { amount, currency='EUR' } = req.body || {}
  try{ const o = await createOrder(Number(amount||0), currency); res.json(o) } catch(e){ res.status(400).json({ error:(e as Error).message }) }
})
app.post('/pay/paypal/capture', async (req,res)=>{
  const { orderId } = req.body || {}
  try{ const r = await captureOrder(String(orderId||'')); res.json(r) } catch(e){ res.status(400).json({ error:(e as Error).message }) }
})

app.post('/pay/redsys/form', (req,res)=>{
  const { amount, order, return_url } = req.body || {}
  try{ const f = createRedsysForm(Number(amount||0), String(order||''), String(return_url||'')); res.json(f) } catch(e){ res.status(400).json({ error:(e as Error).message }) }
})


// --- HTTP server + WS proxy ---
const server = createServer(app)
const wss = new WebSocketServer({ server, path: '/openai/session' })

wss.on('connection', (client, req) => {
  if (!OPENAI_API_KEY){ client.close(1011, 'Server missing OPENAI_API_KEY'); return }
  const url = `wss://api.openai.com/v1/realtime?model=${encodeURIComponent(OPENAI_REALTIME_MODEL)}`
  const upstream = new WebSocket(url, { headers: { 'Authorization': `Bearer ${OPENAI_API_KEY}`, 'OpenAI-Beta': 'realtime=v1' } })

  upstream.on('open', ()=>{})
  upstream.on('message', (data)=>{ try{ client.readyState===WebSocket.OPEN && client.send(data) }catch{} })
  upstream.on('close', (c,r)=>{ try{ client.close(c, r.toString()) }catch{} })
  upstream.on('error', ()=>{ try{ client.close(1011, 'Upstream error') }catch{} })

  client.on('message', (data)=>{ try{ upstream.readyState===WebSocket.OPEN && upstream.send(data) }catch{} })
  client.on('close', ()=>{ try{ upstream.close() }catch{} })
  client.on('error', ()=>{ try{ upstream.close() }catch{} })
})


// ---- CRM Guests ----
app.get('/guests', auth, (_req, res)=>{
  const rows = db.prepare('SELECT * FROM guests ORDER BY id DESC').all()
  res.json(rows)
})
app.post('/guests', auth, (req, res)=>{
  const { name, email, phone, tags } = req.body || {}
  const info = db.prepare('INSERT INTO guests (name,email,phone,tags) VALUES (?,?,?,?)').run(name||'', email||'', phone||'', (tags||[]).join(','))
  res.json({ id: info.lastInsertRowid })
})
app.put('/guests/:id', auth, (req, res)=>{
  const { name, email, phone, tags } = req.body || {}
  db.prepare('UPDATE guests SET name=?, email=?, phone=?, tags=? WHERE id=?').run(name||'', email||'', phone||'', (tags||[]).join(','), Number(req.params.id))
  res.json({ ok: true })
})

// ---- Reservations ----
app.get('/reservations', auth, (_req,res)=>{
  const rows = db.prepare(`SELECT r.*, g.name as guest_name, g.email as guest_email FROM reservations r LEFT JOIN guests g ON g.id=r.guest_id ORDER BY r.created_at DESC`).all()
  res.json(rows)
})
app.post('/reservations', (req, res)=>{
  const { name, email, phone, property, check_in, check_out, price } = req.body || {}
  // upsert guest by email
  let guest = db.prepare('SELECT * FROM guests WHERE email = ?').get(email||'')
  if (!guest){
    const info = db.prepare('INSERT INTO guests (name,email,phone,tags) VALUES (?,?,?,?)').run(name||'', email||'', phone||'', '')
    guest = { id: info.lastInsertRowid }
  }
  const info = db.prepare('INSERT INTO reservations (guest_id, property, check_in, check_out, price, status) VALUES (?,?,?,?,?,?)').run(guest.id, property||'', check_in||'', check_out||'', Number(price||0), 'pending')
  // award tokens: 1 token por cada 20€
  const tokens = Math.floor((Number(price||0))/20)
  const row = db.prepare('SELECT balance FROM tokens WHERE guest_id=?').get(guest.id) as any
  if (row) db.prepare('UPDATE tokens SET balance = balance + ?, updated_at=CURRENT_TIMESTAMP WHERE guest_id=?').run(tokens, guest.id)
  else db.prepare('INSERT INTO tokens (guest_id, balance) VALUES (?, ?)').run(guest.id, tokens)
  // event
  db.prepare('INSERT INTO analytics_events (type, guest_id, props) VALUES (?,?,?)').run('reservation_created', guest.id, JSON.stringify({ reservation_id: info.lastInsertRowid, property, price }))
  res.json({ id: info.lastInsertRowid, tokens_awarded: tokens })
})
app.put('/reservations/:id/status', auth, (req, res)=>{
  const { status } = req.body || {}
  db.prepare('UPDATE reservations SET status=? WHERE id=?').run(status||'pending', Number(req.params.id))
  res.json({ ok: true })
})

// ---- Tokens ----
app.get('/tokens/:guest_id', auth, (req,res)=>{
  const row = db.prepare('SELECT balance FROM tokens WHERE guest_id=?').get(Number(req.params.guest_id))
  res.json({ balance: row?.balance || 0 })
})
app.post('/tokens/award', auth, (req,res)=>{
  const { guest_id, amount } = req.body || {}
  const row = db.prepare('SELECT balance FROM tokens WHERE guest_id=?').get(Number(guest_id))
  if (row) db.prepare('UPDATE tokens SET balance=balance+?, updated_at=CURRENT_TIMESTAMP WHERE guest_id=?').run(Number(amount||0), Number(guest_id))
  else db.prepare('INSERT INTO tokens (guest_id, balance) VALUES (?, ?)').run(Number(guest_id), Number(amount||0))
  res.json({ ok: true })
})

// ---- Campaigns ----
app.get('/campaigns', auth, (_req,res)=>{
  const rows = db.prepare('SELECT * FROM campaigns ORDER BY scheduled_at DESC NULLS LAST, id DESC').all()
  res.json(rows)
})
app.post('/campaigns', auth, (req,res)=>{
  const { name, season, channel, content, scheduled_at } = req.body || {}
  const info = db.prepare('INSERT INTO campaigns (name, season, channel, content, status, scheduled_at) VALUES (?,?,?,?,?,?)').run(name||'', season||'custom', channel||'social', content||'', 'draft', scheduled_at||null)
  res.json({ id: info.lastInsertRowid })
})
app.post('/campaigns/:id/activate', auth, (req,res)=>{
  db.prepare('UPDATE campaigns SET status=? WHERE id=?').run('active', Number(req.params.id))
  res.json({ ok: true })
})

// ---- Social CM ----
app.get('/social/queue', auth, (_req,res)=>{
  const rows = db.prepare('SELECT * FROM social_queue ORDER BY scheduled_at ASC').all()
  res.json(rows)
})
app.post('/social/queue', auth, (req,res)=>{
  const { platform, content, image_url, scheduled_at } = req.body || {}
  const info = db.prepare('INSERT INTO social_queue (platform, content, image_url, scheduled_at, status) VALUES (?,?,?,?,?)').run(platform||'instagram', content||'', image_url||'', scheduled_at||null, 'queued')
  res.json({ id: info.lastInsertRowid })
})
app.post('/social/queue/:id/send', auth, (req,res)=>{
  // En producción, aquí llamarías a APIs reales de cada plataforma.
  db.prepare('UPDATE social_queue SET status=? WHERE id=?').run('sent', Number(req.params.id))
  res.json({ ok: true })
})

// ---- Analytics ----
const analyticsClients: any[] = []
app.get('/analytics/stream', (req,res)=>{ res.setHeader('Content-Type','text/event-stream'); res.setHeader('Cache-Control','no-cache'); res.setHeader('Connection','keep-alive'); res.flushHeaders(); const client = { res }; analyticsClients.push(client); req.on('close',()=>{ const i=analyticsClients.indexOf(client); if(i>=0) analyticsClients.splice(i,1) }) })

app.post('/analytics/events', (_req,res)=>{
  const { type, guest_id, props } = _req.body || {}
  db.prepare('INSERT INTO analytics_events (type, guest_id, props) VALUES (?,?,?)').run(type||'custom', guest_id||null, JSON.stringify(props||{})); try{ const msg = `data: ${JSON.stringify({type, guest_id, props})}\n\n`; for (const c of analyticsClients){ c.res.write(msg) } }catch{}
  res.json({ ok: true })
})

// ===== Sales utils =====
const EMOJI = ['🚀','🔥','✨','✅','🧠','🌍','🎯','🛎️','🏖️','🏙️','💡','🤝','📈','💬','📣','🧳','🔒','⚡']
function stylePost(text:string){
  // prepend / sprinkle emojis in a consistent, upbeat tone
  return `${EMOJI[0]} ${text} ${EMOJI[2]}`
}

function computeNegotiation({asking, base, commissionPct, extraMarginPct}:{asking:number, base:number, commissionPct:number, extraMarginPct:number}){
  // Rule set:
  // - Remove OTA commission to create headroom
  // - Add extraMarginPct for service value
  // - Never go below base
  const headroom = asking * (commissionPct/100)
  const target = Math.max(base, Math.min(asking, asking - headroom + (asking * (extraMarginPct/100))))
  // ladder with 3 counteroffers toward target
  const step1 = asking - Math.min(headroom*0.5, Math.max(10, (asking-target)*0.5))
  const step2 = asking - Math.min(headroom*0.8, Math.max(15, (asking-target)*0.8))
  return { target: Math.round(target), ladder: [Math.round(step1), Math.round(step2), Math.round(target)] }
}

// ===== Owners & Leads =====
app.get('/owners', auth, (_req,res)=>{
  res.json(db.prepare('SELECT * FROM owners ORDER BY id DESC').all())
})
app.post('/owners', auth, (req,res)=>{
  const { name, company, email, phone, locale, notes } = req.body || {}
  const info = db.prepare('INSERT INTO owners (name,company,email,phone,locale,notes) VALUES (?,?,?,?,?,?)').run(name||'',company||'',email||'',phone||'',locale||'es-ES',notes||'')
  res.json({ id: info.lastInsertRowid })
})
app.get('/leads', auth, (_req,res)=>{
  const rows = db.prepare('SELECT l.*, o.name as owner_name, o.email as owner_email FROM leads l LEFT JOIN owners o ON o.id=l.owner_id ORDER BY l.id DESC').all()
  res.json(rows)
})
app.post('/leads', auth, (req,res)=>{
  const { owner_id, source, property } = req.body || {}
  const info = db.prepare('INSERT INTO leads (owner_id,source,property,status) VALUES (?,?,?,?)').run(Number(owner_id), source||'inbound', property||'', 'new')
  res.json({ id: info.lastInsertRowid })
})

// ===== Outreach Queue =====
app.get('/outreach', auth, (_req,res)=>{
  const rows = db.prepare('SELECT q.*, l.property, o.name owner_name, o.email owner_email, o.phone owner_phone FROM outreach_queue q LEFT JOIN leads l ON l.id=q.lead_id LEFT JOIN owners o ON o.id=l.owner_id ORDER BY q.scheduled_at ASC NULLS LAST, q.id DESC').all()
  res.json(rows)
})
app.post('/outreach', auth, (req,res)=>{
  const { lead_id, channel, payload, scheduled_at } = req.body || {}
  const info = db.prepare('INSERT INTO outreach_queue (lead_id,channel,payload,scheduled_at) VALUES (?,?,?,?)').run(Number(lead_id), channel||'email', JSON.stringify(payload||{}), scheduled_at||null)
  res.json({ id: info.lastInsertRowid })
})
app.post('/outreach/:id/send', auth, (req,res)=>{
  const row = db.prepare('SELECT * FROM outreach_queue WHERE id=?').get(Number(req.params.id)) as any
  if (!row) return res.status(404).json({ error:'Not found' })
  // Simula envío. Para producción, conecta Twilio/SendGrid/Meta.
  db.prepare('UPDATE outreach_queue SET status=? WHERE id=?').run('sent', row.id)
  res.json({ ok: true })
})

// ===== Negotiation =====
app.post('/sales/negotiate', auth, (req,res)=>{
  const { lead_id, asking_price, base_price, channel='chat', ota='airbnb' } = req.body || {}
  const pol = db.prepare("SELECT json FROM sales_policies WHERE name='default'").get() as any
  const cfg = pol?.json ? JSON.parse(pol.json) : { airbnb_commission_pct:15, booking_commission_pct:15, extra_margin_pct:3 }
  const commissionPct = ota==='booking' ? cfg.booking_commission_pct : cfg.airbnb_commission_pct
  const r = computeNegotiation({ asking:Number(asking_price||0), base:Number(base_price||0), commissionPct, extraMarginPct: cfg.extra_margin_pct })
  const info = db.prepare('INSERT INTO negotiations (lead_id, asking_price, base_price, max_discount_pct, result_price, transcript) VALUES (?,?,?,?,?,?)').run(Number(lead_id||0), Number(asking_price||0), Number(base_price||0), Number(cfg.extra_margin_pct||0), r.target, JSON.stringify([{role:'system', text:'start'}]))
  res.json({ negotiation_id: info.lastInsertRowid, ...r })
})

// ===== International segments =====
app.get('/intl/segments', auth, (_req,res)=>{
  const rows = db.prepare("SELECT g.id, g.email, g.tags, r.property, r.created_at FROM guests g LEFT JOIN reservations r ON r.guest_id=g.id").all() as any[]
  // simple heuristic: tags may include country code, else fallback to email TLD
  const map:any = {}
  for (const r of rows){
    const tag = String(r.tags||'').toLowerCase()
    let country = /([a-z]{2})/.exec(tag)?.[1] || (/\.[a-z]{2}$/.exec(String(r.email||''))?.[1]) || 'es'
    map[country] = (map[country]||0)+1
  }
  const out = Object.entries(map).map(([country,count])=>({ country, count }))
  res.json(out.sort((a,b)=>b.count-a.count))
})

// ===== Phone calls (stub) =====
app.post('/calls/outbound', auth, (req,res)=>{
  const { to, from, script } = req.body || {}
  // En producción: Twilio Programmable Voice aquí.
  res.json({ ok:true, simulated:true, to, from })
})

// ===== Social copy with consistent emoji style =====
app.post('/social/generate', auth, (req,res)=>{
  const { text } = req.body || {}
  res.json({ post: stylePost(String(text||'')) })
})

// -------------- Concierge: itineraries --------------
app.post('/concierge/itinerary/preview', auth, async (req,res)=>{
  const { guest, origin, destination, arrivalISO } = req.body||{}
  const it = await buildItinerary({ guest, origin, destination, arrivalISO })
  res.json(it)
})
app.post('/concierge/itinerary/send', auth, async (req,res)=>{
  const { channel='whatsapp', to, guest, origin, destination, arrivalISO } = req.body||{}
  const it = await buildItinerary({ guest, origin, destination, arrivalISO })
  const r = await sendItinerary({ channel, to }, it)
  res.json(r)
})
// Cron-like endpoint to send 3 days before arrival (agent lo llama)
app.post('/concierge/schedule/run', auth, async (_req,res)=>{
  const rows = db.prepare('SELECT r.id, r.guest_id, g.name, g.phone, r.property, r.created_at FROM reservations r LEFT JOIN guests g ON g.id=r.guest_id WHERE date(r.created_at) = date(datetime("now", "+3 days"))').all() as any[]
  const out:any[] = []
  for (const r of rows){
    const dest = r.property || 'Valencia, Spain'
    const it = await buildItinerary({ guest: r.name||'Amigo', origin:'Origen', destination: dest, arrivalISO: r.created_at })
    const to = r.phone||''
    const sent = await sendItinerary({ channel:'whatsapp', to }, it)
    out.push({ id:r.id, to, sent })
  }
  res.json({ count: out.length, items: out })
})

// -------------- Concierge: restaurants --------------
app.post('/restaurants', auth, requireRole('admin'), (req,res)=>{
  const { name, phone, address, cuisine, commission_pct, notes } = req.body||{}
  const info = db.prepare('INSERT INTO restaurants (name, phone, address, cuisine, commission_pct, notes) VALUES (?,?,?,?,?,?)').run(name,phone,address,cuisine,Number(commission_pct||10),notes||'')
  res.json({ id: info.lastInsertRowid })
})
app.get('/restaurants', auth, (_req,res)=>{
  res.json(db.prepare('SELECT * FROM restaurants ORDER BY id DESC').all())
})
app.post('/restaurants/deal', auth, requireRole('admin'), (req,res)=>{
  const { restaurant_id, terms, commission_pct } = req.body||{}
  Resto.createDeal(db, Number(restaurant_id), String(terms||''), Number(commission_pct||10))
  res.json({ ok:true })
})
app.post('/restaurants/book', auth, async (req,res)=>{
  const { restaurant_id, date, pax, amount, guest_name, guest_phone, email, success_url, cancel_url } = req.body||{}
  try{ const r = await Resto.bookWithPrepay(db, { restaurant_id:Number(restaurant_id), date, pax:Number(pax), amount:Number(amount), guest_name, guest_phone, success_url, cancel_url, email }); res.json(r) }
  catch(e){ res.status(400).json({ error: (e as Error).message }) }
})
app.post('/restaurants/negotiate/call', auth, requireRole('admin'), async (req,res)=>{
  const { phone, script } = req.body||{}
  try{ const r = await Resto.callForNegotiation(String(phone||''), String(script||'')); res.json(r) } catch(e){ res.status(400).json({ error: (e as Error).message }) }
})

// -------------- Concierge: services (providers) --------------
app.post('/services/providers', auth, requireRole('admin'), (req,res)=>{
  const { type, name, phone, email, price, city, notes } = req.body||{}
  const info = db.prepare('INSERT INTO providers (type,name,phone,email,price,city,notes) VALUES (?,?,?,?,?,?,?)').run(type,name,phone,email,Number(price||0),city,notes||'')
  res.json({ id: info.lastInsertRowid })
})
app.get('/services/providers', auth, (_req,res)=>{
  res.json(db.prepare('SELECT * FROM providers ORDER BY id DESC').all())
})
app.post('/services/book', auth, (req,res)=>{
  const { provider_id, guest_name, guest_phone, date, notes } = req.body||{}
  const info = db.prepare('INSERT INTO service_bookings (provider_id, guest_name, guest_phone, date, notes) VALUES (?,?,?,?,?)').run(Number(provider_id), guest_name, guest_phone, date, notes||'')
  res.json({ id: info.lastInsertRowid })
})

// -------------- Check-in / Check-out --------------
app.post('/checkin/start', auth, async (req,res)=>{
  const { reservation_id, to, address, map_link } = req.body||{}
  db.prepare('INSERT INTO checkins (reservation_id, status, lat, lng) VALUES (?,?,?,?)').run(Number(reservation_id||0),'started',null,null)
  try{ await CheckIn.pingArrival(String(to||''), String(address||''), String(map_link||'')) }catch{}
  res.json({ ok:true })
})
app.post('/checkout/start', auth, (req,res)=>{
  const { reservation_id } = req.body||{}
  db.prepare('INSERT INTO checkins (reservation_id, status) VALUES (?,?)').run(Number(reservation_id||0),'checkout')
  res.json({ ok:true })
})

app.get('/analytics/summary', auth, (_req,res)=>{
  const reservations = db.prepare('SELECT COUNT(*) as c FROM reservations').get() as any
  const guests = db.prepare('SELECT COUNT(*) as c FROM guests').get() as any
  const tokens = db.prepare('SELECT SUM(balance) as s FROM tokens').get() as any
  const last7 = db.prepare("SELECT date(created_at) d, COUNT(*) c FROM reservations GROUP BY date(created_at) ORDER BY d DESC LIMIT 7").all()
  res.json({ totals: { reservations: reservations.c||0, guests: guests.c||0, tokens: tokens.s||0 }, reservations_last7: last7 })
})

// ---- Push personalized by tag ----
app.post('/push/send', auth, async (req,res)=>{
  if (!process.env.VAPID_PUBLIC || !process.env.VAPID_PRIVATE) return res.status(400).json({ error:'No VAPID' })
  const { title, body, tag } = req.body || {}
  const subs = db.prepare('SELECT * FROM push_subs').all()
  let sent = 0
  for (const s of subs){
    try{
      // In a real system, filter by guest tags; for demo we send to all
      await webpush.sendNotification(JSON.parse(s.data), JSON.stringify({ title: title||'Sandra', body: body||'' }))
      sent++
    }catch(e){}
  }
  res.json({ sent })
})

// ---- Background worker (demo) ----
setInterval(()=>{
  // mark due social posts as 'sent' (simulation)
  const due = db.prepare("SELECT * FROM social_queue WHERE status='queued' AND (scheduled_at IS NULL OR datetime(scheduled_at) <= datetime('now'))").all()
  for (const row of due){
    try{ db.prepare("UPDATE social_queue SET status='sent' WHERE id=?").run(row.id) }catch{}
  }
}, 30000)


// ===== Protect Hogar: Familia =====
app.get('/family', auth, (_req,res)=>{
  const rows = db.prepare('SELECT * FROM family_members ORDER BY id DESC').all()
  res.json(rows)
})
app.post('/family', auth, (req,res)=>{
  const { name, relation, face_ref, voice_ref } = req.body || {}
  const info = db.prepare('INSERT INTO family_members (name, relation, face_ref, voice_ref) VALUES (?,?,?,?)').run(name||'', relation||'', face_ref||'', voice_ref||'')
  res.json({ id: info.lastInsertRowid })
})

// ===== Protect Hogar: Dispositivos & Domótica =====
app.get('/devices', auth, (_req,res)=>{
  const rows = db.prepare('SELECT * FROM devices ORDER BY id DESC').all()
  res.json(rows)
})
app.post('/devices', auth, (req,res)=>{
  const { name, type, location } = req.body || {}
  const info = db.prepare('INSERT INTO devices (name,type,location) VALUES (?,?,?)').run(name||'', type||'', location||'')
  res.json({ id: info.lastInsertRowid })
})
app.post('/domotics/command', auth, (req,res)=>{
  const { device_id, command, payload } = req.body || {}
  db.prepare('INSERT INTO domotics_commands (device_id, command, payload) VALUES (?,?,?)').run(Number(device_id), command||'', JSON.stringify(payload||{}))
  // En producción: enviar al hub IoT real (Home Assistant, Tuya, KNX, etc.)
  res.json({ ok: true })
})

// ===== SOS: Config & Trigger =====
app.get('/sos/config', auth, (_req,res)=>{
  const row = db.prepare('SELECT * FROM sos_config ORDER BY id DESC LIMIT 1').get()
  res.json(row || null)
})
app.post('/sos/config', auth, (req,res)=>{
  const { contact_name, phone, email, note } = req.body || {}
  const info = db.prepare('INSERT INTO sos_config (contact_name,phone,email,note) VALUES (?,?,?,?)').run(contact_name||'', phone||'', email||'', note||'')
  res.json({ id: info.lastInsertRowid })
})
app.post('/sos/trigger', async (req,res)=>{
  const { guest_id, lat, lng, note } = req.body || {}
  db.prepare('INSERT INTO sos_events (guest_id,lat,lng,note) VALUES (?,?,?,?)').run(guest_id||null, Number(lat||0), Number(lng||0), note||'')
  // Notifica por push si está configurado
  if (process.env.VAPID_PUBLIC && process.env.VAPID_PRIVATE){
    const subs = db.prepare('SELECT * FROM push_subs').all()
    for (const s of subs){
      try { await webpush.sendNotification(JSON.parse(s.data), JSON.stringify({ title:'🚨 SOS Sandra', body:`Ubicación: ${lat||'?'} , ${lng||'?'}` })) } catch {}
    }
  }
  res.json({ ok: true })
})

// ===== Content Creator (scripts desde plantilla) =====
app.get('/content/templates', auth, (_req,res)=>{
  const rows = db.prepare('SELECT * FROM content_templates ORDER BY category,name').all()
  res.json(rows)
})
app.post('/content/generate', auth, (req,res)=>{
  const { template_id, vars } = req.body || {}
  const row = db.prepare('SELECT template FROM content_templates WHERE id=?').get(Number(template_id)) as any
  if (!row) return res.status(404).json({ error:'Template not found' })
  let out = String(row.template)
  for (const [k,v] of Object.entries(vars||{})){ out = out.replaceAll(`{${k}}`, String(v)) }
  res.json({ script: out })
})

// ===== Sandrita (Kids) videos queue =====
app.get('/videos', auth, (_req,res)=>{
  const rows = db.prepare('SELECT * FROM videos_queue ORDER BY scheduled_at ASC NULLS LAST, id DESC').all()
  res.json(rows)
})
app.post('/videos', auth, (req,res)=>{
  const { title, audience, avatar, script, platform, scheduled_at } = req.body || {}
  const info = db.prepare('INSERT INTO videos_queue (title,audience,avatar,script,platform,scheduled_at,status) VALUES (?,?,?,?,?,?,?)').run(title||'', audience||'kids', avatar||'Sandrita', script||'', platform||'youtube', scheduled_at||null, 'queued')
  res.json({ id: info.lastInsertRowid })
})
app.post('/videos/:id/publish', auth, (req,res)=>{
  // En producción: invocar API de YouTube/Instagram/TikTok con el video generado
  db.prepare('UPDATE videos_queue SET status=? WHERE id=?').run('published', Number(req.params.id))
  res.json({ ok: true })
})

// ===== Wellness presets =====
app.get('/wellness/presets', (_req,res)=>{
  res.json([
    { id: 'yoga-10', name:'Yoga 10’', steps:['Saludo al sol','Estiramientos suaves','Respiración 4-4-6'] },
    { id: 'pilates-core-8', name:'Pilates Core 8’', steps:['Puente','Hundred mod','Side kicks'] },
    { id: 'mindfulness-3', name:'Mindfulness 3’', steps:['Respira 4-4-6','Visualiza luz azul','Agradece 3 cosas'] },
  ])
})

server.listen(PORT, ()=> console.log(`[Backend] http://localhost:${PORT}`))

// --- API key auth (alternative to JWT) ---
import crypto from 'node:crypto'
function hashKey(k:string){ return crypto.createHash('sha256').update(k).digest('hex') }
function apiKeyAuth(req:any,res:any,next:any){
  const key = req.headers['x-api-key'] as string
  if (!key) return next()
  const row = db.prepare('SELECT * FROM api_keys WHERE hash=? AND (expires_at IS NULL OR expires_at > CURRENT_TIMESTAMP)').get(hashKey(key)) as any
  if (!row) return res.status(401).json({ error:'invalid api key' })
  req.user = { sub: 0, email: 'apikey', role: 'agent', scopes: (row.scopes||'').split(',') }
  db.prepare('UPDATE api_keys SET last_used_at=CURRENT_TIMESTAMP WHERE id=?').run(row.id)
  next()
}
app.use(apiKeyAuth)

app.post('/apikeys', auth, requireRole('admin'), (req,res)=>{
  const { name, scopes='*', days=90 } = req.body || {}
  const raw = 'gv_' + crypto.randomBytes(18).toString('hex')
  const hash = hashKey(raw)
  db.prepare('INSERT INTO api_keys (name,hash,scopes,expires_at) VALUES (?,?,?, datetime("now", ?))').run(name||'key', hash, String(scopes), `+${Number(days)} days`)
  res.json({ api_key: raw, expires_in_days: Number(days) })
})
app.get('/apikeys', auth, requireRole('admin'), (_req,res)=>{
  const rows = db.prepare('SELECT id,name,scopes,created_at,expires_at,last_used_at FROM api_keys').all()
  res.json(rows)
})
app.delete('/apikeys/:id', auth, requireRole('admin'), (req,res)=>{
  db.prepare('DELETE FROM api_keys WHERE id=?').run(Number(req.params.id))
  res.json({ ok:true })
})

// --- Refresh tokens for session management ---
app.post('/auth/refresh', (req,res)=>{
  const { refresh } = req.body||{}
  if (!refresh) return res.status(400).json({ error:'missing refresh' })
  const row = db.prepare('SELECT * FROM refresh_tokens WHERE token=? AND revoked=0 AND expires_at > CURRENT_TIMESTAMP').get(String(refresh)) as any
  if (!row) return res.status(401).json({ error:'invalid refresh' })
  const token = jwt.sign({ sub: row.user_id }, JWT_SECRET, { expiresIn: '1h' })
  res.json({ token })
})
