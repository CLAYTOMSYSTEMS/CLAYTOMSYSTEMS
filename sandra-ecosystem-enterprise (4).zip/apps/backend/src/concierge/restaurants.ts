import { Database } from 'better-sqlite3'
import { createCheckoutSession } from '../payments/stripe.js'
import { placeCall } from '../integrations/twilio.js'

export function ensureTables(db: Database){
  db.exec(`
    CREATE TABLE IF NOT EXISTS restaurants (id INTEGER PRIMARY KEY, name TEXT, phone TEXT, address TEXT, cuisine TEXT, commission_pct REAL DEFAULT 10, notes TEXT);
    CREATE TABLE IF NOT EXISTS restaurant_menus (id INTEGER PRIMARY KEY, restaurant_id INTEGER, name TEXT, price REAL, per_person INTEGER DEFAULT 1, notes TEXT);
    CREATE TABLE IF NOT EXISTS restaurant_deals (id INTEGER PRIMARY KEY, restaurant_id INTEGER, terms TEXT, commission_pct REAL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS restaurant_bookings (id INTEGER PRIMARY KEY, guest_name TEXT, guest_phone TEXT, restaurant_id INTEGER, date TEXT, pax INTEGER, prepaid REAL DEFAULT 0, status TEXT DEFAULT 'pending', session_url TEXT);
  `)
}

export function createDeal(db: Database, restaurant_id:number, terms:string, commission_pct:number){
  db.prepare('INSERT INTO restaurant_deals (restaurant_id, terms, commission_pct) VALUES (?,?,?)').run(restaurant_id, terms, commission_pct)
}

export async function bookWithPrepay(db:Database, payload:{restaurant_id:number, date:string, pax:number, amount:number, guest_name:string, guest_phone:string, success_url:string, cancel_url:string, email?:string}){
  const { amount, success_url, cancel_url, email } = payload
  const s = await createCheckoutSession({ amount, currency:'EUR', success_url, cancel_url, customer_email: email })
  const info = db.prepare('INSERT INTO restaurant_bookings (guest_name, guest_phone, restaurant_id, date, pax, prepaid, status, session_url) VALUES (?,?,?,?,?,?,?,?)')
    .run(payload.guest_name, payload.guest_phone, payload.restaurant_id, payload.date, payload.pax, amount, 'payment_url', s.url)
  return { booking_id: info.lastInsertRowid, url: s.url }
}

export async function callForNegotiation(phone:string, script:string){
  return await placeCall(phone, script)
}
