import { Database } from 'better-sqlite3'
import { sendWhatsApp } from '../integrations/whatsapp.js'

export function ensureTables(db: Database){
  db.exec(`
    CREATE TABLE IF NOT EXISTS checkins (id INTEGER PRIMARY KEY, reservation_id INTEGER, status TEXT, lat REAL, lng REAL, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
  `)
}

export async function pingArrival(to:string, address:string, mapLink:string){
  const text = `¡Bienvenido! Estoy en modo concierge. Tu acceso: ${address}. Guía paso a paso: ${mapLink}`
  try{ await sendWhatsApp(to, text) }catch{}
}
