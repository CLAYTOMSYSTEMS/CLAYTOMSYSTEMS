import helmet from 'helmet'
import { RequestHandler } from 'express'

export const secureHeaders: RequestHandler = helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      "default-src": ["'self'"],
      "img-src": ["'self'", "data:", "blob:", "https:"],
      "media-src": ["'self'", "data:", "blob:", "https:"],
      "script-src": ["'self'", "'unsafe-inline'", "'unsafe-eval'", "https://www.googletagmanager.com"],
      "connect-src": ["'self'", "https:", "wss:"],
      "frame-ancestors": ["'self'"],
      "frame-src": ["'self'", "https://app.heygen.com"],
    }
  },
  crossOriginEmbedderPolicy: true,
  crossOriginOpenerPolicy: { policy: "same-origin" },
  crossOriginResourcePolicy: { policy: "same-origin" },
  hsts: { maxAge: 31536000, includeSubDomains: true, preload: true },
  referrerPolicy: { policy: "strict-origin-when-cross-origin" },
  // HPKP está deprecado; no se configura por seguridad.
})

export const hstsOnly: RequestHandler = helmet.hsts({ maxAge: 31536000, includeSubDomains: true, preload: true })
