
'use client'
import { useEffect, useState } from 'react'
export default function Wellness(){
  const [presets,setPresets]=useState<any[]>([])
  useEffect(()=>{ fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/wellness/presets').then(r=>r.json()).then(setPresets) },[])
  return <div className="max-w-3xl mx-auto p-8 space-y-4">
    <h2 className="text-2xl font-bold">Wellness</h2>
    <div className="space-y-2">{presets.map((p:any)=>(
      <div key={p.id} className="glass p-3 rounded-xl">
        <div className="font-semibold">{p.name}</div>
        <ul className="text-sm list-disc ml-6 opacity-90">{p.steps.map((s:string)=><li key={s}>{s}</li>)}</ul>
      </div>
    ))}</div>
  </div>
}
