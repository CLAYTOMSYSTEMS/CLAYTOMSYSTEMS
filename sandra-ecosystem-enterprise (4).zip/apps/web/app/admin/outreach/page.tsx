
'use client'
import { useEffect, useState } from 'react'
export default function Outreach(){
  const token=typeof window!=='undefined'?localStorage.getItem('token'):''
  const [owners,setOwners]=useState<any[]>([])
  const [leads,setLeads]=useState<any[]>([])
  const [queue,setQueue]=useState<any[]>([])
  const [o,setO]=useState({name:'',company:'',email:'',phone:'',locale:'es-ES',notes:''})
  const [l,setL]=useState({owner_id:0,source:'inbound',property:''})
  const [payload,setPayload]=useState('Hola {name}, soy Sandra de Guests Valencia. ¿Te interesa una gestión win‑win?')
  useEffect(()=>{ load() },[])
  async function load(){
    setOwners(await (await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/owners',{headers:{Authorization:'Bearer '+token}})).json())
    setLeads(await (await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/leads',{headers:{Authorization:'Bearer '+token}})).json())
    setQueue(await (await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/outreach',{headers:{Authorization:'Bearer '+token}})).json())
  }
  async function addOwner(){ await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/owners',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify(o)}); setO({name:'',company:'',email:'',phone:'',locale:'es-ES',notes:''}); load() }
  async function addLead(){ await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/leads',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify(l)}); setL({owner_id:0,source:'inbound',property:''}); load() }
  async function enqueue(id:number, channel:string){ await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/outreach',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({lead_id:id,channel,payload:{text:payload}})}); load() }
  async function send(id:number){ await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+`/outreach/${id}/send`,{method:'POST',headers:{Authorization:'Bearer '+token}}); load() }
  return <div className="max-w-6xl mx-auto p-8 space-y-6">
    <h2 className="text-2xl font-bold">Outreach · Propietarios</h2>
    <div className="grid md:grid-cols-2 gap-4">
      <div className="glass p-4 rounded-xl">
        <h3 className="font-semibold mb-2">Nuevo propietario</h3>
        <div className="grid grid-cols-2 gap-2">
          <input className="px-2 py-2 bg-white/10 rounded" placeholder="Nombre" value={o.name} onChange={e=>setO({...o,name:e.target.value})}/>
          <input className="px-2 py-2 bg-white/10 rounded" placeholder="Empresa" value={o.company} onChange={e=>setO({...o,company:e.target.value})}/>
          <input className="px-2 py-2 bg-white/10 rounded" placeholder="Email" value={o.email} onChange={e=>setO({...o,email:e.target.value})}/>
          <input className="px-2 py-2 bg-white/10 rounded" placeholder="Teléfono" value={o.phone} onChange={e=>setO({...o,phone:e.target.value})}/>
          <input className="px-2 py-2 bg-white/10 rounded" placeholder="Locale (es-ES,...)" value={o.locale} onChange={e=>setO({...o,locale:e.target.value})}/>
          <input className="px-2 py-2 bg-white/10 rounded col-span-2" placeholder="Notas" value={o.notes} onChange={e=>setO({...o,notes:e.target.value})}/>
          <button onClick={addOwner} className="col-span-2 px-4 py-2 bg-white text-black rounded">Guardar</button>
        </div>
        <ul className="mt-3 text-sm space-y-1">{owners.map(x=><li key={x.id}><strong>{x.name}</strong> — {x.email} · {x.phone}</li>)}</ul>
      </div>
      <div className="glass p-4 rounded-xl">
        <h3 className="font-semibold mb-2">Nuevo lead</h3>
        <div className="grid grid-cols-2 gap-2">
          <select className="px-2 py-2 bg-white/10 rounded" value={l.owner_id} onChange={e=>setL({...l,owner_id:Number(e.target.value)})}>
            <option value={0}>Propietario…</option>
            {owners.map(o=><option key={o.id} value={o.id}>{o.name}</option>)}
          </select>
          <select className="px-2 py-2 bg-white/10 rounded" value={l.source} onChange={e=>setL({...l,source:e.target.value})}>
            <option value="inbound">Inbound</option><option value="airbnb">Airbnb</option><option value="booking">Booking</option><option value="referral">Referido</option>
          </select>
          <input className="px-2 py-2 bg-white/10 rounded col-span-2" placeholder="Propiedad" value={l.property} onChange={e=>setL({...l,property:e.target.value})}/>
          <button onClick={addLead} className="col-span-2 px-4 py-2 bg-white text-black rounded">Guardar</button>
        </div>
        <div className="mt-4">
          <h4 className="font-semibold mb-1">Leads</h4>
          <ul className="text-sm space-y-1">{leads.map(x=>(<li key={x.id} className="flex justify-between"><span><strong>#{x.id}</strong> {x.property} — {x.owner_name}</span><span className="space-x-2"><button onClick={()=>enqueue(x.id,'email')} className="px-2 py-1 border rounded">Email</button><button onClick={()=>enqueue(x.id,'call')} className="px-2 py-1 border rounded">Llamada</button></span></li>))}</ul>
        </div>
      </div>
    </div>
    <div className="glass p-4 rounded-xl">
      <h3 className="font-semibold mb-2">Cola de outreach</h3>
      <ul className="space-y-2">{queue.map(q=>(<li key={q.id} className="flex justify-between"><span>#{q.id} · {q.channel} → {q.owner_name} · {q.property} · {q.status}</span>{q.status!=='sent' && <button onClick={()=>send(q.id)} className="px-3 py-1 border rounded">Enviar</button>}</li>))}</ul>
    </div>
    <div className="glass p-4 rounded-xl">
      <h3 className="font-semibold mb-2">Plantilla</h3>
      <textarea className="w-full h-24 px-2 py-2 bg-white/10 rounded" value={payload} onChange={e=>setPayload(e.target.value)} />
      <p className="text-xs opacity-60 mt-2">Cumple RGPD y normativa anti-spam. Usa consentimiento o base legítima documentada.</p>
    </div>
  </div>
}
