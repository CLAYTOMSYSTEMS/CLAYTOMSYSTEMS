'use client'
import { SandraMicPanel } from '@gv/shared/src'
export default function SandraPage(){
  return <div className="max-w-5xl mx-auto p-8">
    <h2 className="text-3xl font-bold">Sandra IA 7.0</h2>
    <p className="text-white/70 mb-6">Pulsa Hablar o usa la barra espaciadora.</p>
    <SandraMicPanel />
  </div>
}
