export const EMOJI = ['🚀','🔥','✨','✅','🧠','🌍','🎯','🛎️','🏖️','🏙️','💡','🤝','📈','💬','📣','🧳','🔒','⚡']
export function stylePost(text: string){
  return `${EMOJI[0]} ${text} ${EMOJI[2]}`
}
