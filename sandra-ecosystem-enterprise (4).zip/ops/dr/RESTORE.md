# Disaster Recovery
1) Provisionar VM secundaria con Docker y Traefik.
2) Restaurar DB: `node ops/backup/restore.js <backup-file>`.
3) Reasignar DNS en Cloudflare (proxied) a la IP secundaria.
4) Validar health (`/healthz`), métricas (`/metrics`) y login admin.
