// Cloudflare WAF rules via API (requires CLOUDFLARE_API_TOKEN, ZONE_ID)
import fetch from 'node-fetch'
const token = process.env.CLOUDFLARE_API_TOKEN
const zone = process.env.CLOUDFLARE_ZONE_ID
if(!token||!zone){ console.error('Set CLOUDFLARE_API_TOKEN and CLOUDFLARE_ZONE_ID'); process.exit(1) }

async function enableBotFight(){
  const url = `https://api.cloudflare.com/client/v4/zones/${zone}/bot_management`
  const res = await fetch(url, { method:'PATCH', headers:{'Authorization':'Bearer '+token,'Content-Type':'application/json'}, body: JSON.stringify({ fight_mode: { enabled: true } }) })
  console.log('BotFight:', res.status)
}
enableBotFight().catch(console.error)
