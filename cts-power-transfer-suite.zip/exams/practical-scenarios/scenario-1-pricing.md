# Escenario práctico — Pricing
- Degradación parcial
- SLA ≥ 99.5% en 90m
- Entregables: mitigación, evidencias, métricas
