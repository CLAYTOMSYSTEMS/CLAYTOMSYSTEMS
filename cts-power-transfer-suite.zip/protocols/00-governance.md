# 00 — Corporate Governance (CGF)
- Políticas L0–L3, RACI, auditorías trimestrales.
- Decisiones críticas: firma hash y archivo en `org.claytom.corporate.audit`.
- Gate financiero: ROI ≥ 300% y payback ≤ 18 meses.
