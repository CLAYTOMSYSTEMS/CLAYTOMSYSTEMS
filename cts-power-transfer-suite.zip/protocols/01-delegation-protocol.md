# 01 — Delegation & Power Transfer
- ChatGPT‑5: Chief Training Officer (forma y certifica)
- Experts: ejecutan entrenamiento y playbooks
- Agents: operación bajo SOPs/QA
- RACI y manifiesto de poderes en `rbac/*`
