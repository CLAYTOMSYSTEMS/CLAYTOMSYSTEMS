# 06 — Release Management
- GitOps ArgoCD App-of-Apps; tags semánticos; backout plan
