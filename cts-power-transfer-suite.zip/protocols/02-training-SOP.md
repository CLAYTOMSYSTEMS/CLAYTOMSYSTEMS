# 02 — Training SOP (TMS)
- Cohortes: 500→1000/semana por subsidiaria
- Material: standards, SOPs, QA, observabilidad, seguridad
- Examen teórico+práctico con rúbrica
