# 05 — Quality Gates
- Lint+Unit+Contract+Security+Prompt QA
- Canary 10% + SLO ≥ 99.5%
