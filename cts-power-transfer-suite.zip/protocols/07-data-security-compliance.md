# 07 — Data Security & Compliance
- IAM, rotación secretos, WAF, SBOM
- Data governance & auditoría IA generativa
