# 03 — Exam Rubrics
- Teórico 60% (30x2)
- Práctico 40% (4x10)
- Aprobado ≥ 70/100; distinción ≥ 90/100
