# 04 — Incident & Escalation
- SEV1/SEV2/SEV3 con SLAs y postmortems
- Topics: `org.claytom.<subsidiary>.incident.*`
