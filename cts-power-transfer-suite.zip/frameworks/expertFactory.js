
const fs = require('fs'), path = require('path');
const cfg = JSON.parse(fs.readFileSync(path.resolve(__dirname, 'expertFactory.config.json'),'utf-8'));
function blueprint(subsidiary){return {subsidiary,roles:[{role:'Director',qty:5,level:'L4'},{role:'Coordinator',qty:10,level:'L3'},{role:'Specialist',qty:10,level:'L2'},{role:'Innovator',qty:5,level:'L2'}]};}
function trainingPlan(){return {trainers:500,operators:1000,syllabus:['standards','SOPs','QA','observability','security'],evaluation:{theory_weight:0.6,practice_weight:0.4,pass_mark:0.7}};}
module.exports = { cfg, blueprint, trainingPlan };
