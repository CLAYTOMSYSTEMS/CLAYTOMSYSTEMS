# CTS Power Transfer Suite
Uso: `node automation/cli.js assign|train|exam|certify --subs <slug>`
Ver `frameworks/` y `protocols/` para todo el marco.
