
const fs = require('fs'), path = require('path');
const { blueprint, trainingPlan } = require('../frameworks/expertFactory');
const args = process.argv.slice(2); const cmd = args[0]; const subs = (args[2]||'pricing');
const outdir = path.resolve(__dirname,'../out'); if(!fs.existsSync(outdir)) fs.mkdirSync(outdir,{recursive:true});
function writeJSON(name,obj){fs.writeFileSync(path.resolve(outdir,name),JSON.stringify(obj,null,2));}
if(cmd==='assign'){writeJSON(`assign-${subs}.json`, blueprint(subs)); console.log('[ASSIGN] out/assign-'+subs+'.json');}
else if(cmd==='train'){writeJSON(`train-${subs}.json`, trainingPlan()); console.log('[TRAIN] out/train-'+subs+'.json');}
else if(cmd==='exam'){writeJSON(`exam-${subs}.json`, {theory:30,practice:4,rubric:{theory_weight:0.6,practice_weight:0.4,pass_mark:0.7}}); console.log('[EXAM] out/exam-'+subs+'.json');}
else if(cmd==='certify'){const thr = Number(args[args.indexOf('--threshold')+1]||0.7);const score=0.82;const passed=score>=thr;writeJSON(`certify-${subs}.json`,{threshold:thr,sampleScore:score,passed}); console.log('[CERTIFY]',passed?'APROBADO':'REPROBADO');}
else{console.log('Uso: assign|train|exam|certify --subs <slug> [--threshold 0.7]');}
