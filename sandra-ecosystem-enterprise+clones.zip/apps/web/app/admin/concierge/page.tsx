'use client'
import { useState,useEffect } from 'react'
export default function Concierge(){
  const token=typeof window!=='undefined'?localStorage.getItem('token'):''
  const [it,setIt]=useState<any>(null); const [rest,setRest]=useState<any[]>([]); const [prov,setProv]=useState<any[]>([])
  async function preview(){ const r=await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/concierge/itinerary/preview',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({guest:'Invitado',origin:'Origen',destination:'Plaza del Ayuntamiento, Valencia',arrivalISO:new Date().toISOString()})}); setIt(await r.json()) }
  useEffect(()=>{ (async()=>{ setRest(await (await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/restaurants',{headers:{Authorization:'Bearer '+token}})).json()); setProv(await (await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/services/providers',{headers:{Authorization:'Bearer '+token}})).json()) })() },[])
  return <div className="max-w-6xl mx-auto p-8 space-y-6">
    <h2 className="text-2xl font-bold">Concierge Premium</h2>
    <button onClick={preview} className="px-4 py-2 bg-white text-black rounded">Previsualizar Itinerario</button>
    {it && <pre className="text-xs whitespace-pre-wrap">{JSON.stringify(it,null,2)}</pre>}
    <div className="grid md:grid-cols-2 gap-4">
      <div className="glass p-4 rounded-xl"><h3 className="font-semibold mb-2">Restaurantes</h3><ul className="text-sm space-y-1">{rest.map((r:any)=>(<li key={r.id}><b>{r.name}</b> · {r.cuisine}</li>))}</ul></div>
      <div className="glass p-4 rounded-xl"><h3 className="font-semibold mb-2">Proveedores</h3><ul className="text-sm space-y-1">{prov.map((p:any)=>(<li key={p.id}><b>{p.type}</b> · {p.name}</li>))}</ul></div>
    </div>
  </div>
}
