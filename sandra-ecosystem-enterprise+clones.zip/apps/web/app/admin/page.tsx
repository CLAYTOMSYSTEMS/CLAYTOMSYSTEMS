import Link from 'next/link'
export default function Admin(){
  return <main className="max-w-5xl mx-auto p-12 space-y-4">
    <h2 className="text-3xl font-bold">Admin</h2>
    <nav className="grid md:grid-cols-3 gap-4">
      <Link href="/admin/observability" className="glass p-4 rounded-xl">Observabilidad</Link>
      <Link href="/admin/concierge" className="glass p-4 rounded-xl">Concierge</Link>
      <Link href="/admin/roi" className="glass p-4 rounded-xl">ROI por sector</Link>
      <Link href="/admin/docendo" className="glass p-4 rounded-xl">Docendo</Link>
    </nav>
  </main>
}
