'use client'
import { useState } from 'react'
export default function Docendo(){
  const token=typeof window!=='undefined'?localStorage.getItem('token'):''
  const [partner,setPartner]=useState<any>(null); const [center,setCenter]=useState<any>(null); const [remain,setRemain]=useState<number|null>(null)
  async function post(url:string, body:any){ const r=await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+url,{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify(body)}); return r }
  return <div className="max-w-3xl mx-auto p-8 space-y-3">
    <h2 className="text-2xl font-bold">Docendo · Manager</h2>
    <button onClick={async()=>setPartner(await (await post('/docendo/partner',{name:'Docendo España'})).json())} className="px-3 py-2 bg-white text-black rounded">Crear Partnership</button>
    <button onClick={async()=>setCenter(await (await post('/docendo/center',{partner_id:partner?.id,name:'Colegio Demo',city:'Valencia',region:'CV',contact:'director@colegio.es',policy_screen_min:90})).json())} disabled={!partner} className="px-3 py-2 bg-white text-black rounded disabled:opacity-40">Crear Centro</button>
    <button onClick={async()=>{ await post('/docendo/program',{center_id:center?.id,title:'Inglés Interactivo',age_min:3,age_max:6,lang:'es'}) }} disabled={!center} className="px-3 py-2 bg-white text-black rounded disabled:opacity-40">Añadir Programa</button>
    <button onClick={async()=>{ const r=await post('/docendo/session',{center_id:center?.id,program_id:1,day:new Date().toISOString().slice(0,10),start:'17:00',end:'17:45',content:'Cuentacuentos bilingüe'}); const js=await r.json(); if(!r.ok) alert('Límite de pantalla: '+js.remain); else setRemain(js.remain_after) }} disabled={!center} className="px-3 py-2 bg-white text-black rounded disabled:opacity-40">Programar Sesión</button>
    {remain!==null && <div className="text-sm opacity-75">Minutos restantes hoy: {remain}</div>}
  </div>
}
