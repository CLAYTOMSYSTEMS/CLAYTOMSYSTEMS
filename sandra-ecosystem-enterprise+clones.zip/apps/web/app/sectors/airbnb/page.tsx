'use client'
import { useState } from 'react'
export default function Sector(){
  const [name,setName]=useState(''); const [email,setEmail]=useState(''); const [phone,setPhone]=useState('')
  async function submit(){ await fetch(process.env.NEXT_PUBLIC_SANDRA_API_URL+'/sectors/lead',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,email,phone,sector:'airbnb'})}); alert('Gracias, te contactamos para demo.'); }
  return <div className="max-w-3xl mx-auto p-8 space-y-6">
    <h1 className="text-3xl font-bold">Claytom System · Airbnb Hosts</h1>
    <p className="opacity-80">Optimiza ocupación y precio con IA; capta directo sin comisiones.</p>
    <div className="glass p-4 rounded-xl space-y-2">
      <input className="w-full px-3 py-2 bg-white/10 rounded" placeholder="Nombre" value={name} onChange={e=>setName(e.target.value)}/>
      <input className="w-full px-3 py-2 bg-white/10 rounded" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)}/>
      <input className="w-full px-3 py-2 bg-white/10 rounded" placeholder="Teléfono" value={phone} onChange={e=>setPhone(e.target.value)}/>
      <button onClick={submit} className="px-4 py-2 bg-white text-black rounded">Solicitar demo</button>
    </div>
  </div>
}
