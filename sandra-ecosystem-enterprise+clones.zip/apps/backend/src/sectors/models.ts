export type SectorKind = 'guarderias'|'mayores'|'hoteles'|'booking'|'airbnb'|'realestate'|'hostales'|'aparthoteles'|'docendo'|'hospitales'|'centros-comerciales'|'bibliotecas'|'ayuntamientos'|'cruceros-parques'
export const GuarderiasModels = [{ code:'valencia', name:'Sandra Educa · Valencia', locale:'es-ES', city:'Valencia' }]
export const MayoresModels = [{ code:'compan-urbana', name:'Sandra Mayores · Compañía Urbana', locale:'es-ES' }]
export const DocendoModels = ['valencia','madrid','barcelona','sevilla','malaga','alicante','murcia','zaragoza','baleares','canarias','cantabria','euskadi','galicia','castilla','rioja'].map(c=>({code:c,name:`Sandra Docendo · ${c}`,locale:'es-ES'}))
export const HospitalsModels = Array.from({length:20}).map((_,i)=>({ code:`hosp${i+1}`, name:`Sandra Hospital Infantil · Modelo ${i+1}`, locale:'es-ES' }))
export const MallsModels     = Array.from({length:15}).map((_,i)=>({ code:`mall${i+1}`, name:`Sandra Centros Comerciales · Modelo ${i+1}`, locale:'es-ES' }))
export const LibrariesModels = Array.from({length:12}).map((_,i)=>({ code:`lib${i+1}`,  name:`Sandra Bibliotecas · Modelo ${i+1}`, locale:'es-ES' }))
export const MunicipModels   = Array.from({length:10}).map((_,i)=>({ code:`mun${i+1}`,  name:`Sandra Ayuntamientos · Modelo ${i+1}`, locale:'es-ES' }))
export const CruisesParksModels = Array.from({length:25}).map((_,i)=>({ code:`cru${i+1}`, name:`Sandra Cruceros/Parques · Modelo ${i+1}`, locale:'es-ES' }))
export const Pricing = { oneoff:{min:2999,max:4999}, subscription:{min:199,max:399,period:'month'}, support:{price:99,period:'month'}, setup:{price:499} }
export function estimateROI({oneoff, subscription, activeCenters, months, convRate, extraRevenuePerCenter}:{oneoff:number, subscription:number, activeCenters:number, months:number, convRate:number, extraRevenuePerCenter:number}){
  const upfront = oneoff * activeCenters * convRate; const mrr = subscription * activeCenters; const added = extraRevenuePerCenter * activeCenters; const revenue = upfront + (mrr*months) + (added*months); return { upfront, mrr, addedMonthly: added, revenue, months }
}
