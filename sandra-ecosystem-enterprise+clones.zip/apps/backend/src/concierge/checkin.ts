import type { Database } from 'better-sqlite3'
export function ensureTables(db: Database){
  db.exec(`CREATE TABLE IF NOT EXISTS checkins (id INTEGER PRIMARY KEY, reservation_id INTEGER, status TEXT, lat REAL, lng REAL, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);`)
}
export async function pingArrival(to:string, address:string, mapLink:string){
  return { ok:true, to, message:`Bienvenido. Acceso: ${address}. Guía: ${mapLink}` }
}
