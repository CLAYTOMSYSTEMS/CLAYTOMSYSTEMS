import type { Database } from 'better-sqlite3'
export function ensureTables(db: Database){
  db.exec(`
    CREATE TABLE IF NOT EXISTS restaurants (id INTEGER PRIMARY KEY, name TEXT, phone TEXT, address TEXT, cuisine TEXT, commission_pct REAL DEFAULT 10);
    CREATE TABLE IF NOT EXISTS restaurant_deals (id INTEGER PRIMARY KEY, restaurant_id INTEGER, terms TEXT, commission_pct REAL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS restaurant_bookings (id INTEGER PRIMARY KEY, guest_name TEXT, guest_phone TEXT, restaurant_id INTEGER, date TEXT, pax INTEGER, prepaid REAL DEFAULT 0, status TEXT DEFAULT 'pending', session_url TEXT);
  `)
}
export function createDeal(db: Database, restaurant_id:number, terms:string, commission_pct:number){
  db.prepare('INSERT INTO restaurant_deals (restaurant_id, terms, commission_pct) VALUES (?,?,?)').run(restaurant_id, terms, commission_pct)
}
export async function bookWithPrepay(_db:Database, payload:any){
  // Stripe real pending; returns placeholder URL
  return { booking_id: Math.floor(Math.random()*1e6), url: 'https://checkout.stripe.com/demo' }
}
export async function callForNegotiation(phone:string, script:string){
  return { ok:true, to: phone, script }
}
