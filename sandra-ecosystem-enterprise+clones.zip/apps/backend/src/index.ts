import 'dotenv/config'
import express from 'express'
import rateLimit from 'express-rate-limit'
import jwt from 'jsonwebtoken'
import Database from 'better-sqlite3'
import { secureHeaders } from './security/headers.js'
import { buildItinerary, sendItinerary } from './concierge/itineraries.js'
import * as Resto from './concierge/restaurants.js'
import * as Srv from './concierge/services.js'
import * as CheckIn from './concierge/checkin.js'
import { router as sectorsRouter } from './sectors/routes.js'
import { ensureEducationTables, getRemainingScreenMinutes } from './education/docendo.js'
import { buildICS } from './meetings/ics.js'
import prom from 'prom-client'

const PORT = Number(process.env.PORT||4000)
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret'
const DB_PATH = 'apps/backend/data/sandra.db'

const app = express()
app.use(express.json({ limit: '2mb' }))
app.use(secureHeaders)

const limiter = rateLimit({ windowMs: 60_000, max: Number(process.env.RATE_LIMIT_MAX||120) })
app.use(limiter)

const db = new Database(DB_PATH)
app.locals.db = db

// Core tables
db.exec(`
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, email TEXT UNIQUE, pass TEXT, role TEXT DEFAULT 'admin');
CREATE TABLE IF NOT EXISTS leads (id INTEGER PRIMARY KEY, owner_id INTEGER, source TEXT, property TEXT, status TEXT, last_contact TEXT);
CREATE TABLE IF NOT EXISTS api_keys (id INTEGER PRIMARY KEY, name TEXT, hash TEXT, scopes TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, expires_at TEXT, last_used_at TEXT);
CREATE TABLE IF NOT EXISTS refresh_tokens (id INTEGER PRIMARY KEY, user_id INTEGER, token TEXT, expires_at TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, revoked INTEGER DEFAULT 0);
`)
try{ Resto.ensureTables(db); Srv.ensureTables(db); CheckIn.ensureTables(db); ensureEducationTables(db) }catch{}

// Auth helpers
function auth(req:any,res:any,next:any){
  const h = req.headers.authorization||''
  const t = h.startsWith('Bearer ') ? h.slice(7) : null
  if (!t) return res.status(401).json({ error:'missing token' })
  try{ req.user = jwt.verify(String(t), JWT_SECRET); next() }catch{ return res.status(401).json({ error:'invalid token' }) }
}
function requireRole(role:string){ return function(req:any,res:any,next:any){ if (req.user?.role===role || req.user?.role==='admin') return next(); return res.status(403).json({error:'forbidden'}) }}

app.get('/healthz', (_req,res)=> res.json({ ok:true }))

// Metrics
if (process.env.PROMETHEUS_ENABLED==='true'){
  prom.collectDefaultMetrics()
  app.get('/metrics', (_req,res)=>{ res.setHeader('Content-Type', prom.register.contentType); prom.register.metrics().then(m=>res.send(m)) })
}

// Login (demo) issues JWT 1h + refresh
import crypto from 'node:crypto'
app.post('/auth/login', (req,res)=>{
  const { email='admin@local', pass='admin' } = req.body||{}
  let row = db.prepare('SELECT * FROM users WHERE email=?').get(email) as any
  if (!row){ db.prepare('INSERT INTO users (email, pass, role) VALUES (?,?,?)').run(email, pass, 'admin'); row = db.prepare('SELECT * FROM users WHERE email=?').get(email) }
  const token = jwt.sign({ sub: row.id, email: row.email, role: row.role }, JWT_SECRET, { expiresIn: '1h' })
  const refresh = crypto.randomBytes(24).toString('hex')
  db.prepare('INSERT INTO refresh_tokens (user_id, token, expires_at) VALUES (?,?, datetime("now","+30 days"))').run(row.id, refresh)
  res.json({ token, refresh })
})
app.post('/auth/refresh', (req,res)=>{
  const { refresh } = req.body||{}
  const row = db.prepare('SELECT * FROM refresh_tokens WHERE token=? AND revoked=0 AND expires_at > CURRENT_TIMESTAMP').get(String(refresh||'')) as any
  if (!row) return res.status(401).json({ error:'invalid refresh' })
  const token = jwt.sign({ sub: row.user_id }, JWT_SECRET, { expiresIn: '1h' })
  res.json({ token })
})

// Sectors
app.use('/sectors', sectorsRouter)

// Concierge
app.post('/concierge/itinerary/preview', auth, async (req,res)=>{ const { guest, origin, destination, arrivalISO } = req.body||{}; const it = await buildItinerary({ guest, origin, destination, arrivalISO }); res.json(it) })
app.post('/concierge/itinerary/send', auth, async (req,res)=>{ const { channel='whatsapp', to, guest, origin, destination, arrivalISO } = req.body||{}; const it = await buildItinerary({ guest, origin, destination, arrivalISO }); const r = await sendItinerary({ channel, to }, it); res.json(r) })
app.post('/restaurants', auth, requireRole('admin'), (req,res)=>{ const { name, phone, address, cuisine, commission_pct=10 } = req.body||{}; const info = db.prepare('INSERT INTO restaurants (name,phone,address,cuisine,commission_pct) VALUES (?,?,?,?,?)').run(name,phone,address,cuisine,commission_pct); res.json({ id: info.lastInsertRowid }) })
app.get('/restaurants', auth, (_req,res)=> res.json(db.prepare('SELECT * FROM restaurants ORDER BY id DESC').all()))
app.post('/restaurants/deal', auth, requireRole('admin'), (req,res)=>{ const { restaurant_id, terms, commission_pct=10 } = req.body||{}; Resto.createDeal(db, Number(restaurant_id), String(terms||''), Number(commission_pct)); res.json({ ok:true }) })
app.post('/restaurants/book', auth, async (req,res)=>{ const r = await Resto.bookWithPrepay(db, req.body||{}); res.json(r) })
app.post('/services/providers', auth, requireRole('admin'), (req,res)=>{ const { type, name, phone, email, price, city, notes } = req.body||{}; const info = db.prepare('INSERT INTO providers (type,name,phone,email,price,city,notes) VALUES (?,?,?,?,?,?,?)').run(type,name,phone,email,Number(price||0),city,notes||''); res.json({ id: info.lastInsertRowid }) })
app.get('/services/providers', auth, (_req,res)=> res.json(db.prepare('SELECT * FROM providers ORDER BY id DESC').all()))
app.post('/services/book', auth, (req,res)=>{ const { provider_id, guest_name, guest_phone, date, notes } = req.body||{}; const info = db.prepare('INSERT INTO service_bookings (provider_id,guest_name,guest_phone,date,notes) VALUES (?,?,?,?,?)').run(Number(provider_id),guest_name,guest_phone,date,notes||''); res.json({ id: info.lastInsertRowid }) })
app.post('/checkin/start', auth, async (req,res)=>{ const { reservation_id, to, address, map_link } = req.body||{}; db.prepare('INSERT INTO checkins (reservation_id, status) VALUES (?,?)').run(Number(reservation_id||0),'started'); const ping = await CheckIn.pingArrival(String(to||''), String(address||''), String(map_link||'')); res.json({ ok:true, ping }) })
app.post('/meetings/ics', (req,res)=>{ const ics = buildICS(req.body||{}); res.setHeader('Content-Type','text/calendar'); res.send(ics) })

app.listen(PORT, ()=> console.log('API on :' + PORT))
