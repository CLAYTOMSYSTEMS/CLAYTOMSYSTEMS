#!/usr/bin/env bash
set -euo pipefail
: "${GIT_REMOTE:?Set GIT_REMOTE}"
: "${GIT_BRANCH:=main}"
if [ ! -d .git ]; then git init && git checkout -b "$GIT_BRANCH"; fi
git add -A
git commit -m "deploy: initial ecosystem"
git remote remove origin >/dev/null 2>&1 || true
git remote add origin "$GIT_REMOTE"
git push -u origin "$GIT_BRANCH"
