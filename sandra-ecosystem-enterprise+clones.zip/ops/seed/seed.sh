#!/usr/bin/env bash
set -euo pipefail
npx ts-node ops/seed/generate_sector_models.ts
if command -v sqlite3 >/dev/null 2>&1; then
  sqlite3 apps/backend/data/sandra.db < ops/seed/sql_sector_models.sql || true
else
  echo "sqlite3 not installed; skipped DB seed."
fi
