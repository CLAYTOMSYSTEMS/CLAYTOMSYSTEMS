// Generate 97+ franchise kits
import fs from 'node:fs'; import path from 'node:path'
type Kit = { slug:string, models: string[] }
const byCount = (p:string,n:number)=>Array.from({length:n}).map((_,i)=>`${p}-${String(i+1).padStart(2,'0')}`)
const kits:Kit[]=[
  { slug:'docendo', models:['valencia','madrid','barcelona','sevilla','malaga','alicante','murcia','zaragoza','baleares','canarias','cantabria','euskadi','galicia','castilla','rioja'] },
  { slug:'hospitales', models:byCount('modelo',20) },
  { slug:'centros-comerciales', models:byCount('modelo',15) },
  { slug:'bibliotecas', models:byCount('modelo',12) },
  { slug:'ayuntamientos', models:byCount('modelo',10) },
  { slug:'cruceros-parques', models:byCount('modelo',25) },
]
const root = path.resolve(process.cwd(),'franchises','sectorial'); fs.mkdirSync(root,{recursive:true})
for (const kit of kits){ for(const m of kit.models){ const dir=path.join(root,kit.slug,m); fs.mkdirSync(dir,{recursive:true}); const brand={ name:`Sandra ${kit.slug} · ${m}`, sector:kit.slug, model:m, primaryColor:'#00D8FF', accentColor:'#A78BFA', domain:`${kit.slug}-${m}.guestsvalencia.es`, locale:'es-ES' }; fs.writeFileSync(path.join(dir,'branding.json'),JSON.stringify(brand,null,2)); fs.writeFileSync(path.join(dir,'.env.example'),[`NEXT_PUBLIC_BRAND_NAME=${brand.name}`,`NEXT_PUBLIC_BRAND_SECTOR=${kit.slug}`,`NEXT_PUBLIC_BRAND_MODEL=${m}`,`NEXT_PUBLIC_BRAND_DOMAIN=${brand.domain}`].join('\n')) } }
console.log('✓ Sectorial franchise kits generated under franchises/sectorial')
