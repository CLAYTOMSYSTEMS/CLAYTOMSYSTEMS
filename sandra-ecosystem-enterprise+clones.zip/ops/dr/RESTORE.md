1) Provision VM 2) Restore DB 3) Switch DNS 4) Validate /healthz & /metrics
