// generator placeholder
