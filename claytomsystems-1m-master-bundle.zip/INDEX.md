# ClayTomSystems — 1M MASTER BUNDLE
Date: 2025-09-05 (Europe/Madrid)

## Artifacts & SHA-256
- activation_doc: MODE : ON DIRECT - FINAL-52000-AGENTES-ACTIVACION.md  sha256=a2624ab9e3303abb8765743c2155473a6a10c2d29f13f84d7ed299349cd5fd01
- final-52000-activacion-per-subsidiaria: final-52000-activacion-per-subsidiaria.zip  sha256=20c569348f2bd78c42f516875a8a2b79d7c92a75ffac7438ba6c4ec7f02b4e8d
- claytomsystems-hierarchy-1500: claytomsystems-hierarchy-1500.zip  sha256=bc1e09e1182128ed32f480f20085c804862ae2125d1d9314c0fe09a8f38a20b1
- cts-holding-galaxy: cts-holding-galaxy.zip  sha256=8c4bac8e4333a560dc5edac14e52a01e40ae31f7ee834f9b76673625739a73e5
- cts-power-transfer-suite: cts-power-transfer-suite.zip  sha256=548eed716ad8ce406323adbfddeccebf1faa5fb1ee939fedb617f1ba60af659b
- cts-contribution-150k: cts-contribution-150k.zip  sha256=fbd4f1792d861a86c844518c1c0424ff8c711b1a04e6698809c62a72cb4e691b
- cts-mega-infrastructure-700k: cts-mega-infrastructure-700k.zip  sha256=a5a526c148fcb28b9bafb0659d851bf855b68710c5a1c59dd5e892fc0ac6a35d
- cts-1m-addon-100k: cts-1m-addon-100k.zip  sha256=6c47d4fb96acc444a0e3b7a773f904862e3dd3c35d83a6adcf68a1bb9abf57e0
- cts-legend-pack-1m: cts-legend-pack-1m.zip  sha256=a6c1b6979ba28e2d4f937fab5844f5c5ce694aed68552fb161a026620739676b
