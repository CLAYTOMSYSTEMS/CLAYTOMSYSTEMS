const BRAND_CONFIGS = {
  'crypto.guestsvalencia.es': { name:'Sandra Crypto — Daily', personality:'educativo no asesoramiento' },
  'defi.guestsvalencia.es':   { name:'Sandra DeFi — Debates', personality:'moderadora educativa' }
}; module.exports = { BRAND_CONFIGS };