Doc de activación — pricing
