# Sandra PROTECH — Guests Valencia (Full-Stack Realtime Voice + Avatar)

Monorepo listo para producción con **backend (Express+WS)** y **frontend (Next.js+Tailwind)**.
Incluye:
- Proxy WebSocket a **OpenAI Realtime** (`/openai/session`)
- Endpoints para **HeyGen** de arranque/cierre de sesión (`/heygen/session/new`, `/heygen/session/close`)
- **Botón trifásico** (toggle / push-to-talk / VAD) con diseño PRO y medidor RMS
- Integración lista con tu UI mediante `attachSandraMicSingle(...)`

## Requisitos
- Node.js 18+
- API keys:
  - `OPENAI_API_KEY` (server)
  - `HEYGEN_EMBED_URL` (si usas HeyGen, pon la URL de embed de tu sesión/room)

## Instalación
```bash
npm i
npm --workspace=@gv/server i
npm --workspace=@gv/web i
cp .env.example .env
cp apps/web/.env.example apps/web/.env.local
```

## Desarrollo (levanta server:4000 y web:3000)
```bash
npm run dev
```

## Producción
```bash
npm run build
npm run start
```

## Notas
- El **frontend** usa `NEXT_PUBLIC_SANDRA_API_URL` y `NEXT_PUBLIC_REALTIME_API_URL` (por defecto `http://localhost:4000` en dev).
- El **backend** hace de **proxy WS** a `wss://api.openai.com/v1/realtime?model=...` con el header `OpenAI-Beta: realtime=v1`.
- Los eventos enviados: `input_audio_buffer.append`, `input_audio_buffer.commit`, `response.create`.
