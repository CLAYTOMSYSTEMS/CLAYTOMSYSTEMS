import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import { createServer } from 'http'
import { WebSocketServer, WebSocket } from 'ws'

const app = express()
app.use(cors({ origin: '*'}))
app.use(express.json())

const PORT = Number(process.env.PORT) || 4000
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || ''
const OPENAI_REALTIME_MODEL = process.env.OPENAI_REALTIME_MODEL || 'gpt-4o-realtime-preview-2024-12-17'
const HEYGEN_EMBED_URL = process.env.HEYGEN_EMBED_URL || 'about:blank'

app.get('/healthz', (_req, res) => res.json({ ok: true }))

// --- HeyGen endpoints (ajusta a tu flujo real) ---
app.post('/heygen/session/new', (_req, res) => {
  // En producción, crea la sala/room y devuelve la URL embed real
  res.json({ url: HEYGEN_EMBED_URL })
})
app.post('/heygen/session/close', (_req, res) => {
  res.json({ ok: true })
})

// --- HTTP server + WS proxy ---
const server = createServer(app)

// WS server en /openai/session
const wss = new WebSocketServer({ server, path: '/openai/session' })

wss.on('connection', (client, req) => {
  console.log('[WS] client connected', req.socket.remoteAddress)

  if (!OPENAI_API_KEY) {
    client.close(1011, 'Server missing OPENAI_API_KEY')
    return
  }

  // Conecta a OpenAI Realtime por WebSocket (server-to-server)
  const url = `wss://api.openai.com/v1/realtime?model=${encodeURIComponent(OPENAI_REALTIME_MODEL)}`
  const upstream = new WebSocket(url, {
    headers: {
      'Authorization': `Bearer ${OPENAI_API_KEY}`,
      'OpenAI-Beta': 'realtime=v1'
    }
  })

  upstream.on('open', () => {
    console.log('[WS] upstream connected')
  })

  upstream.on('message', (data) => {
    try {
      // Reenvía tal cual (texto/binario)
      client.readyState === WebSocket.OPEN && client.send(data)
    } catch (e) { console.error('Send to client error:', e) }
  })

  upstream.on('close', (code, reason) => {
    console.log('[WS] upstream closed', code, reason.toString())
    try { client.close(code, reason.toString()) } catch {}
  })

  upstream.on('error', (err) => {
    console.error('[WS] upstream error', err)
    try { client.close(1011, 'Upstream error') } catch {}
  })

  client.on('message', (data) => {
    try {
      upstream.readyState === WebSocket.OPEN && upstream.send(data)
    } catch (e) { console.error('Send to upstream error:', e) }
  })

  client.on('close', (code, reason) => {
    console.log('[WS] client closed', code, reason.toString())
    try { upstream.close() } catch {}
  })

  client.on('error', (err) => {
    console.error('[WS] client error', err)
    try { upstream.close() } catch {}
  })
})

server.listen(PORT, () => {
  console.log(`[HTTP] listening on http://localhost:${PORT}`)
})
