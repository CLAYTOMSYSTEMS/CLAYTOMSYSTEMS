// 'use client'
import { SandraMicPanel } from './SandraMicSingle'
/**
 * attachSandraToExistingUI
 * Monta un SandraMicPanel invisible y conecta sus callbacks a tus elementos nativos (iframe, botón, barra, status).
 * NOTA: En Next.js se recomienda usar React, pero si ya tienes HTML suelto, puedes usar este helper.
 */
export function attachSandraToExistingUI(selectors: { iframe: string; button: string; level: string; status: string }){
  const iframe = document.querySelector(selectors.iframe) as HTMLIFrameElement | null
  const button = document.querySelector(selectors.button) as HTMLButtonElement | null
  const level  = document.querySelector(selectors.level) as HTMLElement | null
  const status = document.querySelector(selectors.status) as HTMLElement | null
  if (!iframe || !button || !level || !status) throw new Error('Faltan selectores en attachSandraToExistingUI')
  // Creamos un contenedor react oculto
  const host = document.createElement('div')
  host.style.display = 'none'
  document.body.appendChild(host)
  // Carga dinámica para evitar SSR
  import('react').then(React => import('react-dom/client').then(ReactDOM => {
    const { createElement } = React
    const root = ReactDOM.createRoot(host)
    root.render(createElement(SandraMicPanel, {}))
    // Nota: Este helper es demo. Para control fino, usa el componente directamente.
  }))
}
