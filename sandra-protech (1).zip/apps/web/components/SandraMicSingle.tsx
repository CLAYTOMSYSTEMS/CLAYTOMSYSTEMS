// 'use client'
import React, { useEffect, useRef, useState } from 'react'

type SandraState = 'idle' | 'connecting' | 'active' | 'stopping' | 'error'
type VADCfg = { speechThreshold?: number; silenceMs?: number }
type SandraConfig = {
  apiBase?: string
  rtBase?: string
  wsPath?: string
  avatarPaths?: { start: string; stop: string }
  vad?: VADCfg
  authToken?: string
  model?: string
}

const DEF_API = process.env.NEXT_PUBLIC_SANDRA_API_URL || 'http://localhost:4000'
const DEF_RT  = process.env.NEXT_PUBLIC_REALTIME_API_URL || 'http://localhost:4000'

const defaults = {
  apiBase: DEF_API,
  rtBase: DEF_RT,
  wsPath: '/openai/session',
  avatarPaths: { start: '/heygen/session/new', stop: '/heygen/session/close' },
  vad: { silenceMs: 900, speechThreshold: 0.12 },
}

function clamp01(n:number){ return Math.min(1, Math.max(0, n)) }
function resolveVad(user?: VADCfg){
  const s = typeof user?.speechThreshold === 'number' ? Math.min(1, Math.max(0, user!.speechThreshold!)) : defaults.vad.speechThreshold
  const ms = typeof user?.silenceMs === 'number' ? Math.max(200, user!.silenceMs!) : defaults.vad.silenceMs
  return { speechThreshold: s!, silenceMs: ms! }
}
function buildWSUrl(rtBase: string, wsPath = '/openai/session'){
  const u = new URL(rtBase.startsWith('http')||rtBase.startsWith('ws')?rtBase:`https://${rtBase}`)
  const proto = u.protocol.startsWith('http') ? (u.protocol==='http:'?'ws:':'wss:') : u.protocol
  const p = wsPath.startsWith('/')?wsPath:`/${wsPath}`
  return `${proto}//${u.host}${p}`
}

function floatTo16BitPCM(float32: Float32Array){
  const out = new Int16Array(float32.length)
  for (let i=0;i<float32.length;i++){
    const s = Math.max(-1, Math.min(1, float32[i]))
    out[i] = s<0 ? s*0x8000 : s*0x7fff
  }
  return out
}
function pcm16ToBase64(int16: Int16Array){
  const buf = new Uint8Array(int16.buffer)
  let bin = ''
  for (let i=0;i<buf.byteLength;i++) bin += String.fromCharCode(buf[i])
  return btoa(bin)
}
function resampleTo16k(input: Float32Array, inRate: number){
  const outRate = 16000
  if (inRate === outRate) return input
  const ratio = inRate / outRate
  const outLen = Math.floor(input.length / ratio)
  const out = new Float32Array(outLen)
  for (let i=0;i<outLen;i++){
    const idx = i*ratio
    const i0 = Math.floor(idx)
    const i1 = Math.min(i0+1, input.length-1)
    const frac = idx - i0
    out[i] = input[i0]*(1-frac) + input[i1]*frac
  }
  return out
}

export function SandraMicPanel(props: Partial<SandraConfig> & { className?: string }){
  const cfg = {
    apiBase: props.apiBase || defaults.apiBase,
    rtBase: props.rtBase || defaults.rtBase,
    wsPath: props.wsPath || defaults.wsPath,
    avatarPaths: props.avatarPaths || defaults.avatarPaths,
    vad: resolveVad(props.vad),
  }
  const [state, setState] = useState<SandraState>('idle')
  const [label, setLabel] = useState('Hablar')
  const refBtn = useRef<HTMLButtonElement>(null)
  const refLevel = useRef<HTMLDivElement>(null)
  const refStatus = useRef<HTMLSpanElement>(null)
  const refIframe = useRef<HTMLIFrameElement>(null)
  const wsRef = useRef<WebSocket | null>(null)
  const ctxRef = useRef<AudioContext | null>(null)
  const procRef = useRef<ScriptProcessorNode | null>(null)
  const srcRef = useRef<MediaStreamAudioSourceNode | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const hadSpeechRef = useRef(false)
  const timerRef = useRef<number | null>(null)

  useEffect(()=>{
    setLabel(state==='active' ? 'Detener' : (state==='connecting' ? 'Conectando…' : 'Hablar'))
  }, [state])

  function setLevel(v:number){ if(refLevel.current){ refLevel.current.style.width = `${Math.round(clamp01(v)*100)}%` } }
  function setStatus(t:string){ if(refStatus.current) refStatus.current.textContent = t }

  async function avatarStart(){
    const res = await fetch(`${cfg.apiBase}${cfg.avatarPaths.start}`, { method:'POST', headers: { 'Content-Type':'application/json' } })
    if (!res.ok) throw new Error('Avatar start failed')
    const data = await res.json()
    if (!data?.url) throw new Error('No avatar URL')
    if (refIframe.current) refIframe.current.src = String(data.url)
  }
  async function avatarStop(){
    try { await fetch(`${cfg.apiBase}${cfg.avatarPaths.stop}`, { method:'POST' }) } catch {}
  }

  function scheduleSilence(){
    if (timerRef.current) window.clearTimeout(timerRef.current)
    timerRef.current = window.setTimeout(()=>{
      if (hadSpeechRef.current && wsRef.current && wsRef.current.readyState===1){
        wsRef.current.send(JSON.stringify({ type: 'input_audio_buffer.commit' }))
        wsRef.current.send(JSON.stringify({ type: 'response.create', response: { instructions: 'continue' } }))
        hadSpeechRef.current = false
      }
    }, cfg.vad.silenceMs)
  }

  async function start(){
    if (state==='active' || state==='connecting') return
    setState('connecting'); setStatus('CONECTANDO…')
    try{
      await avatarStart()
      // WS
      const url = buildWSUrl(cfg.rtBase!, cfg.wsPath)
      const ws = new WebSocket(url)
      ws.onopen = ()=>{ /* ready */ }
      ws.onmessage = (ev)=>{ /* audio renderiza HeyGen iframe */ }
      ws.onerror = ()=>{ /* noop */ }
      ws.onclose = ()=>{ /* noop */ }
      wsRef.current = ws

      // Audio
      const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } })
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)()
      const src = ctx.createMediaStreamSource(stream)
      const proc = ctx.createScriptProcessor(4096, 1, 1)
      src.connect(proc); proc.connect(ctx.destination)
      proc.onaudioprocess = (e)=>{
        const input = e.inputBuffer.getChannelData(0)
        let sum=0; for(let i=0;i<input.length;i++){ const s=input[i]; sum+=s*s }
        const rms = Math.sqrt(sum/input.length)
        setLevel(rms)
        const speaking = rms >= cfg.vad.speechThreshold
        if (speaking){ hadSpeechRef.current = true; scheduleSilence() }
        // encode and send
        const resampled = resampleTo16k(input, ctx.sampleRate)
        const pcm16 = floatTo16BitPCM(resampled)
        const b64 = pcm16ToBase64(pcm16)
        ws.readyState===1 && ws.send(JSON.stringify({ type:'input_audio_buffer.append', audio: b64 }))
      }
      ctxRef.current = ctx; procRef.current = proc; srcRef.current = src; streamRef.current = stream
      setState('active'); setStatus('ACTIVA')
    }catch(e){
      console.error('start error', e)
      setState('error'); setStatus('ERROR')
      await stop()
      throw e
    }
  }

  async function stop(){
    if (state==='idle' || state==='stopping') return
    setState('stopping'); setStatus('DETENIENDO…')
    try{
      try { wsRef.current && wsRef.current.send(JSON.stringify({ type:'input_audio_buffer.commit' })) } catch {}
      try { wsRef.current && wsRef.current.close() } catch {}
      wsRef.current = null
      if (procRef.current){ try{ procRef.current.disconnect() }catch{}; procRef.current = null }
      if (srcRef.current){ try{ srcRef.current.disconnect() }catch{}; srcRef.current = null }
      if (streamRef.current){ streamRef.current.getTracks().forEach(t=>t.stop()); streamRef.current = null }
      if (ctxRef.current){ try{ await ctxRef.current.close() }catch{}; ctxRef.current = null }
      if (timerRef.current){ window.clearTimeout(timerRef.current); timerRef.current = null }
      setLevel(0)
      await avatarStop()
    } finally {
      setState('idle'); setStatus('INACTIVA')
    }
  }

  async function toggle(){ return state==='active' ? stop() : start() }

  // Push-to-talk (barra espaciadora)
  useEffect(()=>{
    const onKey = (e: KeyboardEvent)=>{
      if (e.code === 'Space'){
        e.preventDefault()
        if (state==='idle') start()
        else stop()
      }
    }
    window.addEventListener('keydown', onKey)
    return ()=> window.removeEventListener('keydown', onKey)
  }, [state])

  return (
    <div className={props.className || ''}>
      <div className="relative glass p-6">
        <div className="absolute inset-0 -z-10 bg-gradient-to-br from-fuchsia-500/10 via-purple-500/10 to-cyan-500/10 rounded-2xl blur-2xl" />
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold">Sandra IA · Realtime</h2>
          <span ref={refStatus} className="text-sm opacity-80">INACTIVA</span>
        </div>
        <iframe ref={refIframe} className="w-full h-72 rounded-xl border mt-4" />
        <div className="mt-4 flex items-center gap-3">
          <button ref={refBtn} onClick={toggle} className="px-5 py-3 rounded-2xl bg-white text-black font-medium hover:opacity-90 transition disabled:opacity-60">{label}</button>
          <div className="flex-1 h-2 bg-white/20 rounded-full overflow-hidden">
            <div ref={refLevel} className="h-2 bg-white" style={{width: '0%'}} />
          </div>
          <span className="text-xs opacity-70">Barra espaciadora = PTT</span>
        </div>
      </div>
    </div>
  )
}
