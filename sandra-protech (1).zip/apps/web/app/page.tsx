'use client'
import { SandraMicPanel } from '@/components/SandraMicSingle'
import { Mic, Waves } from 'lucide-react'

export default function Page(){
  return (
    <main className="min-h-screen bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-900 via-black to-black">
      <div className="max-w-5xl mx-auto px-6 pt-16 pb-24">
        <header className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-white text-black grid place-items-center"><Mic size={18} /></div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Guests Valencia · SANDRA 7.0</h1>
              <p className="text-sm opacity-70">Experiencia huésped PROTECH · Realtime Voice + Avatar</p>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-2 text-white/70"><Waves className="animate-pulse" /><span>GPT‑5 Powered</span></div>
        </header>

        <section className="mt-10 grid md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <h2 className="text-4xl md:text-5xl font-black leading-tight">Atiende a tus huéspedes <span className="text-white/70">en tiempo real</span></h2>
            <p className="text-white/80 text-lg">Pulsa Hablar o usa la barra espaciadora (push‑to‑talk). El avatar se muestra dentro del panel. Diseño PRO listo para tu marca.</p>
            <ul className="text-white/70 list-disc ml-6 space-y-2">
              <li>Proxy WS seguro al Realtime</li>
              <li>VAD local con RMS + commit automático</li>
              <li>Diseño glass + gradientes GPT‑5 style</li>
            </ul>
          </div>

          <SandraMicPanel className="mt-2" apiBase={process.env.NEXT_PUBLIC_SANDRA_API_URL} rtBase={process.env.NEXT_PUBLIC_REALTIME_API_URL} />
        </section>
      </div>
    </main>
  )
}
