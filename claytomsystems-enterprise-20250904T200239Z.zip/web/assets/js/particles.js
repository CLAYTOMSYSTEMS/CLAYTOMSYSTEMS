
(() => {
  const c = document.getElementById('particles'); if(!c) return;
  const ctx = c.getContext('2d'); let W, H, DPR = Math.max(1, window.devicePixelRatio||1);
  const N = 180; const P = [];
  function resize(){ W = c.clientWidth; H = c.clientHeight; c.width = W*DPR; c.height = H*DPR; ctx.setTransform(DPR,0,0,DPR,0,0); }
  addEventListener('resize', resize); resize();
  for(let i=0;i<N;i++) P.push({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-0.5)*.6,vy:(Math.random()-0.5)*.6,r:Math.random()*2+0.8});
  function step(){
    ctx.clearRect(0,0,W,H);
    for(const p of P){ p.x+=p.vx; p.y+=p.vy; if(p.x<0||p.x>W)p.vx*=-1; if(p.y<0||p.y>H)p.vy*=-1;
      ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,6.283); ctx.fillStyle='rgba(255,255,255,0.7)'; ctx.fill(); }
    for(let i=0;i<N;i++) for(let j=i+1;j<N;j++){ const a=P[i], b=P[j]; const dx=a.x-b.x, dy=a.y-b.y; const d=Math.hypot(dx,dy);
      if(d<110){ const alpha=1-d/110; ctx.strokeStyle=`rgba(124,58,237,${0.12*alpha})`; ctx.beginPath(); ctx.moveTo(a.x,a.y); ctx.lineTo(b.x,b.y); ctx.stroke(); } }
    requestAnimationFrame(step);
  } step();
})();
