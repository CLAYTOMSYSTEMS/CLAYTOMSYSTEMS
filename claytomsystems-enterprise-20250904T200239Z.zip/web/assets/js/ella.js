
const ui = { toggle: document.getElementById('mic-toggle'), status: document.getElementById('status'), out: document.getElementById('out') };
let active=false;
function log(m){ ui.out.value += m + "\n"; ui.out.scrollTop = ui.out.scrollHeight; }
async function start(){
  ui.status.textContent='Conectando…';
  const r = await fetch('/.netlify/functions/realtime-session', {method:'POST'});
  if(!r.ok){ ui.status.textContent='Error sesión'; return; }
  const data = await r.json();
  log('Realtime listo (token recibido)');
  ui.status.textContent='Activa. Di "hola" o escribe y envía.';
}
function stop(){ ui.status.textContent='Inactiva'; }
ui.toggle?.addEventListener('click', async () => { active=!active; ui.toggle.textContent=active?'Detener':'Hablar'; if(active) start(); else stop(); });
document.getElementById('send')?.addEventListener('click', async () => {
  const q = document.getElementById('q').value.trim(); if(!q) return;
  log('Tú: ' + q);
  const r = await fetch('/.netlify/functions/health'); log('Ella: (demo) ok');
});
