
export async function handler(event) {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return { statusCode: 500, body: 'Missing OPENAI_API_KEY' };
  try {
    const r = await fetch('https://api.openai.com/v1/realtime/sessions', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: 'gpt-4o-realtime-preview-2024-12-17' })
    });
    const data = await r.json();
    return { statusCode: 200, body: JSON.stringify({ client_secret: data.client_secret, url: data?.url || null }) };
  } catch (e) {
    return { statusCode: 500, body: 'Realtime error' };
  }
}
