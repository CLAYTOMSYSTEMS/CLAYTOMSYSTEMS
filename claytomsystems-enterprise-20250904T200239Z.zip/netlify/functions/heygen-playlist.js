
export async function handler() {
  const data = {
    education: ["https://app.heygen.com/video/REEMPLAZA_ID"],
    industrial: ["https://app.heygen.com/video/REEMPLAZA_ID"],
    healthcare: ["https://app.heygen.com/video/REEMPLAZA_ID"],
    tourism: ["https://app.heygen.com/video/REEMPLAZA_ID"],
    finance: ["https://app.heygen.com/video/REEMPLAZA_ID"],
    ecommerce: ["https://app.heygen.com/video/REEMPLAZA_ID"]
  };
  return { statusCode: 200, body: JSON.stringify(data) };
}
