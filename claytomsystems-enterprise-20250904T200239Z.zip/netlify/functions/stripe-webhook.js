
export async function handler(event) {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };
  // TODO: verifica firma con STRIPE_WEBHOOK_SECRET y procesa events
  return { statusCode: 200, body: 'ok' };
}
