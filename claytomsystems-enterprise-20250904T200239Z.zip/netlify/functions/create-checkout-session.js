
import Stripe from 'stripe';
export async function handler(event) {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };
  const { kind } = JSON.parse(event.body||'{}');
  const secret = process.env.STRIPE_SECRET_KEY;
  const priceOne = process.env.STRIPE_PRICE_ONETIME;
  const priceSubs = process.env.STRIPE_PRICE_SUBS;
  const site = process.env.SITE_URL || 'http://localhost:8888';
  if(!secret) return { statusCode: 500, body:'Missing STRIPE_SECRET_KEY' };
  const stripe = new Stripe(secret, { apiVersion: '2024-06-20' });
  const line = kind === 'subs' ? { price: priceSubs, quantity: 1 } : { price: priceOne, quantity: 1 };
  const mode = kind === 'subs' ? 'subscription' : 'payment';
  try {
    const session = await stripe.checkout.sessions.create({
      mode,
      line_items: [line],
      success_url: `${site}/?checkout=success`,
      cancel_url: `${site}/?checkout=cancel`
    });
    return { statusCode: 200, body: JSON.stringify({ url: session.url }) };
  } catch (e) {
    return { statusCode: 500, body: 'Stripe error' };
  }
}
