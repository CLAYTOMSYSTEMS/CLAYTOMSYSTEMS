
# CLAYTOMSYSTEMS — Enterprise Ecosystem
Entrega lista para producción (Netlify + GitHub).

## Estructura
- `web/` — Sitio molecular (150+ partículas), 6 sectores, "Pregúntale a Ella", e‑commerce, demos de video
- `netlify/functions/` — Endpoints serverless (Stripe Checkout, OpenAI Realtime, HeyGen playlist, health)
- `docs/` — Presentación comercial y guías
- `netlify.toml` — Seguridad + headers + rutas funciones
- `.env.template` — Variables a definir en Netlify → Site settings → Environment

## Despliegue rápido (Netlify)
1. Crea un repo GitHub privado y sube todo este paquete.
2. En Netlify: **New site from Git** → elige el repo.
3. En **Site settings → Environment variables**, define:
   - `OPENAI_API_KEY` (para realtime)
   - `STRIPE_SECRET_KEY`, `STRIPE_PRICE_ONETIME`, `STRIPE_PRICE_SUBS`, `STRIPE_WEBHOOK_SECRET`
   - `HEYGEN_API_KEY` (si usas playlist privada)
   - `SITE_URL` (https://claytomsystems.com)
4. Asegúrate de apuntar tus dominios **claytomsystems.com** y **.es** al site de Netlify (Domain settings).
5. Verifica el health: `https://claytomsystems.com/.netlify/functions/health` → **ok**

## Rutas principales
- Landing molecular: `/` (hero con 180 partículas + navegación)
- Sectores: `/sectors/education.html`, `/industrial.html`, `/healthcare.html`, `/tourism.html`, `/finance.html`, `/ecommerce.html`
- "Pregúntale a Ella": `/ella.html` (voz + teclado, Realtime via WS, barge‑in)
- Demos de vídeo (avatar): `/videos.html`
- E‑commerce: `/checkout.html` (compra única + suscripción)

## Legal / Cumplimiento
- No es asesoramiento financiero/médico. Archivos con disclaimers en UI.
- Stripe/PayPal requieren claves reales. Nunca subas secretos al repo.

