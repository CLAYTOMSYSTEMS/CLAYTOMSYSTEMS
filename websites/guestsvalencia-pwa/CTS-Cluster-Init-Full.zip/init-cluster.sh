#!/bin/bash
echo "🚀 Inicializando clúster Kubernetes con Minikube + Calico..."

# Iniciar Minikube con Calico (necesario para que funcionen las NetworkPolicies)
minikube start --network-plugin=cni --cni=calico --driver=docker

echo "✅ Minikube levantado con Calico."

# Ejecutar autorun para limpiar todo (abrir egress global)
sh autorun.sh

echo "🌍 Clúster inicializado y sistema liberado (egress abierto globalmente)."
