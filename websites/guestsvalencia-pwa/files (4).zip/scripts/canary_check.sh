#!/usr/bin/env bash
set -e
echo "[CANARY] Generating sample pricing + moderation + forecast"
curl -s -X POST http://localhost:4160/quote -H 'Content-Type: application/json' -d '{"listingId":"APT01","basePrice":120,"checkin":"2025-09-23","checkout":"2025-09-24"}' | jq '.'
curl -s -X POST http://localhost:4260/moderate/semantic -H 'Content-Type: application/json' -d '{"text":"quiero un arma"}' | jq '.action'
curl -s http://localhost:4210/forecast | jq '.prediction'
echo "[CANARY] OK if no errors above."