import 'dotenv/config';
import { PrismaClient } from '@prisma/client';
import { openAIEmbed } from '../apps/api/src/services/vectorSearch.js';

const prisma = new PrismaClient();

async function main() {
  const properties = await prisma.property.findMany();
  for (const prop of properties) {
    const text = `${prop.title}. ${prop.description}`;
    const vector = await openAIEmbed(text);
    await prisma.embeddingDocument.create({
      data: {
        propertyId: prop.id,
        source: 'property_description',
        text,
        language: prop.locale,
        vector
      }
    });
    console.log('Embedded property', prop.id);
  }
}

main().catch(e=>{console.error(e);process.exit(1);}).finally(()=>prisma.$disconnect());