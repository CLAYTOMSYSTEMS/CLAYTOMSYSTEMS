#!/usr/bin/env bash
set -e
declare -a URLS=(
  "http://localhost:4200/healthz"
  "http://localhost:4260/healthz"
  "http://localhost:4250/healthz"
  "http://localhost:4210/forecast"
  "http://localhost:4290/healthz"
  "http://localhost:4300/healthz"
)
echo "=== HEALTH CHECKS ==="
for u in "${URLS[@]}"; do
  code=$(curl -s -o /dev/null -w "%{http_code}" "$u")
  echo "$u -> $code"
done