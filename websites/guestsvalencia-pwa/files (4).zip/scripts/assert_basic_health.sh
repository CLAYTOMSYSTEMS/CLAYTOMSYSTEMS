#!/usr/bin/env bash
set -e

echo "[Health] API"
curl -sf "${BASE_API}/health/live" >/dev/null || (echo "API live failed" && exit 1)

echo "[Health] Booking Command"
curl -sf -X POST "${BOOKING_CMD:-$BASE_API/booking/command/create}" \
  -H 'Content-Type: application/json' \
  -d '{"propertyId":"prop-demo-1","userId":"user-demo-1","checkIn":"2025-10-01","checkOut":"2025-10-03","guests":2,"totalCents":0}' | grep -q 'bookingId' || (echo "Booking command fail" && exit 1)

echo "[Health] Retrieval"
curl -sf -X POST "${GATEWAY_URL}/conversation/query" \
  -H 'Content-Type: application/json' \
  -d '{"query":"precio apartamento","locale":"es"}' >/dev/null || (echo "Retrieval fail" && exit 1)

echo "[Health] OK"