import 'dotenv/config';
import { PrismaClient } from '@prisma/client';
import crypto from 'crypto';

const prisma = new PrismaClient();
const N = parseInt(process.env.SYNTHETIC_EMBED_COUNT || '5000', 10);
const DIM = 1536;

function synthVector(seed: string) {
  const hash = crypto.createHash('sha256').update(seed).digest();
  const buf = Buffer.alloc(DIM * 4);
  for (let i=0;i<DIM;i++) {
    const v = (hash[i % hash.length] / 255) * 2 - 1;
    buf.writeFloatLE(v, i*4);
  }
  return buf;
}

async function run() {
  for (let i=0;i<N;i++) {
    const title = `Synthetic Property ${i}`;
    const desc = `Synthetic description embedding stress test ${i} near beach center premium pool terrace wifi`;
    const text = `${title}. ${desc}`;
    const vector = synthVector(title);
    await prisma.embeddingDocument.create({
      data: {
        source: 'synthetic',
        text,
        language:'es',
        vector
      }
    });
    if (i % 200 === 0) console.log('Inserted', i);
  }
  console.log('Done synthetic embeddings', N);
}
run().catch(e=>{console.error(e);process.exit(1);});