#!/usr/bin/env bash
OUT=backups/config_$(date +%Y%m%d_%H%M%S)
mkdir -p "$OUT"
echo "[SNAPSHOT] Exporting environment + policies..."
cp services/*/.env* "$OUT" 2>/dev/null || true
pg_dump --schema-only "${POSTGRES_URL:-postgres://gv:example@postgres:5432/gv_core}" > "$OUT/schema.sql" || true
curl -s http://localhost:4260/healthz > "$OUT/guardrails_health.json" || true
sha256sum "$OUT"/* > "$OUT/SHA256SUMS.txt" 2>/dev/null || true
echo "[DONE] Stored at $OUT"