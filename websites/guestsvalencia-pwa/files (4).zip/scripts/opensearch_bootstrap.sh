#!/usr/bin/env bash
set -e
OS_URL=${OPENSEARCH_URL:-http://localhost:9200}
INDEX=properties_index

echo "[*] Creating index mapping..."
curl -s -X PUT "$OS_URL/$INDEX" -H 'Content-Type: application/json' -d '{
  "settings": {
    "number_of_shards": 1,
    "analysis": {
      "analyzer": {
        "lang_es": { "type":"standard", "stopwords":"_spanish_" }
      }
    }
  },
  "mappings": {
    "properties": {
      "title": {"type":"text","analyzer":"lang_es"},
      "description":{"type":"text","analyzer":"lang_es"},
      "locale":{"type":"keyword"},
      "amenities":{"type":"text"},
      "boost_factor":{"type":"float"}
    }
  }
}' >/dev/null

echo "[*] Seeding sample docs..."
curl -s -X POST "$OS_URL/$INDEX/_bulk" -H 'Content-Type: application/x-ndjson' --data-binary @- <<'ND'
{ "index": {} }
{ "title":"Apartamento Centro", "description":"Luminoso cerca plaza ayuntamiento", "locale":"es", "amenities":"wifi aire", "boost_factor":1.2 }
{ "index": {} }
{ "title":"Loft Playa", "description":"Vista mar ideal familia", "locale":"es", "amenities":"terraza wifi", "boost_factor":1.1 }
{ "index": {} }
{ "title":"City Apartment", "description":"Close to old town", "locale":"en", "amenities":"wifi ac", "boost_factor":1.0 }
ND
echo
echo "[*] Done."