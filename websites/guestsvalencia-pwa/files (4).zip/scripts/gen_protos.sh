#!/usr/bin/env bash
set -euo pipefail

PROTO_DIR=proto
OUT_TS=libs/generated
mkdir -p "$OUT_TS"

npx protoc \
  --plugin=./node_modules/.bin/protoc-gen-ts_proto \
  --ts_proto_out="$OUT_TS" \
  --ts_proto_opt=esModuleInterop=true,outputServices=grpc-js,useExactTypes=false \
  -I "$PROTO_DIR" \
  $(find "$PROTO_DIR" -name "*.proto")

echo "[protos] TypeScript generation complete."

# (Opcional Go / Java generation hooks aquí)