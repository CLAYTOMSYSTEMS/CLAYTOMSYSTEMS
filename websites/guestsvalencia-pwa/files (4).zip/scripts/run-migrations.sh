#!/usr/bin/env bash
set -e
echo "Aplicando migraciones (init.sql) vía psql"
psql "$NEON_DB_URL" -f migrations/init.sql