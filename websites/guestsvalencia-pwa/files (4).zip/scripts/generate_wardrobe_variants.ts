/**
 * Generate combinational wardrobe JSON (styles x palettes x accessories)
 */
const base = [
  { base:'suit', variants:['navy','charcoal','light_gray'], moods:['serious','premium'], formality:0.9 },
  { base:'blazer', variants:['white','black','emerald'], moods:['premium','elegant'], formality:0.8 },
  { base:'dress', variants:['royal_blue','wine','cream'], moods:['elegant'], formality:0.95 },
  { base:'hoodie', variants:['bitcoin_black','eth_white','defi_purple'], moods:['tech','edgy'], formality:0.2 },
  { base:'tshirt', variants:['ethereum','solana','plain_lux'], moods:['neutral','tech'], formality:0.2 },
  { base:'valencia_dress', variants:['sunset','ocean','citrus'], moods:['warm','lifestyle'], formality:0.55 },
  { base:'casual_set', variants:['street_modern','trend_pastel','denim_lux'], moods:['energetic'], formality:0.3 }
];

const accessories = ['none','gold_pendant','silver_chain','smartwatch','subtle_earring','lapel_pin_crypto'];

const out: any[] = [];
for (const b of base) {
  for (const v of b.variants) {
    for (const acc of accessories) {
      out.push({
        code:`${b.base}_${v}_${acc}`,
        base:b.base,
        variant:v,
        accessory:acc,
        moods:b.moods,
        formality:b.formality,
        energy: energyHeuristic(b.base, v),
        tags:[b.base, v, acc].concat(b.moods)
      });
    }
  }
}
console.log(JSON.stringify(out,null,2));

function energyHeuristic(base:string, variant:string){
  if (/hoodie|tshirt|casual/.test(base)) return 0.8;
  if (/valencia/.test(base)) return 0.7;
  if (/dress/.test(base)) return 0.5;
  return 0.45;
}