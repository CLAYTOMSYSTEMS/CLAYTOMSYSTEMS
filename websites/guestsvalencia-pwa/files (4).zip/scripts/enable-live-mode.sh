#!/usr/bin/env bash
set -e
ENV_FILE=services/prompt-autopilot/.env
if grep -q 'DRY_RUN=true' "$ENV_FILE"; then
  sed -i 's/DRY_RUN=true/DRY_RUN=false/' "$ENV_FILE"
  docker compose restart prompt-autopilot
  echo "Autopilot live mode enabled."
fi