#!/usr/bin/env bash
set -e
declare -a URLS=(
  "http://localhost:4200/healthz"
  "http://localhost:4210/forecast"
  "http://localhost:4160/quote"
  "http://localhost:4060/healthz"
  "http://localhost:4010/healthz"
)
for u in "${URLS[@]}"; do
  code=$(curl -s -o /dev/null -w "%{http_code}" "$u")
  echo "$u -> $code"
done