#!/usr/bin/env bash
set -e
DATE=$(date +%Y%m%d-%H%M%S)
pg_dump "$NEON_DB_URL" > backups/backup-$DATE.sql
echo "Backup saved backups/backup-$DATE.sql"