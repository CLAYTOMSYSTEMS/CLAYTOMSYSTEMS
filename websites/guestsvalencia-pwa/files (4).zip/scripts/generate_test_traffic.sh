#!/usr/bin/env bash
echo "Simulating 20 pricing quotes + 10 moderation checks..."
for i in $(seq 1 20); do
  curl -s -X POST http://localhost:4160/quote -H 'Content-Type: application/json' \
    -d '{"listingId":"APT01","basePrice":120,"checkin":"2025-09-25","checkout":"2025-09-26"}' >/dev/null
done
for i in $(seq 1 10); do
  curl -s -X POST http://localhost:4260/moderate/semantic -H 'Content-Type: application/json' \
    -d '{"text":"mensaje normal de prueba"}' >/dev/null
done
echo "Done."