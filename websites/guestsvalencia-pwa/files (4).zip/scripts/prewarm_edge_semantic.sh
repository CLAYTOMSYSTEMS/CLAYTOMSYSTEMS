#!/usr/bin/env bash
set -e
# Pre-carga queries frecuentes (ej: "precio medio", "apartamento centro")
QUERIES=("apartamento centro" "precio medio" "alojamiento familia" "booking julio valencia")
for q in "${QUERIES[@]}"; do
  curl -s -X POST "https://edge.yourdomain/conversation/query" \
    -H "Content-Type: application/json" \
    -d "{\"query\":\"$q\",\"locale\":\"es\"}" >/dev/null || true
  echo "Prewarmed: $q"
done