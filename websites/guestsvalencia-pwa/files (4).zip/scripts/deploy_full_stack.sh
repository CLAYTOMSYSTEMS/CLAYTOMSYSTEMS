#!/usr/bin/env bash
set -e
echo "[1/8] Building images..."
docker compose -f docker-compose.yml build
echo "[2/8] Applying migrations..."
bash scripts/migrate-blindaje.sh "${DB_URL:-postgres://gv:example@postgres:5432/gv_core}"
echo "[3/8] Starting core services..."
docker compose -f docker-compose.yml up -d postgres nats prometheus grafana
sleep 5
echo "[4/8] Starting application layer..."
docker compose -f docker-compose.yml up -d ws-core llm-gateway pricing revenue-engine guardrails-v2 embeddings agent-hub
echo "[5/8] Starting intelligence & ML..."
docker compose -f docker-compose.yml up -d bi-forecast pricing-ml pricing-ml-adv prompt-autopilot voice-clone edge-vector-cache cache-replica-broker policy-signer
echo "[6/8] Health verification..."
bash scripts/verify_stack.sh
echo "[7/8] Seeding policies..."
bash scripts/seed_policies.sh
echo "[8/8] Ready. Tail decisions: bash scripts/monitor_agents.sh"