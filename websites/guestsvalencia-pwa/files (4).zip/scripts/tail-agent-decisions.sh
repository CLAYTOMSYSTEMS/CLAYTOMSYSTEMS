#!/usr/bin/env bash
# Requiere nats CLI instalado (https://github.com/nats-io/natscli)
nats sub 'agent.decision.>' --server nats://localhost:4222