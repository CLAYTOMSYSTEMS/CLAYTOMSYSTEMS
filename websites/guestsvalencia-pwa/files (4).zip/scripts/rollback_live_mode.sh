#!/usr/bin/env bash
set -e
FILES=(
  services/prompt-autopilot/.env
  services/pricing-ml/.env
  services/pricing-ml-adv/.env
)
for f in "${FILES[@]}"; do
  if grep -q 'DRY_RUN=false' "$f"; then
    sed -i 's/DRY_RUN=false/DRY_RUN=true/' "$f"
    echo "[REVERTED] $f -> DRY_RUN=true"
  fi
done
docker compose restart prompt-autopilot pricing-ml pricing-ml-adv
echo "[ROLLBACK COMPLETE]"