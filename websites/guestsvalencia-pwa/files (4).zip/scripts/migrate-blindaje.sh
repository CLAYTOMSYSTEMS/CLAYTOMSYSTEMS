#!/usr/bin/env bash
set -e
DB=${NEON_DB_URL:-$1}
echo "Applying BLINDAJE migrations..."
psql "$DB" -f migrations/prompt_autopilot_extend.sql
psql "$DB" -f migrations/pricing_competitor.sql
psql "$DB" -f migrations/autopilot_conflicts.sql || true
echo "Done."