import 'dotenv/config';
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
  const adminEmail = 'admin@example.com';
  const existing = await prisma.user.findUnique({ where: { email: adminEmail }});
  if (!existing) {
    await prisma.user.create({
      data: {
        email: adminEmail,
        passwordHash: 'DEV_HASH', // Reemplazar con bcrypt real
        role: 'ADMIN'
      }
    });
    console.log('Seed: admin user created');
  }
  const propCount = await prisma.property.count();
  if (propCount === 0) {
    await prisma.property.create({
      data: {
        title: 'Apartamento Centro Valencia',
        description: 'Luminoso, 2 habitaciones, cerca de la plaza.',
        baseRate: 120,
        locale: 'es'
      }
    });
    console.log('Seed: property created');
  }
}

main().catch(e => {
  console.error(e);
  process.exit(1);
}).finally(()=>prisma.$disconnect());