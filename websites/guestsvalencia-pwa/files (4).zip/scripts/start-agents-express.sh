#!/usr/bin/env bash
set -e
echo "[+] Building express agents overlay..."
docker compose -f docker-compose.yml -f docker-compose.express-agents.yml build agent-hub bi-forecast gpu-metrics-exporter
echo "[+] Starting services..."
docker compose -f docker-compose.yml -f docker-compose.express-agents.yml up -d agent-hub bi-forecast gpu-metrics-exporter
echo "[+] Tail agent hub logs:"
docker compose logs -f agent-hub | sed -u 's/^/[AGENT-HUB] /'