#!/usr/bin/env bash
echo "Press Ctrl+C to exit."
( command -v nats >/dev/null 2>&1 && nats sub 'agent.decision.>' ) || \
docker run --rm --network host synadia/nats-box:latest nats sub 'agent.decision.>' -s nats://localhost:4222