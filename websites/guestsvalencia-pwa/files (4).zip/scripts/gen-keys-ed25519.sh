#!/usr/bin/env bash
openssl genpkey -algorithm Ed25519 -out ed25519_private.pem
openssl pkey -in ed25519_private.pem -pubout -out ed25519_public.pem
echo "Generated ed25519_private.pem & ed25519_public.pem"