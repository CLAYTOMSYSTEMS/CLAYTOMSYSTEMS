#!/usr/bin/env bash
set -e
echo "[CHECK] Autopilot health"
curl -sf http://localhost/prompt-autopilot/healthz >/dev/null && echo "OK autopilot"
echo "[CHECK] Pricing ML Adv"
curl -sf http://localhost:4290/healthz >/dev/null && echo "OK pricing-ml-adv"
echo "[CHECK] Policy signer"
curl -sf http://localhost:4300/healthz >/dev/null && echo "OK policy-signer"
echo "[CHECK] Guardrails anomalies stable (<=1 last 5m)"
ANOM=$(curl -s "http://prometheus:9090/api/v1/query?query=increase(guardrails_anomaly_events_total[5m])" | jq -r '.data.result[0].value[1]' || echo 0)
echo "Anomalies(5m)=$ANOM"
if [ "${ANOM:-0}" != "0" ]; then
  echo "WARN: anomalies detected; consider delaying."
fi