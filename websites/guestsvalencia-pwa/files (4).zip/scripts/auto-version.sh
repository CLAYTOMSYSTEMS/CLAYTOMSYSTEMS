#!/usr/bin/env bash
set -e
# Simple semantic increment from last tag
LAST_TAG=$(git describe --tags --abbrev=0 2>/dev/null || echo "v0.0.0")
echo "Último tag: $LAST_TAG"
COMMITS=$(git log --format=%s "${LAST_TAG}.." || true)
MAJOR=false; MINOR=false; PATCH=false
while read -r line; do
  [[ "$line" =~ BREAKING ]] && MAJOR=true
  [[ "$line" =~ ^feat ]] && MINOR=true
  [[ "$line" =~ ^fix ]] && PATCH=true
done <<< "$COMMITS"

IFS=. read -r v M m p <<< "$(echo $LAST_TAG | sed 's/v//')"
if $MAJOR; then
  M=$((M+1)); m=0; p=0
elif $MINOR; then
  m=$((m+1)); p=0
else
  p=$((p+1))
fi
NEW_TAG="v${M}.${m}.${p}"
echo "Nuevo tag: $NEW_TAG"
git tag "$NEW_TAG"
git push origin "$NEW_TAG"
echo "::set-output name=version::$NEW_TAG"