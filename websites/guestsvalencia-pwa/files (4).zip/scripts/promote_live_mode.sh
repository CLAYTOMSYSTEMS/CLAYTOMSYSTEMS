#!/usr/bin/env bash
set -e
FILES=(
  services/prompt-autopilot/.env
  services/pricing-ml/.env
  services/pricing-ml-adv/.env
)
for f in "${FILES[@]}"; do
  if grep -q 'DRY_RUN=true' "$f"; then
    sed -i 's/DRY_RUN=true/DRY_RUN=false/' "$f"
    echo "[MODIFIED] $f -> DRY_RUN=false"
  fi
done
docker compose restart prompt-autopilot pricing-ml pricing-ml-adv
echo "[LIVE MODE ENABLED] Monitor for 60 minutes before expanding."