#!/usr/bin/env bash
set -e
PROM_URL="${PROM_URL:-http://prometheus:9090}"
THRESHOLD_MS="${RETRIEVAL_P95_BUDGET_MS:-120}"

VAL=$(curl -s "${PROM_URL}/api/v1/query?query=histogram_quantile(0.95,sum(rate(retrieval_latency_ms_bucket[5m]))%20by%20(le))" | jq -r '.data.result[0].value[1]')
echo "Current Retrieval P95: $VAL ms (Budget ${THRESHOLD_MS}ms)"
if [ "$(printf '%.0f' "$VAL")" -gt "$THRESHOLD_MS" ]; then
  echo "FAIL: p95 retrieval exceeds budget"
  exit 1
fi
echo "OK: within budget"