#!/usr/bin/env bash
set -e
NAMESPACE=${NAMESPACE:-gv}
kubectl get ns $NAMESPACE >/dev/null 2>&1 || kubectl create ns $NAMESPACE
helm upgrade --install guestsvalencia deployment/helm -n $NAMESPACE -f deployment/helm/values-prod.yaml