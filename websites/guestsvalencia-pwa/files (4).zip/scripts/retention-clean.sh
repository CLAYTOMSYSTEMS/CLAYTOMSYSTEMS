#!/usr/bin/env bash
psql "$NEON_DB_URL" -c "DELETE FROM conversation_messages WHERE created_at < now() - interval '30 days';"