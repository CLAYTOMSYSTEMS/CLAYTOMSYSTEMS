#!/usr/bin/env bash
set -e
for i in {1..40}; do
  if curl -fsS http://localhost/healthz >/dev/null 2>&1; then
    echo "Gateway OK"
    exit 0
  fi
  sleep 2
done
echo "Timeout esperando gateway"
exit 1