#!/usr/bin/env bash
set -e
URL=${GUARD_URL:-http://localhost:4260/policy/dsl}
cat <<'EOF' > /tmp/rules.dsl
RULE armas WHEN CONTAINS("arma") THEN BLOCK reason="weapons"
RULE menores WHEN REGEX(/(niñ[oa]|menor)/i) THEN SOFT_BLOCK tag="underage" SCORE +10
RULE jailbreak WHEN REGEX(/ignore (all )?previous/i) THEN BLOCK reason="jailbreak"
RULE pii_card WHEN REGEX(/\b\d{16}\b/) THEN BLOCK reason="pii"
EOF
ESCAPED=$(sed 's/"/\\"/g' /tmp/rules.dsl)
curl -s -X POST "$URL" -H 'Content-Type: application/json' -d "{\"name\":\"seed\",\"raw\":\"$ESCAPED\"}" | jq