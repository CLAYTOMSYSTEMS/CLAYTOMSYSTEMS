from fastapi import FastAPI, Body
from sentence_transformers import CrossEncoder
from rank_bm25 import BM25Okapi

app = FastAPI(title="Rerank Service")
model = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2")

@app.post("/rerank")
def rerank(payload=Body(...)):
    query = payload.get("query","")
    docs = payload.get("docs",[])
    if not query or not docs:
        return {"docs":[]}
    # BM25 stage
    bm25 = BM25Okapi([d.split() for d in docs])
    bm_scores = bm25.get_scores(query.split())
    pairs = [(query, d) for d in docs]
    ce_scores = model.predict(pairs)
    fused = []
    for i,d in enumerate(docs):
        fused.append({
            "doc": d,
            "score": float(0.6*ce_scores[i] + 0.4*bm_scores[i])
        })
    fused.sort(key=lambda x: x["score"], reverse=True)
    return {"reranked": fused[:5]}