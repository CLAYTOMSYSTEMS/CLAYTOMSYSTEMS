import LRU from 'lru-cache';
import client from 'prom-client';

export const cache = new LRU({ max: parseInt(process.env.CACHE_MAX||'1000',10) });

export const metrics = {
  requests: new client.Counter({ name:'guardrails_requests_total', help:'Total moderation requests' }),
  blocks: new client.Counter({ name:'guardrails_blocks_total', help:'Total blocked texts', labelNames:['type'] }),
  latency: new client.Histogram({ name:'guardrails_latency_seconds', help:'Moderation latency', buckets:[0.01,0.02,0.05,0.1,0.2,0.5,1] }),
  vectorHits: new client.Counter({ name:'guardrails_vector_hits_total', help:'Vector cache hits'}),
  vectorMisses: new client.Counter({ name:'guardrails_vector_misses_total', help:'Vector cache misses'}),
  anomalies: new client.Counter({ name:'guardrails_anomaly_events_total', help:'Anomalies detected', labelNames:['metric'] })
};

export const register = new client.Registry();
client.collectDefaultMetrics({ register });
Object.values(metrics).forEach(m=> register.registerMetric(m));

// Anomaly simple (promedio sliding)
const windowSec = parseInt(process.env.ANOMALY_WINDOW_SECONDS || '300',10);
const zThreshold = parseFloat(process.env.ANOMALY_Z_THRESHOLD || '3');
const blockSeries = [];

export function recordBlockEvent(ts=Date.now()){
  blockSeries.push(ts);
  // Purga ventana
  const cutoff = ts - windowSec*1000;
  while (blockSeries.length && blockSeries[0] < cutoff) blockSeries.shift();
}

export function detectAnomaly(){
  // Bloques por minuto dentro de ventana
  const mins = windowSec/60;
  const rate = blockSeries.length / mins;
  // Mantener histórico simple en cache
  const histKey = '__an_hist__';
  let hist = cache.get(histKey) || [];
  hist.push(rate);
  if (hist.length > 50) hist.shift();
  cache.set(histKey, hist);
  if (hist.length < 10) return null;
  const avg = hist.reduce((a,b)=>a+b,0)/hist.length;
  const variance = hist.reduce((a,b)=>a+(b-avg)**2,0)/hist.length;
  const std = Math.sqrt(variance)||1e-6;
  const z = (rate-avg)/std;
  if (z >= zThreshold) {
    metrics.anomalies.labels('block_rate').inc();
    return { rate, avg, std, z };
  }
  return null;
}