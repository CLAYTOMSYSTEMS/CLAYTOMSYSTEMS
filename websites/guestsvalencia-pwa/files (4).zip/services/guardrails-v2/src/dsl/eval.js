export function evaluateRules(compiled, text, opts={}){
  // opts: vectorSim (opcional), category
  const lower = text.toLowerCase();
  const result = {
    score: 0,
    tags: new Set(),
    blocked: false,
    softBlocked: false,
    reasons: []
  };
  for (const rule of compiled) {
    let ruleMatch = false;
    // OR groups
    for (const andGroup of rule.predicates) {
      let ok = true;
      for (const atom of andGroup) {
        if (atom.type === 'contains') {
          if (!lower.includes(atom.value.toLowerCase())) { ok=false; break; }
        } else if (atom.type === 'regex') {
          const parts = atom.value.match(/^\/(.+)\/([gimuy]*)$/);
            if (!parts) { ok=false; break; }
            const rg = new RegExp(parts[1], parts[2]);
            if (!rg.test(text)) { ok=false; break; }
        } else if (atom.type === 'category') {
          if (!opts.category || opts.category !== atom.value) { ok=false; break; }
        } else if (atom.type === 'length_gt') {
          if (text.length <= atom.value) { ok=false; break; }
        } else if (atom.type === 'vector_sim') {
          if ((opts.vectorSim || 0) < atom.value) { ok=false; break; }
        }
      }
      if (ok) { ruleMatch = true; break; }
    }
    if (!ruleMatch) continue;
    // Acciones
    for (const a of rule.actions) {
      if (a.type === 'BLOCK') {
        result.blocked = true;
        if (a.reason) result.reasons.push(a.reason);
      } else if (a.type === 'SOFT_BLOCK') {
        result.softBlocked = true;
        if (a.tag) result.tags.add(a.tag);
      } else if (a.type === 'SCORE') {
        result.score += a.delta;
      } else if (a.type === 'TAG') {
        result.tags.add(a.tag);
      } else if (a.type === 'ESCALATE') {
        result.tags.add('ESCALATE:'+a.channel);
      }
    }
  }
  return {
    ...result,
    tags: [...result.tags]
  };
}