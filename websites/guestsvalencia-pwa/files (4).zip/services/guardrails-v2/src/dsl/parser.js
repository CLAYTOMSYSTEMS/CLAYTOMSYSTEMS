const ruleRegex = /^RULE\s+(\w+)\s+WHEN\s+(.+?)\s+THEN\s+(.+)$/i;

function parsePredicate(predStr){
  // Tokenizado simple
  const orParts = predStr.split(/\s+OR\s+/i).map(p=> p.trim());
  return orParts.map(part=>{
    const ands = part.split(/\s+AND\s+/i).map(x=> x.trim());
    return ands.map(atom => {
      if (/^CONTAINS\(/i.test(atom)) {
        const m = atom.match(/^CONTAINS\("(.+)"\)$/i);
        return { type:'contains', value: m?.[1] };
      }
      if (/^REGEX\(/i.test(atom)) {
        const m = atom.match(/^REGEX\((\/.+\/[gimuy]*)\)$/i);
        return { type:'regex', value: m?.[1] };
      }
      if (/^CATEGORY\s*==\s*/i.test(atom)) {
        const m = atom.match(/^CATEGORY\s*==\s*"(.+)"$/i);
        return { type:'category', value: m?.[1] };
      }
      if (/^LENGTH\s*>\s*\d+$/i.test(atom)) {
        const m = atom.match(/^LENGTH\s*>\s*(\d+)$/i);
        return { type:'length_gt', value: parseInt(m[1],10) };
      }
      if (/^VECTOR_SIM\s*>=\s*/i.test(atom)) {
        const m = atom.match(/^VECTOR_SIM\s*>=\s*(0(\.\d+)?|1(\.0+)?)$/i);
        return { type:'vector_sim', value: parseFloat(m[1]) };
      }
      return { type:'unknown', value: atom };
    });
  });
}

function parseAction(actionStr){
  const actions = [];
  // Soportar múltiples palabras: BLOCK reason="x" SCORE +10 TAG "y"
  const tokens = actionStr.match(/BLOCK(\s+reason="[^"]*")?|SOFT_BLOCK(\s+tag="[^"]*")?|SCORE\s+[+-]?\d+|ESCALATE\s+channel="[^"]*"|TAG\s+"[^"]*"/gi) || [];
  tokens.forEach(t=>{
    if (/^BLOCK/i.test(t)) {
      const m = t.match(/reason="([^"]+)"/i);
      actions.push({ type:'BLOCK', reason: m?.[1] });
    } else if (/^SOFT_BLOCK/i.test(t)) {
      const m = t.match(/tag="([^"]+)"/i);
      actions.push({ type:'SOFT_BLOCK', tag: m?.[1] });
    } else if (/^SCORE/i.test(t)) {
      const m = t.match(/SCORE\s+([+-]?\d+)/i);
      actions.push({ type:'SCORE', delta: parseInt(m[1],10) });
    } else if (/^ESCALATE/i.test(t)) {
      const m = t.match(/channel="([^"]+)"/i);
      actions.push({ type:'ESCALATE', channel: m?.[1] });
    } else if (/^TAG/i.test(t)) {
      const m = t.match(/TAG\s+"([^"]+)"/i);
      actions.push({ type:'TAG', tag: m?.[1] });
    }
  });
  return actions;
}

export function parseDSL(raw){
  const lines = raw.split(/\r?\n/).map(l=>l.trim()).filter(l=>l && !l.startsWith('#'));
  const compiled = [];
  for (const line of lines) {
    const m = line.match(ruleRegex);
    if (!m) throw new Error(`Invalid rule syntax: ${line}`);
    const [, name, predStr, actionStr] = m;
    compiled.push({
      name,
      predicates: parsePredicate(predStr),
      actions: parseAction(actionStr)
    });
  }
  return compiled;
}