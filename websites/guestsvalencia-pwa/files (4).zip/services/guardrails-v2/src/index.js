import Fastify from 'fastify';
import fetch from 'node-fetch';
import { Pool } from 'pg';
import { parseDSL } from './dsl/parser.js';
import { evaluateRules } from './dsl/eval.js';
import { cache, metrics, register, recordBlockEvent, detectAnomaly } from './engine.js';

const app = Fastify({ logger:true });
const pool = new Pool({ connectionString: process.env.PG_URL });

async function embed(text){
  const key = 'vec:'+text;
  if (cache.has(key)) { metrics.vectorHits.inc(); return cache.get(key); }
  metrics.vectorMisses.inc();
  const r = await fetch(process.env.EMBED_URL,{
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ text })
  }).then(r=>r.json());
  cache.set(key, r.embedding);
  return r.embedding;
}

async function loadDSL() {
  const res = await pool.query('SELECT id,name,raw_rule,compiled FROM guardrail_dsl_rules WHERE active=true');
  return res.rows.map(r=>({
    id: r.id,
    name: r.name,
    compiled: r.compiled
  }));
}

let dslCache = [];
async function refreshDSL(){
  dslCache = await loadDSL();
  app.log.info({ rules: dslCache.length }, 'DSL refreshed');
}
setInterval(refreshDSL, 60000);
refreshDSL();

app.post('/policy/dsl', async (req, reply)=>{
  const { name, raw } = req.body || {};
  if (!raw) return reply.code(400).send({ error:'raw required' });
  let compiled;
  try {
    compiled = parseDSL(raw);
  } catch(e){
    return reply.code(400).send({ error:'parse_error', detail: e.message });
  }
  await pool.query(`
    INSERT INTO guardrail_dsl_rules(name,raw_rule,compiled)
    VALUES($1,$2,$3)
  `,[name||'unnamed', raw, JSON.stringify(compiled)]);
  await refreshDSL();
  return { ok:true, rules: compiled.length };
});

app.post('/moderate/semantic', async (req, reply)=>{
  const start = process.hrtime.bigint();
  metrics.requests.inc();
  const { text, category=null, vectorTopK=3, vectorThreshold=0.82 } = req.body || {};
  if (!text) return reply.code(400).send({ error:'text required' });

  const em = await embed(text);
  const vecRes = await pool.query(`
    SELECT id,name,category, 1-(embedding <=> $1) AS score
    FROM guardrail_policies
    ORDER BY embedding <=> $1
    LIMIT $2
  `,[em, vectorTopK]);

  const hits = vecRes.rows.filter(r=> r.score >= vectorThreshold);
  let vectorSimTop = hits[0]?.score || 0;
  // Evaluar DSL
  let combined = { score:0, blocked:false, softBlocked:false, tags:[], reasons:[] };
  for (const rule of dslCache) {
    const partial = evaluateRules(rule.compiled, text, { category, vectorSim: vectorSimTop });
    // Merge incremental
    if (partial.blocked) combined.blocked = true;
    if (partial.softBlocked) combined.softBlocked = true;
    combined.score += partial.score;
    combined.tags.push(...partial.tags);
    combined.reasons.push(...partial.reasons);
  }

  const finalAction = combined.blocked ? 'block' : combined.softBlocked ? 'soft_block' : 'allow';
  if (finalAction !== 'allow') {
    metrics.blocks.labels(finalAction).inc();
    recordBlockEvent();
  }
  const anomaly = detectAnomaly();
  if (anomaly) {
    app.log.warn({ anomaly }, 'Anomaly detected (block rate spike)');
    // opcional: insert anomaly row
    await pool.query(`
      INSERT INTO guardrail_anomalies(kind,metric,value,baseline,z_score,window_start,window_end)
      VALUES($1,$2,$3,$4,$5, now() - interval '5 minutes', now())
    `,['block_rate','blocks_per_min', anomaly.rate, anomaly.avg, anomaly.z]);
  }

  await pool.query(`
    INSERT INTO moderation_audit(text,policy_hits,allowed)
    VALUES($1,$2,$3)
  `,[text, JSON.stringify(hits), finalAction==='allow']);

  const end = process.hrtime.bigint();
  metrics.latency.observe(Number(end-start)/1e9);

  return {
    action: finalAction,
    vectorHits: hits,
    score: combined.score,
    tags: combined.tags,
    reasons: combined.reasons,
    anomaly
  };
});

// Streaming Moderation (tokens)
app.post('/moderate/stream', async (req, reply)=>{
  const { tokens=[], partial="", category=null } = req.body || {};
  const text = (tokens.join(' ') + ' ' + partial).trim();
  if (!text) return reply.send({ action:'allow', score:0 });
  // Heurística rápida (sin vector todavía)
  const fastBlock = /arma|explosiv|bomba|ignore previous/i.test(text);
  if (fastBlock) return reply.send({ action:'block_fast', reason:'heuristic' });
  // Llamada mínima a DSL sin vectorSim
  let interim = { score:0, blocked:false, softBlocked:false, tags:[], reasons:[] };
  for (const rule of dslCache) {
    const part = evaluateRules(rule.compiled, text, { category });
    if (part.blocked) interim.blocked = true;
    if (part.softBlocked) interim.softBlocked = true;
    interim.score += part.score;
    interim.tags.push(...part.tags);
  }
  const action = interim.blocked ? 'block' : interim.softBlocked ? 'soft_block' : 'allow';
  return reply.send({ action, score: interim.score, tags: interim.tags });
});

app.get('/stats', async ()=>{
  const blocks = await pool.query(`
    SELECT date_trunc('minute', created_at) m,
           count(*) FILTER (WHERE NOT allowed) blocked,
           count(*) total
    FROM moderation_audit
    WHERE created_at > now() - interval '60 minutes'
    GROUP BY 1 ORDER BY 1
  `);
  return { series: blocks.rows };
});

app.get('/metrics', async (req, reply)=>{
  reply.header('Content-Type', register.contentType);
  return reply.send(await register.metrics());
});

app.get('/healthz', async ()=>({ ok:true, rules:dslCache.length }));

app.listen({ port: process.env.PORT || 4260, host:'0.0.0.0' });