#!/usr/bin/env bash
set -e
URL=${1:-http://localhost:4260/policy/dsl}
cat <<'EOF' > /tmp/seed.rules
# Armas
RULE armas WHEN CONTAINS("arma") OR REGEX(/explosiv/i) THEN BLOCK reason="weapons"
# Menores
RULE menores WHEN REGEX(/(niñ[oa]|menor)/i) THEN SOFT_BLOCK tag="underage" SCORE +10
# Jailbreak
RULE jailbreak WHEN REGEX(/ignore (all )?previous/i) THEN BLOCK reason="jailbreak" TAG "jailbreak"
# Datos sensibles
RULE card WHEN REGEX(/\b\d{16}\b/) THEN BLOCK reason="carddata" TAG "pii"
EOF
curl -s -X POST "$URL" -H "Content-Type: application/json" \
  -d "{\"name\":\"seed\",\"raw\":\"$(sed 's/"/\\"/g' /tmp/seed.rules)\"}" | jq