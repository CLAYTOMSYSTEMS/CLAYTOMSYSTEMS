import express from 'express';
import { bookingRegister } from './metrics';

export const metricsApp = express();
metricsApp.get('/metrics', async (_req,res) => {
  res.set('Content-Type', bookingRegister.contentType);
  res.end(await bookingRegister.metrics());
});