import client from 'prom-client';

export const bookingRegister = new client.Registry();
client.collectDefaultMetrics({ register: bookingRegister });

export const bookingCreateLatency = new client.Histogram({
  name: 'booking_create_latency_ms',
  help: 'Latency to execute booking create command (ms)',
  buckets: [50,100,150,200,300,400,600,800,1000,1500]
});
export const bookingConfirmedTotal = new client.Counter({
  name: 'bookings_confirmed_total',
  help: 'Total confirmed bookings'
});
export const bookingPendingTotal = new client.Counter({
  name: 'bookings_pending_total',
  help: 'Total pending bookings'
});
export const bookingAvailConflictTotal = new client.Counter({
  name: 'booking_availability_conflict_total',
  help: 'Number of availability conflict rejections'
});

bookingRegister.registerMetric(bookingCreateLatency);
bookingRegister.registerMetric(bookingConfirmedTotal);
bookingRegister.registerMetric(bookingPendingTotal);
bookingRegister.registerMetric(bookingAvailConflictTotal);

export function observeBookingCreate(start: number, status: 'CONFIRMED'|'PENDING'|'CONFLICT') {
  bookingCreateLatency.observe(Date.now() - start);
  if (status === 'CONFIRMED') bookingConfirmedTotal.inc();
  else if (status === 'PENDING') bookingPendingTotal.inc();
  else if (status === 'CONFLICT') bookingAvailConflictTotal.inc();
}