import express from 'express';
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();
const app = express();
app.use(express.json());

app.post('/booking/command/create', async (req,res) => {
  const { propertyId, userId, checkIn, checkOut, guests, totalCents, currency='EUR' } = req.body;
  if (!propertyId || !userId || !checkIn || !checkOut || !totalCents) return res.status(400).json({ error:'MISSING' });
  // availability trivial check
  const overlap = await prisma.booking.findFirst({
    where:{
      propertyId,
      OR:[
        { checkIn: { lte: new Date(checkOut) }, checkOut:{ gte: new Date(checkIn) } }
      ]
    }
  });
  if (overlap) return res.status(409).json({ error:'UNAVAILABLE' });

  const booking = await prisma.booking.create({
    data:{
      propertyId,
      userId,
      checkIn:new Date(checkIn),
      checkOut:new Date(checkOut),
      totalPrice: totalCents / 100,
      status:'PENDING'
    }
  });
  res.json({ bookingId: booking.id });
});

app.post('/booking/command/markPaid', async (req,res) => {
  const { bookingId, paymentRef } = req.body;
  if (!bookingId) return res.status(400).json({ error:'MISSING' });
  const b = await prisma.booking.update({
    where:{ id: bookingId },
    data:{ status:'CONFIRMED' }
  });
  res.json({ ok:true, status:b.status, paymentRef });
});

const port = process.env.PORT || 4600;
app.listen(port, ()=>console.log('[booking-cqrs-svc] quick commands on', port));