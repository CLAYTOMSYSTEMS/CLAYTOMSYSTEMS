import random, time

def predict_tasks(property_id: str):
    # Dummy heuristic: random predictive issues
    issues = []
    if random.random() < 0.15:
        issues.append({"code":"HVAC_FILTER","priority":"MEDIUM","confidence":0.72})
    if random.random() < 0.05:
        issues.append({"code":"PLUMBING_CHECK","priority":"LOW","confidence":0.66})
    return issues

if __name__ == "__main__":
    for pid in ["prop1","prop2"]:
        print(pid, predict_tasks(pid))