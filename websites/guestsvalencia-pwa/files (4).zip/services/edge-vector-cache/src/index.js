import Fastify from 'fastify';
import LRU from 'lru-cache';
import fetch from 'node-fetch';
import { connect } from 'nats';
import client from 'prom-client';
import { hash128 } from './util.js';

const app = Fastify({ logger:true });
const cache = new LRU({ max: parseInt(process.env.CACHE_MAX||'5000',10) });
const region = process.env.REGION || 'unknown';
const nc = await connect({ servers: process.env.NATS_URL });
const hits = new client.Counter({ name:'edge_cache_hits_total', help:'hits'});
const misses = new client.Counter({ name:'edge_cache_misses_total', help:'misses'});
const register = new client.Registry();
client.collectDefaultMetrics({ register });
register.registerMetric(hits); register.registerMetric(misses);

(async()=>{
  const sub = nc.subscribe('edge.cache.invalidate');
  for await (const m of sub) {
    const { key } = JSON.parse(m.data.toString());
    if (cache.delete(key)) {
      app.log.info({ key },'invalidated');
    }
  }
})().catch(()=>{});

app.get('/semantic', async (req, reply)=>{
  const q = req.query.q;
  if (!q) return reply.code(400).send({ error:'q required' });
  const key = hash128(q);
  if (cache.has(key)) {
    hits.inc();
    return { region, cached:true, key, vector: cache.get(key) };
  }
  misses.inc();
  const emb = await fetch(process.env.EMBED_URL,{
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ text: q })
  }).then(r=>r.json());
  cache.set(key, emb.embedding);
  return { region, cached:false, key, vector: emb.embedding };
});

app.post('/invalidate', async (req, reply)=>{
  const { key } = req.body || {};
  if (!key) return reply.code(400).send({ error:'key required' });
  cache.delete(key);
  // broadcast
  nc.publish('edge.cache.invalidate', Buffer.from(JSON.stringify({ key })));
  return { ok:true };
});

app.get('/metrics', async (req, rep)=>{
  rep.header('Content-Type', register.contentType);
  return rep.send(await register.metrics());
});

app.get('/healthz', async ()=>({ ok:true, region }));

app.listen({ port: process.env.PORT || 4230, host:'0.0.0.0' });