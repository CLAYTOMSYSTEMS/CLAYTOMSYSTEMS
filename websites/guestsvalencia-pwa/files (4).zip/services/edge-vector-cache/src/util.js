import { xxhash64 } from 'xxhash-wasm';
let ready = false;
export async function hash128(input){
  if (!ready) await xxhash64();
  // simplified hashed string
  return Buffer.from(await xxhash64().h64To64(input)).toString('hex');
}