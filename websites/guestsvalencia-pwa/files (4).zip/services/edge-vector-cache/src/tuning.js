import fetch from 'node-fetch';
import os from 'os';

export function startHeartbeat(app, nc, cache){
  const nodeId = os.hostname() + '-' + (process.env.REGION||'reg');
  async function beat(){
    const stats = cache.stats || { hits:0, misses:0 };
    try {
      await fetch(process.env.BROKER_URL + '/heartbeat',{
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ nodeId, region: process.env.REGION, hits: stats.hits||0, misses: stats.misses||0 })
      });
    } catch {}
  }
  setInterval(beat,15000);
  (async()=>{
    const sub = nc.subscribe('edge.cache.tuning');
    for await (const m of sub) {
      try {
        const msg = JSON.parse(m.data.toString());
        if (msg.avg_hit_ratio < 0.55) {
          // raise TTL heuristic or enlarge cache
          if (cache.max < 8000) {
            cache.max = cache.max + 500;
            app.log.info({ newMax: cache.max },'Adaptive cache growth');
          }
        }
      } catch {}
    }
  })();
}