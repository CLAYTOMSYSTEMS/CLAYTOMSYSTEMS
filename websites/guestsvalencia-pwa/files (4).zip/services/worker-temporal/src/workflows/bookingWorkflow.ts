import { proxyActivities } from '@temporalio/workflow';
const { reserveInventory, processPayment, finalizeBooking } = proxyActivities<{
  reserveInventory(args: any): Promise<boolean>;
  processPayment(args: any): Promise<{ ok: boolean; authId?: string }>;
  finalizeBooking(args: any): Promise<void>;
}>({ startToCloseTimeout: '2 minute' });

export async function bookingWorkflow(input: { bookingId: string; propertyId: string; userId: string; totalCents: number }) {
  const reserved = await reserveInventory(input);
  if (!reserved) throw new Error('RESERVE_FAILED');
  const payment = await processPayment({ bookingId: input.bookingId, amount: input.totalCents });
  if (!payment.ok) throw new Error('PAYMENT_FAILED');
  await finalizeBooking({ bookingId: input.bookingId, authId: payment.authId });
  return { status: 'CONFIRMED' };
}