import librosa, soundfile as sf, os

def normalize_audio(path: str):
    y, sr = librosa.load(path, sr=16000, mono=True)
    y = librosa.effects.trim(y, top_db=35)[0]
    peak = max(abs(y)) if len(y)>0 else 1
    if peak > 0: y = y / peak * 0.97
    out_path = path.replace(".wav","_norm.wav")
    sf.write(out_path, y, 16000)
    return out_path, librosa.get_duration(y=y, sr=16000)