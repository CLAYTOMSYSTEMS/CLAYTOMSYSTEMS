from .trainer_real import start_training, TRAIN_REGISTRY

@app.post("/train/fine_tune")
async def fine_tune(model_name: str):
    await start_training(model_name, DATA_DIR)
    return {"model": model_name, "status":"running"}

@app.get("/train/fine_status/{model}")
async def fine_status(model: str):
    return TRAIN_REGISTRY.get(model, {"status":"unknown"})