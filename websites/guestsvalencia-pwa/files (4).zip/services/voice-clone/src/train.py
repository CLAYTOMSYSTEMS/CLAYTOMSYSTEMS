import asyncio, uuid

TRAIN_JOBS = {}

async def _run_training(job_id, model_name, data_dir):
    TRAIN_JOBS[job_id]["status"]="running"
    # Simulate epochs
    for e in range(1,4):
        await asyncio.sleep(3)
        TRAIN_JOBS[job_id]["progress"] = e/3
    TRAIN_JOBS[job_id]["status"]="completed"
    TRAIN_JOBS[job_id]["artifact"]=f"/models/voice/{model_name}.pt"

async def enqueue_training(model_name, data_dir):
    job_id = str(uuid.uuid4())
    TRAIN_JOBS[job_id] = {
        "status":"queued","progress":0.0,"model":model_name
    }
    asyncio.create_task(_run_training(job_id, model_name, data_dir))
    return job_id