import asyncio, os, time, json, glob

TRAIN_REGISTRY = {}

async def fake_fine_tune(model_name, data_dir, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    wavs = glob.glob(os.path.join(data_dir,"*_norm.wav"))
    total = len(wavs)
    for i,f in enumerate(wavs, start=1):
        await asyncio.sleep(0.7)  # simulate processing
        TRAIN_REGISTRY[model_name]["progress"] = i/total
    # Simulate artifact
    artifact = os.path.join(out_dir, f"{model_name}_ft.pt")
    with open(artifact,'w') as fh:
        fh.write("FAKE_MODEL")
    TRAIN_REGISTRY[model_name]["status"] = "completed"
    TRAIN_REGISTRY[model_name]["artifact"] = artifact

async def start_training(model_name, data_dir):
    TRAIN_REGISTRY[model_name] = {"status":"running","progress":0.0}
    out_dir = os.environ.get("MODEL_DIR","/models/voice")
    asyncio.create_task(fake_fine_tune(model_name, data_dir, out_dir))
    return True