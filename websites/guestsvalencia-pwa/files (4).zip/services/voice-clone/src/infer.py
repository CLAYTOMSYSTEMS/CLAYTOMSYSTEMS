import base64, struct, math

def synth_stub(text: str):
    # Dummy: generate a sine wave "audio"
    sr=16000
    dur= min(2 + len(text)/30, 8)
    samples = int(sr*dur)
    import math
    frames = bytearray()
    for i in range(samples):
        val = int(8000*math.sin(2*math.pi*220*(i/sr)))
        frames += struct.pack('<h', val)
    return base64.b64encode(frames).decode()