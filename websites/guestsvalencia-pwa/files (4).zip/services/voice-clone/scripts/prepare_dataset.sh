#!/usr/bin/env bash
set -e
RAW_DIR=$1
OUT_DIR=$2
mkdir -p "$OUT_DIR/wav"
for f in "$RAW_DIR"/*.wav; do
  base=$(basename "$f")
  sox "$f" -r 16000 -c 1 -b 16 "$OUT_DIR/wav/$base" gain -n -5
done
echo "Dataset normalized -> $OUT_DIR/wav"