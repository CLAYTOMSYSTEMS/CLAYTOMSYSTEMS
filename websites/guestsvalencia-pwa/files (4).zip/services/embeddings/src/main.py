import os, math, json
from fastapi import FastAPI, Body
import psycopg
import numpy as np
from datetime import datetime

PG_URL = os.getenv("PG_URL")
DIM = int(os.getenv("EMBED_DIM","1536"))

app = FastAPI(title="Embeddings Service")

@app.on_event("startup")
async def startup():
    app.state.conn = await psycopg.AsyncConnection.connect(PG_URL)
    await app.state.conn.set_autocommit(True)

def fake_embed(text: str):
    # Deterministic pseudo embedding
    rng = np.random.default_rng(abs(hash(text)) % (2**32))
    v = rng.random(DIM).astype(np.float32)
    # L2 normalize
    v = v / (np.linalg.norm(v) + 1e-9)
    return v

@app.post("/semantic/embed")
async def embed(payload: dict = Body(...)):
    text = payload.get("text","").strip()
    if not text: return {"error":"empty"}
    vec = fake_embed(text)
    async with app.state.conn.cursor() as cur:
        await cur.execute(
            "INSERT INTO embeddings(model,dim,content,embedding) VALUES(%s,%s,%s,%s)",
            ('fake-local', DIM, text, vec.tolist())
        )
    return {
        "model":"fake-local",
        "dim": DIM,
        "embedding": vec.tolist(),
        "created_at": datetime.utcnow().isoformat()
    }