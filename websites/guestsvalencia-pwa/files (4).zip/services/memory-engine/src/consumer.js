import { connect } from 'nats';
import fetch from 'node-fetch';

const nc = await connect({ servers: process.env.NATS_URL || 'nats://nats:4222' });
const sub = nc.subscribe('conversation.reply');
for await (const m of sub) {
  // Could schedule faster summarization
  // console.log('EVENT reply', m.getSubject(), m.data.toString());
  // Optionally trigger short summary early
}