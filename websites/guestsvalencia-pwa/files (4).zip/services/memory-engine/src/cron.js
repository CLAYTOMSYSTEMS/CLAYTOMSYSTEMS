import fetch from 'node-fetch';
import { Pool } from 'pg';

const pool = new Pool({ connectionString: process.env.PG_URL });
const INTERVAL = 60_000; // 1 min demo

async function run() {
  const client = await pool.connect();
  try {
    const sessions = await client.query(`
      SELECT DISTINCT session_id FROM conversation_messages
      WHERE created_at > now() - interval '2 hours'
    `);
    for (const row of sessions.rows) {
      for (const level of ['short','mid','long']) {
        await fetch(`http://localhost:${process.env.PORT}/summarize`,{
          method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({ sessionId: row.session_id, target: level })
        }).catch(()=>{});
      }
    }
  } finally { client.release(); }
}

setInterval(run, INTERVAL);