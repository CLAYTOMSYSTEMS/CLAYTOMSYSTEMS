export function generateSuggestions(ctx: { intent: string; slots: any }) {
  if (ctx.intent === 'booking_inquiry') {
    return [
      { label:'Fechas', utterance:'¿Cuáles son tus fechas exactas de llegada y salida?', confidence:0.88 },
      { label:'Huéspedes', utterance:'¿Para cuántas personas necesitas el alojamiento?', confidence:0.82 }
    ];
  }
  return [
    { label:'Info', utterance:'¿Deseas detalles de una propiedad específica?', confidence:0.60 }
  ];
}