/**
 * Simple heuristic negotiation logic (discount bracket & anchor messaging).
 */
export function negotiationStrategy(ctx: {
  occupancyPct:number;
  leadDays:number;
  userRequestedDiscount:boolean;
  baseRate:number;
}) {
  if(!ctx.userRequestedDiscount) return null;
  // Determine discount flexibility
  let maxDiscount = 0.05;
  if (ctx.occupancyPct < 0.5 && ctx.leadDays < 10) maxDiscount = 0.12;
  if (ctx.occupancyPct < 0.4 && ctx.leadDays < 5) maxDiscount = 0.18;

  const offered = Math.min(maxDiscount, 0.15);
  const anchorMsg = `La tarifa refleja la alta calidad y ubicación, sin embargo puedo ofrecer un ajuste limitado del ${(offered*100).toFixed(0)}% si confirmas ahora.`;
  return {
    actionId: 'NEGOTIATION_OFFER',
    type: 'REPLY_MESSAGE',
    confidence: 0.8,
    content: anchorMsg,
    conflictsWith: [],
    synergyTags: ['booking_path','revenue_core'],
    costEstimate: 0
  };
}