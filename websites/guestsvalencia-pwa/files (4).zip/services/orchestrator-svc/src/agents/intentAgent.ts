interface IntentResult { intent:string; confidence:number; complexity:number; flags?:string[] }

const PATTERNS: { intent:string; rx:RegExp; base:number; complexity:number }[] = [
  { intent:'booking_inquiry', rx:/\b(reserva(r|s)?|book(ing)?|alquilar|quiero\s+reservar)\b/i, base:0.92, complexity:0.35 },
  { intent:'pricing_query',   rx:/\b(precio|price|cost|tarifa|rate)\b/i, base:0.88, complexity:0.30 },
  { intent:'availability_query', rx:/\b(disponible|availability|available|dates?)\b/i, base:0.86, complexity:0.32 },
  { intent:'cancellation', rx:/\b(cancel(ar|lation)|anular)\b/i, base:0.80, complexity:0.40 }
];

export function classifyIntent(text: string): IntentResult {
  const lower = text.toLowerCase();
  const matches = PATTERNS
    .map(p => ({ p, hit: p.rx.test(lower) }))
    .filter(m => m.hit);

  if (!matches.length) {
    return { intent:'general', confidence:0.55, complexity:0.20 };
  }
  // pick highest base
  let best = matches.sort((a,b)=>b.p.base - a.p.base)[0].p;
  // refine confidence with signal counts
  let bonus = 0;
  const numbers = (lower.match(/\b\d+\b/g) || []).length;
  if (numbers >= 2) bonus += 0.03; // dates/guests hint
  if (/ahora|now|inmediatamente/i.test(lower)) bonus += 0.04;
  let confidence = Math.min(best.base + bonus, 0.97);
  return { intent:best.intent, confidence, complexity:best.complexity + (bonus>0.02?0.05:0) };
}