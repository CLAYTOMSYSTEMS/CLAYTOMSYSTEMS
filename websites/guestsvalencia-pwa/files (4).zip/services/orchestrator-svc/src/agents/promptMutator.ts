export function mutatePrompt(base: string, context: { intent: string; emotion: { valence:number; arousal:number }}) {
  let tone = '';
  if (context.emotion.valence < -0.3) tone = 'Responde con empatía y calma. ';
  else if (context.emotion.valence > 0.5) tone = 'Mantén tono positivo y conciso. ';
  return tone + base + ` (INTENT=${context.intent})`;
}