// Combine last N emotion frames into a synthetic valence/arousal weighting
export function aggregateEmotion(frames: { valence:number; arousal:number }[]) {
  if (!frames.length) return { valence:0, arousal:0 };
  const v = frames.reduce((s,f)=>s+f.valence,0)/frames.length;
  const a = frames.reduce((s,f)=>s+f.arousal,0)/frames.length;
  return { valence: v, arousal: a };
}