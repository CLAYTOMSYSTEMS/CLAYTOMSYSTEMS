export interface PolicyDecision { allow:boolean; reasons:string[] }

const RULES: { name:string; test:(t:string)=>boolean }[] = [
  { name:'PII_CARD', test:t=>/\b(?:\d[ -]*?){13,16}\b/.test(t) },
  { name:'PII_EMAIL', test:t=>/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i.test(t) },
  { name:'SQL_INJECTION', test:t=>/(union\s+select|drop\s+table|--|;--|\/\*)/i.test(t) },
  { name:'PROMPT_INJECTION', test:t=>/(ignore\s+previous|disregard\s+instructions)/i.test(t) },
  { name:'ABUSE', test:t=>/(idiota|stupid|fuck)/i.test(t) }
];

export function evaluatePolicy(text: string): PolicyDecision {
  const reasons = RULES.filter(r=>r.test(text)).map(r=>r.name);
  return { allow: reasons.length === 0, reasons };
}