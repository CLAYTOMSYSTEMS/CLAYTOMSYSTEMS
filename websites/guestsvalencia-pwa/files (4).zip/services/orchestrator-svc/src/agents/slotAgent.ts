export function extractSlots(text: string) {
  const slots: any = {};
  const g = text.match(/(\d+)\s+(guests|personas)/i);
  if (g) slots.guests = Number(g[1]);
  return slots;
}