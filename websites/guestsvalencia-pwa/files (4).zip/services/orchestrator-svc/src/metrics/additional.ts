import client from 'prom-client';
export const orchestrationRegister = new client.Registry();

export const agentChainLatency = new client.Histogram({
  name: 'agent_chain_latency_ms',
  help: 'Latency executing chosen agent chain',
  buckets: [20,40,60,90,130,180,250,350,500,800]
});
export const negotiationDiscountOffered = new client.Histogram({
  name: 'negotiation_discount_pct',
  help: 'Histogram of discount percentages offered',
  buckets: [0,2,5,8,10,12,15,20]
});
export const rlRewardDistribution = new client.Histogram({
  name: 'rl_conflict_reward',
  help: 'RL reward distribution for conflict decisions',
  buckets: [-1,-0.5,-0.2,0,0.2,0.5,0.8,1]
});

orchestrationRegister.registerMetric(agentChainLatency);
orchestrationRegister.registerMetric(negotiationDiscountOffered);
orchestrationRegister.registerMetric(rlRewardDistribution);