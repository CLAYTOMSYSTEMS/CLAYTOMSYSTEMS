import { trace } from '@opentelemetry/api';

export function withSpan<T>(name: string, fn: () => Promise<T>) {
  const tracer = trace.getTracer('orchestrator');
  return tracer.startActiveSpan(name, async span => {
    try {
      const result = await fn();
      span.setStatus({ code: 1 });
      return result;
    } catch (e:any) {
      span.recordException(e);
      span.setStatus({ code: 2, message: e.message });
      throw e;
    } finally {
      span.end();
    }
  });
}