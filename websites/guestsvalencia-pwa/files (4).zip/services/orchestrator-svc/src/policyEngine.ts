export interface PolicyDecision { allow: boolean; reasons?: string[]; }

export function evaluatePolicy(input: { prompt: string; userRole: string }): PolicyDecision {
  if (/credit card/i.test(input.prompt)) {
    return { allow: false, reasons: ['PII_DETECTED'] };
  }
  return { allow: true };
}