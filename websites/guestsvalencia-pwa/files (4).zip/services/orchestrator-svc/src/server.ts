import { Server, ServerCredentials } from '@grpc/grpc-js';
import { OrchestratorServiceService } from './generated/orchestrator_grpc_pb.js';
import { OrchestratorImpl } from './serviceImpl';

async function start() {
  const server = new Server();
  server.addService(OrchestratorServiceService, new OrchestratorImpl());
  const port = process.env.PORT || '52051';
  server.bindAsync(`0.0.0.0:${port}`, ServerCredentials.createInsecure(), () => {
    server.start();
    console.log('[orchestrator-svc] listening', port);
  });
}
start();