import { classifyIntent } from './agents/intentAgent';
import { extractSlots } from './agents/slotAgent';
import { evaluatePolicy } from './agents/policyAgent';
import { mutatePrompt } from './agents/promptMutator';
import { generateSuggestions } from './agents/suggestionAgent';

// gRPC generated types would be imported; using loose typings for skeleton.
export class OrchestratorImpl {
  async routeAgents(call: any, callback: any) {
    const req = call.request;
    const { latestUserText } = req;
    const intentData = classifyIntent(latestUserText);
    const slots = extractSlots(latestUserText);
    const policy = evaluatePolicy(latestUserText);
    const emotion = { valence: req.emotionValence || 0, arousal: req.emotionArousal || 0 };
    const prompt = mutatePrompt(latestUserText, { intent:intentData.intent, emotion });

    let selected_path = 'FAST_CHAIN';
    if (intentData.complexity > 0.5) selected_path = 'REASONING_CHAIN';
    else if (intentData.intent === 'booking_inquiry') selected_path = 'RETRIEVAL_CHAIN';

    const invoked = [ 'IntentAgent', 'SlotAgent', 'PolicyAgent' ];
    callback(null, {
      selectedPath: selected_path,
      invokedAgents: invoked,
      policyDecision: policy.allow ? 'ALLOW' : 'BLOCK',
      promptFinal: prompt
    });
  }

  async getProactiveSuggestions(call: any, callback: any) {
    const req = call.request;
    const suggestions = generateSuggestions({ intent:'booking_inquiry', slots:{} });
    callback(null, { suggestions });
  }
}