interface Candidate {
  role: string;
  proposalId: string;
  preview: string;
  relevance: number;
  novelty: number;
  valence: number;
  arousal: number;
  lastTurnAgoMs: number;
  recentlySpoke: boolean;
  diversityNeed: number;
}

interface Decision {
  awardedRole: string;
  proposalId: string;
  score: number;
  isInterruption: boolean;
  reasons: string[];
}

const WEIGHTS = {
  relevance: 0.32,
  novelty: 0.18,
  diversity: 0.12,
  recencyPenalty: 0.15,
  emotionalVariance: 0.08,
  lengthPenalty: 0.05,
  moderatorBoostIfBridgeNeeded: 0.10
};

export function decideTurn(candidates: Candidate[], context: {
  segmentId: string;
  moderatorRole: string;
  bridgeNeeded: boolean;
  currentSpeaker?: string;
  elapsedSpeakerMs?: number;
}) : Decision {
  const decisions = candidates.map(c => {
    let base = 0;
    base += c.relevance * WEIGHTS.relevance;
    base += c.novelty * WEIGHTS.novelty;
    base += c.diversityNeed * WEIGHTS.diversity;
    if (c.recentlySpoke) base -= WEIGHTS.recencyPenalty;
    // Emotional variance (prefer if arousal moderate for stability)
    const emotionalBalanced = 1 - Math.abs(c.arousal - 0.5);
    base += emotionalBalanced * WEIGHTS.emotionalVariance;
    if (context.bridgeNeeded && c.role === context.moderatorRole) base += WEIGHTS.moderatorBoostIfBridgeNeeded;

    return { role:c.role, score:base, proposalId:c.proposalId, isInterruption:false, reasons:[] as string[] };
  }).sort((a,b)=>b.score - a.score);

  // Interruption heuristic
  if (context.currentSpeaker && context.elapsedSpeakerMs && context.elapsedSpeakerMs > 2500) {
    const top = decisions[0];
    if (top.role !== context.currentSpeaker && top.score > decisions.find(d=>d.role===context.currentSpeaker)!.score + 0.12) {
      top.isInterruption = true;
      top.reasons.push('score_gap_interruption');
    }
  }
  decisions[0].reasons.push('top_score');
  return {
    awardedRole: decisions[0].role,
    proposalId: decisions[0].proposalId,
    score: decisions[0].score,
    isInterruption: decisions[0].isInterruption,
    reasons: decisions[0].reasons
  };
}