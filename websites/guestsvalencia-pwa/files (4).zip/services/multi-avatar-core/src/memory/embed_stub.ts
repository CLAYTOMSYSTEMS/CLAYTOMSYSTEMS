export async function embed(text:string) {
  // return fake vector
  return new Array(16).fill(0).map((_,i)=>((text.charCodeAt(i % text.length)||31)%101)/100);
}