import { embed } from './embed_stub';

interface MemoryTurn {
  role: string;
  text: string;
  ts: number;
  segmentId: string;
  tags?: string[];
}

const GLOBAL: MemoryTurn[] = [];
const ROLE_MEMORY: Record<string, MemoryTurn[]> = {};

export function addTurn(turn: MemoryTurn) {
  GLOBAL.push(turn);
  ROLE_MEMORY[turn.role] = ROLE_MEMORY[turn.role] || [];
  ROLE_MEMORY[turn.role].push(turn);
  if (GLOBAL.length > 500) GLOBAL.shift();
  if (ROLE_MEMORY[turn.role].length > 150) ROLE_MEMORY[turn.role].shift();
}

export async function buildSegmentSummary(segmentId: string) {
  const segmentTurns = GLOBAL.filter(t=>t.segmentId === segmentId);
  const keyPoints = segmentTurns.slice(-8).map(t=>`${t.role}: ${t.text}`).join('\n');
  // Placeholder summary
  return `Segment focus evolving. Last contributions:\n${keyPoints}`;
}

export async function retrieveRelevant(role: string, query: string, k=3) {
  const vecQuery = await embed(query);
  const pool = (ROLE_MEMORY[role]||[]).slice(-80);
  // Fake scoring
  const scored = pool.map(t => ({ t, score: Math.random() }));
  return scored.sort((a,b)=>b.score - a.score).slice(0,k).map(s=>s.t);
}