interface Turn { role:string; text:string; sentiment?:number; novelty?:number; ts:number; }
export function extractHighlights(turns: Turn[], limit=5) {
  const scored = turns.map(t => ({
    t,
    score: (t.novelty||Math.random()*0.5) + (t.sentiment||0.3)
  }));
  return scored.sort((a,b)=>b.score - a.score).slice(0,limit).map(s=>s.t);
}