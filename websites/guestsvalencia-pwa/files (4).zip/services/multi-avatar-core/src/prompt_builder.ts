import personalities from '../../../config/multi_avatar_personalities.json' assert { type:'json' };

export function buildRolePrompt(role: string, segmentSummary: string, recentTurns: {role:string; text:string}[], objective: string) {
  const p = (personalities as any)[role] || {};
  const style = (p.style_guidelines||[]).map((s:string)=>`- ${s}`).join('\n');
  return `
You are ${role}.
Tone: ${p.tone || 'neutral'}.
Guidelines:
${style}

Current Segment Objective: ${objective}
Segment Context Summary: ${segmentSummary}

Recent Turns:
${recentTurns.slice(-6).map(t=>`${t.role.toUpperCase()}: ${t.text.slice(0,160)}`).join('\n')}

Your job:
- Add value (no repetition).
- Keep within ${p.max_turn_length_chars || 300} chars.
- If bridging differences, be concise.
Output ONLY the textual response (no meta commentary).
`;
}