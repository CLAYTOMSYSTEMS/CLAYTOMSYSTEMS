interface SegmentStyle {
  segmentType: string;
  wardrobeHint: string;
  environmentHint: string;
}

const RULES: SegmentStyle[] = [
  { segmentType:'crypto_analysis', wardrobeHint:'crypto_punk_v1', environmentHint:'modern_executive_crypto_screens' },
  { segmentType:'business_strategy', wardrobeHint:'suit_navy_modern', environmentHint:'office_modern_analytics' },
  { segmentType:'family_wellness', wardrobeHint:'valencia_dress_mediterranean', environmentHint:'terrace_city_view_sunset' },
  { segmentType:'marketing_trends', wardrobeHint:'casual_trendy_street', environmentHint:'led_lights_professional_setup' }
];

export function planSegmentStyle(segmentType: string) {
  return RULES.find(r=>r.segmentType === segmentType) ||
    { wardrobeHint:'studio_sleek_black', environmentHint:'led_lights_professional_setup' };
}