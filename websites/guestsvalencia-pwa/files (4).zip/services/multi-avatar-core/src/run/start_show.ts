import { buildRolePrompt } from '../prompt_builder';
import { decideTurn } from '../turn_engine';
import { addTurn, buildSegmentSummary } from '../memory/memory_fusion';

const ROLES = ['sandra_moderator','crypto_expert','business_strategist','wellness_coach','kids_educator','community_manager'];

async function generateCandidate(role:string, segmentId:string, objective:string) {
  const prompt = buildRolePrompt(role, 'Segment placeholder summary', [], objective);
  // TODO call LLM -> for MVP stub
  return {
    role,
    proposalId: 'p_'+Math.random().toString(36).slice(2),
    preview: `(${role}) aporte sobre ${objective}`,
    relevance: Math.random(),
    novelty: Math.random(),
    valence: 0.1 + Math.random()*0.8,
    arousal: 0.2 + Math.random()*0.6,
    lastTurnAgoMs: Math.random()*10000,
    recentlySpoke: false,
    diversityNeed: Math.random()
  };
}

async function runSegment(segmentId:string, objective:string, turns=8) {
  console.log('\n[SEGMENT]', segmentId, objective);
  let currentSpeaker: string | undefined;
  let startSpeakerTime = Date.now();
  for (let i=0;i<turns;i++){
    const candidates = await Promise.all(ROLES.map(r => generateCandidate(r, segmentId, objective)));
    const decision = decideTurn(candidates, {
      segmentId,
      moderatorRole:'sandra_moderator',
      bridgeNeeded: Math.random()<0.2,
      currentSpeaker,
      elapsedSpeakerMs: currentSpeaker ? Date.now()-startSpeakerTime : undefined
    });
    currentSpeaker = decision.awardedRole;
    startSpeakerTime = Date.now();
    const chosen = candidates.find(c=>c.role===decision.awardedRole)!;
    const text = chosen.preview + (decision.isInterruption ? ' [INTERRUPCIÓN]' : '');
    addTurn({ role:chosen.role, text, ts:Date.now(), segmentId });
    console.log(decision.awardedRole.toUpperCase()+':', text);
    await wait(400 + Math.random()*600);
  }
  const summary = await buildSegmentSummary(segmentId);
  console.log('[SEGMENT SUMMARY]', summary);
}

function wait(ms:number){ return new Promise(r=>setTimeout(r,ms)); }

(async () => {
  await runSegment('segment_crypto','Analizar oportunidades BTC/PropTech sin exagerar');
  await runSegment('segment_business','Cómo monetizar reservas multi-canal hoy');
  await runSegment('segment_wellness','Integrar bienestar en experiencia huésped y familia');
  console.log('\n[SHOW COMPLETE]');
})();