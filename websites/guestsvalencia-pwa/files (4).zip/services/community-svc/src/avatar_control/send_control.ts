import fetch from 'node-fetch';

export async function updateAvatarLook(sessionId:string, wardrobeStyle:string, environment:string) {
  await fetch(`${process.env.AVATAR_CTRL_URL}/session/${sessionId}/wardrobe`, {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ style: wardrobeStyle })
  });
  await fetch(`${process.env.AVATAR_CTRL_URL}/session/${sessionId}/environment`, {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ environment })
  });
}