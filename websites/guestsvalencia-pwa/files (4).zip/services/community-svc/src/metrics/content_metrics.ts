import client from 'prom-client';
export const contentRegistry = new client.Registry();
client.collectDefaultMetrics({ register: contentRegistry });

export const scriptGenerationLatency = new client.Histogram({
  name: 'content_script_generation_latency_ms',
  help: 'Latency generating script text',
  buckets: [50,100,200,300,500,800,1200]
});
export const renderQueueSize = new client.Gauge({
  name: 'content_render_queue_size',
  help: 'Pending renders count'
});
export const publishLatency = new client.Histogram({
  name: 'content_publish_latency_ms',
  help: 'Time from script finalization to scheduled publish'
});
export const engagementResponseLatency = new client.Histogram({
  name: 'content_engagement_response_latency_ms',
  help: 'Latency auto-response to comment'
});
export const styleDiversityIndex = new client.Gauge({
  name: 'content_style_diversity_index',
  help: 'Number of distinct wardrobe styles used last 7d'
});
[ scriptGenerationLatency, renderQueueSize, publishLatency, engagementResponseLatency, styleDiversityIndex ]
  .forEach(m => contentRegistry.registerMetric(m));