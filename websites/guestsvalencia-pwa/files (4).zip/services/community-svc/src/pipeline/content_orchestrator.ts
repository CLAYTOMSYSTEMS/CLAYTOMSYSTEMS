import { aggregateTrendTopics } from '../trends/trend_hunter';
import { generateScript } from '../scripts/script_writer';
import { selectWardrobe, selectEnvironment } from '../styling/wardrobe_engine';
import { buildSEO } from '../seo/seo_metadata';
import { optimizeHashtags } from '../seo/hashtag_optimizer';
import { decideCTA } from '../revenue/content_revenue_optimizer';
import { buildChannelAdapters } from '../publish/channel_adapters';

export async function produceSlot(slotDef: { slot:string; type:string; channel:string; durationSecTarget:number; category:string }) {
  const topics = await aggregateTrendTopics();
  const topic = topics.find(t=>t.category === slotDef.category) || topics[0];
  const script = generateScript(topic, {
    channel: slotDef.channel as any,
    durationTargetSec: slotDef.durationSecTarget,
    language: 'es',
    tone: slotDef.type === 'deep_dive' ? 'analytical' : 'entertaining'
  });
  const wardrobe = selectWardrobe({ category: topic.category, timeSlot: inferTimeSlot(slotDef.slot) });
  const environment = selectEnvironment(topic.category);
  const seo = buildSEO(script.rawText, topic.primary, slotDef.channel);
  const hashtags = optimizeHashtags([topic.primary, ...topic.secondary], topic.category);
  const cta = decideCTA({
    channel: slotDef.channel as any,
    videoLengthSec: slotDef.durationSecTarget,
    category: topic.category,
    averageWatchTime: 0
  });
  // Render stub (would call avatar / TTS / composition)
  const renderId = 'render_'+Date.now();
  // Schedule publish (stub)
  const adapters = buildChannelAdapters();
  const adapter = adapters[slotDef.channel as keyof typeof adapters];
  await adapter.authenticate();
  await adapter.publishShort({
    filePath:`/tmp/${renderId}.mp4`,
    caption: seo.title + '\n' + hashtags.join(' ') + '\nCTA: '+ cta.ctaType,
    hashtags
  });
  return {
    slot: slotDef.slot,
    topic: topic.primary,
    scriptId: script.id,
    renderId,
    wardrobe: wardrobe.code,
    environment: environment.code,
    cta: cta.ctaType
  };
}

function inferTimeSlot(hhmm: string) {
  const h = parseInt(hhmm.split(':')[0],10);
  if (h < 11) return 'morning';
  if (h < 17) return 'midday';
  if (h < 21) return 'evening';
  return 'night';
}