interface ContentContext {
  channel: 'tiktok'|'instagram'|'youtube';
  videoLengthSec: number;
  category: string;
  averageWatchTime: number;
  ctrThumbnail?: number;
  rpm?: number;
  affiliateConvRate?: number;
  bookingConvRate?: number;
}

export interface CTADecision {
  ctaType: 'affiliate'|'booking'|'course'|'newsletter'|'membership';
  rationale: string;
  priority: number;
  experimentVariant?: string;
}

export function decideCTA(ctx: ContentContext): CTADecision {
  // Heurística simple
  if (ctx.category === 'crypto' && (ctx.affiliateConvRate||0) > 0.02) {
    return { ctaType:'affiliate', rationale:'High affiliate conv', priority:90 };
  }
  if (ctx.category === 'real_estate' && (ctx.bookingConvRate||0) > 0.015) {
    return { ctaType:'booking', rationale:'Booking funnel stable', priority:85 };
  }
  if (ctx.videoLengthSec > 600 && ctx.channel==='youtube') {
    return { ctaType:'course', rationale:'Long form education lends to course upsell', priority:80 };
  }
  return { ctaType:'newsletter', rationale:'Default lead capture', priority:60 };
}