export interface PublicationResult {
  success: boolean;
  externalId?: string;
  errors?: any[];
}

export interface ChannelAdapter {
  name: string;
  authenticate(): Promise<void>;
  uploadVideo(params: { filePath:string; title:string; description:string; tags:string[]; scheduledAt?:Date }): Promise<PublicationResult>;
  publishShort(params: { filePath:string; caption:string; hashtags:string[]; scheduledAt?:Date }): Promise<PublicationResult>;
  replyComment?(params:{ externalVideoId:string; commentId:string; text:string }): Promise<boolean>;
}

export class TikTokAdapter implements ChannelAdapter {
  name='tiktok';
  async authenticate(){ /* OAuth or cookie-based (use official APIs if available) */ }
  async uploadVideo(params:any){ return { success:true, externalId:'tiktok_'+Date.now() }; }
  async publishShort(params:any){ return { success:true, externalId:'tiktok_'+Date.now() }; }
}

export class InstagramAdapter implements ChannelAdapter {
  name='instagram';
  async authenticate(){}
  async uploadVideo(p:any){ return { success:true, externalId:'ig_'+Date.now() }; }
  async publishShort(p:any){ return { success:true, externalId:'ig_'+Date.now() }; }
}

export class YouTubeAdapter implements ChannelAdapter {
  name='youtube';
  async authenticate(){}
  async uploadVideo(p:any){ return { success:true, externalId:'yt_'+Date.now() }; }
  async publishShort(p:any){ return { success:true, externalId:'yt_short_'+Date.now() }; }
}

export function buildChannelAdapters() {
  return {
    tiktok: new TikTokAdapter(),
    instagram: new InstagramAdapter(),
    youtube: new YouTubeAdapter()
  };
}