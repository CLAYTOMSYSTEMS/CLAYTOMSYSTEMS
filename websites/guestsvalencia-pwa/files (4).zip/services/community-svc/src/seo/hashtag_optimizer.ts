export interface HashtagCandidate { tag:string; freq:number; trendScore:number; relevance:number; }
export function optimizeHashtags(baseKeywords: string[], category: string) {
  // Placeholder scored combination
  const baseTags = baseKeywords.slice(0,5).map(k => ({
    tag: normalize(k),
    freq: Math.random()*100,
    trendScore: Math.random()*1.5,
    relevance: 0.7 + Math.random()*0.3
  }));
  return baseTags
    .map(t => ({ ...t, finalScore: t.trendScore*0.5 + t.relevance*0.5 }))
    .sort((a,b)=>b.finalScore - a.finalScore)
    .slice(0,8)
    .map(t => `#${t.tag}`);
}
function normalize(s:string){ return s.toLowerCase().replace(/\s+/g,''); }