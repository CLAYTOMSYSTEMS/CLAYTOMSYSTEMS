export interface SEOResult {
  title: string;
  description: string;
  keywords: string[];
  hashtags: string[];
}

export function buildSEO(scriptText: string, topicPrimary: string, channel: string) : SEOResult {
  const baseKw = deriveKeywords(scriptText).slice(0,10);
  const hashtags = baseKw.slice(0,6).map(k=>`#${k}`);
  const title = channel === 'youtube'
    ? `${capitalize(topicPrimary)}: Análisis Completo & Oportunidades`
    : `${capitalize(topicPrimary)} ahora mismo`;
  const description = `Resumen rápido sobre ${topicPrimary}. Profundizamos en señales clave y oportunidades. Sigue a Sandra para más.`;
  return { title, description, keywords: baseKw, hashtags };
}

function deriveKeywords(text:string){
  const words = text.toLowerCase().match(/[a-záéíóúñ0-9]+/gi) || [];
  const freq:Record<string,number> = {};
  words.forEach(w=>freq[w]=(freq[w]||0)+1);
  return Object.entries(freq)
    .filter(([w])=>w.length>4)
    .sort((a,b)=>b[1]-a[1])
    .map(([w])=>w);
}
function capitalize(s:string){return s.charAt(0).toUpperCase()+s.slice(1);}