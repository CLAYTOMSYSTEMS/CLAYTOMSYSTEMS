export interface WardrobeStyle { code:string; tags:string[]; mood:string; formality:number; energy:number; }
export interface EnvironmentStyle { code:string; scenePrompt:string; lighting:string; motionPreset:string; tags:string[]; }

const CATEGORY_TO_STYLES: Record<string,string[]> = {
  crypto: ['crypto_punk_v1','crypto_modern_exec','crypto_deep_dive','tech_casual_dark'],
  real_estate: ['valencia_mediterranean_chic','business_elegant','studio_clean_light','apartment_showcase'],
  lifestyle: ['valencia_terrace_sunset','casual_trendy_day','co_work_lux_led','relaxed_beach_breeze'],
  finance: ['office_modern_analytics','trading_floor_live','boardroom_formal','macro_briefing']
};

export const WARDROBE: WardrobeStyle[] = [
  { code:'suit_navy_modern', tags:['business','finance'], mood:'serious', formality:0.95, energy:0.5 },
  { code:'blazer_white_gold', tags:['business','executive'], mood:'premium', formality:0.9, energy:0.55 },
  { code:'dress_formal_royal', tags:['formal','finance'], mood:'elegant', formality:0.97, energy:0.45 },
  { code:'crypto_punk_v1', tags:['crypto','edgy'], mood:'bold', formality:0.3, energy:0.9 },
  { code:'hoodie_bitcoin_black', tags:['crypto','casual'], mood:'tech', formality:0.2, energy:0.8 },
  { code:'tshirt_ethereum_white', tags:['crypto'], mood:'neutral', formality:0.2, energy:0.6 },
  { code:'valencia_dress_mediterranean', tags:['valencia','lifestyle'], mood:'warm', formality:0.55, energy:0.7 },
  { code:'casual_trendy_street', tags:['tiktok','casual'], mood:'energetic', formality:0.25, energy:0.85 },
  { code:'studio_sleek_black', tags:['youtube','education'], mood:'focused', formality:0.6, energy:0.5 },
  // ... puedes extender hasta 50+ combinando arrays generativos
];

export const ENVIRONMENTS: EnvironmentStyle[] = [
  { code:'modern_executive_crypto_screens', scenePrompt:'ultra modern office with live crypto tickers', lighting:'cool_edge', motionPreset:'slow_pan', tags:['office','crypto'] },
  { code:'led_lights_professional_setup', scenePrompt:'sleek studio with dynamic neon gradients', lighting:'neon_mix', motionPreset:'orbit_subtle', tags:['studio'] },
  { code:'terrace_city_view_sunset', scenePrompt:'Valencia terrace golden hour, Mediterranean vibe', lighting:'sunset_warm', motionPreset:'gentle_dolly', tags:['valencia','lifestyle'] },
  { code:'multiple_monitors_charts_live', scenePrompt:'trading floor, multi screens, data streaming', lighting:'cool_contrast', motionPreset:'handheld_slight', tags:['finance','crypto'] },
  { code:'apartment_showcase_premium', scenePrompt:'luxury apartment interior, natural light', lighting:'soft_day', motionPreset:'room_sweep', tags:['real_estate'] },
];

interface SelectionInput {
  category: string;
  desiredMood?: string;
  formalityTarget?: number;
  energyTarget?: number;
  timeSlot?: string; // morning|midday|evening|night
}

export function selectWardrobe(input: SelectionInput) {
  const poolCodes = CATEGORY_TO_STYLES[input.category] || [];
  const pool = WARDROBE.filter(w => poolCodes.includes(w.code) || w.tags.includes(input.category));
  if (!pool.length) return WARDROBE[0];
  // score
  const scored = pool.map(w => {
    let score = 0;
    if (input.desiredMood && w.mood === input.desiredMood) score += 1;
    if (input.formalityTarget !== undefined) score -= Math.abs(w.formality - input.formalityTarget)*0.7;
    if (input.energyTarget !== undefined) score -= Math.abs(w.energy - input.energyTarget)*0.5;
    if (input.timeSlot === 'evening' && w.mood === 'elegant') score += 0.4;
    return { w, score };
  }).sort((a,b)=>b.score - a.score);
  return scored[0].w;
}

export function selectEnvironment(category: string, mood?: string) {
  const filtered = ENVIRONMENTS.filter(e => e.tags.includes(category) || (mood && e.tags.includes(mood)));
  if (!filtered.length) return ENVIRONMENTS[0];
  return filtered[Math.floor(Math.random()*filtered.length)];
}