export const DEFAULT_DAILY_SLOTS = [
  { slot:'06:00', type:'morning_market', channel:'youtube', durationSecTarget: 900, category:'crypto' },
  { slot:'12:00', type:'trend_burst', channel:'tiktok', durationSecTarget: 60, category:'crypto' },
  { slot:'18:00', type:'deep_dive', channel:'youtube', durationSecTarget: 1200, category:'finance' },
  { slot:'21:00', type:'light_fun', channel:'instagram', durationSecTarget: 45, category:'lifestyle' }
];