import { DEFAULT_DAILY_SLOTS } from './daily_slots';
import { produceSlot } from '../pipeline/content_orchestrator';

async function main() {
  for (const slot of DEFAULT_DAILY_SLOTS) {
    try {
      const res = await produceSlot(slot);
      console.log('[slot-produced]', res);
    } catch (e) {
      console.error('[slot-error]', slot.slot, e);
    }
  }
}

main();