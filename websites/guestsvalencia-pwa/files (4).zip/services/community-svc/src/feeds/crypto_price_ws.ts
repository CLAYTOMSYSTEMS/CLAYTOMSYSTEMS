import WebSocket, { WebSocketServer } from 'ws';
import fetch from 'node-fetch';

const wss = new WebSocketServer({ port: Number(process.env.CRYPTO_WS_PORT||4900) });
console.log('[crypto-feed] listening');

async function fetchPrices() {
  const res = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,solana,chainlink&vs_currencies=usd&include_24hr_change=true');
  return res.json();
}

setInterval(async ()=>{
  try {
    const prices = await fetchPrices();
    const payload = { type:'prices', ts:Date.now(), prices };
    const msg = JSON.stringify(payload);
    wss.clients.forEach(c => { if (c.readyState === WebSocket.OPEN) c.send(msg); });
  } catch(e) {}
}, 10000);