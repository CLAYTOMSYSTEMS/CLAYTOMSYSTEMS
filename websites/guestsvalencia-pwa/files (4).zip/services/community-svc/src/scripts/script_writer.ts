import { TrendTopic } from '../trends/trend_hunter';

export interface ScriptConfig {
  channel: 'tiktok'|'instagram'|'youtube';
  durationTargetSec: number;
  language: string;
  tone: 'educational'|'entertaining'|'analytical'|'lifestyle';
}

export function generateScript(topic: TrendTopic, cfg: ScriptConfig) {
  const hook = buildHook(topic, cfg);
  const sections: string[] = [];
  sections.push(hook);
  sections.push(coreInsight(topic, cfg));
  if (cfg.channel === 'youtube' && cfg.durationTargetSec > 600) {
    sections.push(deepDive(topic));
  }
  sections.push(callToAction(topic, cfg));
  return {
    id: `script_${Date.now()}`,
    topicId: topic.id,
    channel: cfg.channel,
    language: cfg.language,
    rawText: sections.join('\n\n'),
    readability: 0.82,
    viralityScoreEstimate: estimateVirality(topic, cfg)
  };
}

function buildHook(topic: TrendTopic, cfg: ScriptConfig) {
  return `HOOK: ${capitalize(topic.primary)} en movimiento – ¿Qué significa este cambio para ti ahora mismo?`;
}
function coreInsight(topic: TrendTopic, cfg: ScriptConfig) {
  return `INSIGHT: ${topic.primary} está mostrando señales de volatilidad ${topic.volatility.toFixed(2)}%. Interpretamos esto como oportunidad táctica.`;
}
function deepDive(topic: TrendTopic) {
  return `DEEP DIVE: Métricas técnicas, soportes y resistencias clave, y correlaciones con macro eventos (resumen).`;
}
function callToAction(topic: TrendTopic, cfg: ScriptConfig) {
  return `CTA: Sigue a Sandra para análisis diario y descubre oportunidades en crypto y real estate Valencia.`;
}
function estimateVirality(topic: TrendTopic, cfg: ScriptConfig) {
  return Math.min(1, (topic.trendScore/2)*0.6 + (cfg.channel==='tiktok'?0.3:0.1));
}
function capitalize(s:string){return s.charAt(0).toUpperCase()+s.slice(1);}