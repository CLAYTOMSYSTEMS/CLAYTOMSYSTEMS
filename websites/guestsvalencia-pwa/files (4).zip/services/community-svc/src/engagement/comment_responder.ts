export interface CommentRecord {
  id: string;
  text: string;
  sentiment: number; // -1..1
  toxicity: number;  // 0..1
  timestamp: number;
  language: string;
  userReputation?: number;
}

export function generateReply(c: CommentRecord) {
  if (c.toxicity > 0.6) return null; // skip
  if (/precio|price|cost/i.test(c.text)) {
    return `Gracias por tu interés. Publicaremos un análisis de costes detallado en breve. ¿Te gustaría recibir alertas personalizadas?`;
  }
  if (/gracias|thanks/i.test(c.text) && c.sentiment > 0) {
    return `¡Gracias a ti! Si buscas más análisis diario, activa las notificaciones 😊`;
  }
  if (/scam|estafa/i.test(c.text)) {
    return `Entendemos tu preocupación. Nuestros análisis son informativos y no constituyen asesoramiento financiero.`;
  }
  return `Gracias por comentar. ¿Hay algún aspecto específico que te gustaría que cubriéramos?`;
}