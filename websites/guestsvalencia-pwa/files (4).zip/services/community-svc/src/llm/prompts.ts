export function buildScriptLLMPrompt(topic: {primary:string; secondary:string[]}, tone:string, durationSec:number, locale:string) {
  return `
System: Eres Sandra IA 7.0 guionista experta multilingüe. Genera un guion claro, dinámico y con CTA final breve. Evita lenguaje financiero recomendado explícito.
Topic Primary: ${topic.primary}
Secondary Keywords: ${topic.secondary.join(', ')}
Tone: ${tone}
Target Duration (sec): ${durationSec}
Locale: ${locale}
Sections: HOOK (1 frase), BODY (3-5 bloques cortos), CTA (1 frase)
Format: texto en ${locale} con ligera emoción y profesionalismo.
`;
}