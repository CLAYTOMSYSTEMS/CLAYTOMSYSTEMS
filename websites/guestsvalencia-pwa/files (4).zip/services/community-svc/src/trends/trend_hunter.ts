import fetch from 'node-fetch';

export interface TrendTopic {
  id: string;
  category: string;
  primary: string;
  secondary: string[];
  trendScore: number;
  volatility: number;
  locale: string;
  source: string[];
}

export async function fetchCryptoSignals(): Promise<TrendTopic[]> {
  const res = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,solana&vs_currencies=usd&include_24hr_change=true');
  const data = await res.json();
  return Object.entries(data).map(([coin, val]: any, i) => {
    const change = val.usd_24h_change || 0;
    return {
      id: `crypto_${coin}_${Date.now()}`,
      category: 'crypto',
      primary: coin,
      secondary: ['price','volatility','market'],
      trendScore: Math.min(Math.abs(change)/5, 2), // 0..2 scale
      volatility: Math.abs(change),
      locale: 'global',
      source: ['coingecko']
    };
  });
}

export async function detectTrendingNewsHeadlines(): Promise<TrendTopic[]> {
  // Placeholder; integrate news API + NLP ranking
  return [{
    id:`news_macro_${Date.now()}`,
    category:'finance',
    primary:'Fed Rate Outlook',
    secondary:['macro','rates','usd'],
    trendScore:1.2,
    volatility:0.4,
    locale:'en',
    source:['news_api']
  }];
}

export async function aggregateTrendTopics() {
  const [crypto, news] = await Promise.all([
    fetchCryptoSignals(),
    detectTrendingNewsHeadlines()
  ]);
  return [...crypto, ...news].sort((a,b)=>b.trendScore - a.trendScore).slice(0,12);
}