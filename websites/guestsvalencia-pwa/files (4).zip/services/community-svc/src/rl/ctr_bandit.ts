/**
 * Epsilon-decreasing Thompson Sampling hybrid
 */
interface ArmStats {
  armId: string;
  impressions: number;
  clicks: number;
  alpha: number;
  beta: number;
}

export class CTRBandit {
  private arms: Record<string,ArmStats> = {};
  private epsilon: number;
  private decay: number;

  constructor(armIds: string[], epsilon=0.15, decay=0.995) {
    this.epsilon = epsilon;
    this.decay = decay;
    for (const id of armIds) {
      this.arms[id] = { armId:id, impressions:0, clicks:0, alpha:1, beta:1 };
    }
  }

  selectArm(): string {
    if (Math.random() < this.epsilon) {
      return randomKey(this.arms);
    }
    // Thompson sample
    let best = null;
    let bestVal = -1;
    for (const a of Object.values(this.arms)) {
      const sample = betaSample(a.alpha, a.beta);
      if (sample > bestVal) { bestVal = sample; best = a.armId; }
    }
    return best || randomKey(this.arms);
  }

  recordOutcome(armId: string, clicked: boolean) {
    const a = this.arms[armId];
    if (!a) return;
    a.impressions++;
    if (clicked) {
      a.clicks++;
      a.alpha++;
    } else {
      a.beta++;
    }
    this.epsilon *= this.decay;
  }

  stats() {
    return Object.values(this.arms).map(a => ({
      armId:a.armId,
      ctr: a.clicks / Math.max(1,a.impressions),
      impressions: a.impressions,
      alpha:a.alpha, beta:a.beta
    }));
  }
}

function randomKey(obj:any){
  const keys = Object.keys(obj);
  return keys[Math.floor(Math.random()*keys.length)];
}
function betaSample(alpha:number,beta:number) {
  // Simple approximation using Math.random() fallback
  // For production: use proper gamma sampler
  const u1 = Math.random(), u2 = Math.random();
  return (Math.pow(u1, 1/alpha) + Math.pow(u2, 1/beta)) / 2;
}