/**
 * Linear UCB for contextual CTR optimization.
 */
export class LinUCB {
  private arms: Record<string, {A:number[][]; b:number[]}> = {};
  private d: number;
  private alpha: number;

  constructor(armIds: string[], dimension: number, alpha=1.2) {
    this.d = dimension;
    this.alpha = alpha;
    for (const id of armIds) {
      this.arms[id] = { A: identity(dimension), b: new Array(dimension).fill(0) };
    }
  }

  selectArm(context: number[]): string {
    let bestId = armIds(this.arms)[0];
    let bestScore = -Infinity;
    for (const id of armIds(this.arms)) {
      const { A, b } = this.arms[id];
      const Ainv = invert(A);
      const theta = multiplyVecMat(b, Ainv);
      const p = dot(theta, context) + this.alpha * Math.sqrt(quad(context, Ainv));
      if (p > bestScore) { bestScore = p; bestId = id; }
    }
    return bestId;
  }

  update(armId:string, context:number[], reward:number) {
    const arm = this.arms[armId];
    const { A, b } = arm;
    // A = A + x x^T
    for (let i=0;i<this.d;i++){
      for (let j=0;j<this.d;j++){
        A[i][j] += context[i]*context[j];
      }
    }
    for (let i=0;i<this.d;i++){
      b[i] += reward * context[i];
    }
  }
}

/* --- Linear Algebra Helpers (naive) --- */
function identity(n:number){ return Array.from({length:n},(_,i)=>Array.from({length:n},(__,j)=>i===j?1:0)); }
function armIds(o:any){ return Object.keys(o); }
function dot(a:number[], b:number[]){ return a.reduce((s,v,i)=>s+v*b[i],0); }
function multiplyVecMat(b:number[], A:number[][]) {
  const n = b.length;
  const x = new Array(n).fill(0);
  for (let i=0;i<n;i++){
    for (let j=0;j<n;j++){
      x[i] += A[i][j]*b[j];
    }
  }
  return x;
}
function quad(x:number[], Ainv:number[][]) {
  // x^T Ainv x
  let sum=0;
  for (let i=0;i<x.length;i++){
    for (let j=0;j<x.length;j++){
      sum += x[i]*Ainv[i][j]*x[j];
    }
  }
  return sum;
}
function invert(M:number[][]){
  // naive Gauss-Jordan (NOT for production large matrices)
  const n = M.length;
  const A = M.map(r=>r.slice());
  const I = identity(n);
  for (let i=0;i<n;i++){
    let pivot = A[i][i];
    if (Math.abs(pivot) < 1e-9) pivot = 1e-9;
    const invPivot = 1/pivot;
    for (let j=0;j<n;j++){ A[i][j]*=invPivot; I[i][j]*=invPivot; }
    for (let r=0;r<n;r++){
      if (r===i) continue;
      const factor = A[r][i];
      for (let c=0;c<n;c++){
        A[r][c]-=factor*A[i][c];
        I[r][c]-=factor*I[i][c];
      }
    }
  }
  return I;
}