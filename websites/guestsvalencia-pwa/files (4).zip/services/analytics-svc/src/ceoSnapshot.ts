interface SnapshotDeps {
  getRevenueLast24h():Promise<number>;
  getOccupancyNext30d():Promise<number>;
  getADRCurrent():Promise<number>;
  getPaceVariance():Promise<number>;
  getSentimentIndex():Promise<number>;
  getDynamicPricingUplift():Promise<number>;
}

export async function buildDailyCeoSnapshot(deps: SnapshotDeps) {
  const [
    revenue24h,
    occupancy30d,
    adrCurrent,
    paceVar,
    sentimentIndex,
    uplift
  ] = await Promise.all([
    deps.getRevenueLast24h(),
    deps.getOccupancyNext30d(),
    deps.getADRCurrent(),
    deps.getPaceVariance(),
    deps.getSentimentIndex(),
    deps.getDynamicPricingUplift()
  ]);

  return {
    generatedAt: new Date().toISOString(),
    revenue24h,
    occupancy30d,
    adrCurrent,
    paceVariance: paceVar,
    sentimentIndex,
    pricingUpliftPercent: uplift,
    summary: buildSummary({revenue24h, occupancy30d, adrCurrent, paceVar, sentimentIndex, uplift})
  };
}

function buildSummary(k: any) {
  return `Revenue 24h €${k.revenue24h.toFixed(0)}, Occ30d ${(k.occupancy30d*100).toFixed(1)}%, ADR €${k.adrCurrent.toFixed(2)}, Uplift ${(k.uplift*100).toFixed(1)}%. PaceVar ${(k.paceVar*100).toFixed(1)}%, Sentiment ${(k.sentimentIndex*100).toFixed(1)}%.`;
}