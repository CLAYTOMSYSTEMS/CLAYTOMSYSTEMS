"""
Incremental clustering stub (mini-batch KMeans style).
Features: avg_session_length, booking_conversion, lead_time_avg, cancellation_rate, locale_diversity
"""
import random, math
from typing import List, Dict

K = 5
centroids = [ [random.random() for _ in range(5)] for _ in range(K) ]
counts = [1]*K

def extract_features(user_metrics:Dict):
  return [
    user_metrics.get("avg_session_length",0)/300,     # normalized
    user_metrics.get("booking_conversion",0),
    user_metrics.get("lead_time_avg",0)/60,
    user_metrics.get("cancellation_rate",0),
    user_metrics.get("locale_diversity",1)/5
  ]

def distance(a,b):
  return math.sqrt(sum((x-y)**2 for x,y in zip(a,b)))

def assign(vec):
  dists = [distance(vec,c) for c in centroids]
  return min(range(K), key=lambda i:dists[i])

def update_cluster(idx, vec, lr=0.05):
  global centroids
  c = centroids[idx]
  centroids[idx] = [c[i]*(1-lr) + vec[i]*lr for i in range(len(vec))]
  counts[idx]+=1

def segment_user(user_metrics:Dict):
  vec = extract_features(user_metrics)
  idx = assign(vec)
  update_cluster(idx, vec)
  return {"cluster": idx, "profile_vector": vec}

if __name__ == "__main__":
  sample = {"avg_session_length":180,"booking_conversion":0.12,"lead_time_avg":25,"cancellation_rate":0.05,"locale_diversity":3}
  print(segment_user(sample))