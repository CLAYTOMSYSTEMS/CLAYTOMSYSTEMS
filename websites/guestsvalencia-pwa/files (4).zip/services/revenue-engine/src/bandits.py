import math, random

class UCB1:
    def __init__(self):
        self.counts = {}
        self.rewards = {}

    def select(self):
        total = sum(self.counts.values()) or 1
        best, best_score = None, -1
        for arm in self.counts:
            c = self.counts[arm]
            r = self.rewards[arm]
            mean = r / c if c else 0
            bonus = math.sqrt(2 * math.log(total) / (c or 1))
            score = mean + bonus
            if score > best_score:
                best, best_score = arm, score
        return best

    def update(self, arm, reward):
        self.counts.setdefault(arm,0); self.rewards.setdefault(arm,0)
        self.counts[arm]+=1
        self.rewards[arm]+=reward

class ThompsonBinary:
    def __init__(self):
        self.success = {}
        self.fail = {}

    def select(self):
        best, best_val = None, -1
        for arm in self.success:
            a = self.success[arm] + 1
            b = self.fail[arm] + 1
            sample = random.betavariate(a,b)
            if sample > best_val:
                best, best_val = arm, sample
        return best

    def update(self, arm, reward):
        self.success.setdefault(arm,0); self.fail.setdefault(arm,0)
        if reward > 0:
            self.success[arm]+=1
        else:
            self.fail[arm]+=1