import client from 'prom-client';
export const register = new client.Registry();
client.collectDefaultMetrics({ register });
export const bookingValue = new client.Counter({ name:'booking_confirmed_value_total', help:'Sum confirmed booking value EUR' });
register.registerMetric(bookingValue);