@app.get("/select/next")
async def select_next(strategy: str = 'ucb'):
    arm = app.state.ucb.select() if strategy=='ucb' else app.state.ts.select()
    return {"arm": arm, "strategy": strategy}