/**
 * Exact MWIS via branch & bound for small candidate sets (<=20).
 * Fallback to greedy if bigger.
 */
export interface CandidateAction {
  actionId: string;
  conflictsWith: string[];
  score: number; // pre-computed composite score
}

export function resolveMWIS(actions: CandidateAction[]): string[] {
  if (actions.length > 20) {
    return greedyFallback(actions);
  }
  // Build adjacency
  const index = new Map(actions.map((a,i)=>[a.actionId,i]));
  const adj: boolean[][] = actions.map(()=>Array(actions.length).fill(false));
  actions.forEach((a,i)=>{
    a.conflictsWith.forEach(c=>{
      const j = index.get(c);
      if (j !== undefined) {
        adj[i][j] = adj[j][i] = true;
      }
    });
  });

  let bestSet: number[] = [];
  function backtrack(pos:number, current:number[], currentScore:number) {
    if (pos === actions.length) {
      const bestScore = scoreSet(bestSet, actions);
      if (currentScore > bestScore) bestSet = [...current];
      return;
    }
    // bound: optimistic remaining
    const optimistic = currentScore + optimisticRemainder(pos, actions);
    if (optimistic < scoreSet(bestSet, actions)) return;

    // Try include
    if (!conflicts(pos, current, adj)) {
      current.push(pos);
      backtrack(pos+1, current, currentScore + actions[pos].score);
      current.pop();
    }
    // Exclude
    backtrack(pos+1, current, currentScore);
  }

  backtrack(0, [], 0);
  return bestSet.map(i=>actions[i].actionId);
}

function greedyFallback(actions: CandidateAction[]) {
  const chosen: CandidateAction[] = [];
  for (const a of actions.sort((x,y)=>y.score - x.score)) {
    if (!chosen.some(c => conflictsWith(c, a))) chosen.push(a);
  }
  return chosen.map(c=>c.actionId);
}

function conflictsWith(a:CandidateAction,b:CandidateAction){
  return a.conflictsWith.includes(b.actionId) || b.conflictsWith.includes(a.actionId);
}
function conflicts(i:number, current:number[], adj:boolean[][]){
  return current.some(j=>adj[i][j]);
}
function scoreSet(idxs:number[], actions:CandidateAction[]){
  return idxs.reduce((s,i)=>s+actions[i].score,0);
}
function optimisticRemainder(pos:number, actions:CandidateAction[]){
  // naive optimistic = sum of positive scores remaining
  return actions.slice(pos).reduce((s,a)=> s + (a.score>0?a.score:0), 0);
}