/**
 * RL Bandit fallback for conflict resolution tie-break.
 * Maintains actionType value estimates (epsilon-greedy).
 */
interface BanditState {
  counts: Record<string, number>;
  values: Record<string, number>;
  epsilon: number;
}

export class ConflictBandit {
  private state: BanditState;
  constructor(epsilon=0.08) {
    this.state = { counts:{}, values:{}, epsilon };
  }
  select(actionTypes: string[]): string {
    if (Math.random() < this.state.epsilon) {
      return actionTypes[Math.floor(Math.random()*actionTypes.length)];
    }
    // pick max value
    let best = actionTypes[0];
    for (const a of actionTypes) {
      if ((this.state.values[a]||0) > (this.state.values[best]||0)) best = a;
    }
    return best;
  }
  update(actionType: string, reward: number) {
    const c = (this.state.counts[actionType]||0)+1;
    const v = this.state.values[actionType]||0;
    const newV = v + (reward - v)/c;
    this.state.counts[actionType] = c;
    this.state.values[actionType] = newV;
  }
}