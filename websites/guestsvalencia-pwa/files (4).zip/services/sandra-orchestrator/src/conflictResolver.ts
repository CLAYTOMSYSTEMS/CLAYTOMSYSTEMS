interface CandidateAction {
  actionId: string;
  agent: string;
  type: string;
  confidence: number;
  costEstimate: number;
  conflictsWith: string[];
  synergyTags: string[];
  content: string;
}

interface DecisionResult {
  chosen: CandidateAction[];
  discarded: CandidateAction[];
}

export function resolveConflicts(actions: CandidateAction[]): DecisionResult {
  // Score heuristic
  const synergyMap = buildSynergy(actions);
  const scored = actions.map(a => {
    const synergyBoost = synergyMap.get(a.actionId) || 1;
    const base = a.confidence * synergyBoost * priorityWeight(a.type);
    return { action:a, score: base };
  }).sort((a,b)=>b.score - a.score);

  const chosen: CandidateAction[] = [];
  const conflicts = new Set<string>();

  for (const s of scored) {
    if (s.action.conflictsWith.some(c => conflicts.has(c))) continue;
    chosen.push(s.action);
    s.action.conflictsWith.forEach(c => conflicts.add(c));
  }

  const chosenIds = new Set(chosen.map(c=>c.actionId));
  const discarded = actions.filter(a => !chosenIds.has(a.actionId));

  if (!chosen.length) {
    // Fallback safe action
    const safe: CandidateAction = {
      actionId: 'safe-info',
      agent: 'orchestrator',
      type: 'SAFE_INFO',
      confidence: 1,
      costEstimate: 0,
      conflictsWith: [],
      synergyTags: [],
      content: 'Información base proporcionada.'
    };
    return { chosen:[safe], discarded: actions };
  }

  return { chosen, discarded };
}

function priorityWeight(type: string) {
  switch(type) {
    case 'PRICE_ADJUST': return 1.2;
    case 'REPLY_MESSAGE': return 1.0;
    case 'PUSH_AVAILABILITY': return 1.1;
    case 'UPSELL_OFFER': return 1.05;
    default: return 0.9;
  }
}

function buildSynergy(actions: CandidateAction[]) {
  const map = new Map<string,number>();
  for (const a of actions) {
    let boost = 1;
    if (a.synergyTags.includes('booking_path')) boost += 0.1;
    if (a.synergyTags.includes('revenue_core')) boost += 0.15;
    map.set(a.actionId, boost);
  }
  return map;
}