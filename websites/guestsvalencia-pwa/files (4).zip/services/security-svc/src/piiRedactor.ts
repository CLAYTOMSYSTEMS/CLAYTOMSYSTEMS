const patterns = [
  { name:'CREDIT_CARD', regex:/\b(?:\d[ -]*?){13,16}\b/g },
  { name:'EMAIL', regex:/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi }
];

export function redact(text: string) {
  let matches: any[] = [];
  let redacted = text;
  for (const p of patterns) {
    redacted = redacted.replace(p.regex, (m) => {
      matches.push({ type:p.name, value:m });
      return `[REDACTED_${p.name}]`;
    });
  }
  return { redacted, matches };
}