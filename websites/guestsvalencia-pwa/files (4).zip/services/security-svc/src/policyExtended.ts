export function evaluateGuardrails(text: string) {
  const reasons:string[] = [];
  if (/\b(?:\d[ -]*?){13,16}\b/.test(text)) reasons.push('PII_CARD');
  if (/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i.test(text)) reasons.push('PII_EMAIL');
  if (/(union\s+select|drop\s+table|;--|\/\*)/i.test(text)) reasons.push('SQL_INJECTION');
  if (/(ignore previous|disregard instructions)/i.test(text)) reasons.push('PROMPT_INJECTION');
  if (/(idiot|stupid|fuck|gilipollas)/i.test(text)) reasons.push('ABUSE');
  const allow = reasons.length === 0;
  return { allow, reasons };
}