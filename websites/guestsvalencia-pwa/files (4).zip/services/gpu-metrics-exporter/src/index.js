import Fastify from 'fastify';
import client from 'prom-client';
import fetch from 'node-fetch';

const app = Fastify({ logger:true });
const register = new client.Registry();
client.collectDefaultMetrics({ register });

const qLen = new client.Gauge({ name:'gpu_queue_length', help:'Pending inference jobs'});
const inflight = new client.Gauge({ name:'gpu_inflight_jobs', help:'Running jobs'});
register.registerMetric(qLen);
register.registerMetric(inflight);

async function poll(){
  try {
    // Extend: call orchestrator endpoints or Redis stats
    const pending = Math.floor(Math.random()*5); // placeholder
    const run = Math.floor(Math.random()*2);
    qLen.set(pending);
    inflight.set(run);
  } catch {}
}
setInterval(poll, 5000);

app.get('/metrics', async (req, reply)=>{
  reply.header('Content-Type', register.contentType);
  return reply.send(await register.metrics());
});
app.get('/healthz', async ()=>({ ok:true }));

app.listen({ port: process.env.PORT || 4240, host:'0.0.0.0' });