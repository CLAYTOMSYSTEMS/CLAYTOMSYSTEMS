import { Pool } from 'pg';
import { v4 as uuid } from 'uuid';
const pool = new Pool();

interface BuildInput {
  guestId: string;
  date: string; // YYYY-MM-DD
  tier: string;
  preferences: { diets:string[]; cuisines:string[]; };
}

export async function buildDailyItinerary(input: BuildInput) {
  const id = uuid();
  // naive slots
  const baseSlots = [
    { category:'breakfast', start:'08:30', end:'09:15' },
    { category:'activity', start:'10:00', end:'12:00' },
    { category:'lunch', start:'13:30', end:'14:30' },
    { category:'rest', start:'15:00', end:'16:30' },
    { category:'dinner', start:'20:30', end:'22:00' }
  ];
  await pool.query('INSERT INTO itinerary(id,guest_id,tier,date,summary) VALUES($1,$2,$3,$4,$5)',
    [id, input.guestId, input.tier, input.date, 'Generated base plan']);
  for (const slot of baseSlots) {
    await pool.query(`
      INSERT INTO itinerary_slot(itinerary_id,start_time,end_time,category,notes)
      VALUES($1,$2,$3,$4,$5)
    `,[id, `${input.date}T${slot.start}:00`, `${input.date}T${slot.end}:00`, slot.category, (slot.category==='dinner' && input.preferences.cuisines[0])?`Try ${input.preferences.cuisines[0]}`:'']);
  }
  return { itineraryId:id };
}