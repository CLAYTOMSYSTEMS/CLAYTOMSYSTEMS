import Fastify from 'fastify';
import fetch from 'node-fetch';

const app = Fastify({ logger:true });

const jailPatterns = (process.env.JAILBREAK_PATTERNS || '').split(',').filter(Boolean).map(p=> new RegExp(p,'i'));

app.post('/moderate', async (req, reply)=>{
  const { text } = req.body || {};
  if (!text) return reply.code(400).send({ error:'text required' });
  const jailbreak = jailPatterns.some(r=> r.test(text));
  // Stub external moderation (replace with real OpenAI moderation if desired)
  const toxicity = /violencia|odio|matar|arma/i.test(text);
  return {
    allowed: !(toxicity || jailbreak),
    flags:{
      toxicity,
      jailbreak
    }
  };
});

app.get('/healthz', async ()=>({ ok:true }));

app.listen({ port: process.env.PORT || 4180, host:'0.0.0.0' });