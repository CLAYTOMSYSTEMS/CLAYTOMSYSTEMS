interface Lead {
  id: string;
  email: string;
  intent: string;
  createdAt: Date;
  score?: number;
}

interface SequenceStep {
  delayHours: number;
  templateCode: string;
  channel: 'EMAIL'|'WHATSAPP';
}

const BASE_SEQUENCE: SequenceStep[] = [
  { delayHours: 0.1, templateCode:'WELCOME_INFO', channel:'EMAIL' },
  { delayHours: 12, templateCode:'VALUE_PROPOSITION', channel:'EMAIL' },
  { delayHours: 36, templateCode:'SOCIAL_PROOF', channel:'EMAIL' },
  { delayHours: 60, templateCode:'LAST_CHANCE_OFFER', channel:'EMAIL' }
];

export function scheduleLeadSequence(lead: Lead, enqueue: (job:any)=>void) {
  const score = estimateScore(lead);
  BASE_SEQUENCE.forEach(step => {
    enqueue({
      type:'SEND_TEMPLATE',
      leadId: lead.id,
      runAt: new Date(Date.now() + step.delayHours*3600*1000),
      template: step.templateCode,
      channel: step.channel,
      personalization: { score }
    });
  });
}

function estimateScore(lead: Lead) {
  let score = 0.5;
  if (/booking/i.test(lead.intent)) score += 0.2;
  if ((Date.now() - lead.createdAt.getTime()) < 3600_000) score += 0.1;
  return Math.min(score, 1);
}