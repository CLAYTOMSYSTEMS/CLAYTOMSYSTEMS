import client from 'prom-client';
export const register = new client.Registry();
client.collectDefaultMetrics({ register });
export const quoteCounter = new client.Counter({ name:'revenue_dynamic_quote_total', help:'Quotes issued', labelNames:['variant','listing'] });
export const upliftCounter = new client.Counter({ name:'revenue_dynamic_uplift_amount_total', help:'Accumulated uplift EUR' });
register.registerMetric(quoteCounter);
register.registerMetric(upliftCounter);