export function seasonTag(dateStr){
  const m = new Date(dateStr).getMonth()+1;
  if ([6,7,8].includes(m)) return 'summer';
  if ([12,1].includes(m)) return 'winter';
  return 'regular';
}