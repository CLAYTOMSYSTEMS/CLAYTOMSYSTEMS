import { Pool } from 'pg';
const pool = new Pool({ connectionString: process.env.PG_URL });

export async function ingestEvent(ev){
  await pool.query(`
    INSERT INTO pricing_events(source,event_type,payload,start_time,end_time)
    VALUES($1,$2,$3,$4,$5)
  `,[ev.source, ev.type, ev.payload, ev.start_time, ev.end_time]);
}