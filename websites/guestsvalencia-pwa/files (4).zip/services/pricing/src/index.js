// PATCH SNIPPET (añadir endpoints nuevos)
import { ingestEvent } from './events.js';

app.post('/events/ingest', async (req, reply)=>{
  const body = req.body || {};
  if (!body.source) return reply.code(400).send({ error:'source required' });
  await ingestEvent(body);
  return { ok:true };
});

app.post('/elasticity/update', async (req, reply)=>{
  const { listingId, season, elasticity } = req.body || {};
  if (!listingId) return reply.code(400).send({ error:'listingId required' });
  await pool.query(`
    INSERT INTO pricing_elasticity(listing_id,season,elasticity)
    VALUES($1,$2,$3)
    ON CONFLICT(listing_id,season) DO UPDATE SET elasticity=EXCLUDED.elasticity, updated_at=now()
  `,[listingId, season||'all', elasticity||0.2]);
  return { ok:true };
});

// Modify /quote to include elasticity
// inside handler after demand calculation:
  const elastRow = await pool.query(
    'SELECT elasticity FROM pricing_elasticity WHERE listing_id=$1 AND (season=$2 OR season=$3) ORDER BY season DESC LIMIT 1',
    [listingId, seasonTag(checkin), 'all']
  );
  const elasticity = elastRow.rowCount ? Number(elastRow.rows[0].elasticity) : 0.2;
  const elasticityAdj = (1 + elasticity * uplift);
  const dynamicNight = basePrice * (1 + uplift) * elasticityAdj;