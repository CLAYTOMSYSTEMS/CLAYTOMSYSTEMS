import Fastify from 'fastify';
import { Pool } from 'pg';
import fetch from 'node-fetch';

const app = Fastify({ logger:true });
const pool = new Pool({ connectionString: process.env.PG_URL });

function choosePriceBand(base, elasticity=0.2){
  const variants = [
    base * (1 - 0.1),
    base * (1 - 0.05),
    base,
    base * (1 + 0.05),
    base * (1 + 0.1),
    base * (1 + 0.15)
  ];
  // Simple: pick center weighted by elasticity sign
  if (elasticity > 0.3) return variants[4];
  if (elasticity < -0.1) return variants[1];
  return variants[2];
}

app.post('/suggest', async (req, reply)=>{
  const { listingId, basePrice=100 } = req.body || {};
  if (!listingId) return reply.code(400).send({ error:'listingId required' });
  const elastRow = await pool.query(`
    SELECT elasticity FROM pricing_elasticity
    WHERE listing_id=$1 ORDER BY updated_at DESC LIMIT 1
  `,[listingId]);
  const elasticity = elastRow.rowCount ? Number(elastRow.rows[0].elasticity) : 0.2;
  const testPrice = Math.round(choosePriceBand(basePrice, elasticity)*100)/100;
  return { listingId, basePrice, elasticity, testPrice, dryRun: process.env.DRY_RUN==='true' };
});

app.post('/log-outcome', async (req, reply)=>{
  const { listingId, basePrice, testPrice, outcome, revenue } = req.body || {};
  if (!listingId) return reply.code(400).send({ error:'listingId required' });
  await pool.query(`
    INSERT INTO price_experiments(listing_id,base_price,test_price,outcome,revenue)
    VALUES($1,$2,$3,$4,$5)
  `,[listingId, basePrice, testPrice, !!outcome, revenue||0]);
  return { ok:true };
});

app.get('/healthz', async ()=>({ ok:true }));

app.listen({ port: process.env.PORT || 4270, host:'0.0.0.0' });