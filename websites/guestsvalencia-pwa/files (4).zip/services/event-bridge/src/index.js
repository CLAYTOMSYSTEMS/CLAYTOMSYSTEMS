import { connect as natsConnect } from 'nats';
import { Kafka } from 'kafkajs';
import pino from 'pino';

const log = pino({ level:'info' });
const nc = await natsConnect({ servers: process.env.NATS_URL });
const kafka = new Kafka({ brokers:[process.env.KAFKA_BROKER] });
const producer = kafka.producer();
await producer.connect();

const topics = ['conversation.reply','booking.confirmed','payment.completed'];

for (const t of topics) {
  (async ()=>{
    const sub = nc.subscribe(t);
    for await (const m of sub) {
      const payload = m.data.toString();
      await producer.send({
        topic: process.env.TOPIC_PREFIX + t,
        messages:[{ value: payload }]
      });
      log.info({ t }, 'bridged');
    }
  })();
}