import fetch from 'node-fetch';

export async function moderateUserText(text) {
  try {
    const r = await fetch(process.env.GUARDRAILS_V2_URL + '/moderate/semantic',{
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ text })
    }).then(r=>r.json());
    return r;
  } catch { return { action:'allow' }; }
}