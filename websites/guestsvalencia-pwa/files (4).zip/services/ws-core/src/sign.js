import crypto from 'crypto';
export function signPayload(obj) {
  const secret = process.env.JWT_SECRET || 'dev';
  const body = JSON.stringify(obj);
  const hmac = crypto.createHmac('sha256', secret).update(body).digest('hex');
  return { body: obj, sig: hmac };
}