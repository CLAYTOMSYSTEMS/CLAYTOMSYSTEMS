export function moderateKids(text) {
  const lower = text.toLowerCase();
  const banned = [/violencia/i,/arma/i,/sexo/i];
  for (const r of banned) {
    if (r.test(lower)) return { allowed:false, category:'blocked' };
  }
  return { allowed:true, category:'clean' };
}

export function educationalIntent(text) {
  const keywords = [/aprender/i,/historia/i,/número/i,/color/i,/animales/i,/planeta/i];
  return keywords.some(r=>r.test(text.toLowerCase()));
}