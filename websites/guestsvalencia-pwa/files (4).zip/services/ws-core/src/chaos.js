export function maybeChaos() {
  const p = parseFloat(process.env.CHAOS_PROB_FAILURE || '0');
  if (Math.random() < p) {
    throw new Error('InjectedChaosFailure');
  }
}