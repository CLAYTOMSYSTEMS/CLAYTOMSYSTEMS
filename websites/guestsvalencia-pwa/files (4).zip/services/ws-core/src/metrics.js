import client from 'prom-client';

export const register = new client.Registry();
client.collectDefaultMetrics({ register });

export const msgCounter = new client.Counter({
  name: 'ws_core_messages_total',
  help: 'Total de mensajes recibidos del usuario',
  labelNames: ['mode']
});
export const replyTokens = new client.Counter({
  name: 'ws_core_reply_tokens_total',
  help: 'Tokens respuesta LLM (estimados)',
  labelNames: ['provider']
});
export const activeSessions = new client.Gauge({
  name: 'ws_core_active_sessions',
  help: 'Sesiones WebSocket activas'
});

register.registerMetric(msgCounter);
register.registerMetric(replyTokens);
register.registerMetric(activeSessions);