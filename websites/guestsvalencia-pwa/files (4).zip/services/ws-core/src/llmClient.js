import fetch from 'node-fetch';

export async function generateLLM({ conversation, userText, systemExtra }) {
  const messages = [
    { role:'system', content: 'Eres Sandra IA 7.0, especialista en alojamientos Valencia. Responde útil, breve, veraz.' },
    ...systemExtra,
    ...conversation,
    { role:'user', content: userText }
  ];
  const res = await fetch(process.env.LLM_GATEWAY_URL + '/generate',{
    method:'POST',
    headers:{ 'Content-Type':'application/json' },
    body: JSON.stringify({ messages })
  });
  const json = await res.json();
  if (json.error) throw new Error(json.error);
  return json;
}