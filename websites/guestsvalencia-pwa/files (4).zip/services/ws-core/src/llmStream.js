import fetch from 'node-fetch';

export async function* streamLLM({ messages }) {
  const res = await fetch(process.env.LLM_GATEWAY_URL + '/stream',{
    method:'POST',
    headers:{ 'Content-Type':'application/json' },
    body: JSON.stringify({ messages })
  });
  if (!res.ok) throw new Error('LLM stream failed '+res.status);
  let buffer = '';
  for await (const chunk of res.body) {
    buffer += chunk.toString();
    // SSE lines separated by \n\n
    const parts = buffer.split('\n\n');
    buffer = parts.pop();
    for (const part of parts) {
      if (!part.trim()) continue;
      const lines = part.split('\n');
      let event;
      let data;
      for (const l of lines) {
        if (l.startsWith('event:')) event = l.slice(6).trim();
        else if (l.startsWith('data:')) data = l.slice(5).trim();
      }
      if (event === 'token') {
        try {
          const j = JSON.parse(data);
          if (j.delta) yield { type:'delta', token: j.delta };
        } catch {}
      } else if (event === 'done') {
        return;
      }
    }
  }
}