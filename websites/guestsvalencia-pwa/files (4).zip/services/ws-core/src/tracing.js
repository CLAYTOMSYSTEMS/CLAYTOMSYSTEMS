import { NodeTracerProvider } from '@opentelemetry/sdk-trace-node';
import { OTLPTraceExporter } from '@opentelemetry/exporter-trace-otlp-http';
import { SimpleSpanProcessor } from '@opentelemetry/sdk-trace-node';
import { trace } from '@opentelemetry/api';

const provider = new NodeTracerProvider();
const exporter = new OTLPTraceExporter({ url: process.env.OTLP_URL || 'http://otel-collector:4318/v1/traces' });
provider.addSpanProcessor(new SimpleSpanProcessor(exporter));
provider.register();
export const tracer = trace.getTracer('ws-core');