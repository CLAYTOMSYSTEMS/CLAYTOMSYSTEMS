import { readFileSync } from 'fs';
import * as crypto from 'crypto';

const PRIV = process.env.ED25519_PRIVATE_PATH
  ? readFileSync(process.env.ED25519_PRIVATE_PATH)
  : null;

export function signEvent(obj) {
  if (!PRIV) return { body: obj, sig: null, alg:'none' };
  const body = Buffer.from(JSON.stringify(obj));
  const signature = crypto.sign(null, body, PRIV).toString('base64');
  return { body: obj, sig: signature, alg:'ed25519' };
}