import { tracer } from './tracing.js';
const span = tracer.startSpan('incoming_message');
span.setAttribute('session_id', sessionId);
... // after processing
span.end();