export function detectBookingIntent(text) {
  const t = text.toLowerCase();
  if (/(reserv|book|alquil|apartamento|quiero.*(noche|noches|habitación|semana))/i.test(t)) {
    return true;
  }
  return false;
}