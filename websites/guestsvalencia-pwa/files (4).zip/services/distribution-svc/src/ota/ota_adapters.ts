export interface PriceUpdatePayload {
  listingId: string;
  date: string;
  newPrice: number;
  currency: string;
  minStay?: number;
}

export interface AvailabilityUpdatePayload {
  listingId: string;
  date: string;
  available: boolean;
  minStay?: number;
}

export interface OTAAdapter {
  name: string;
  pushPrices(updates: PriceUpdatePayload[]): Promise<{ success: boolean; failures?: any[] }>;
  pushAvailability(updates: AvailabilityUpdatePayload[]): Promise<{ success: boolean; failures?: any[] }>;
  fetchReservations?(sinceISO: string): Promise<any[]>;
  respondReview?(reviewId:string, text:string): Promise<boolean>;
}

export class AirbnbAdapter implements OTAAdapter {
  name='airbnb';
  async pushPrices(updates:PriceUpdatePayload[]) {
    // TODO: call official partner API / channel manager
    return { success:true };
  }
  async pushAvailability(updates:AvailabilityUpdatePayload[]) {
    return { success:true };
  }
  async fetchReservations(sinceISO: string) { return []; }
  async respondReview(reviewId:string, text:string) { return true; }
}

export class BookingComAdapter implements OTAAdapter {
  name='bookingcom';
  async pushPrices(updates:PriceUpdatePayload[]) { return { success:true }; }
  async pushAvailability(updates:AvailabilityUpdatePayload[]) { return { success:true }; }
  async fetchReservations(sinceISO: string) { return []; }
  async respondReview(reviewId:string, text:string) { return true; }
}

export function buildAdapters(): Record<string,OTAAdapter> {
  return {
    airbnb: new AirbnbAdapter(),
    bookingcom: new BookingComAdapter()
  };
}