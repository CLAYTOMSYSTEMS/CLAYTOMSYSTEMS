import express from 'express';
import { paymentRegister } from './metrics';
export const metricsApp = express();
metricsApp.get('/metrics', async (_req,res)=>{
  res.set('Content-Type', paymentRegister.contentType);
  res.end(await paymentRegister.metrics());
});