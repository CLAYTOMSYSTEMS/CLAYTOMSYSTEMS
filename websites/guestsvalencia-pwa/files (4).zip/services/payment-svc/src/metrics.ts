import client from 'prom-client';
export const paymentRegister = new client.Registry();
client.collectDefaultMetrics({ register: paymentRegister });

export const paymentSessionLatency = new client.Histogram({
  name: 'payment_session_latency_ms',
  help: 'Latency creating Stripe checkout session',
  buckets: [50,100,150,200,300,500,800,1200]
});
export const paymentsSuccess = new client.Counter({
  name: 'payments_success_total',
  help: 'Payment success confirmations'
});
export const paymentsError = new client.Counter({
  name: 'payments_error_total',
  help: 'Payment errors'
});

paymentRegister.registerMetric(paymentSessionLatency);
paymentRegister.registerMetric(paymentsSuccess);
paymentRegister.registerMetric(paymentsError);