import express from 'express';
import Stripe from 'stripe';
import bodyParser from 'body-parser';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion:'2023-10-16' });
const app = express();
app.use(bodyParser.json());

app.post('/checkout/session', async (req,res) => {
  const { bookingId, amountCents, currency='EUR', successUrl, cancelUrl } = req.body;
  if (!bookingId || !amountCents) return res.status(400).json({ error:'MISSING' });
  const session = await stripe.checkout.sessions.create({
    mode:'payment',
    line_items:[{
      price_data:{
        currency,
        product_data:{ name: `Booking ${bookingId}` },
        unit_amount: amountCents
      },
      quantity:1
    }],
    success_url: successUrl + '?session={CHECKOUT_SESSION_ID}',
    cancel_url: cancelUrl,
    metadata:{ bookingId }
  });
  res.json({ url: session.url, sessionId: session.id });
});

app.post('/webhook/stripe', bodyParser.raw({ type:'application/json' }), (req,res) => {
  const sig = req.headers['stripe-signature'] as string;
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET!);
  } catch (err:any) {
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }
  if (event.type === 'checkout.session.completed') {
    const session = event.data.object as any;
    const bookingId = session.metadata?.bookingId;
    // TODO: call booking-cqrs-svc MarkPaidCommand (gRPC or REST)
    console.log('[PAYMENT] Booking paid', bookingId);
  }
  res.json({ received:true });
});

const port = process.env.PORT || 4700;
app.listen(port, ()=>console.log('[payment-svc] listening', port));