import { conversationActiveSessions } from '../../gateway-api/src/metrics'; // o exporta vía shared lib
let active = 0;
export function onSessionOpen() {
  active++;
  conversationActiveSessions.set(active);
}
export function onSessionClose() {
  active = Math.max(0, active - 1);
  conversationActiveSessions.set(active);
}