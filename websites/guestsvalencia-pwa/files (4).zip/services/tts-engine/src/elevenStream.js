import WebSocket from 'ws';

export function elevenStream({ text, voiceId, apiKey }) {
  return new Promise((resolve, reject) => {
    // DOC real: wss://api.elevenlabs.io/v1/text-to-speech/${voiceId}/stream
    // Aquí simulamos: se devuelve events "chunk"
    const ws = new WebSocket('wss://api.elevenlabs.io/v1/text-to-speech/'+voiceId+'/stream', {
      headers: { 'xi-api-key': apiKey }
    });
    const events = [];
    ws.on('open', ()=> {
      ws.send(JSON.stringify({ text, model_id:"eleven_multilingual_v2", optimize_streaming_latency:2 }));
    });
    ws.on('message', raw => {
      // Real: binary audio + metadata frames (depende spec)
      events.push({ type:'audio-chunk', data: raw.toString('base64') });
    });
    ws.on('close', ()=> resolve(events));
    ws.on('error', reject);
    setTimeout(()=> {
      // fallback timeout (demo)
      if (events.length===0) resolve([{ type:'audio-chunk', data:'' }]);
    }, 8000);
  });
}