import { WebSocketServer } from 'ws';

export function attachPCM(server) {
  const wss = new WebSocketServer({ server, path:'/ws/pcm' });
  wss.on('connection', ws => {
    ws.on('message', raw => {
      let msg; try { msg = JSON.parse(raw); } catch { return; }
      if (msg.type === 'synthesize') {
        // Demo: enviar 30 paquetes PCM silenciosos
        for (let i=0;i<30;i++) {
          const pcm = Buffer.alloc(1600); // 100ms @16k 16bit mono (approx)
          ws.send(pcm);
        }
        ws.send(JSON.stringify({ type:'done' }));
      }
    });
  });
}