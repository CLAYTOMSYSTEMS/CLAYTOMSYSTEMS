import { elevenRealtime } from './elevenRealtime.js';

app.post('/realtime/eleven', async (req,res)=>{
  const { text } = req.body || {};
  if (!text) return res.status(400).json({ error:'text required' });
  try {
    const audioBuf = await elevenRealtime({
      apiKey: process.env.ELEVEN_API_KEY,
      voiceId: process.env.ELEVEN_VOICE_ID,
      text
    });
    res.setHeader('Content-Type','audio/mpeg');
    return res.send(audioBuf);
  } catch(e){
    return res.status(500).json({ error:'eleven_fail', detail:String(e) });
  }
});