import WebSocket from 'ws';
import { randomUUID } from 'crypto';

export function elevenRealtime({ apiKey, voiceId, text }) {
  return new Promise((resolve, reject) => {
    const url = `wss://api.elevenlabs.io/v1/text-to-speech/${voiceId}/stream-input?model_id=eleven_multilingual_v2`;
    const ws = new WebSocket(url, { headers:{ 'xi-api-key': apiKey } });
    const chunks = [];
    ws.on('open', ()=>{
      ws.send(JSON.stringify({
        text, voice_settings:{ stability:0.5, similarity_boost:0.7 },
        generation_config:{ chunk_length_schedule:[120,200,260] }
      }));
      ws.send(JSON.stringify({ type:'end_of_stream' }));
    });
    ws.on('message', data => {
      // Real: some frames are JSON, others binary audio
      if (Buffer.isBuffer(data)) {
        chunks.push(data);
      } else {
        try {
          const j = JSON.parse(data.toString());
          if (j.type === 'error') reject(new Error(j.error));
        } catch {}
      }
    });
    ws.on('close', ()=> resolve(Buffer.concat(chunks)));
    ws.on('error', reject);
  });
}