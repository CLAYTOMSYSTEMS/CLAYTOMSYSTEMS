import { Pool } from 'pg';
const pool = new Pool();

export interface PartnerInput {
  id: string;
  name: string;
  category: string;
  city: string;
  commissionPct: number;
  minSpend?: number;
  apiEndpoint?: string;
}

export async function onboardPartner(p: PartnerInput) {
  await pool.query(`
    INSERT INTO partner(id,name,category,city,commission_pct,min_spend,contact_channel)
    VALUES($1,$2,$3,$4,$5,$6,$7)
    ON CONFLICT (id) DO UPDATE SET commission_pct=EXCLUDED.commission_pct`,
    [p.id,p.name,p.category,p.city,p.commissionPct,p.minSpend || 0, JSON.stringify({api:p.apiEndpoint})]);
}