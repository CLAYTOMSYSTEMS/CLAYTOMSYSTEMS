import Fastify from 'fastify';
import nacl from 'tweetnacl';
import { connect } from 'nats';
import crypto from 'crypto';

const app = Fastify({ logger:true });
const nc = await connect({ servers: process.env.NATS_URL });

const keys = {};
function gen(alias){
  const kp = nacl.sign.keyPair();
  keys[alias] = {
    public: Buffer.from(kp.publicKey).toString('base64'),
    secret: Buffer.from(kp.secretKey).toString('base64'),
    created: Date.now()
  };
}
if (!keys[process.env.ACTIVE_KEY_ALIAS]) gen(process.env.ACTIVE_KEY_ALIAS);

app.post('/sign', async (req, reply)=>{
  const { payload } = req.body || {};
  if (!payload) return reply.code(400).send({ error:'payload required' });
  const alias = process.env.ACTIVE_KEY_ALIAS;
  const key = keys[alias];
  const msg = Buffer.from(JSON.stringify(payload));
  const sig = nacl.sign.detached(msg, Buffer.from(key.secret,'base64'));
  const signature = Buffer.from(sig).toString('base64');
  nc.publish('policy.updated', Buffer.from(JSON.stringify({ alias, signature })));
  return { alias, signature };
});

app.post('/verify', async (req, reply)=>{
  const { payload, signature, alias } = req.body || {};
  if (!payload || !signature || !alias) return reply.code(400).send({ error:'missing fields' });
  const key = keys[alias];
  if (!key) return reply.code(404).send({ error:'alias not found' });
  const ok = nacl.sign.detached.verify(
    Buffer.from(JSON.stringify(payload)),
    Buffer.from(signature,'base64'),
    Buffer.from(key.public,'base64')
  );
  return { valid: ok };
});

app.post('/rotate', async (req, reply)=>{
  const { alias } = req.body || {};
  if (!alias) return reply.code(400).send({ error:'alias required' });
  gen(alias);
  return { ok:true, alias };
});

app.get('/jwks', async ()=>{
  return {
    keys: Object.entries(keys).map(([k,v])=>({
      kty:"OKP",
      crv:"Ed25519",
      kid:k,
      alg:"EdDSA",
      use:"sig",
      x: v.public
    }))
  };
});

app.get('/healthz', async ()=>({ ok:true, keys: Object.keys(keys) }));

app.listen({ port: process.env.PORT || 4300, host:'0.0.0.0' });