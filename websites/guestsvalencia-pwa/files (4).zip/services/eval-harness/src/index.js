import Fastify from 'fastify';
import { Pool } from 'pg';
import fetch from 'node-fetch';

const app = Fastify({ logger:true });
const pool = new Pool({ connectionString: process.env.PG_URL });

app.post('/run', async (req, reply)=>{
  const { dataset=[] } = req.body || {};
  const results = [];
  for (const item of dataset) {
    const messages = [
      { role:'system', content:item.system || 'Eres Sandra IA 7.0.' },
      { role:'user', content:item.prompt }
    ];
    const r = await fetch(process.env.LLM_GATEWAY_URL + '/generate',{
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ messages })
    }).then(r=>r.json());
    const answer = r.text || '';
    // naive score: containment of expected keywords
    const score = item.keywords ? item.keywords.filter(k=> answer.toLowerCase().includes(k.toLowerCase())).length / item.keywords.length : 0;
    results.push({ id:item.id, score, answer });
    await pool.query(`
      INSERT INTO eval_runs(id, prompt, answer, score, expected)
      VALUES(gen_random_uuid(), $1,$2,$3,$4)
    `,[item.prompt, answer, score, JSON.stringify(item.keywords || [])]);
  }
  return { count: results.length, results };
});

app.get('/healthz', async ()=>({ ok:true }));

app.listen({ port: process.env.PORT || 4190, host:'0.0.0.0' });