const DIET_MAP = [
  { tag:'vegan', regex:/\bvegano|vegan\b/i },
  { tag:'gluten_free', regex:/\b(sin gluten|gluten[- ]?free)\b/i },
  { tag:'vegetarian', regex:/\bvegetaria[no]\b/i },
  { tag:'halal', regex:/\bhalal\b/i }
];
const CUISINE_MAP = [
  { tag:'paella', regex:/\bpaella\b/i },
  { tag:'tapas', regex:/\btapas?\b/i },
  { tag:'italian', regex:/\bitalian|italiano\b/i },
  { tag:'sushi', regex:/\bsushi\b/i }
];

export function extractPreferences(freeText: string) {
  const diets = DIET_MAP.filter(d=>d.regex.test(freeText)).map(d=>d.tag);
  const cuisines = CUISINE_MAP.filter(c=>c.regex.test(freeText)).map(c=>c.tag);
  const dinnerTime = (/(\b(?:19|20|21):?([0-5]\d)?)/.exec(freeText)?.[0]) || null;
  return { diets, cuisines, dinnerTime };
}