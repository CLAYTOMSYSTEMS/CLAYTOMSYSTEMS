import express from 'express';
import { extractPreferences } from './preferenceExtractor';
import { Pool } from 'pg';
const pool = new Pool();
const app = express(); app.use(express.json());

app.post('/profile/update', async (req,res)=>{
  const { guestId, text } = req.body;
  const prefs = extractPreferences(text);
  await pool.query(`
    INSERT INTO preference_profile(guest_id,diet_tags,cuisine_likes,avg_dinner_time,last_updated)
    VALUES($1,$2,$3,$4,now())
    ON CONFLICT (guest_id) DO UPDATE SET diet_tags=EXCLUDED.diet_tags, cuisine_likes=EXCLUDED.cuisine_likes, avg_dinner_time=EXCLUDED.avg_dinner_time, last_updated=now()
  `,[guestId, prefs.diets, prefs.cuisines, prefs.dinnerTime]);
  res.json({ updated:true, prefs });
});
const port = process.env.PORT || 5305;
app.listen(port, ()=>console.log('[preferences] listening', port));