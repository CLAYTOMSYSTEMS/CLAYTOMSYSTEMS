import os, math, numpy as np
from fastapi import FastAPI
import psycopg

PG = os.getenv("PG_URL")
app = FastAPI(title="Pricing ML Advanced")

async def fetch_observations(conn, listing_id):
    async with conn.cursor() as cur:
        await cur.execute("""
            SELECT offered_price, booked::int
            FROM price_observations
            WHERE listing_id=%s
            ORDER BY created_at DESC
            LIMIT 400
        """,(listing_id,))
        rows = await cur.fetchall()
    return rows

async def fetch_competitors(conn, listing_id):
    async with conn.cursor() as cur:
        await cur.execute("""
            SELECT price FROM competitor_prices
            WHERE listing_id=%s
            ORDER BY observed_at DESC
            LIMIT 20
        """,(listing_id,))
        return [r[0] for r in await cur.fetchall()]

def bayes_elasticity(prices, booked_flags, prior_mean, prior_std):
    # Simple conjugate-like update approximating logistic trend:
    # Assumption: conversion ~ sigmoid(a + b*price), elasticity ~ -b*(price/conv)
    # We'll approximate b with linear log-odds regression (without full solver).
    if len(prices) < 8:
        return prior_mean, 0.2
    p = np.array(prices)
    y = np.array(booked_flags)
    # avoid extremes
    eps=1e-6
    # use normalized price
    pn = (p - p.mean())/ (p.std()+eps)
    # linear fit y ~ alpha + beta*pn
    beta = np.cov(pn, y)[0,1] / (pn.var()+eps)
    # Map beta to elasticity proxy
    elasticity = - beta * 0.3  # heuristic scale
    # Bayesian shrinkage
    post_var = 1/(1/prior_std**2 + len(pn))
    post_mean = post_var * (prior_mean/prior_std**2 + len(pn)*elasticity)
    return float(post_mean), float(math.sqrt(post_var))

def competitor_adjust(base_elast, base_price, comp_prices, weight):
    if not comp_prices:
        return base_elast
    avg_comp = sum(comp_prices)/len(comp_prices)
    diff = (avg_comp - base_price)/max(base_price,1)
    # If competitors higher -> we can raise price; elasticity effectively a bit lower
    return base_elast - weight * diff

@app.on_event("startup")
async def start():
    app.state.conn = await psycopg.AsyncConnection.connect(PG)
    await app.state.conn.set_autocommit(True)

@app.get("/elasticity/{listing_id}")
async def elasticity(listing_id: str, base_price: float=120):
    prior_mean = float(os.getenv("GLOBAL_ELASTICITY_PRIOR_MEAN","0.2"))
    prior_std = float(os.getenv("GLOBAL_ELASTICITY_PRIOR_STD","0.15"))
    comp_weight = float(os.getenv("COMPETITOR_WEIGHT","0.25"))

    obs = await fetch_observations(app.state.conn, listing_id)
    prices = [o[0] for o in obs]
    booked = [o[1] for o in obs]
    elast, elast_std = bayes_elasticity(prices, booked, prior_mean, prior_std)
    comps = await fetch_competitors(app.state.conn, listing_id)
    adjusted = competitor_adjust(elast, base_price, comps, comp_weight)

    # Price ladder suggestions
    ladder = [0.9, 1.0, 1.05, 1.1, 1.15]
    suggestions = []
    for f in ladder:
        # expected conversion proxy: sigmoid(-adjusted * (f-1)*5)
        conv = 1/(1+math.exp(adjusted * (f-1)*12))
        rev = base_price*f*conv
        suggestions.append({"factor":f, "expected_conversion":conv, "expected_revenue":rev})
    best = max(suggestions, key=lambda x: x["expected_revenue"])
    return {
        "listing_id": listing_id,
        "elasticity_mean": adjusted,
        "elasticity_std": elast_std,
        "base_price": base_price,
        "suggestions": suggestions,
        "best": best
    }

@app.get("/healthz")
async def health():
    return {"ok":True}