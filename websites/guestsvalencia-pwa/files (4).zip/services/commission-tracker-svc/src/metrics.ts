import client from 'prom-client';
export const registry = new client.Registry();
client.collectDefaultMetrics({ register: registry });

export const reservationCreationLatency = new client.Histogram({
  name:'reservation_create_latency_ms',
  help:'Latency broker create reservation',
  buckets:[50,100,150,200,300,500,800]
});
export const commissionAccruedTotal = new client.Counter({
  name:'commission_accrued_total',
  help:'Count of accrual events'
});
export const commissionAmountTotal = new client.Counter({
  name:'commission_amount_eur_total',
  help:'Sum commission amounts EUR'
});
export const tierDistribution = new client.Gauge({
  name:'guest_tier_current',
  help:'Gauge of guests per tier',
  labelNames:['tier']
});
registry.registerMetric(reservationCreationLatency);
registry.registerMetric(commissionAccruedTotal);
registry.registerMetric(commissionAmountTotal);
registry.registerMetric(tierDistribution);