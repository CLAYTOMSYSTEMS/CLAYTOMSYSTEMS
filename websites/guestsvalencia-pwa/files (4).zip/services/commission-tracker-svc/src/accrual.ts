import { Pool } from 'pg';
const pool = new Pool();

export async function recordAccrual(evt:{
  reservationId:string;
  partnerId:string;
  guestId:string;
  actualBill:number;
  commissionPct:number;
  currency?:string;
}) {
  const commissionAmount = evt.actualBill * evt.commissionPct;
  await pool.query(`
    INSERT INTO consumption_record(reservation_id,partner_id,guest_id,actual_bill,commission_amount,currency)
    VALUES($1,$2,$3,$4,$5,$6)
  `,[evt.reservationId, evt.partnerId, evt.guestId, evt.actualBill, commissionAmount, evt.currency||'EUR']);
  return { commissionAmount };
}