import { Pool } from 'pg';
import { v4 as uuid } from 'uuid';
const pool = new Pool();

export async function generateSettlement(partnerId: string, start: string, end: string) {
  const rows = await pool.query(`
    SELECT commission_amount, actual_bill, reservation_id
    FROM consumption_record
    WHERE partner_id=$1 AND closed_at >= $2 AND closed_at < $3
  `,[partnerId,start,end]);
  const gross = rows.rows.reduce((s,r)=>s + Number(r.actual_bill||0),0);
  const commission = rows.rows.reduce((s,r)=>s + Number(r.commission_amount||0),0);
  const settlementId = uuid();
  await pool.query(`
    INSERT INTO commission_settlement(id,partner_id,period_start,period_end,gross_total,commission_total,items,status)
    VALUES($1,$2,$3,$4,$5,$6,$7,'pending')
  `,[settlementId, partnerId, start, end, gross, commission, JSON.stringify(rows.rows.map(r=>r.reservation_id))]);
  return { settlementId, gross, commission };
}