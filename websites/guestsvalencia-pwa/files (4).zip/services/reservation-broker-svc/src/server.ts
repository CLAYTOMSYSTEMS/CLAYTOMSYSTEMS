import express from 'express';
import { createReservation } from './broker';
import { reservationCreationLatency } from '../../commission-tracker-svc/src/metrics'; // or shared metrics lib
const app = express(); app.use(express.json());

app.post('/reservations', async (req,res) => {
  const start = Date.now();
  const result = await createReservation(req.body);
  reservationCreationLatency.observe(Date.now()-start);
  res.json(result);
});
const port = process.env.PORT || 5205;
app.listen(port, ()=>console.log('[reservation-broker] listening', port));