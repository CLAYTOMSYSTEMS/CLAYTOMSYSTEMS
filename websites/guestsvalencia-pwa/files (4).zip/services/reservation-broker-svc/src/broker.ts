import { Pool } from 'pg';
import { v4 as uuid } from 'uuid';
const pool = new Pool();

export async function createReservation(input: {
  guestId: string;
  partnerId: string;
  tier: string;
  desiredTimeISO: string;
  partySize: number;
  notes?: string;
}) {
  const id = uuid();
  // Commission estimate (simple): partner.commission_pct * expected_bill heuristic
  const partner = await pool.query('SELECT commission_pct, min_spend FROM partner WHERE id=$1',[input.partnerId]);
  const commissionPct = partner.rows[0]?.commission_pct || 0.15;
  const baseEstimate = (partner.rows[0]?.min_spend || 50);
  const commissionEstimate = baseEstimate * commissionPct;

  await pool.query(`
    INSERT INTO reservation_request(id,guest_id,partner_id,tier,scheduled_for,status,party_size,notes,estimated_bill,commission_estimate)
    VALUES($1,$2,$3,$4,$5,'pending',$6,$7,$8,$9)
  `, [id, input.guestId, input.partnerId, input.tier, input.desiredTimeISO, input.partySize, input.notes || '', baseEstimate, commissionEstimate]);

  // TODO: call partner API / queue job -> partner.confirmation
  return { reservationId:id, status:'pending', commissionEstimate };
}