import Fastify from 'fastify';
import { Pool } from 'pg';
import fetch from 'node-fetch';

const app = Fastify({ logger:true });
const pool = new Pool({ connectionString: process.env.PG_URL });

app.get('/healthz', async ()=>({ ok:true }));

app.post('/intent', async (req, reply)=>{
  const { listingId, guestName, checkin, checkout } = req.body || {};
  if (!listingId || !checkin || !checkout) return reply.code(400).send({ error:'missing fields' });
  const client = await pool.connect();
  try {
    const listing = await client.query('SELECT * FROM listings WHERE id=$1',[listingId]);
    if (!listing.rowCount) return reply.code(404).send({ error:'listing not found' });
    const nights = (new Date(checkout)-new Date(checkin)) / 86400000;
    const total = nights * Number(listing.rows[0].base_price);
    const book = await client.query(`
      INSERT INTO bookings(listing_id, guest_name, checkin_date, checkout_date, total_price)
      VALUES($1,$2,$3,$4,$5) RETURNING id,total_price
    `,[listingId, guestName || 'Huésped', checkin, checkout, total]);
    return { bookingId: book.rows[0].id, total: book.rows[0].total_price };
  } finally { client.release(); }
});

app.post('/confirm', async (req, reply)=>{
  const { bookingId } = req.body || {};
  if (!bookingId) return reply.code(400).send({ error:'bookingId required' });
  const client = await pool.connect();
  try {
    await client.query('UPDATE bookings SET status=$2 WHERE id=$1',[bookingId,'confirmed']);
    const code = 'LK-' + Math.random().toString(36).slice(2,8).toUpperCase();
    await client.query('INSERT INTO lock_codes(booking_id, code) VALUES($1,$2)',[bookingId, code]);
    fetch(process.env.REVENUE_URL + '/event', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ event_type:'booking_confirmed', booking_id: bookingId, reward: 1.0 })
    }).catch(()=>{});
    return { status:'confirmed', lockCode: code };
  } finally { client.release(); }
});

app.listen({ port: process.env.PORT || 4110, host:'0.0.0.0' });