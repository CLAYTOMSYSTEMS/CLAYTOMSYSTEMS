// Añadir endpoint parcial
app.post('/timeline/partial', async (req,res)=>{
  const { tokens=[] } = req.body || {};
  // Mapear cada token a visema “predictiva”
  const timeline = tokens.map((tk,i)=>({
    symbol: visemeMap[(tk.length + i) % visemeMap.length],
    t: i*90
  }));
  return res.json({ timeline });
});