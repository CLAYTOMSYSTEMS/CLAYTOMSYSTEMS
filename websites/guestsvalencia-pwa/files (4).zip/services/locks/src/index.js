import Fastify from 'fastify';
import fetch from 'node-fetch';

const app = Fastify({ logger:true });

app.get('/healthz', async ()=>({ ok:true }));

app.post('/nuki/code', async (req, reply)=>{
  const { bookingId, lockId } = req.body || {};
  // Placeholder: real Nuki Bridge or Web API call
  const code = 'NK-' + Math.random().toString(36).slice(2,8).toUpperCase();
  // store mapping (TODO DB)
  return { lockId, code, bookingId };
});

app.post('/ttlock/code', async (req, reply)=>{
  const { bookingId, lockId, start, end } = req.body || {};
  const code = 'TT-' + Math.random().toString(36).slice(2,8).toUpperCase();
  return { lockId, code, valid_from:start, valid_to:end, bookingId };
});

app.listen({ port: process.env.PORT || 4130, host:'0.0.0.0' });