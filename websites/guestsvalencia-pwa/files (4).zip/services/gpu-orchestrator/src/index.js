import Fastify from 'fastify';
import { Queue, Worker } from 'bullmq';
import fetch from 'node-fetch';
import IORedis from 'ioredis';

const app = Fastify({ logger:true });
const connection = new IORedis(process.env.REDIS_URL);
const queue = new Queue('inference', { connection });

const MAX = parseInt(process.env.MAX_CONCURRENT || '2',10);

new Worker('inference', async job => {
  const { messages, model } = job.data;
  const res = await fetch(process.env.VLLM_ENDPOINT + '/v1/chat/completions',{
    method:'POST',
    headers:{ 'Content-Type':'application/json' },
    body: JSON.stringify({ model, messages, temperature:0.7 })
  }).then(r=>r.json());
  return res;
}, { connection, concurrency: MAX });

app.post('/enqueue', async (req, reply)=>{
  const { messages, model='local-mixtral', priority=5 } = req.body || {};
  if (!messages) return reply.code(400).send({ error:'messages required' });
  const job = await queue.add('chat', { messages, model }, { priority });
  return { jobId: job.id };
});

app.get('/result/:id', async (req, reply)=>{
  const job = await queue.getJob(req.params.id);
  if (!job) return reply.code(404).send({ error:'not found' });
  const st = await job.getState();
  const res = await job.returnvalue;
  return { state: st, result: res };
});

app.get('/healthz', async ()=>({ ok:true }));

app.listen({ port: process.env.PORT || 4170, host:'0.0.0.0' });