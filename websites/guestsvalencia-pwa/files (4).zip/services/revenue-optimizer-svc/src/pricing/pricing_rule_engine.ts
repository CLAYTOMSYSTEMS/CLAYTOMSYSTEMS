/**
 * Advanced Pricing Rule Engine
 * Supports stacked rules, scoring, fallback curves, and dynamic factor overrides.
 */
export interface PricingContext {
  propertyId: string;
  baseRate: number;
  demandIndex: number;        // 0..2
  occupancyPct: number;       // 0..1
  leadDays: number;
  eventScore: number;         // 0..1
  competitorDelta: number;    // -0.3..0.3 (positive=we are cheaper)
  sentimentDrift: number;     // -0.1..0.1
  pacingVariance: number;     // -0.4..0.4 (negative=behind pace)
  minStayRestriction?: number;
  historicalADR?: number;
  currency?: string;
  now?: Date;
}

export interface PriceRule {
  id: string;
  description: string;
  weight: number; // aggregated influence
  apply(ctx: PricingContext): PricePartial;
}

export interface PricePartial {
  ruleId: string;
  factor: number;        // multiplicative
  rationale: string;
  confidence: number;    // 0..1
  cap?: { min?: number; max?: number };
}

export interface PricingDecision {
  propertyId: string;
  newPrice: number;
  floorApplied?: boolean;
  ceilingApplied?: boolean;
  partials: PricePartial[];
  finalFactor: number;
  finalConfidence: number;
  rationaleSummary: string;
  timestamp: string;
}

const clamp = (v:number,min:number,max:number)=>Math.min(Math.max(v,min),max);

export class PricingRuleEngine {
  private rules: PriceRule[] = [];
  private floorPct = 0.6;
  private ceilingPct = 1.9;

  register(rule: PriceRule) { this.rules.push(rule); }
  setGlobalBounds(floorPct:number, ceilingPct:number){
    this.floorPct = floorPct; this.ceilingPct = ceilingPct;
  }

  compute(ctx: PricingContext, previousPrice?: number): PricingDecision {
    const partials = this.rules.map(r => r.apply(ctx));
    // Weighted geometric-ish composition
    let aggFactor = 1;
    let totalWeight = 0;
    let weightedConfidence = 0;
    for (const p of partials) {
      const w = this.rules.find(r=>r.id===p.ruleId)?.weight || 1;
      totalWeight += w;
      aggFactor *= Math.pow(p.factor, w / 5); // compress influence
      weightedConfidence += p.confidence * w;
    }
    const finalConfidence = weightedConfidence / (totalWeight || 1);

    // Smooth vs previous
    let raw = ctx.baseRate * aggFactor;
    if (previousPrice) {
      const delta = Math.abs(raw - previousPrice);
      if (delta < ctx.baseRate * 0.04) raw = 0.65*previousPrice + 0.35*raw;
    }

    const floor = ctx.baseRate * this.floorPct;
    const ceiling = ctx.baseRate * this.ceilingPct;
    const bounded = clamp(raw, floor, ceiling);

    return {
      propertyId: ctx.propertyId,
      newPrice: Math.round(bounded),
      floorApplied: bounded === floor,
      ceilingApplied: bounded === ceiling,
      partials,
      finalFactor: aggFactor,
      finalConfidence,
      rationaleSummary: summarizePartials(partials),
      timestamp: new Date().toISOString()
    };
  }
}

function summarizePartials(parts: PricePartial[]) {
  return parts
    .sort((a,b)=>b.confidence - a.confidence)
    .slice(0,5)
    .map(p=>`${p.ruleId}:${(p.factor).toFixed(2)}`)
    .join(' | ');
}

/* SAMPLE RULES */
export const demandRule: PriceRule = {
  id: 'DEMAND',
  description: 'Scale by demand index',
  weight: 3,
  apply(ctx) {
    const factor = 0.9 + (Math.min(ctx.demandIndex,2)/2)*0.3; // 0.9 .. 1.2
    return { ruleId:'DEMAND', factor, rationale:`demandIndex=${ctx.demandIndex}`, confidence:0.85 };
  }
};

export const occupancyRule: PriceRule = {
  id: 'OCCUPANCY',
  description: 'Adjust for current occupancy & leadDays interplay',
  weight: 2,
  apply(ctx) {
    let factor = 1;
    if (ctx.occupancyPct < 0.35 && ctx.leadDays < 20) factor -= 0.05;
    if (ctx.occupancyPct > 0.8 && ctx.leadDays > 7) factor += 0.08;
    return { ruleId:'OCCUPANCY', factor, rationale:`occ=${ctx.occupancyPct}`, confidence:0.8 };
  }
};

export const eventRule: PriceRule = {
  id: 'EVENT',
  description: 'Boost during event periods',
  weight: 2,
  apply(ctx) {
    const factor = 1 + ctx.eventScore * 0.18;
    return { ruleId:'EVENT', factor, rationale:`eventScore=${ctx.eventScore}`, confidence:0.75 };
  }
};

export const competitorRule: PriceRule = {
  id: 'COMP',
  description: 'Adjust vs competitor delta',
  weight: 1.5,
  apply(ctx) {
    const factor = 1 + clamp(ctx.competitorDelta, -0.2, 0.2) * 0.5;
    return { ruleId:'COMP', factor, rationale:`competitorDelta=${ctx.competitorDelta}`, confidence:0.7 };
  }
};

export const pacingRule: PriceRule = {
  id: 'PACING',
  description: 'If behind pace, discount; ahead pace, premium',
  weight: 1.5,
  apply(ctx) {
    const adj = clamp(ctx.pacingVariance, -0.3, 0.3);
    let factor = 1;
    if (adj < 0) factor += adj * 0.4; // discount
    if (adj > 0) factor += adj * 0.3; // premium
    return { ruleId:'PACING', factor, rationale:`paceVar=${ctx.pacingVariance}`, confidence:0.65 };
  }
};

export const sentimentRule: PriceRule = {
  id: 'SENTIMENT',
  description: 'Small adjustment based on guest sentiment drift',
  weight: 1,
  apply(ctx) {
    const factor = 1 + ctx.sentimentDrift * 0.2; // -2%..+2% typical
    return { ruleId:'SENTIMENT', factor, rationale:`sentimentDrift=${ctx.sentimentDrift}`, confidence:0.55 };
  }
};

/* Factory */
export function buildDefaultEngine() {
  const engine = new PricingRuleEngine();
  engine.register(demandRule);
  engine.register(occupancyRule);
  engine.register(eventRule);
  engine.register(competitorRule);
  engine.register(pacingRule);
  engine.register(sentimentRule);
  return engine;
}