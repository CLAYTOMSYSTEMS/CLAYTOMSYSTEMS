interface Factors {
  demandIndex: number;      // 0..2 normalized
  occupancyPct: number;     // 0..1
  leadDays: number;
  eventScore: number;       // 0..1
  sentimentDrift: number;   // -0.1..0.1
  competitorDelta: number;  // -0.2..0.2 (positive = we are cheaper)
}

export function computeDynamicPrice(base: number, f: Factors, prevPrice?: number) {
  const demandFactor = 0.9 + (Math.min(f.demandIndex,2) / 2) * 0.25;       // 0.9..1.125
  const occFactor = occupancyFactor(f.occupancyPct, f.leadDays);
  const leadFactor = leadTimeFactor(f.leadDays);
  const eventFactor = 1 + f.eventScore * 0.15;
  const competitorFactor = 1 + clamp(f.competitorDelta, -0.15, 0.15);
  const sentimentFactor = 1 + clamp(f.sentimentDrift, -0.05, 0.05);

  let raw = base * demandFactor * occFactor * leadFactor * eventFactor * competitorFactor * sentimentFactor;

  if (prevPrice && Math.abs(raw - prevPrice) < base * 0.03) {
    raw = 0.7*prevPrice + 0.3*raw; // smoothing
  }
  return clamp(raw, base*0.6, base*1.8);
}

function occupancyFactor(occ: number, lead: number) {
  if (occ < 0.4 && lead < 15) return 0.95;
  if (occ > 0.8 && lead > 7) return 1.08;
  return 1.0;
}

function leadTimeFactor(lead: number) {
  if (lead > 90) return 0.95;
  if (lead > 30) return 1.0;
  if (lead > 14) return 1.05;
  if (lead > 7) return 1.08;
  return 1.12;
}

function clamp(v:number, min:number, max:number){ return Math.min(Math.max(v,min), max); }