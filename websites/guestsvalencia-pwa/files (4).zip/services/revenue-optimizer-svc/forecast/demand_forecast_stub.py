"""
Time-series demand forecast stub (daily horizon).
Replace with Prophet / NeuralProphet / LightGBM hybrid later.
"""
import math, random, datetime as dt
from typing import List, Dict

def generate_features(day: dt.date):
    dow = day.weekday()
    seasonal = 1 + 0.15*math.sin(2*math.pi*(day.timetuple().tm_yday)/365)
    weekend_boost = 1.1 if dow in (4,5) else 1.0
    return seasonal * weekend_boost

def forecast_demand(start: dt.date, days:int=30) -> List[Dict]:
    out = []
    base = 100
    for i in range(days):
        day = start + dt.timedelta(days=i)
        features = generate_features(day)
        noise = random.uniform(-0.05,0.05)
        demand_index = (base * features * (1+noise))/100  # normalized around 1
        out.append({
            "date": day.isoformat(),
            "demand_index": round(demand_index,3),
            "confidence": 0.65
        })
    return out

if __name__ == "__main__":
    today = dt.date.today()
    print(forecast_demand(today, 14))