import fs from 'fs';
import Ajv from 'ajv';

const registry = JSON.parse(fs.readFileSync('/app/src/../tools.json','utf-8'));
const ajv = new Ajv();
const validators = {};
registry.tools.forEach(t=> validators[t.name] = ajv.compile(t.schema));

app.post('/call', async (req, reply)=>{
  const { name, args={} } = req.body || {};
  const def = registry.tools.find(t=>t.name===name);
  if (!def) return reply.code(404).send({ error:'tool not found' });
  const valid = validators[name](args);
  if (!valid) return reply.code(400).send({ error:'invalid args', details: validators[name].errors });
  ...
});