import { proxyActivities } from '@temporalio/workflow';
const { fetchFeatures, computePrice, pushChannelUpdate, recordDecision } = proxyActivities<{
  fetchFeatures(args:any):Promise<any>;
  computePrice(args:any):Promise<{ newPrice:number; confidence:number }>;
  pushChannelUpdate(args:any):Promise<boolean>;
  recordDecision(args:any):Promise<void>;
}>({ startToCloseTimeout: '2 minutes' });

export async function pricingAdjustmentWorkflow(input: { propertyId: string; baseRate: number }) {
  const features = await fetchFeatures(input);
  const result = await computePrice({ ...input, features });
  const ok = await pushChannelUpdate({ propertyId: input.propertyId, newPrice: result.newPrice });
  await recordDecision({ propertyId: input.propertyId, newPrice: result.newPrice, confidence: result.confidence, applied: ok });
  return { applied: ok, price: result.newPrice };
}