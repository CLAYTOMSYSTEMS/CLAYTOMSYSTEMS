import { proxyActivities } from '@temporalio/workflow';
const { generateTopics, writeScript, selectWardrobe, renderVideo, schedulePost } = proxyActivities<{
  generateTopics(args:any):Promise<any[]>;
  writeScript(args:any):Promise<any>;
  selectWardrobe(args:any):Promise<any>;
  renderVideo(args:any):Promise<any>;
  schedulePost(args:any):Promise<void>;
}>({ startToCloseTimeout:'15 minutes' });

export async function contentDailyWorkflow(input: { dateISO: string; slots: string[] }) {
  const topics = await generateTopics({ date: input.dateISO });
  for (const slot of input.slots) {
    const topic = topics.shift();
    if (!topic) break;
    const script = await writeScript({ topic, slot });
    const style = await selectWardrobe({ topicCategory: topic.category, slot });
    const render = await renderVideo({ scriptId: script.id, wardrobe: style.code, slot });
    await schedulePost({ renderId: render.id, slot });
  }
  return { done:true };
}