const MAP: Record<string,string> = {
  'AA':'open_wide','AE':'open_mid','AH':'open_small','AO':'o_round',
  'B':'closed','CH':'affricate','D':'tongue_front','EH':'open_mid2',
  'F':'teeth','G':'throat','IY':'smile_wide','K':'throat','L':'tongue_front2',
  'M':'closed','N':'tongue_front3','OW':'o_round2','P':'closed','R':'rounded',
  'S':'sibilant','SH':'sibilant2','T':'tongue_front','TH':'tongue_teeth',
  'UH':'pucker','UW':'pucker2','V':'teeth2','W':'pucker3','Y':'smile_mid',
  'Z':'sibilant3'
};

export interface PhonemeTiming { t_ms:number; phoneme:string; }
export interface VisemeTiming { t_ms:number; viseme:string; intensity:number; }

export function mapPhonemes(list: PhonemeTiming[]): VisemeTiming[] {
  return list.map(p => ({
    t_ms: p.t_ms,
    viseme: MAP[p.phoneme.toUpperCase()] || 'neutral',
    intensity: 1
  }));
}