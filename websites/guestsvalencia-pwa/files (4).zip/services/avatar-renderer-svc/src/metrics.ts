import client from 'prom-client';
export const avatarRegistry = new client.Registry();
client.collectDefaultMetrics({ register: avatarRegistry });

export const frameRenderTime = new client.Histogram({
  name:'avatar_frame_render_time_ms',
  help:'Per-frame render time',
  buckets:[5,8,12,16,20,25,33,40,50]
});
export const encodeLatency = new client.Histogram({
  name:'avatar_encode_latency_ms',
  help:'Encoding pipeline latency',
  buckets:[5,10,15,20,30,40,60,80,120]
});
export const lipsyncOffset = new client.Histogram({
  name:'avatar_lipsync_offset_ms',
  help:'Audio vs viseme schedule offset',
  buckets:[0,10,20,30,40,50,60,80,100]
});
export const wardrobeSwapTime = new client.Histogram({
  name:'avatar_wardrobe_swap_ms',
  help:'Time to apply wardrobe style',
  buckets:[100,250,400,600,800,1000,1500]
});

[frameRenderTime, encodeLatency, lipsyncOffset, wardrobeSwapTime].forEach(m => avatarRegistry.registerMetric(m));