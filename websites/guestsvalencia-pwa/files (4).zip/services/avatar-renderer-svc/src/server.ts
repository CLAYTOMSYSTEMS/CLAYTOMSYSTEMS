import express from 'express';
import { spawn } from 'child_process';
import { wardrobeChange, environmentChange } from './switchers';
import { createWebRTCSession } from './webrtcSession';

const app = express();
app.use(express.json());

// Create WebRTC publishing session (SFU expects inbound)
app.post('/session/start', async (req,res) => {
  const { quality='4k', wardrobeStyle='suit_navy_modern', environment='modern_executive_crypto_screens' } = req.body;
  const session = await createWebRTCSession({ quality });
  // schedule initial wardrobe/env
  await wardrobeChange(session.id, wardrobeStyle);
  await environmentChange(session.id, environment);
  res.json({ sessionId: session.id, offer: session.offer });
});

// Apply wardrobe in real-time
app.post('/session/:id/wardrobe', async (req,res) => {
  const ok = await wardrobeChange(req.params.id, req.body.style);
  res.json({ ok });
});

// Apply environment switch
app.post('/session/:id/environment', async (req,res) => {
  const ok = await environmentChange(req.params.id, req.body.environment);
  res.json({ ok });
});

// Inject timeline (phoneme→viseme)
app.post('/session/:id/visemes', async (req,res) => {
  // store or push via websocket to engine plugin
  // body: [{ t_ms, phoneme }]
  res.json({ accepted:true });
});

const port = process.env.PORT || 7700;
app.listen(port, ()=>console.log('[avatar-renderer] listening on', port));