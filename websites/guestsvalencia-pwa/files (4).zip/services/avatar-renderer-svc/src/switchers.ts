export async function wardrobeChange(sessionId: string, style: string) {
  // send control message to Unreal plugin / gRPC sidecar
  // Could push to Redis pubsub channel 'avatar:sessionId:wardrobe'
  return true;
}
export async function environmentChange(sessionId: string, env: string) {
  return true;
}