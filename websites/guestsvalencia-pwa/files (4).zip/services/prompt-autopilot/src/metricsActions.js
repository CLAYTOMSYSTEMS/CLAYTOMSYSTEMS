import client from 'prom-client';
import { register } from './metrics.js';
export const actionsCounter = new client.Counter({ name:'autopilot_actions_total', help:'Autopilot actions', labelNames:['action'] });
register.registerMetric(actionsCounter);