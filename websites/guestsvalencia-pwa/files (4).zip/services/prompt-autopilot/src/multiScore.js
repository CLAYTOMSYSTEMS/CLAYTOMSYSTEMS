import { Pool } from 'pg';
import { WEIGHTS, MIN_RUNS, COOLDOWN_MINUTES, CONFIDENCE_THRESHOLD } from './config.js';
import fetch from 'node-fetch';
import crypto from 'crypto';

const pool = new Pool({ connectionString: process.env.PG_URL });

async function recentRuns(experiment){
  const r = await pool.query(`
    SELECT avg_score, created_at, raw
    FROM prompt_autopilot_runs
    WHERE experiment=$1
    ORDER BY created_at DESC
    LIMIT 12
  `,[experiment]);
  return r.rows;
}

async function guardrailsRisk(){
  try {
    const stats = await fetch(process.env.ANOMALY_API || 'http://guardrails-v2:4260/stats').then(r=>r.json());
    const last = stats.series?.slice(-1)[0];
    if (!last) return 0;
    const blockRate = last.blocked / Math.max(last.total,1);
    // Map blockRate 0→0; 0.3→1
    return Math.min(1, blockRate / 0.3);
  } catch { return 0; }
}

async function latencyPenalty(){
  try {
    const p95 = await fetch(process.env.PROM_LAT_API || 'http://prometheus:9090/api/v1/query?query='
      + encodeURIComponent('histogram_quantile(0.95, sum(rate(llm_gateway_latency_seconds_bucket[5m])) by (le))'))
      .then(r=>r.json());
    const val = parseFloat(p95.data?.result?.[0]?.value?.[1] || '1');
    return Math.min(1, Math.max(0, (val - 2) / 5)); // 2s ideal, 7s = 1 penalty
  } catch { return 0; }
}

async function costPenalty(){
  // Placeholder: query cost metric if exists; fallback static
  return 0.2;
}

function qualityScore(latestAvg){
  // treat as normalized 0..1 by dividing by plausible max (keywords coverage)
  return Math.min(1, latestAvg);
}

function conversionScore(runs){
  if (!runs.length) return 0;
  // use average of last 3 vs previous 3
  const recent = runs.slice(0,3).map(r=> Number(r.avg_score));
  const prior = runs.slice(3,6).map(r=> Number(r.avg_score));
  if (recent.length < 3 || prior.length < 3) return 0.5;
  const recentAvg = recent.reduce((a,b)=>a+b,0)/recent.length;
  const priorAvg = prior.reduce((a,b)=>a+b,0)/prior.length;
  if (priorAvg === 0) return 0.6;
  const lift = (recentAvg - priorAvg) / Math.abs(priorAvg);
  // map lift (-0.5 .. +0.5) to (0..1)
  return Math.max(0, Math.min(1, 0.5 + lift));
}

function composite(scores){
  const raw = scores.conv*WEIGHTS.conv +
              scores.quality*WEIGHTS.quality +
              scores.guard*WEIGHTS.guard +
              scores.latency*WEIGHTS.latency +
              scores.cost*WEIGHTS.cost;
  // Normalize to 0..1 sigmoid
  const norm = 1/(1+Math.exp(-raw));
  return { raw, norm };
}

async function lastActionTime(experiment){
  const r = await pool.query(`
    SELECT created_at FROM prompt_autopilot_decisions
    WHERE experiment=$1 ORDER BY created_at DESC LIMIT 1
  `,[experiment]);
  if (!r.rowCount) return null;
  return new Date(r.rows[0].created_at);
}

export async function guardedMultiDecision(experiment, latestAvg){
  const runs = await recentRuns(experiment);
  const guard = await guardrailsRisk();
  const lat = await latencyPenalty();
  const cost = await costPenalty();
  const scores = {
    conv: conversionScore(runs),
    quality: qualityScore(latestAvg),
    guard,
    latency: lat,
    cost
  };
  const compositeScore = composite(scores);
  const enoughRuns = runs.length >= MIN_RUNS;
  const cooldownOk = await (async ()=>{
    const last = await lastActionTime(experiment);
    if (!last) return true;
    const mins = (Date.now() - last.getTime())/60000;
    return mins >= COOLDOWN_MINUTES;
  })();

  let action = 'hold';
  let reason = 'stable';
  if (enoughRuns && cooldownOk) {
    if (scores.guard > 0.6) {
      action = 'rollback';
      reason = 'guardrails_risk_high';
    } else if (compositeScore.norm > 0.7 && scores.conv > 0.55 && scores.guard < 0.3) {
      action = 'promote';
      reason = 'composite_positive';
    } else if (compositeScore.norm < 0.35) {
      action = 'rollback';
      reason = 'low_composite';
    }
  }

  const confidence = 1 - (scores.guard*0.4 + scores.latency*0.3);
  if (confidence < CONFIDENCE_THRESHOLD) {
    action = 'hold';
    reason = 'low_confidence';
  }

  const payload = { experiment, action, reason, composite: compositeScore, scores, confidence };
  const sig = crypto.createHmac('sha256', process.env.SIGN_SECRET || 'dev').update(JSON.stringify(payload)).digest('hex');
  return { ...payload, signature: sig, dryRun: process.env.DRY_RUN==='true' };
}