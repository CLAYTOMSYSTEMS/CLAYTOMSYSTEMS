import crypto from 'crypto';
export function signPayload(obj, secret){
  return crypto.createHmac('sha256', secret).update(JSON.stringify(obj)).digest('hex');
}