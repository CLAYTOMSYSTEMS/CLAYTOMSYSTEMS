import Fastify from 'fastify';
import fetch from 'node-fetch';
import { Pool } from 'pg';
import { CronJob } from 'cron';

const app = Fastify({ logger:true });
const pool = new Pool({ connectionString: process.env.PG_URL });

async function evaluateExperiment(experiment='base-system'){
  // fetch two variants (simulate A/B)
  // In future: fetch variant IDs from prompt-lab; here stub prompt texts
  const dataset = [
    { id:'d1', prompt:'Describe ventajas de reservar ahora', keywords:['reservar']},
    { id:'d2', prompt:'Explica beneficios estancia prolongada', keywords:['beneficios']}
  ];
  const res = await fetch(process.env.EVAL_URL + '/run',{
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ dataset })
  }).then(r=>r.json()).catch(()=>({ results:[] }));

  const avgScore = res.results.reduce((a,b)=>a+b.score,0)/(res.results.length||1);
  await pool.query(`
    INSERT INTO prompt_autopilot_runs(experiment,avg_score,raw)
    VALUES($1,$2,$3)
  `,[experiment, avgScore, JSON.stringify(res.results)]);

  // Fetch last 3 runs for trend
  const trend = await pool.query(`
    SELECT avg_score FROM prompt_autopilot_runs
    WHERE experiment=$1 ORDER BY created_at DESC LIMIT 3
  `,[experiment]);
  if (trend.rows.length === 3) {
    const delta = trend.rows[0].avg_score - trend.rows[2].avg_score;
    if (delta < parseFloat(process.env.ROLLBACK_THRESHOLD || '-0.2')) {
      app.log.warn({ delta },'Rollback suggested');
      if (process.env.DRY_RUN === 'false') {
        // call prompt-lab rollback endpoint (to implement)
      }
    }
  }
  return { avgScore };
}

new CronJob('*/5 * * * * *', ()=> {
  evaluateExperiment().catch(e=> app.log.error(e,'autopilot eval failed'));
}, null, true);

app.get('/healthz', async ()=>({ ok:true }));
app.post('/run-now', async (req, reply)=>{
  const r = await evaluateExperiment();
  return r;
});

app.listen({ port: process.env.PORT || 4250, host:'0.0.0.0' });