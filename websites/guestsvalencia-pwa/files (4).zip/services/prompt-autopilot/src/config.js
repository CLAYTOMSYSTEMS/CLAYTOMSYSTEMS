export const WEIGHTS = {
  conv: parseFloat(process.env.W_CONV || '0.35'),
  quality: parseFloat(process.env.W_QUALITY || '0.25'),
  guard: parseFloat(process.env.W_GUARD || '-0.25'),
  latency: parseFloat(process.env.W_LATENCY || '-0.10'),
  cost: parseFloat(process.env.W_COST || '-0.05')
};
export const MIN_RUNS = parseInt(process.env.MIN_RUNS_FOR_ACTION || '5',10);
export const COOLDOWN_MINUTES = parseInt(process.env.ACTION_COOLDOWN_MINUTES || '30',10);
export const CONFIDENCE_THRESHOLD = parseFloat(process.env.CONFIDENCE_THRESHOLD || '0.6');