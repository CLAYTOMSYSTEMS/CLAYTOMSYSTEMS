import fetch from 'node-fetch';
import { signPayload } from './sign.js';
import { Pool } from 'pg';
const pool = new Pool({ connectionString: process.env.PG_URL });

export async function guardAwareDecision(experiment, latestAvg){
  // Guardrails anomaly check
  let anomalyRate = 0;
  try {
    const stats = await fetch(process.env.ANOMALY_API).then(r=>r.json());
    // Simple: count last minute blocked ratio
    const last = stats.series?.slice(-1)[0];
    if (last) {
      anomalyRate = (last.blocked || 0) / (last.total || 1);
    }
  } catch {}
  // Fetch previous run
  const prev = await pool.query(`
    SELECT avg_score FROM prompt_autopilot_runs
    WHERE experiment=$1 ORDER BY created_at DESC OFFSET 1 LIMIT 1
  `,[experiment]);
  const before = prev.rowCount ? Number(prev.rows[0].avg_score) : latestAvg;
  const delta = latestAvg - before;
  let action = 'hold';
  let reason = 'stable';
  if (delta < parseFloat(process.env.ROLLBACK_THRESHOLD||'-0.2') || anomalyRate > 0.25) {
    action = 'rollback';
    reason = delta < 0 ? 'score_drop' : 'anomaly_block_rate';
  } else if (delta > parseFloat(process.env.PROMOTE_THRESHOLD||'0.05') && anomalyRate < 0.1) {
    action = 'promote';
    reason = 'improved_score';
  }
  const record = { experiment, action, reason, score_before: before, score_after: latestAvg, anomalyRate };
  let signature=null;
  if (action !== 'hold') {
    signature = signPayload(record, process.env.SIGN_SECRET || 'dev');
  }
  await pool.query(`
    INSERT INTO prompt_autopilot_decisions(experiment,variant,action,reason,score_before,score_after,anomaly_context, signed, signature)
    VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)
  `,[experiment,'A',action,reason,before,latestAvg, JSON.stringify({ anomalyRate }), !!signature, signature]);
  return { ...record, signature, dryRun: process.env.DRY_RUN==='true' };
}