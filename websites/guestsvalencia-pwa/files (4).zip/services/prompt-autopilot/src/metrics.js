import client from 'prom-client';
export const register = new client.Registry();
client.collectDefaultMetrics({ register });
export const compositeGauge = new client.Gauge({ name:'autopilot_composite_score', help:'Composite normalized score'});
export const guardRiskGauge = new client.Gauge({ name:'autopilot_guardrails_risk', help:'Guardrails risk factor'});
register.registerMetric(compositeGauge);
register.registerMetric(guardRiskGauge);