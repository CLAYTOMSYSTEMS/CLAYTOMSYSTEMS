from .extended import seasonal_adjust

@app.get("/forecast/extended")
async def forecast_ext():
    base = await forecast()
    if base["history"] is None:
        return base
    adjusted, scale = seasonal_adjust(base["history"])
    return { **base, "adjusted_history": adjusted, "scale_factor": scale }