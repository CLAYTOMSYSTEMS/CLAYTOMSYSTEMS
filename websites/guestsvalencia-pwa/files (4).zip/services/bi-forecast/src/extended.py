import numpy as np, math, datetime

def seasonal_adjust(series):
    if len(series) < 24:
        return series, 1.0
    day_slice = series[-24:]
    scale = (np.mean(day_slice) + 0.01) / (np.mean(series) + 0.01)
    adjusted = [v*scale for v in series]
    return adjusted, scale