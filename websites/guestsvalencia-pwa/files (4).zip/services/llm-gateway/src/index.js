import { register } from './metrics.js';
app.get('/metrics', async (_,reply)=>{
  reply.header('Content-Type', register.contentType);
  reply.send(await register.metrics());
});