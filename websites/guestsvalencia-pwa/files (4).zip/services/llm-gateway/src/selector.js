import { llmLatency, llmErrors } from './metrics.js';
// dentro de loop provider:
const start = Date.now();
...
const dur = (Date.now()-start)/1000;
llmLatency.labels(p).observe(dur);
...
catch(e){ llmErrors.labels(p).inc(); ... }