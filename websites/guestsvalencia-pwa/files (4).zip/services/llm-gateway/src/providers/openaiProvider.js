import fetch from 'node-fetch';

export async function openaiChat({ messages, model="gpt-4o" }) {
  const res = await fetch('https://api.openai.com/v1/chat/completions',{
    method:'POST',
    headers:{
      'Content-Type':'application/json',
      'Authorization':'Bearer '+process.env.OPENAI_API_KEY
    },
    body: JSON.stringify({
      model, messages, temperature:0.7
    })
  });
  const json = await res.json();
  if (json.error) throw new Error(json.error.message);
  return {
    text: json.choices[0].message.content,
    usage: json.usage,
    provider:'openai', model
  };
}

export async function openaiStream({ messages, model="gpt-4o" }) {
  const res = await fetch('https://api.openai.com/v1/chat/completions',{
    method:'POST',
    headers:{
      'Content-Type':'application/json',
      'Authorization':'Bearer '+process.env.OPENAI_API_KEY
    },
    body: JSON.stringify({
      model, messages, temperature:0.7, stream:true
    })
  });
  if (!res.ok) {
    let err = await res.text();
    throw new Error('OpenAI stream error: '+err);
  }
  return res.body;
}