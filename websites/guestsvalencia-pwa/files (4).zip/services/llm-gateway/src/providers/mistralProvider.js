import fetch from 'node-fetch';

export async function mistralChat({ messages, model=process.env.MISTRAL_MODEL || "mistral-large-latest" }) {
  const res = await fetch('https://api.mistral.ai/v1/chat/completions',{
    method:'POST',
    headers:{
      'Content-Type':'application/json',
      'Authorization':'Bearer '+process.env.MISTRAL_API_KEY
    },
    body: JSON.stringify({ model, messages, temperature:0.7 })
  });
  const json = await res.json();
  if (json.error) throw new Error(json.error.message);
  return { text: json.choices[0].message.content, provider:'mistral', model };
}