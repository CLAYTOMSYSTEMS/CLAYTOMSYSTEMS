import fetch from 'node-fetch';

export async function localChat({ messages, model="local-mixtral" }) {
  const res = await fetch(process.env.LOCAL_LLM_URL + '/v1/chat/completions',{
    method:'POST',
    headers:{ 'Content-Type':'application/json' },
    body: JSON.stringify({ model, messages, temperature:0.8 })
  });
  const json = await res.json();
  if (json.error) throw new Error(json.error.message);
  return { text: json.choices[0].message.content, provider:'local', model };
}