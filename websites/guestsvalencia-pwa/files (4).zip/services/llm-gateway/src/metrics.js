import client from 'prom-client';
export const register = new client.Registry();
client.collectDefaultMetrics({ register });

export const llmLatency = new client.Histogram({
  name: 'llm_gateway_latency_seconds',
  help: 'Latencia por proveedor',
  labelNames: ['provider']
});
export const llmErrors = new client.Counter({
  name: 'llm_gateway_errors_total',
  help: 'Errores por proveedor',
  labelNames: ['provider']
});
register.registerMetric(llmLatency);
register.registerMetric(llmErrors);