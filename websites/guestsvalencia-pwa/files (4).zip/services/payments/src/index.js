import Fastify from 'fastify';
import Stripe from 'stripe';
import fetch from 'node-fetch';

const app = Fastify({ logger:true });
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion:"2023-10-16" });

app.get('/healthz', async ()=>({ ok:true }));

app.post('/checkout/session', async (req, reply)=>{
  const { lineItems=[{ price_data:{ currency: process.env.CURRENCY || 'EUR', product_data:{ name:'Reserva' }, unit_amount: 5000 }, quantity:1 }], mode="payment", successUrl, cancelUrl, metadata={} } = req.body || {};
  const session = await stripe.checkout.sessions.create({
    mode,
    line_items: lineItems,
    success_url: successUrl || 'https://example.com/success',
    cancel_url: cancelUrl || 'https://example.com/cancel',
    metadata
  });
  return { id: session.id, url: session.url };
});

app.post('/webhook', async (req, reply)=>{
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(await req.rawBody, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch(e){
    app.log.error(e);
    return reply.code(400).send({ error:'invalid signature' });
  }
  if (event.type === 'checkout.session.completed') {
    fetch(process.env.REVENUE_URL + '/event', {
      method:'POST', headers:{ 'Content-Type':'application/json' },
      body: JSON.stringify({ event_type:'payment', reward:1.5, payload:{ session_id: event.data.object.id } })
    }).catch(()=>{});
  }
  return { received:true };
});

// Raw body hook
app.addHook('onRequest',(req,res,done)=>{
  if (req.routerPath === '/webhook') {
    let data=''; req.raw.on('data',c=> data+=c); req.raw.on('end',()=>{ req.rawBody = data; done(); });
  } else done();
});

app.listen({ port: process.env.PORT || 4120, host:'0.0.0.0' });