import re, math, time

SUSPICIOUS_PATTERNS = [
  (re.compile(r'(sql\s+injection|union\s+select)', re.I), 0.9),
  (re.compile(r'(drop\s+table)', re.I), 0.85),
  (re.compile(r'(0x[0-9a-f]{6,})', re.I), 0.6)
]

def score(text: str):
  base = 0.1
  for rgx, w in SUSPICIOUS_PATTERNS:
    if rgx.search(text):
      base += w
  return min(base, 1.0)

if __name__ == "__main__":
  sample = "test union select credit card"
  print(score(sample))