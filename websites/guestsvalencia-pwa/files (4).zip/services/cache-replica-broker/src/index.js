import Fastify from 'fastify';
import { connect } from 'nats';

const app = Fastify({ logger:true });
const nc = await connect({ servers: process.env.NATS_URL });
const nodes = new Map(); // nodeId -> { region, lastSeen, stats }

app.post('/heartbeat', async (req, reply)=>{
  const { nodeId, region, hits=0, misses=0 } = req.body || {};
  if (!nodeId) return reply.code(400).send({ error:'nodeId required' });
  nodes.set(nodeId,{ region, lastSeen: Date.now(), hits, misses });
  return { ok:true };
});

app.get('/nodes', async ()=> ({ nodes:[...nodes.entries()] }));

// Adaptive broadcast every 30s
setInterval(()=>{
  const arr = [...nodes.entries()];
  if (!arr.length) return;
  // Compute global avg hit ratio
  const ratios = arr.map(([id,n])=> {
    const total = (n.hits + n.misses)||1;
    return n.hits/total;
  });
  const avg = ratios.reduce((a,b)=>a+b,0)/ratios.length;
  nc.publish('edge.cache.tuning', Buffer.from(JSON.stringify({ avg_hit_ratio: avg })));
},30000);

app.get('/healthz', async ()=>({ ok:true, nodes: nodes.size }));

app.listen({ port: process.env.PORT || 4280, host:'0.0.0.0' });