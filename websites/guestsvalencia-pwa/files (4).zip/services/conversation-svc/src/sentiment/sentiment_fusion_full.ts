/**
 * Combina texto, prosodia, aspecto reviews y contexto histórico.
 */
export interface SentimentInput {
  textPolarity: number;      // -1..1
  textSubjectivity: number;  // 0..1
  prosodyValence: number;    // -1..1
  prosodyArousal: number;    // 0..1
  reviewAspect?: { cleanliness?:number; location?:number; value?:number };
  historicalDrift?: number;  // -0.2..0.2 average past N
  weight?: number;
  ts: number;
}

export interface SentimentFusionOutput {
  valence: number;
  arousal: number;
  stability: number;
  aspectsScore?: number;
  compositeIndex: number;
}

export function fuseSentiment(inputs: SentimentInput[]): SentimentFusionOutput {
  if (!inputs.length) return { valence:0, arousal:0, stability:1, compositeIndex:0 };
  let sumW=0, v=0, a=0, sub=0, drift=0, aspects=0, countAspects=0;
  for (const i of inputs) {
    const w = i.weight || 1;
    sumW+=w;
    v += (i.textPolarity*0.6 + i.prosodyValence*0.4) * w;
    a += i.prosodyArousal * w;
    sub += i.textSubjectivity * w;
    drift += (i.historicalDrift||0)* w;
    if (i.reviewAspect) {
      const local = Object.values(i.reviewAspect).filter(x=>x!==undefined) as number[];
      if (local.length) {
        aspects += (local.reduce((s,c)=>s+c,0)/local.length) * w;
        countAspects++;
      }
    }
  }
  const valence = v / sumW;
  const arousal = a / sumW;
  const subj = sub / sumW;
  const hist = drift / sumW;
  const aspectsScore = countAspects ? aspects / sumW : undefined;
  const stability = 1 - Math.min(Math.abs(hist),0.9);
  const compositeIndex = clamp((valence+1)/2 * 0.5 + (stability)*0.3 + (1 - subj)*0.2, 0, 1);
  return { valence, arousal, stability, aspectsScore, compositeIndex };
}

function clamp(v:number,min:number,max:number){return Math.min(Math.max(v,min),max);}