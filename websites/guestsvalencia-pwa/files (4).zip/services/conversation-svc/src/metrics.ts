import client from 'prom-client';
export const convoRegister = new client.Registry();
client.collectDefaultMetrics({ register: convoRegister });

export const partialToFinalLatency = new client.Histogram({
  name: 'conversation_partial_to_final_latency_ms',
  help: 'Latency from last partial transcript to final',
  buckets: [20,40,60,80,120,180,250,400,600,800]
});
export const bargeInterruptLatency = new client.Histogram({
  name: 'barge_interrupt_latency_ms',
  help: 'Time between barge signal and TTS stop',
  buckets: [20,40,60,80,120,180,250,350,500]
});
export const conversationTurns = new client.Counter({
  name: 'conversation_turns_total',
  help: 'Total conversation turns completed'
});

convoRegister.registerMetric(partialToFinalLatency);
convoRegister.registerMetric(bargeInterruptLatency);
convoRegister.registerMetric(conversationTurns);