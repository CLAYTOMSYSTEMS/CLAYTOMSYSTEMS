import { Server, ServerCredentials } from '@grpc/grpc-js';
import { ConversationServiceService } from './generated/conversation_grpc_pb.js';
import { ConversationImpl } from './serviceImpl';

export async function start() {
  const server = new Server();
  server.addService(ConversationServiceService, new ConversationImpl());
  const port = process.env.PORT || '50051';
  server.bindAsync(`0.0.0.0:${port}`, ServerCredentials.createInsecure(), () => {
    server.start();
    console.log('[conversation-svc] listening on', port);
  });
}
start();