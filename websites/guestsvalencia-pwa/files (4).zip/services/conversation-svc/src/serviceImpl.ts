import { IConversationServiceServer } from './generated/conversation_grpc_pb.js';
import { hybridRetrieve } from '../../../libs/embeddings/src/hybridRetriever';

export class ConversationImpl implements IConversationServiceServer {
  async startConversation(call: any, callback: any) {
    const conversationId = 'c_' + Date.now();
    callback(null, { conversationId });
  }

  streamTranscripts(call: any) {
    call.on('data', async (msg: any) => {
      if (msg.final) {
        const retrieval = await hybridRetrieve(msg.text, { locale: 'es' });
        call.write({
          conversationId: msg.conversationId,
            role: 'ASSISTANT',
            content: `Echo: ${msg.text} (candidates=${retrieval.length})`,
            intent: 'echo',
            latencyMs: 42
        });
      } else {
        call.write({
          conversationId: msg.conversationId,
          role: 'SYSTEM',
          content: '[partial received]',
          intent: '',
          latencyMs: 5
        });
      }
    });
    call.on('end', () => call.end());
  }
}