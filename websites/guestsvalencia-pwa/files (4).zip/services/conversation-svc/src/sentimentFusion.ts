interface Frame {
  textSentiment: number;   // -1..1
  prosodyValence: number;  // -1..1
  prosodyArousal: number;  // 0..1
}

export function fuseSentiment(frames: Frame[]) {
  if (!frames.length) return { valence:0, arousal:0 };
  const wText = 0.55, wProsody = 0.45;
  let val=0, aro=0;
  for (const f of frames) {
    val += (f.textSentiment * wText + f.prosodyValence * wProsody);
    aro += f.prosodyArousal;
  }
  const n = frames.length;
  return { valence: val / n, arousal: aro / n };
}