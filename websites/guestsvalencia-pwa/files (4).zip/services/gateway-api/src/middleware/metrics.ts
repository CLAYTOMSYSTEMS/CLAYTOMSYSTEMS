import { performance } from 'node:perf_hooks';
import { retrievalLatency, denseLatency, sparseLatency, mmLatency, hybridBlendRatio } from '../metrics';

interface SegmentTimes {
  dense?: number;
  sparse?: number;
  multimodal?: number;
}

export async function measureRetrieval<T>(fn: (segments: SegmentTimes)=>Promise<{results:any[], denseCount?:number, sparseCount?:number, mmCount?:number}>) {
  const start = performance.now();
  const segments: SegmentTimes = {};
  const denseBefore = performance.now();
  // The provided fn internally will set segment times; leaving hook interface
  const data = await fn(segments);
  const total = performance.now() - start;
  retrievalLatency.observe(total);
  if (segments.dense !== undefined) denseLatency.observe(segments.dense);
  if (segments.sparse !== undefined) sparseLatency.observe(segments.sparse);
  if (segments.multimodal !== undefined) mmLatency.observe(segments.multimodal);
  const totalK = (data.denseCount||0)+(data.sparseCount||0)+(data.mmCount||0);
  if (totalK > 0) {
    hybridBlendRatio.set((data.denseCount||0)/totalK);
  }
  return data;
}