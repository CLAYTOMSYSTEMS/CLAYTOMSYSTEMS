// Añade después de crear lead:
import { leadsCaptured } from '../metrics';
// ...
leadsCaptured.inc();