import express from 'express';
import { orchestratorClient } from '../grpc/clients';
export const router = express.Router();

router.post('/conversation/suggestions', async (req, res) => {
  const { conversationId, userId, locale } = req.body;
  const resp = await orchestratorClient.getProactiveSuggestions({ conversationId, userId, locale, contextWindow:'' });
  res.json(resp);
});