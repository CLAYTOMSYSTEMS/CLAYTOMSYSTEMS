import express from 'express';
import fetch from 'node-fetch';

export const fastBookingRouter = express.Router();

fastBookingRouter.post('/fast/quote-and-pay', async (req,res) => {
  const { propertyId, userId, checkIn, checkOut, guests=1, successUrl, cancelUrl } = req.body;
  // 1) Quote
  const quoteResp = await fetch(process.env.BOOKING_CQRS_URL + '/booking/command/create', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ propertyId, userId, checkIn, checkOut, guests, totalCents:0 }) // provisional
  });
  if (!quoteResp.ok) return res.status(quoteResp.status).json(await quoteResp.json());
  const { bookingId } = await quoteResp.json();
  // Recalcular coste (puedes llamar a un micro pricing real)
  const nights = Math.max(1, (Date.parse(checkOut)-Date.parse(checkIn))/(1000*60*60*24));
  const base = 120 * nights;
  const tax = Math.round(base * 0.1);
  const totalCents = (base + tax) * 100;
  // 2) Crear sesión de pago
  const payResp = await fetch(process.env.PAYMENT_SVC_URL + '/checkout/session', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ bookingId, amountCents: totalCents, successUrl, cancelUrl })
  });
  const payJson = await payResp.json();
  res.json({ bookingId, totalCents, currency:'EUR', checkout: payJson });
});