import express from 'express';
import { measureRetrieval } from '../middleware/metrics';
import { hybridRetrieve } from '../../../libs/embeddings/src/hybridRetriever';

export const retrievalRouter = express.Router();

retrievalRouter.post('/conversation/query', async (req,res) => {
  const { query, locale='es' } = req.body || {};
  const result = await measureRetrieval(async () => {
    const { results, latency_ms } = await hybridRetrieve(query, { locale, k:8 });
    // If hybridRetrieve internally returns latency components, integrate; else leave minimal
    return {
      results,
      denseCount: results.filter((r:any)=>r.modality==='dense').length,
      sparseCount: results.filter((r:any)=>r.modality==='sparse').length,
      mmCount: results.filter((r:any)=>r.modality==='multimodal').length
    };
  });
  res.json({ results: result.results });
});