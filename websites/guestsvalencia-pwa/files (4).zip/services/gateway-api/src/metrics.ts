import client from 'prom-client';

export const gatewayRegister = new client.Registry();
client.collectDefaultMetrics({ register: gatewayRegister });

export const retrievalLatency = new client.Histogram({
  name: 'retrieval_latency_ms',
  help: 'Hybrid (dense+sparse+mm) retrieval end-to-end latency',
  buckets: [10,20,30,40,50,70,90,110,140,180,250,400]
});
export const denseLatency = new client.Histogram({
  name: 'retrieval_dense_latency_ms',
  help: 'Dense vector search latency',
  buckets: [2,5,8,12,20,30,50,70,100]
});
export const sparseLatency = new client.Histogram({
  name: 'retrieval_sparse_latency_ms',
  help: 'Sparse (OpenSearch/BM25) search latency',
  buckets: [2,5,10,20,35,50,80,120]
});
export const mmLatency = new client.Histogram({
  name: 'retrieval_multimodal_latency_ms',
  help: 'Multimodal (CLIP etc) search latency',
  buckets: [5,10,20,35,50,80,120,180]
});
export const hybridBlendRatio = new client.Gauge({
  name: 'retrieval_hybrid_blend_ratio',
  help: 'Percentage of top-K results contributed by dense (0-1)'
});
export const edgeCacheHit = new client.Counter({
  name: 'edge_cache_hit_total',
  help: 'Edge semantic cache hits'
});
export const edgeCacheMiss = new client.Counter({
  name: 'edge_cache_miss_total',
  help: 'Edge semantic cache misses'
});
export const leadsCaptured = new client.Counter({
  name: 'leads_captured_total',
  help: 'Leads captured via CTA funnel'
});
export const paymentsSuccess = new client.Counter({
  name: 'payments_success_total',
  help: 'Number of successful payment confirmations'
});
export const paymentsError = new client.Counter({
  name: 'payments_error_total',
  help: 'Payment errors'
});
export const conversationActiveSessions = new client.Gauge({
  name: 'conversation_active_sessions',
  help: 'Active realtime conversation sessions gauge'
});

gatewayRegister.registerMetric(retrievalLatency);
gatewayRegister.registerMetric(denseLatency);
gatewayRegister.registerMetric(sparseLatency);
gatewayRegister.registerMetric(mmLatency);
gatewayRegister.registerMetric(hybridBlendRatio);
gatewayRegister.registerMetric(edgeCacheHit);
gatewayRegister.registerMetric(edgeCacheMiss);
gatewayRegister.registerMetric(leadsCaptured);
gatewayRegister.registerMetric(paymentsSuccess);
gatewayRegister.registerMetric(paymentsError);
gatewayRegister.registerMetric(conversationActiveSessions);

export async function metricsHandler(_req:any,res:any) {
  res.set('Content-Type', gatewayRegister.contentType);
  res.end(await gatewayRegister.metrics());
}