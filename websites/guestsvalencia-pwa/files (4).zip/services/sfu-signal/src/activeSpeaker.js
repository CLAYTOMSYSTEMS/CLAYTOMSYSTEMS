export async function createAudioObserver(router, room) {
  const observer = await router.createAudioLevelObserver({ interval: 800 });
  observer.on('volumes', vols => {
    const top = vols[0];
    if (!top) return;
    const producerId = top.producer.id;
    // map producerId -> peer (we store in room.producerPeer)
    const peerId = room.producerPeers.get(producerId);
    if (peerId) {
      room.lastSpeaker = peerId;
      broadcast(room, { type:'active-speaker', peerId });
    }
  });
  observer.on('silence', ()=> {
    // optionally send silence event
  });
  return observer;
}