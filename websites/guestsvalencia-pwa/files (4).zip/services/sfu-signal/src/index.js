// en getRoom:
const room = { router, peers:new Map(), producerPeers:new Map(), audioObserver: null };
room.audioObserver = await createAudioObserver(router, room);
...
// cuando se crea producer:
room.producerPeers.set(producer.id, peerId);
await room.audioObserver.addProducer({ producer });