const ENERGY_DECAY = 0.75;

export function enhanceAudioObserver(room) {
  room.energy = room.energy || new Map(); // producerId -> energy
  room.audioObserver.on('volumes', vols => {
    vols.forEach(({ producer, volume }) => {
      const prev = room.energy.get(producer.id) || 0;
      const smoothed = prev * ENERGY_DECAY + (volume/10);
      room.energy.set(producer.id, smoothed);
    });
    const top = [...room.energy.entries()].sort((a,b)=>b[1]-a[1])[0];
    if (top) {
      room.lastSpeaker = room.producerPeers.get(top[0]);
      broadcast(room, {
        type:'active-speaker',
        peerId: room.lastSpeaker,
        energy: Number(top[1].toFixed(2))
      });
    }
  });
}