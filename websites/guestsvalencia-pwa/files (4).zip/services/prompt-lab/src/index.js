import Fastify from 'fastify';
import { Pool } from 'pg';
import { randomUUID } from 'crypto';

const app = Fastify({ logger:true });
const pool = new Pool({ connectionString: process.env.PG_URL });

app.post('/prompt', async (req,reply)=>{
  const { name, role, content } = req.body;
  const version = 1;
  const res = await pool.query(
    'INSERT INTO prompts(name,version,role,content) VALUES($1,$2,$3,$4) RETURNING id',
    [name,version,role,content]
  );
  return { id: res.rows[0].id };
});

app.post('/experiment', async (req, reply)=>{
  const { name, variants, strategy='even' } = req.body;
  await pool.query(
    'INSERT INTO prompt_experiments(name,variants,strategy) VALUES($1,$2,$3)',
    [name, variants, strategy]
  );
  return { ok:true };
});

app.post('/select', async (req, reply)=>{
  const { experiment } = req.body;
  const ex = await pool.query('SELECT * FROM prompt_experiments WHERE name=$1',[experiment]);
  if (!ex.rowCount) return reply.code(404).send({ error:'not found'});
  const data = ex.rows[0];
  const variants = Object.entries(data.variants);
  let pick;
  if (data.strategy === 'even') {
    pick = variants[Math.floor(Math.random()*variants.length)];
  } else {
    // Extend: bandit selection using stats
    pick = variants[0];
  }
  await pool.query(`
    INSERT INTO prompt_experiment_stats(experiment_id,variant,impressions)
    VALUES($1,$2,1)
    ON CONFLICT(experiment_id,variant) DO UPDATE SET impressions=prompt_experiment_stats.impressions+1
  `,[data.id, pick[0]]);
  const prompt = await pool.query('SELECT * FROM prompts WHERE id=$1',[pick[1]]);
  return { variant: pick[0], prompt: prompt.rows[0] };
});

app.post('/reward', async (req, reply)=>{
  const { experiment, variant, reward=0 } = req.body;
  const ex = await pool.query('SELECT id FROM prompt_experiments WHERE name=$1',[experiment]);
  if (!ex.rowCount) return reply.code(404).send({ error:'not found'});
  await pool.query(`
    INSERT INTO prompt_experiment_stats(experiment_id,variant,reward)
    VALUES($1,$2,$3)
    ON CONFLICT(experiment_id,variant) DO UPDATE SET reward=prompt_experiment_stats.reward + EXCLUDED.reward
  `,[ex.rows[0].id, variant, reward]);
  return { ok:true };
});

app.listen({ port: process.env.PORT || 4140, host:'0.0.0.0' });