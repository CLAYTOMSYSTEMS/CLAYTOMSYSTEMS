import crypto from 'crypto';
const SECRET = process.env.PROMPT_SIGN_SECRET || 'dev';
export function signPrompt(content) {
  return crypto.createHmac('sha256', SECRET).update(content).digest('hex');
}