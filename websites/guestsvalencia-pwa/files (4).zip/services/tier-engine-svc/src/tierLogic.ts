export interface TierInput {
  stayLengthDays: number;
  estimatedSpend: number;
  interactionCount: number;
  askedForCustomPlan: boolean;
  requestedMultipleReservations: boolean;
  nightSupportUsage: boolean;
}

export interface TierResult {
  assigned: 'TIER1'|'TIER2'|'TIER3';
  score: number;
  reason: string;
  upgradeSuggestion?: string;
}

export function evaluateTier(i: TierInput): TierResult {
  let score = 0;
  score += Math.min(i.stayLengthDays / 7, 1) * 15;
  score += Math.min(i.estimatedSpend / 500, 1) * 20;
  score += Math.min(i.interactionCount / 25, 1) * 15;
  if (i.askedForCustomPlan) score += 15;
  if (i.requestedMultipleReservations) score += 15;
  if (i.nightSupportUsage) score += 20;

  let assigned: TierResult['assigned'] = 'TIER1';
  if (score >= 35 && score < 60) assigned = 'TIER2';
  if (score >= 60) assigned = 'TIER3';

  let upgradeSuggestion: string | undefined;
  if (assigned === 'TIER1' && score > 28) upgradeSuggestion = 'Mostrar beneficios Premium (reservas y preferencias)';
  if (assigned === 'TIER2' && score > 55) upgradeSuggestion = 'Ofrecer PROTECT: itinerarios completos + 24/7';

  return {
    assigned,
    score,
    reason: `score=${score.toFixed(1)}`,
    upgradeSuggestion
  };
}