import express from 'express';
import { evaluateTier } from './tierLogic';
const app = express();
app.use(express.json());

app.post('/evaluate', (req,res)=>{
  const r = evaluateTier(req.body);
  res.json(r);
});
const port = process.env.PORT || 5105;
app.listen(port, ()=>console.log('[tier-engine] listening', port));