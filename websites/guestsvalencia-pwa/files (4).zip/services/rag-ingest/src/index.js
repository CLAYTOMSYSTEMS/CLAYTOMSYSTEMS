import Fastify from 'fastify';
import fetch from 'node-fetch';
import matter from 'gray-matter';
import { JSDOM } from 'jsdom';
import { Pool } from 'pg';
import { v4 as uuid } from 'uuid';

const app = Fastify({ logger:true });
const pool = new Pool({ connectionString: process.env.PG_URL });

const EMBED_URL = 'https://api.openai.com/v1/embeddings';
const MODEL = process.env.EMBED_MODEL || 'text-embedding-3-small';
const MAX = parseInt(process.env.MAX_TOKENS_PER_CHUNK || '512',10);
const OVERLAP = parseInt(process.env.OVERLAP || '64',10);

function naiveTokenize(text){ return text.split(/\s+/); }

function chunkText(text){
  const tokens = naiveTokenize(text);
  const chunks = [];
  for (let i=0;i<tokens.length;i+= (MAX-OVERLAP)){
    const slice = tokens.slice(i, i+MAX);
    if (!slice.length) break;
    chunks.push(slice.join(' '));
    if (i+MAX >= tokens.length) break;
  }
  return chunks;
}

async function embedBatch(texts){
  const res = await fetch(EMBED_URL,{
    method:'POST',
    headers:{
      'Content-Type':'application/json',
      'Authorization': 'Bearer '+process.env.OPENAI_API_KEY
    },
    body: JSON.stringify({
      model: MODEL,
      input: texts
    })
  });
  const json = await res.json();
  if (json.error) throw new Error(json.error.message);
  return json.data.map(d=>d.embedding);
}

async function storeEmbeddings({ model, contentChunks, meta }){
  const embeddings = await embedBatch(contentChunks);
  const client = await pool.connect();
  try {
    for (let i=0;i<contentChunks.length;i++){
      await client.query(
        'INSERT INTO embeddings(id, model, dim, content, embedding) VALUES($1,$2,$3,$4,$5)',
        [uuid(), model, embeddings[i].length, JSON.stringify({ text: contentChunks[i], meta }), embeddings[i]]
      );
    }
  } finally { client.release(); }
  return embeddings.length;
}

app.post('/ingest', async (req, reply)=>{
  const { sourceType='raw', content='', meta={} } = req.body || {};
  if (!content) return reply.code(400).send({ error:'content required' });
  let text = content;
  if (sourceType === 'markdown') {
    const parsed = matter(content);
    text = parsed.content;
  } else if (sourceType === 'html') {
    const dom = new JSDOM(content);
    text = dom.window.document.body.textContent || '';
  }
  const chunks = chunkText(text);
  const count = await storeEmbeddings({ model: MODEL, contentChunks: chunks, meta });
  return { chunks: count };
});

app.post('/ingest/url', async (req, reply)=>{
  const { url, meta={} } = req.body || {};
  if (!url) return reply.code(400).send({ error:'url required' });
  const r = await fetch(url);
  const html = await r.text();
  const dom = new JSDOM(html);
  const text = dom.window.document.body.textContent || '';
  const chunks = chunkText(text);
  const count = await storeEmbeddings({ model: MODEL, contentChunks: chunks, meta:{ ...meta, url } });
  return { chunks: count };
});

app.post('/semantic/search', async (req, reply)=>{
  const { query, topK=5, minScore=0.7 } = req.body || {};
  if (!query) return reply.code(400).send({ error:'query required' });
  const vec = (await embedBatch([query]))[0];
  const client = await pool.connect();
  try {
    const res = await client.query(`
      SELECT content, 1 - (embedding <=> $1) AS score
      FROM embeddings
      ORDER BY embedding <=> $1
      LIMIT $2
    `,[vec, topK]);
    return {
      results: res.rows.filter(r=>r.score >= minScore).map(r=>({
        text: JSON.parse(r.content).text,
        meta: JSON.parse(r.content).meta,
        score: r.score
      }))
    };
  } finally { client.release(); }
});

app.get('/healthz', async ()=>({ ok:true }));

app.listen({ port: process.env.PORT || 4080, host:'0.0.0.0' });