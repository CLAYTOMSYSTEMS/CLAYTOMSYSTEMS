export class EmotionImpl {
  streamEmotion(call: any) {
    const convo = call.request.conversationId;
    let i = 0;
    const timer = setInterval(() => {
      i++;
      const frame = {
        conversationId: convo,
        userId: call.request.userId,
        tsUnix: Date.now(),
        valence: Math.sin(i/10) * 0.5,
        arousal: 0.4 + (Math.cos(i/13) * 0.3),
        primaryLabel: (i % 20 > 10) ? 'calm' : 'engaged',
        confidence: 0.75
      };
      call.write(frame);
      if (i > 200) {
        clearInterval(timer);
        call.end();
      }
    }, 500);
  }
}