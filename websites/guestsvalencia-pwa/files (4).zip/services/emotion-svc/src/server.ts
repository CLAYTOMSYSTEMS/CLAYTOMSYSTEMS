import { Server, ServerCredentials } from '@grpc/grpc-js';
import { EmotionServiceService } from './generated/emotion_grpc_pb.js';
import { EmotionImpl } from './serviceImpl';

async function start() {
  const server = new Server();
  server.addService(EmotionServiceService, new EmotionImpl());
  const port = process.env.PORT || '53051';
  server.bindAsync(`0.0.0.0:${port}`, ServerCredentials.createInsecure(), () => {
    server.start();
    console.log('[emotion-svc] listening', port);
  });
}
start();