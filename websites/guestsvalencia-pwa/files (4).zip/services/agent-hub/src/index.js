import { register } from './metrics.js';
app.get('/metrics', async (req, reply)=>{
  reply.header('Content-Type', register.contentType);
  return reply.send(await register.metrics());
});