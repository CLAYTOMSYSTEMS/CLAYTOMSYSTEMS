import { connect as natsConnect } from 'nats';
let nc;
export async function bus(url) {
  if (!nc) nc = await natsConnect({ servers: url });
  return nc;
}
export async function publish(topic, payload) {
  const c = await bus(process.env.NATS_URL);
  c.publish(topic, Buffer.from(JSON.stringify(payload)));
}