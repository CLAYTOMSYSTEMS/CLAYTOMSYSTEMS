import fetch from 'node-fetch';

export async function promQuery(expr) {
  const url = `${process.env.PROMETHEUS_URL}/api/v1/query?query=${encodeURIComponent(expr)}`;
  const r = await fetch(url).then(r=>r.json());
  if (r.status !== 'success') return null;
  return r.data.result;
}

export function avgValue(result) {
  if (!Array.isArray(result)) return 0;
  if (!result.length) return 0;
  return result.reduce((acc, r)=> acc + parseFloat(r.value[1]),0) / result.length;
}

export async function safeFetch(url, opts) {
  try { return await fetch(url, opts); } catch { return { ok:false, status:0, json: async ()=>({}) }; }
}

export function nowIso(){ return new Date().toISOString(); }