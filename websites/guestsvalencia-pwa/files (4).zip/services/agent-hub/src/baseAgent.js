import { decisionCounter } from './metrics.js';
// dentro runOnce después de obtener decision:
if (decision) {
  decisionCounter.labels(this.id).inc();
  await publish(`agent.decision.${this.id}`, {
    agent:this.id, ts:Date.now(), decision
  });
}