import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export async function loadAgents(config, globalCtx){
  const list = [];
  for (const def of config.agents) {
    try {
      const file = path.join(__dirname,'..','agents', `${def.class}.js`);
      if (!fs.existsSync(file)) {
        globalCtx.log.warn({ def }, 'Agent file missing');
        continue;
      }
      const mod = await import(file);
      const Cls = mod[def.class];
      if (!Cls) {
        globalCtx.log.warn({ def }, 'Agent class missing export');
        continue;
      }
      const agent = new Cls(def, globalCtx);
      if (agent.init) await agent.init();
      list.push(agent);
    } catch(e){
      globalCtx.log.error(e, 'Agent load failed');
    }
  }
  return list;
}