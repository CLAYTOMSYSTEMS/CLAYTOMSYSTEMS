import client from 'prom-client';
export const register = new client.Registry();
client.collectDefaultMetrics({ register });
export const decisionCounter = new client.Counter({
  name:'agent_hub_decisions_total',
  help:'Decisiones emitidas',
  labelNames:['agent']
});
register.registerMetric(decisionCounter);