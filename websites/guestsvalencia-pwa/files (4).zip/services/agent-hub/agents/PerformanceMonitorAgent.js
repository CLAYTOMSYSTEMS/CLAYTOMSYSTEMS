import { BaseAgent } from '../src/baseAgent.js';
import { promQuery, avgValue } from '../src/util.js';

export class PerformanceMonitorAgent extends BaseAgent {
  async run() {
    const p95 = await promQuery('histogram_quantile(0.95, sum(rate(llm_gateway_latency_seconds_bucket[5m])) by (le))');
    const val = avgValue(p95);
    const slo = parseFloat(process.env.LATENCY_SLO_P95 || '5');
    let status = 'green';
    if (val > slo) status = 'red';
    else if (val > slo * 0.8) status = 'yellow';
    return { latency_p95: val, status };
  }
}