import { BaseAgent } from '../src/baseAgent.js';
import fetch from 'node-fetch';

const CRITICAL = [
  { name:'ws-core', url: process.env.WS_CORE_URL + '/healthz' },
  { name:'llm-gateway', url: process.env.LLM_GATEWAY_URL + '/healthz' },
  { name:'revenue-engine', url: process.env.REVENUE_URL + '/healthz' }
];

export class SystemHealthAgent extends BaseAgent {
  constructor(cfg, ctx){
    super(cfg,ctx);
    this.failCount = {};
  }
  async run() {
    const results = [];
    for (const svc of CRITICAL) {
      const r = await fetch(svc.url).catch(()=>null);
      const ok = !!(r && r.ok);
      if (!ok) {
        this.failCount[svc.name] = (this.failCount[svc.name]||0)+1;
      } else {
        this.failCount[svc.name] = 0;
      }
      results.push({ service: svc.name, ok });
    }
    const toHeal = Object.entries(this.failCount).filter(([,c])=> c >= 3).map(([s])=>s);
    return { results, toHeal, autoHeal: process.env.DRY_RUN==='false' ? 'pending' : 'dry' };
  }
}