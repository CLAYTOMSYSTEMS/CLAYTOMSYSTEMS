import { BaseAgent } from '../src/baseAgent.js';
import { promQuery, avgValue } from '../src/util.js';

export class CostOptimizationAgent extends BaseAgent {
  async run() {
    // Suppose we have a metric llm_gateway_latency_seconds_count and tokens usage (not yet aggregated)
    const latency = await promQuery('histogram_quantile(0.5, sum(rate(llm_gateway_latency_seconds_bucket[5m])) by (le))');
    const median = avgValue(latency);
    // Heuristic: if median < 1.2s and cost threshold high => consider cheaper model
    const threshold = parseFloat(process.env.COST_THRESHOLD_PER_1K || '0.02');
    const rec = median < 1.2 ? 'try_mistral_first' : 'keep_openai_first';
    return { median_latency: median, recommendation: rec, costCap: threshold };
  }
}