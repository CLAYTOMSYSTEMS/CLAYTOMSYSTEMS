import { BaseAgent } from '../src/baseAgent.js';
import { promQuery, avgValue } from '../src/util.js';
import fetch from 'node-fetch';

export class ConversionSpecialistAgent extends BaseAgent {
  async run() {
    // Look at drop-off (payments vs intents)
    const intents = await promQuery('sum(increase(revenue_engine_events_total{event_type="user_message"}[10m]))'); // placeholder
    const payments = await promQuery('sum(increase(revenue_engine_events_total{event_type="payment"}[10m]))');
    const intentVal = avgValue(intents);
    const payVal = avgValue(payments);
    const funnel = intentVal ? payVal / intentVal : 0;
    let promptAdjustment = funnel < 0.05 ? 'enable_booking_prompt_variant_B' : 'keep';
    if (promptAdjustment.startsWith('enable')) {
      if (process.env.DRY_RUN === 'false') {
        // example: call prompt-lab /reward artificial to bias variant
        await fetch(process.env.PROMPT_LAB_URL + '/reward',{
          method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({ experiment:'base-system', variant:'B', reward: 0.2 })
        }).catch(()=>{});
      }
    }
    return { funnel, promptAdjustment };
  }
}