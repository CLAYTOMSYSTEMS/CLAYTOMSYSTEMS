import { BaseAgent } from '../src/baseAgent.js';
import { promQuery, avgValue } from '../src/util.js';
import fetch from 'node-fetch';

export class RevenueOptimizerAgent extends BaseAgent {
  async run() {
    // Example: inspect booking conversion & adjust pricing guidance
    const conv = await promQuery('sum(increase(revenue_engine_events_total{event_type="booking_confirmed"}[15m]))');
    const convRate = avgValue(conv);
    const target = 5; // arbitrary baseline bookings per 15m
    let action = null;
    if (convRate < target * 0.6) {
      action = 'increase_marketing_prompt_variant';
    } else if (convRate > target * 1.2) {
      action = 'test_price_increase';
    }
    if (action === 'test_price_increase') {
      // call pricing for a sample listing to compute uplift log (dry-run)
      const quote = await fetch(process.env.PRICING_URL + '/quote',{
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({
          listingId:'APT01', basePrice:100, checkin:new Date().toISOString().slice(0,10),
          checkout:new Date(Date.now()+86400000).toISOString().slice(0,10)
        })
      }).then(r=>r.json()).catch(()=>null);
      return { convRate, action, sampleQuote: quote, dryRun: process.env.DRY_RUN !== 'false' };
    }
    return { convRate, action: action || 'hold' };
  }
}