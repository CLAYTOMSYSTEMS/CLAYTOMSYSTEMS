import { BaseAgent } from '../src/baseAgent.js';
import fetch from 'node-fetch';

export class BusinessIntelligenceAgent extends BaseAgent {
  async run() {
    const forecast = await fetch(process.env.FORECAST_URL || 'http://bi-forecast:4210/forecast')
      .then(r=>r.json()).catch(()=>({}));
    return { forecast: forecast.prediction || null };
  }
}