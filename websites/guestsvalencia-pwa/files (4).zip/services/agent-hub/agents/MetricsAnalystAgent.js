import { BaseAgent } from '../src/baseAgent.js';
import { promQuery } from '../src/util.js';

export class MetricsAnalystAgent extends BaseAgent {
  async run() {
    const sessions = await promQuery('ws_core_active_sessions');
    const s = sessions?.[0]?.value?.[1];
    return { activeSessions: s ? parseInt(s,10) : 0 };
  }
}