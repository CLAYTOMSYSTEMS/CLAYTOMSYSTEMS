import { BaseAgent } from '../src/baseAgent.js';
import { promQuery, avgValue } from '../src/util.js';

export class ScalingIntelligenceAgent extends BaseAgent {
  async run() {
    const mpsResult = await promQuery('sum(rate(ws_core_messages_total[1m]))');
    const mps = avgValue(mpsResult);
    const target = parseFloat(process.env.SCALING_TARGET_MPS || '40');
    let factor = mps / target;
    if (factor < 0.5) factor = 0.5;
    const desired = Math.min(
      parseInt(process.env.AUTO_SCALING_MAX || '6',10),
      Math.max(parseInt(process.env.AUTO_SCALING_MIN || '1',10), Math.round(factor))
    );
    return { mps, target, desiredReplicas: desired, apply: process.env.DRY_RUN==='false' ? 'pending' : 'dry' };
  }
}