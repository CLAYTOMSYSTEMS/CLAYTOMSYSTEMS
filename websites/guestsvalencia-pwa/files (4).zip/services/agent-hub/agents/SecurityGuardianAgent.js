import { BaseAgent } from '../src/baseAgent.js';

export class SecurityGuardianAgent extends BaseAgent {
  async run() {
    // Future: check key ages from a key registry table
    const daysSinceRotation = 28;
    const rotateAfter = parseInt(process.env.SEC_KEY_ROTATION_DAYS || '30',10);
    const needsRotation = daysSinceRotation >= rotateAfter;
    return { daysSinceRotation, needsRotation };
  }
}