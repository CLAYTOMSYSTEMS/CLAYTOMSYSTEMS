# Negotiation Dataset Stub

Objetivo:
- Entrenar/ajustar heurísticas / modelos RL para descuento y cierre

Schema (JSONL):
{
  "id": "neg_0001",
  "locale": "es",
  "channel": "web",
  "context_features": {
    "occupancy_pct": 0.34,
    "lead_days": 5,
    "competitor_delta": -0.05,
    "user_segment": "last_minute",
    "prior_interactions": 2
  },
  "user_message": "¿Me puedes hacer un mejor precio si reservo ahora?",
  "model_offer_pct": 0.12,
  "counter_user": "¿Podrías 15%?",
  "final_agreed_pct": 0.13,
  "booking_converted": true,
  "reaction_time_ms": 4200,
  "reward": 0.78
}

Reward Heurística:
reward = normalized_margin_preserved * conversion_flag * satisfaction_factor

Etiquetas Sugeridas:
- segment: business_traveler, family, last_minute, high_value
- intent_subtype: discount, upgrade, bundle
- tone: polite, aggressive, neutral

Uso:
1. Pre-entrenar un modelo de política (bandit contextual).
2. Ajustar exploración vs explotación.
3. Analizar correlación final_agreed_pct vs conversion y margin.
