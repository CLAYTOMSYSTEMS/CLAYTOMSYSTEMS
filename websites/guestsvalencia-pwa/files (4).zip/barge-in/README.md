# Barge-In System (Sandra IA 7.0)

Sistema de referencia para:
- WebRTC upstream (mic) + downstream (TTS simulado).
- VAD local → barge-in (interrumpe TTS).
- Eventos conversacionales (turn-taking).
- Canal de señalización (WebSocket) + DataChannel.

## 1. Inicio rápido
cp server/config.example.json server/config.json  # Ajusta API keys si implementas TTS real
(cd server && npm install)
node server/server.js

Sirve cliente con cualquier estático (ej: npx serve client ) o abre client/index.html (asegúrate http vs https según permisos).

## 2. Zipear
cd ..
zip -r bargein_system.zip barge-in

## 3. Sustituir TTS stub
- Reemplaza ttsQueue por integration real (Azure, ElevenLabs, AWS Polly, etc.).
- Inyecta frames PCM16 mono 16k y envía por DataChannel o crea pista con MediaStreamTrackGenerator (node >= 18 + experimental).

## 4. STT real
- Usa streaming Whisper, Deepgram o Azure Cognitive; agrega buffering a transcribePCMBuffer.
- Detecta endpointing: silencio > X ms ⇒ cierre de turno.

## 5. Barge-In
- Cliente manda 'barge_in' apenas VAD detecta voz mientras TTS activo.
- Servidor marca interrupción y descarta cola de frames.

## 6. Seguridad / Producción
- Añadir autenticación WS (token).
- Forzar TLS (wss).
- Limitar bitrate.
- Agregar jitter buffer / marcadores.

## 7. Extensiones
- NLU slots (zona, fechas, huéspedes) tras transcript_final.
- JSON state machine para flujos (booking, info, fallback).
- Latencia <250ms: mover TTS a edge + partial chunk push.

## 8. Limitaciones Demo
- TTS simulado (silencios).
- STT stub (texto inventado).
- Falta reconexión robusta y ICE servers STUN/TURN.

## 9. TURN / NAT
Agregar ICE servers:
const pc = new RTCPeerConnection({ iceServers:[{urls:'stun:stun.l.google.com:19302'}] });

## 10. Licencia
Ajusta según tu repositorio.
