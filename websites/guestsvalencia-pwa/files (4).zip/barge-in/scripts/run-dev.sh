#!/usr/bin/env bash
set -e
(cd server && npm install)
node server/server.js