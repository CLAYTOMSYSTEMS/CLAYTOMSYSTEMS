// Placeholder STT: Return incremental pseudo-text
let counter = 0;

export async function transcribePCMBuffer(_buf) {
  counter++;
  if (counter % 25 === 0) {
    return 'parcial-' + counter;
  }
  return null;
}