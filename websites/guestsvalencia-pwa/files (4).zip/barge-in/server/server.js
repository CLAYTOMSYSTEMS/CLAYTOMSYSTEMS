import fs from 'fs';
import path from 'path';
import { createSignalingServer } from './signaling.js';

const configPath = path.join(process.cwd(), 'server', 'config.json');
let config;
if (fs.existsSync(configPath)) {
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
} else {
  config = JSON.parse(fs.readFileSync(path.join(process.cwd(), 'server', 'config.example.json'), 'utf8'));
  console.warn('Using example config. Copy config.example.json to config.json and set keys.');
}

createSignalingServer({ port: config.port || 8080 });