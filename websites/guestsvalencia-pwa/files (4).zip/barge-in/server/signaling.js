import { WebSocketServer } from 'ws';
import { RTCPeerConnection, RTCSessionDescription } from 'wrtc';
import { v4 as uuid } from 'uuid';
import { createTTSQueue } from './ttsQueue.js';
import { transcribePCMBuffer } from './sttStub.js';

export function createSignalingServer({ port }) {
  const wss = new WebSocketServer({ port });
  console.log('[SIGNALING] Listening on :', port);

  wss.on('connection', (ws) => {
    const id = uuid();
    console.log(`[WS] Client connected ${id}`);

    const pc = new RTCPeerConnection({
      encodedInsertableStreams: false
    });

    const state = {
      id,
      userSpeaking: false,
      systemSpeaking: false,
      currentTurn: 'IDLE', // USER_TURN | SYSTEM_TURN
      lastSpeechTs: Date.now(),
      closed: false
    };

    // DataChannel (client creates or we create)
    let controlChannel = null;
    pc.ondatachannel = (evt) => {
      controlChannel = evt.channel;
      wireDataChannel(controlChannel, state, pc);
    };

    // Outgoing TTS Track (we create a synthetic track initially silent)
    const ttsQueue = createTTSQueue({
      onAudioFrame: (frame) => {
        // Using insertable streams alternative: for simplicity we attach MediaStreamTrackGenerator style not available in wrtc yet in a stable way
        // Simplify: buffer frames, send over datachannel as 'tts_chunk' fallback
        if (controlChannel && controlChannel.readyState === 'open') {
          controlChannel.send(JSON.stringify({ type: 'tts_chunk', payload: frame.toString('base64') }));
        }
      },
      onStart: () => {
        state.systemSpeaking = true;
        sendEvent(controlChannel, 'tts_start', {});
      },
      onEnd: () => {
        state.systemSpeaking = false;
        if (state.currentTurn === 'SYSTEM_TURN') {
          state.currentTurn = 'IDLE';
          sendEvent(controlChannel, 'turn_idle', {});
        }
        sendEvent(controlChannel, 'tts_end', {});
      },
      onInterrupted: () => {
        sendEvent(controlChannel, 'tts_interrupted', {});
      }
    });

    // Incoming tracks (user mic)
    pc.ontrack = (evt) => {
      const [track] = evt.streams;
      console.log('[RTC] Incoming track kind=', evt.track.kind);
      if (evt.track.kind === 'audio') {
        // We can capture raw audio via insertable streams only in browsers; server side we can record using receiver
        const receiver = pc.getReceivers().find(r => r.track && r.track.id === evt.track.id);
        if (receiver) {
          // Periodic pull for STT (placeholder)
          startPCMExtractionLoop(receiver, async (pcm) => {
            // feed STT
            const partial = await transcribePCMBuffer(pcm);
            if (partial && controlChannel && controlChannel.readyState === 'open') {
              sendEvent(controlChannel, 'transcript_partial', { text: partial });
            }
          });
        }
      }
    };

    pc.onicecandidate = (e) => {
      if (e.candidate) {
        ws.send(JSON.stringify({ type: 'ice_candidate', candidate: e.candidate }));
      }
    };

    ws.on('message', async (raw) => {
      let msg;
      try {
        msg = JSON.parse(raw.toString());
      } catch {
        return;
      }
      switch (msg.type) {
        case 'offer': {
          await pc.setRemoteDescription(new RTCSessionDescription(msg.offer));
          const answer = await pc.createAnswer();
            await pc.setLocalDescription(answer);
          ws.send(JSON.stringify({ type: 'answer', answer }));
          break;
        }
        case 'ice_candidate': {
          if (msg.candidate) {
            try {
              await pc.addIceCandidate(msg.candidate);
            } catch (err) {
              console.error('ICE add error', err);
            }
          }
          break;
        }
        case 'client_event': {
          handleClientEvent(msg.event, msg.payload || {}, state, { ttsQueue, controlChannel });
          break;
        }
        default:
          break;
      }
    });

    ws.on('close', () => {
      console.log(`[WS] Closed ${id}`);
      state.closed = true;
      pc.close();
      ttsQueue.clear();
    });

    function handleClientEvent(event, payload, state, ctx) {
      switch (event) {
        case 'speech_start':
          state.userSpeaking = true;
          state.currentTurn = 'USER_TURN';
          sendEvent(controlChannel, 'ack', { event });
          break;
        case 'speech_end':
          state.userSpeaking = false;
          // finalize STT (placeholder)
          finalizeUserTurn();
          break;
        case 'barge_in':
          console.log('[BARGE-IN] Interrupting TTS');
          ctx.ttsQueue.interrupt();
          state.systemSpeaking = false;
          state.currentTurn = 'USER_TURN';
          break;
        case 'user_text_message':
          // (Optional) direct text input
          prepareTTSResponse(payload.text);
          break;
        default:
          break;
      }
    }

    async function finalizeUserTurn() {
      // In real: use aggregated STT buffer
      const finalText = 'Texto simulado del usuario';
      sendEvent(controlChannel, 'transcript_final', { text: finalText });
      // Generate answer (placeholder)
      const answer = `Respuesta generada para: ${finalText}`;
      // Move to system turn
      state.currentTurn = 'SYSTEM_TURN';
      prepareTTSResponse(answer);
    }

    function prepareTTSResponse(text) {
      // Placeholder: split in fake PCM frames
      const fakeFrames = synthFakePCMFrames(text, 40);
      ttsQueue.enqueue({
        id: uuid(),
        text,
        frames: fakeFrames
      });
    }

  });
}

function synthFakePCMFrames(text, chunks) {
  // This just returns silent buffers sized to simulate streaming
  const arr = [];
  for (let i = 0; i < chunks; i++) {
    arr.push(Buffer.alloc(320)); // 20ms @16k mono ~320 bytes for pcm16? (Actually 640 bytes) simplified
  }
  return arr;
}

function wireDataChannel(dc, state, pc) {
  dc.onopen = () => {
    console.log('[DC] Open');
    sendEvent(dc, 'ready', {});
  };
  dc.onmessage = (e) => {
    try {
      const msg = JSON.parse(e.data);
      if (msg.type === 'client_event') {
        // Could route same as WS path if wanted
      }
    } catch { /* ignore */ }
  };
  dc.onclose = () => console.log('[DC] Closed');
}

function sendEvent(dc, type, payload) {
  if (!dc || dc.readyState !== 'open') return;
  dc.send(JSON.stringify({ type, payload }));
}

function startPCMExtractionLoop(receiver, onPCM) {
  // NOTE: wrtc does not expose raw PCM frames trivially; for real capture you'd use receiver.createReadStream()
  if (receiver.createReadStream) {
    const stream = receiver.createReadStream();
    stream.on('data', (data) => {
      onPCM(data).catch(() => {});
    });
  } else {
    console.warn('Receiver raw stream not supported in this build of wrtc (stub).');
  }
}