export function createTTSQueue({ onAudioFrame, onStart, onEnd, onInterrupted }) {
  const queue = [];
  let playing = false;
  let interrupted = false;

  async function process() {
    if (playing) return;
    const item = queue.shift();
    if (!item) return;
    playing = true;
    interrupted = false;
    onStart && onStart(item);
    for (const frame of item.frames) {
      if (interrupted) break;
      onAudioFrame && onAudioFrame(frame);
      await wait(40); // simulate 25fps audio chunk
    }
    if (interrupted) {
      onInterrupted && onInterrupted(item);
    } else {
      onEnd && onEnd(item);
    }
    playing = false;
    if (queue.length) process();
  }

  return {
    enqueue(item) {
      queue.push(item);
      process();
    },
    interrupt() {
      interrupted = true;
    },
    clear() {
      queue.length = 0;
    }
  };
}

function wait(ms) {
  return new Promise(r => setTimeout(r, ms));
}