# Nota
El VAD principal se hace en cliente para poder detectar barge-in inmediato (latencia baja).
Servidor podría añadir un VAD de segunda capa (ej: WebRTC VAD nativo, Silero, webrtcvad lib) si se busca robustez.