# Eventos DataChannel / WS

Cliente -> Servidor:
- speech_start
- speech_end
- barge_in
- user_text_message { text }

Servidor -> Cliente:
- ready
- transcript_partial { text }
- transcript_final { text }
- tts_start
- tts_chunk { base64pcm }
- tts_interrupted
- tts_end
- turn_idle