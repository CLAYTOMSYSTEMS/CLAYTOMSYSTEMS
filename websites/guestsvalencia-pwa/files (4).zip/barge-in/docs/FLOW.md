# Conversational Flow / Turn Taking

USER_TURN => collecting audio (VAD active)
Silence + endpoint => generate answer => SYSTEM_TURN (TTS streaming)
If user speaks during SYSTEM_TURN => barge_in => immediate switch to USER_TURN

Estados clave: IDLE | USER_TURN | SYSTEM_TURN