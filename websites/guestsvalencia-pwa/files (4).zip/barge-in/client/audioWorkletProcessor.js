// Opcional: si quisieras manipular frames antes de enviarlos
// Registrar con audioContext.audioWorklet.addModule('audioWorkletProcessor.js');
class PassthroughProcessor extends AudioWorkletProcessor {
  process(inputs, outputs) {
    // Just pass through
    return true;
  }
}
registerProcessor('passthrough', PassthroughProcessor);