import { SimpleVAD } from './vad.js';

const btnConnect = document.getElementById('btnConnect');
const btnDisconnect = document.getElementById('btnDisconnect');
const btnSendText = document.getElementById('btnSendText');
const textInput = document.getElementById('textInput');

const rtcStatusEl = document.getElementById('rtcStatus');
const turnStatusEl = document.getElementById('turnStatus');
const vadStatusEl = document.getElementById('vadStatus');
const ttsStatusEl = document.getElementById('ttsStatus');
const partialEl = document.getElementById('partial');
const finalEl = document.getElementById('final');
const logsEl = document.getElementById('logs');

let pc;
let ws;
let dc;
let localStream;
let audioContext;
let vad;
let ttsPlaying = false;
let currentlySystemSpeaking = false;

function log(...a) {
  logsEl.textContent += a.join(' ') + '\n';
  logsEl.scrollTop = logsEl.scrollHeight;
}

btnConnect.onclick = async () => {
  btnConnect.disabled = true;
  await start();
};

btnDisconnect.onclick = async () => {
  cleanup();
};

btnSendText.onclick = () => {
  const txt = textInput.value.trim();
  if (!txt) return;
  sendClientEvent('user_text_message', { text: txt });
};

async function start() {
  ws = new WebSocket(`ws://${location.hostname}:8080`);
  ws.onopen = () => log('[WS] open');
  ws.onmessage = onWSMessage;
  ws.onclose = () => log('[WS] closed');

  localStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });

  pc = new RTCPeerConnection();
  localStream.getAudioTracks().forEach(t => pc.addTrack(t, localStream));

  pc.onicecandidate = (e) => {
    if (e.candidate) {
      ws.send(JSON.stringify({ type: 'ice_candidate', candidate: e.candidate }));
    }
  };

  pc.ontrack = (e) => {
    // We expect TTS track (fallback: if using datachannel chunks, they will be handled separately)
    const audio = document.getElementById('remoteAudio');
    if (!audio) {
      const a = document.createElement('audio');
      a.id = 'remoteAudio';
      a.autoplay = true;
      document.body.appendChild(a);
      a.srcObject = e.streams[0];
    }
  };

  dc = pc.createDataChannel('control');
  dc.onopen = () => {
    log('[DC] open');
    btnSendText.disabled = false;
  };
  dc.onmessage = (e) => {
    handleServerEvent(e.data);
  };

  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  ws.addEventListener('open', () => {
    ws.send(JSON.stringify({ type: 'offer', offer }));
  });

  setupVAD(localStream);

  btnDisconnect.disabled = false;
  rtcStatusEl.textContent = 'connecting';
}

function onWSMessage(ev) {
  let msg;
  try { msg = JSON.parse(ev.data); } catch { return; }
  if (msg.type === 'answer') {
    pc.setRemoteDescription(msg.answer);
    rtcStatusEl.textContent = 'connected';
  } else if (msg.type === 'ice_candidate') {
    pc.addIceCandidate(msg.candidate);
  }
}

function handleServerEvent(raw) {
  let msg;
  try { msg = JSON.parse(raw); } catch { return; }
  const { type, payload } = msg;
  switch (type) {
    case 'ready':
      log('[SERVER] ready');
      break;
    case 'ack':
      break;
    case 'transcript_partial':
      partialEl.textContent = payload.text;
      break;
    case 'transcript_final':
      finalEl.textContent += payload.text + '\n';
      partialEl.textContent = '';
      break;
    case 'tts_start':
      ttsStatusEl.textContent = 'PLAY';
      ttsPlaying = true;
      currentlySystemSpeaking = true;
      break;
    case 'tts_end':
      ttsStatusEl.textContent = 'END';
      ttsPlaying = false;
      currentlySystemSpeaking = false;
      break;
    case 'tts_interrupted':
      ttsStatusEl.textContent = 'INTERRUPTED';
      ttsPlaying = false;
      currentlySystemSpeaking = false;
      break;
    case 'turn_idle':
      turnStatusEl.textContent = 'IDLE';
      break;
    case 'tts_chunk':
      // fallback approach: constructing AudioBuffer & play (not ideal)
      playPCMChunkBase64(payload);
      break;
    default:
      log('[DC] event', type);
  }
}

async function playPCMChunkBase64(b64) {
  if (!audioContext) audioContext = new AudioContext();
  const buf = atob(b64);
  const raw = new Int8Array(buf.length);
  for (let i = 0; i < buf.length; i++) raw[i] = buf.charCodeAt(i);
  // Interpret as PCM16 mono 16k (stub)
  const int16 = new Int16Array(raw.buffer);
  const float32 = new Float32Array(int16.length);
  for (let i = 0; i < int16.length; i++) {
    float32[i] = int16[i] / 32768;
  }
  const audioBuf = audioContext.createBuffer(1, float32.length, 16000);
  audioBuf.getChannelData(0).set(float32);
  const src = audioContext.createBufferSource();
  src.buffer = audioBuf;
  src.connect(audioContext.destination);
  src.start();
}

function setupVAD(stream) {
  audioContext = new AudioContext();
  const source = audioContext.createMediaStreamSource(stream);
  vad = new SimpleVAD({
    audioContext,
    sourceNode: source,
    energyThreshold: 0.018,
    hangover: 300,
    onSpeechStart: () => {
      vadStatusEl.textContent = 'hablando';
      sendClientEvent('speech_start');
      // Barge-in detection
      if (ttsPlaying) {
        log('[BARGE-IN] Detected voice during TTS -> sending barge_in');
        sendClientEvent('barge_in');
      }
    },
    onSpeechEnd: () => {
      vadStatusEl.textContent = 'silencio';
      sendClientEvent('speech_end');
    }
  });
  vad.start();
}

function sendClientEvent(event, payload = {}) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type: 'client_event', event, payload }));
  } else if (dc && dc.readyState === 'open') {
    dc.send(JSON.stringify({ type: 'client_event', event, payload }));
  }
}

function cleanup() {
  if (vad) vad.stop();
  if (pc) pc.close();
  if (ws) ws.close();
  localStream && localStream.getTracks().forEach(t => t.stop());
  btnConnect.disabled = false;
  btnDisconnect.disabled = true;
  btnSendText.disabled = true;
  rtcStatusEl.textContent = 'idle';
  ttsStatusEl.textContent = 'off';
  log('Cleaned up');
}