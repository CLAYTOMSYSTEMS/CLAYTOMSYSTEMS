export class SimpleVAD {
  constructor({ audioContext, sourceNode, onSpeechStart, onSpeechEnd, energyThreshold = 0.015, hangover = 250 }) {
    this.ctx = audioContext;
    this.src = sourceNode;
    this.onSpeechStart = onSpeechStart;
    this.onSpeechEnd = onSpeechEnd;
    this.energyThreshold = energyThreshold;
    this.hangover = hangover;
    this._speaking = false;
    this._lastVoice = 0;

    this.analyser = this.ctx.createAnalyser();
    this.analyser.fftSize = 2048;
    this.src.connect(this.analyser);

    this.data = new Float32Array(this.analyser.fftSize);
    this._loop = this._loop.bind(this);
  }

  start() {
    this._running = true;
    requestAnimationFrame(this._loop);
  }
  stop() {
    this._running = false;
  }

  _loop() {
    if (!this._running) return;
    this.analyser.getFloatTimeDomainData(this.data);
    let sum = 0;
    for (let i = 0; i < this.data.length; i++) {
      const v = this.data[i];
      sum += v * v;
    }
    const rms = Math.sqrt(sum / this.data.length);

    if (rms > this.energyThreshold) {
      this._lastVoice = performance.now();
      if (!this._speaking) {
        this._speaking = true;
        this.onSpeechStart && this.onSpeechStart({ rms });
      }
    } else if (this._speaking && (performance.now() - this._lastVoice) > this.hangover) {
      this._speaking = false;
      this.onSpeechEnd && this.onSpeechEnd();
    }

    requestAnimationFrame(this._loop);
  }
}