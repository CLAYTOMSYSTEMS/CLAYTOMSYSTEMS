### Descripción
(Resumen claro de la modificación)

### Checklist
- [ ] No se han borrado ficheros críticos sin justificación.
- [ ] Pasa lint + typecheck.
- [ ] Mantiene compatibilidad multi-idioma (es,en,fr,de,it) donde aplica.
- [ ] Sin exposición de secretos.
- [ ] Si toca conversación: probado barge-in / turn transitions básicos.

### Notas
(Incluir riesgos, migraciones necesarias, rollback plan)

### Screenshots / Logs
(Aportar evidencia)