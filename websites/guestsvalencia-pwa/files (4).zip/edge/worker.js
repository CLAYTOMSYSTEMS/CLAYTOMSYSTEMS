export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    if (url.pathname === '/preprompt') {
      // lightweight redirect to origin or cache a canonical system prompt
      const prompt = 'Eres Sandra IA 7.0 (edge cached system).';
      return new Response(JSON.stringify({ system: prompt }), {
        headers:{ 'Content-Type':'application/json','Cache-Control':'public,max-age=600' }
      });
    }
    return new Response('OK');
  }
};