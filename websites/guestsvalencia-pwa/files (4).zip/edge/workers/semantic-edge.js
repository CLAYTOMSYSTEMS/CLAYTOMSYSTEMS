export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/edge/health') return new Response(JSON.stringify({ ok:true }), { headers:{'Content-Type':'application/json'} });

    if (url.pathname.startsWith('/conversation/query')) {
      const body = await request.json();
      const key = await semanticKey(body.query, body.locale);
      const cache = caches.default;
      let resp = await cache.match(key);
      if (resp) return withHeaders(resp, {'X-Edge-Cache':'HIT'});

      const upstreamStart = Date.now();
      const upstream = await fetch(env.GATEWAY_ORIGIN + url.pathname, {
        method:'POST',
        body: JSON.stringify(body),
        headers:{'Content-Type':'application/json', 'X-Edge-Hint':'semantic-v1'}
      });
      if (!upstream.ok) {
        // degrade fallback: ask sparse only
        const degrade = await fetch(env.GATEWAY_ORIGIN + '/conversation/query-sparse', {
          method:'POST', body: JSON.stringify(body),
          headers:{'Content-Type':'application/json'}
        });
        return withHeaders(new Response(await degrade.text(), { status:degrade.status, headers:{'Content-Type':'application/json'} }),
          {'X-Edge-Degrade':'SPARSE_ONLY'});
      }
      resp = new Response(await upstream.text(), { headers:{'Content-Type':'application/json'} });
      if (Date.now() - upstreamStart < 120) {
        await cache.put(key, resp.clone());
      }
      return withHeaders(resp, {'X-Edge-Cache':'MISS'});
    }

    return fetch(env.GATEWAY_ORIGIN + url.pathname, request);
  }
};

function withHeaders(r, extra) {
  for (const [k,v] of Object.entries(extra)) r.headers.set(k,v);
  return r;
}

async function semanticKey(query, locale) {
  const enc = new TextEncoder().encode(query + '|' + locale);
  const h = await crypto.subtle.digest('SHA-256', enc);
  return 'https://edge.sandra/cache/' + [...new Uint8Array(h)].map(b=>b.toString(16).padStart(2,'0')).join('');
}