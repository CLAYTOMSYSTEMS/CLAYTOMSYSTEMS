CREATE TABLE IF NOT EXISTS competitor_prices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id TEXT,
  competitor_id TEXT,
  price NUMERIC,
  observed_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS price_observations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id TEXT,
  offered_price NUMERIC,
  booked BOOLEAN,
  stay_date DATE,
  created_at TIMESTAMPTZ DEFAULT now()
);