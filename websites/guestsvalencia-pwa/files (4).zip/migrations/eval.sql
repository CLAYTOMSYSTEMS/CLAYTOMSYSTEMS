CREATE TABLE IF NOT EXISTS eval_runs (
  id UUID PRIMARY KEY,
  prompt TEXT,
  answer TEXT,
  score NUMERIC,
  expected JSONB,
  created_at TIMESTAMPTZ DEFAULT now()
);