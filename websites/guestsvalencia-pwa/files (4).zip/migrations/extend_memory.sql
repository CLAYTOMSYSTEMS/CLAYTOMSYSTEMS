CREATE TABLE IF NOT EXISTS conversation_messages (
  id BIGSERIAL PRIMARY KEY,
  session_id UUID NOT NULL,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS conversation_summaries (
  session_id UUID NOT NULL,
  level TEXT NOT NULL,  -- short | mid | long
  summary TEXT,
  updated_at TIMESTAMPTZ DEFAULT now(),
  PRIMARY KEY(session_id, level)
);