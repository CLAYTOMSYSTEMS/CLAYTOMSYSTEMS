ALTER TABLE guardrail_policies
  ADD COLUMN IF NOT EXISTS severity TEXT DEFAULT 'medium',
  ADD COLUMN IF NOT EXISTS action TEXT DEFAULT 'inspect',
  ADD COLUMN IF NOT EXISTS tags TEXT[] DEFAULT ARRAY[]::TEXT[];

CREATE TABLE IF NOT EXISTS guardrail_dsl_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT,
  raw_rule TEXT,
  compiled JSONB,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS guardrail_anomalies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  kind TEXT,
  metric TEXT,
  value NUMERIC,
  baseline NUMERIC,
  z_score NUMERIC,
  window_start TIMESTAMPTZ,
  window_end TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_guardrails_audit_created ON moderation_audit(created_at);