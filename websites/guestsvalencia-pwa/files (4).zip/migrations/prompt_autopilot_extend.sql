CREATE TABLE IF NOT EXISTS prompt_autopilot_decisions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  experiment TEXT,
  variant TEXT,
  action TEXT,
  reason TEXT,
  score_before NUMERIC,
  score_after NUMERIC,
  anomaly_context JSONB,
  signed BOOLEAN DEFAULT false,
  signature TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);