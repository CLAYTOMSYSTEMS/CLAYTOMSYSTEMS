CREATE TABLE IF NOT EXISTS guardrail_policies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT,
  category TEXT,
  rule_text TEXT,
  embedding vector(1536),
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS moderation_audit (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  text TEXT,
  policy_hits JSONB,
  allowed BOOLEAN,
  created_at TIMESTAMPTZ DEFAULT now()
);