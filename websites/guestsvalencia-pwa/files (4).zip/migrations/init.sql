CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS embeddings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  model TEXT NOT NULL,
  dim INT NOT NULL,
  content TEXT NOT NULL,
  embedding vector(1536),
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS embeddings_embedding_idx ON embeddings USING ivfflat (embedding vector_cosine_ops) WITH (lists=100);

CREATE TABLE IF NOT EXISTS revenue_events (
  id BIGSERIAL PRIMARY KEY,
  event_type TEXT NOT NULL,
  payload JSONB,
  reward NUMERIC,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS agent_stats (
  agent TEXT PRIMARY KEY,
  trials INT DEFAULT 0,
  success INT DEFAULT 0,
  total_reward NUMERIC DEFAULT 0
);

CREATE TABLE IF NOT EXISTS kids_moderation_log (
  id BIGSERIAL PRIMARY KEY,
  text TEXT,
  category TEXT,
  blocked BOOLEAN,
  created_at TIMESTAMPTZ DEFAULT now()
);