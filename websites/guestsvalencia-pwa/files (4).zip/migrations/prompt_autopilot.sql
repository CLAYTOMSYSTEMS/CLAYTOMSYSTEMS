CREATE TABLE IF NOT EXISTS prompt_autopilot_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  experiment TEXT,
  avg_score NUMERIC,
  raw JSONB,
  created_at TIMESTAMPTZ DEFAULT now()
);