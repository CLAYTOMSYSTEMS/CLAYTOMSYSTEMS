CREATE TABLE IF NOT EXISTS pricing_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source TEXT,
  event_type TEXT,
  payload JSONB,
  start_time TIMESTAMPTZ,
  end_time TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS pricing_elasticity (
  listing_id TEXT,
  season TEXT,
  elasticity NUMERIC,
  updated_at TIMESTAMPTZ DEFAULT now(),
  PRIMARY KEY(listing_id, season)
);

CREATE TABLE IF NOT EXISTS price_actions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id TEXT,
  old_price NUMERIC,
  new_price NUMERIC,
  rationale TEXT,
  dry_run BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
);