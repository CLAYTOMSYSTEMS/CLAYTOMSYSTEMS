CREATE TABLE IF NOT EXISTS voice_datasets (
  sample_id UUID PRIMARY KEY,
  transcript TEXT,
  duration_seconds NUMERIC,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS voice_models (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  model_name TEXT UNIQUE,
  status TEXT,
  artifact_path TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);