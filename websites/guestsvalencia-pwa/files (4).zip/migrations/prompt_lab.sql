CREATE TABLE IF NOT EXISTS prompts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  version INT NOT NULL,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS prompt_experiments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  variants JSONB, -- {A: promptId, B: promptId, ...}
  strategy TEXT, -- bandit|even|thompson
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS prompt_experiment_stats (
  experiment_id UUID,
  variant TEXT,
  impressions INT DEFAULT 0,
  reward NUMERIC DEFAULT 0,
  PRIMARY KEY(experiment_id, variant)
);