CREATE TABLE IF NOT EXISTS price_experiments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id TEXT,
  base_price NUMERIC,
  test_price NUMERIC,
  outcome BOOLEAN,
  revenue NUMERIC,
  created_at TIMESTAMPTZ DEFAULT now()
);