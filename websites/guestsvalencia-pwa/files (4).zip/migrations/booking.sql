CREATE TABLE IF NOT EXISTS listings (
  id TEXT PRIMARY KEY,
  title TEXT,
  base_price NUMERIC,
  metadata JSONB
);

CREATE TABLE IF NOT EXISTS bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id TEXT NOT NULL REFERENCES listings(id),
  guest_name TEXT,
  checkin_date DATE,
  checkout_date DATE,
  total_price NUMERIC,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS lock_codes (
  booking_id UUID REFERENCES bookings(id),
  code TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);