CREATE TABLE IF NOT EXISTS autopilot_decision_conflicts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  experiment TEXT,
  action_attempt TEXT,
  blocked_reason TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);