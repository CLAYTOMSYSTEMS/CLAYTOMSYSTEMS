'use client';
import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Points, PointMaterial } from '@react-three/drei';
import * as THREE from 'three';

function Particles() {
  const ref = useRef<any>();
  const count = 4000;
  const positions = useMemo(()=> {
    const p = new Float32Array(count*3);
    for (let i=0;i<count;i++){
      const r = Math.random()*18;
      const theta = Math.random()*Math.PI*2;
      const phi = Math.acos((Math.random()*2)-1);
      p[i*3] = r*Math.sin(phi)*Math.cos(theta);
      p[i*3+1] = r*Math.sin(phi)*Math.sin(theta);
      p[i*3+2] = r*Math.cos(phi);
    }
    return p;
  },[]);
  useFrame((state)=>{
    if(ref.current){
      ref.current.rotation.y += 0.0008;
      ref.current.rotation.x += 0.0002;
    }
  });
  return (
    <group ref={ref}>
      <Points positions={positions} stride={3} frustumCulled>
        <PointMaterial transparent color="#7ddcff" size={0.08} sizeAttenuation depthWrite={false}/>
      </Points>
    </group>
  );
}

export default function MolecularScene() {
  return (
    <Canvas style={{position:'fixed', inset:0, zIndex:0}} camera={{position:[0,0,35], fov:55}}>
      <color attach="background" args={['#020409']}/>
      <Particles />
      <ambientLight intensity={0.3}/>
      <pointLight position={[10,10,10]} intensity={1.2}/>
    </Canvas>
  );
}