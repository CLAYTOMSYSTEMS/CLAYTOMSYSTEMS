'use client';
import React, { useEffect, useState } from 'react';

interface Kpi {
  id: string; label: string; value: string; delta?: string; up?: boolean;
}

export default function Dashboard() {
  const [kpis,setKpis] = useState<Kpi[]>([]);

  useEffect(()=>{
    // Replace with real fetch
    setKpis([
      { id:'rev', label:'Revenue 24h', value:'€18.25K', delta:'+6%', up:true },
      { id:'occ', label:'Occupancy 30d', value:'78%', delta:'+2%', up:true },
      { id:'adr', label:'ADR Actual', value:'€142', delta:'+1%', up:true },
      { id:'pace', label:'Pace Variance', value:'+6%', delta:'+1%', up:true },
      { id:'sent', label:'Sentiment Index', value:'74', delta:'+3%', up:true },
      { id:'uplift', label:'Pricing Uplift', value:'+11%', delta:'+1%', up:true },
    ]);
  },[]);

  return (
    <div className="glass scroll-y" style={{padding:20, display:'flex', flexDirection:'column', gap:24}}>
      <KpiGrid kpis={kpis}/>
      <Section title="Acciones Recientes">
        <ActionItem text="Price adjusted Property A €130 → €138 (demand boost)" />
        <ActionItem text="Availability sync Airbnb (12 listings) OK" />
        <ActionItem text="Lead nurturing email batch sent" />
      </Section>
      <Section title="Anomalías">
        <Anomaly text="Property B pacing lag -15% vs target" severity="warn"/>
        <Anomaly text="Booking.com sync latency 4.2s" severity="low"/>
      </Section>
      <Section title="Tareas Predictivas">
        <Task text="HVAC filter inspection (Property C)" />
        <Task text="Plumbing check low priority (Property D)" low />
      </Section>
    </div>
  );
}

function KpiGrid({kpis}:{kpis:Kpi[]}) {
  return (
    <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(160px,1fr))', gap:16}}>
      {kpis.map(k=>(
        <div key={k.id} className="glass" style={{padding:'12px 14px'}}>
          <div style={{fontSize:11, letterSpacing:'1px', opacity:0.6}}>{k.label}</div>
            <div style={{fontSize:23, fontWeight:600, background:'var(--accent-grad)', WebkitBackgroundClip:'text', color:'transparent'}}>{k.value}</div>
          <div style={{fontSize:11, color: k.up ? 'var(--ok)' : 'var(--danger)'}}>{k.delta}</div>
        </div>
      ))}
    </div>
  );
}

function Section({title, children}:{title:string;children:any}){
  return (
    <div>
      <div style={{fontSize:12, opacity:0.6, letterSpacing:1, marginBottom:8}}>{title}</div>
      <div style={{display:'flex', flexDirection:'column', gap:10}}>
        {children}
      </div>
    </div>
  );
}

function ActionItem({text}:{text:string}) {
  return <div style={{fontSize:12, opacity:0.85}}>{text}</div>;
}
function Anomaly({text,severity}:{text:string;severity:'warn'|'low'}) {
  const c = severity==='warn' ? 'var(--warn)' : '#888';
  return <div style={{fontSize:12,color:c}}>{text}</div>;
}
function Task({text,low}:{text:string;low?:boolean}){
  return <div style={{fontSize:12, color: low?'#aaa':'var(--ok)'}}>{text}</div>;
}