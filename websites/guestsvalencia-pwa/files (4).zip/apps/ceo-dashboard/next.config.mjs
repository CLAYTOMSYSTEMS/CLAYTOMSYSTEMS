const nextConfig = {
  experimental:{ appDir:true }
};
export default nextConfig;