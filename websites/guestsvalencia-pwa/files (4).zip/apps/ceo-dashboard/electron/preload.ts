import { contextBridge, ipcRenderer } from 'electron';
contextBridge.exposeInMainWorld('sandraApp', {
  version: () => ipcRenderer.invoke('getVersion')
});