import { app, BrowserWindow, nativeTheme, ipcMain } from 'electron';
import path from 'path';

function createWindow() {
  const win = new BrowserWindow({
    width: 1600,
    height: 1000,
    backgroundColor: '#05070b',
    vibrancy: 'under-window',
    titleBarStyle: 'hiddenInset',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname,'preload.js')
    }
  });
  win.loadURL(process.env.CEO_DASHBOARD_URL || 'http://localhost:4001');
}

app.whenReady().then(()=>{
  nativeTheme.themeSource = 'dark';
  createWindow();
  app.on('activate', ()=>{
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});
app.on('window-all-closed', ()=> {
  if (process.platform !== 'darwin') app.quit();
});

ipcMain.handle('getVersion', ()=>({ version: app.getVersion() }));