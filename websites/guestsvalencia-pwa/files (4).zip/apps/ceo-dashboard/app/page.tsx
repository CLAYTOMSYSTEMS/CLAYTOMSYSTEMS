'use client';
import { Suspense } from 'react';
import dynamic from 'next/dynamic';
import Dashboard from '../components/Dashboard';

const Scene = dynamic(()=>import('../components/MolecularScene'), { ssr:false });

export default function Home() {
  return (
    <>
      <Scene />
      <div style={{position:'absolute', inset:0, padding:24, display:'flex', flexDirection:'column', gap:24}}>
        <HeaderBar />
        <div style={{display:'grid', gridTemplateColumns:'320px 1fr 420px', gap:24, flex:1, minHeight:0}}>
          <SidebarLeft />
          <Dashboard />
          <RightPanel />
        </div>
      </div>
    </>
  );
}

function HeaderBar(){
  return (
    <div className="glass" style={{padding:'12px 20px', display:'flex', justifyContent:'space-between', alignItems:'center'}}>
      <h1 style={{fontSize:18, letterSpacing:1, margin:0}}>Sandra IA 7.0 – CEO Command Center</h1>
      <div style={{display:'flex', gap:12}}>
        <button className="glass" style={{padding:'8px 14px', cursor:'pointer'}}>Snapshot</button>
        <button className="glass" style={{padding:'8px 14px', cursor:'pointer'}}>Training</button>
        <button className="glass" style={{padding:'8px 14px', cursor:'pointer'}}>Settings</button>
      </div>
    </div>
  );
}

function SidebarLeft(){
  return (
    <div className="glass scroll-y" style={{padding:16}}>
      <Section title="Agentes">
        <AgentStatus name="Airbnb" status="OK" latency={132}/>
        <AgentStatus name="Booking" status="OK" latency={144}/>
        <AgentStatus name="Pricing" status="OK" latency={210}/>
        <AgentStatus name="GuestExp" status="OK" latency={98}/>
        <AgentStatus name="Marketing" status="DEGRADED" latency={520}/>
      </Section>
      <Section title="Flags">
        <FlagItem label="ReasoningAgent" active />
        <FlagItem label="Multimodal" active />
        <FlagItem label="Dense Retrieval" active />
        <FlagItem label="Multi-modal Retrieval" active={false}/>
      </Section>
      <Section title="Acciones Rápidas">
        <QuickButton label="Forzar Repricing" />
        <QuickButton label="Sync OTA" />
        <QuickButton label="Rebuild Embeddings" />
      </Section>
    </div>
  );
}

function RightPanel(){
  return (
    <div className="glass" style={{display:'flex', flexDirection:'column', padding:16, gap:16}}>
      <h3 style={{margin:0, fontSize:14, letterSpacing:1}}>Conversación / Avatar</h3>
      <div style={{flex:1, background:'#111', borderRadius:16, position:'relative'}}>
        <div style={{position:'absolute', inset:0, display:'flex',alignItems:'center', justifyContent:'center', fontSize:12, opacity:0.5}}>
          Avatar Stream (4K – placeholder)
        </div>
      </div>
      <div style={{display:'flex', gap:8}}>
        <input placeholder="Mensaje manual al huésped..." style={{flex:1, background:'#1a1f29', border:'1px solid #2a3140', borderRadius:8, padding:'8px 12px'}}/>
        <button className="glass" style={{padding:'8px 14px'}}>Enviar</button>
      </div>
      <div style={{display:'grid', gridTemplateColumns:'repeat(2,1fr)', gap:12}}>
        <MetricCard title="Latencia TTS p95" value="312ms" diff="-5%" up />
        <MetricCard title="Barge Interrupt" value="124ms" diff="+2%" />
      </div>
    </div>
  );
}

function Section({title, children}:{title:string;children:any}) {
  return (
    <div style={{marginBottom:18}}>
      <div style={{fontSize:11, letterSpacing:1, opacity:0.6, marginBottom:6}}>{title}</div>
      <div style={{display:'flex', flexDirection:'column', gap:8}}>{children}</div>
    </div>
  );
}

function AgentStatus({name,status,latency}:{name:string;status:string;latency:number}) {
  const color = status==='OK' ? 'var(--ok)' : status==='DEGRADED' ? 'var(--warn)' : 'var(--danger)';
  return (
    <div className="glass" style={{padding:10, display:'flex', justifyContent:'space-between', alignItems:'center', background:'rgba(255,255,255,0.04)'}}>
      <span style={{fontSize:12}}>{name}</span>
      <span style={{fontSize:11, color}}>{status} • {latency}ms</span>
    </div>
  );
}

function FlagItem({label,active}:{label:string;active:boolean}){
  return (
    <div style={{display:'flex', justifyContent:'space-between', fontSize:12}}>
      <span>{label}</span>
      <span style={{color: active?'var(--ok)':'var(--danger)'}}>{active?'ON':'OFF'}</span>
    </div>
  );
}

function QuickButton({label}:{label:string}){
  return <button className="glass" style={{padding:'8px 12px', fontSize:12, cursor:'pointer'}}>{label}</button>;
}

function MetricCard({title,value,diff,up}:{title:string;value:string;diff:string;up?:boolean}){
  return (
    <div className="glass metric-card">
      <span className="metric-title">{title}</span>
      <span className="metric-value">{value}</span>
      <span className={`metric-diff ${up?'up':'down'}`}>{diff}</span>
    </div>
  );
}