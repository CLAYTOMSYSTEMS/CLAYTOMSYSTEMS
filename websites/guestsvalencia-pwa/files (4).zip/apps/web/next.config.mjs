/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: { appDir: true },
  i18n: {
    locales: ['es', 'en', 'fr', 'de', 'it'],
    defaultLocale: 'es'
  }
};
export default nextConfig;