import '../globals.css';
import React from 'react';

export const metadata = {
  title: 'Sandra IA 7.0',
  description: 'Ecosistema PropTech Inteligente'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body>
        <header className="p-4 bg-slate-800 flex justify-between">
          <h1 className="font-bold">Sandra IA 7.0</h1>
          <nav className="space-x-4">
            <a href="/" className="hover:underline">Home</a>
            <a href="/login" className="hover:underline">Login</a>
            <a href="/dashboard" className="hover:underline">Dashboard</a>
          </nav>
        </header>
        <main className="p-6">{children}</main>
      </body>
    </html>
  );
}