async function fetchProps() {
  const res = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/properties`, { cache: 'no-store' });
  return res.json();
}

export default async function Dashboard() {
  const data = await fetchProps();
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold">Dashboard (Demo)</h2>
      <ul className="space-y-2">
        {data.properties?.map((p: any) => (
          <li key={p.id} className="p-3 rounded bg-slate-800">
            <strong>{p.title}</strong>
            <p className="text-xs opacity-70">{p.description}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}