'use client';
import { useState } from 'react';

export default function CTA() {
  const [email,setEmail] = useState('');
  const [sent,setSent] = useState(false);
  async function submit() {
    const res = await fetch('/api/leads', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ email, intent:'booking', notes:'fast funnel' })
    });
    if (res.ok) setSent(true);
  }
  return (
    <div className="max-w-md space-y-4">
      <h2 className="text-2xl font-bold">Reserva Inteligente con Sandra</h2>
      <p>Recibe una oferta personalizada en minutos.</p>
      {!sent ? <>
        <input className="w-full p-2 rounded bg-slate-800"
          value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email"/>
        <button onClick={submit} className="bg-indigo-600 px-4 py-2 rounded">Quiero mi oferta</button>
      </> : <p className="text-green-400">¡Registro recibido! Te contactaremos enseguida.</p>}
    </div>
  );
}