export default function Home() {
  return (
    <div className="space-y-4">
      <h2 className="text-3xl font-semibold">Bienvenido a Sandra IA 7.0</h2>
      <p>Plataforma Conversacional PropTech Multilingüe.</p>
      <p className="text-sm opacity-70">
        Fase 0 - Estructura inicial. Próximamente: Reservas, NLU avanzada, Barge-In real.
      </p>
    </div>
  );
}