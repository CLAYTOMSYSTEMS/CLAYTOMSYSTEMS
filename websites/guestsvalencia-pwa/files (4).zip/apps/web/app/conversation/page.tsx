'use client';
import { useEffect, useRef, useState } from 'react';

export default function ConversationPage() {
  const [connected, setConnected] = useState(false);
  const [partial, setPartial] = useState('');
  const [finals, setFinals] = useState<string[]>([]);
  const [systemSpeaking, setSystemSpeaking] = useState(false);
  const wsRef = useRef<WebSocket|null>(null);
  const avatarWsRef = useRef<WebSocket|null>(null);
  const pcRef = useRef<RTCPeerConnection|null>(null);
  const remoteAudioRef = useRef<HTMLAudioElement|null>(null);
  const localStreamRef = useRef<MediaStream|null>(null);
  const bargePendingRef = useRef(false);

  async function connect() {
    const ws = new WebSocket(process.env.NEXT_PUBLIC_REALTIME_WS!);
    wsRef.current = ws;
    ws.onmessage = async (e) => {
      const msg = JSON.parse(e.data);
      if (msg.type === 'welcome') {
        await setupWebRTC();
      } else if (msg.type === 'answer') {
        await pcRef.current?.setRemoteDescription(msg.answer);
      } else if (msg.type === 'ice_candidate') {
        await pcRef.current?.addIceCandidate(msg.candidate).catch(()=>{});
      } else if (msg.type === 'stt_partial') {
        setPartial(msg.text);
      } else if (msg.type === 'stt_final') {
        setFinals(f => [...f, msg.text]);
        setPartial('');
      } else if (msg.type === 'tts_start') {
        setSystemSpeaking(true);
      } else if (msg.type === 'tts_end' || msg.type === 'tts_interrupted') {
        setSystemSpeaking(false);
      }
    };
    ws.onopen = () => setConnected(true);
  }

  async function setupWebRTC() {
    const pc = new RTCPeerConnection({ iceServers: [{ urls:'stun:stun.l.google.com:19302' }] });
    pcRef.current = pc;
    localStreamRef.current = await navigator.mediaDevices.getUserMedia({ audio:true });
    localStreamRef.current.getTracks().forEach(t => pc.addTrack(t, localStreamRef.current!));

    pc.ontrack = (evt) => {
      if (!remoteAudioRef.current) {
        remoteAudioRef.current = document.createElement('audio');
        remoteAudioRef.current.autoplay = true;
        document.body.appendChild(remoteAudioRef.current);
      }
      remoteAudioRef.current.srcObject = evt.streams[0];
    };
    pc.onicecandidate = (e) => {
      if (e.candidate) {
        wsRef.current?.send(JSON.stringify({ type: 'ice_candidate', candidate: e.candidate }));
      }
    };
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    wsRef.current?.send(JSON.stringify({ type: 'offer', offer }));
    initAvatarSocket();
    initVAD();
  }

  function initAvatarSocket() {
    const a = new WebSocket('ws://localhost:4200/avatar');
    avatarWsRef.current = a;
    a.onmessage = (e) => {
      const msg = JSON.parse(e.data);
      if (msg.type === 'viseme') {
        // Future: sync a canvas / video overlay
      }
    };
  }

  function initVAD() {
    const ctx = new AudioContext();
    const src = ctx.createMediaStreamSource(localStreamRef.current!);
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 2048;
    src.connect(analyser);
    const data = new Float32Array(analyser.fftSize);
    let speaking = false;
    function loop() {
      analyser.getFloatTimeDomainData(data);
      let rms=0;
      for (let i=0;i<data.length;i++) rms += data[i]*data[i];
      rms = Math.sqrt(rms / data.length);
      if (rms > 0.02) {
        if (!speaking) {
          speaking = true;
          // BARDE IN
          if (systemSpeaking && !bargePendingRef.current) {
            wsRef.current?.send(JSON.stringify({ type: 'barge_in' }));
            bargePendingRef.current = true;
          }
        }
      } else {
        if (speaking) {
          speaking = false;
          bargePendingRef.current = false;
          // rely on STT endpoint detection in backend
        }
      }
      requestAnimationFrame(loop);
    }
    loop();
  }

  function sendText() {
    const text = prompt('Mensaje usuario');
    if (text) {
      wsRef.current?.send(JSON.stringify({ type: 'user_message', payload: { text }}));
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold flex items-center gap-2">
        Conversación (Avatar & Barge-In) { systemSpeaking && <span className="text-xs bg-indigo-600 px-2 py-1 rounded">TTS</span>}
      </h2>
      {!connected && <button onClick={connect} className="bg-green-600 px-4 py-2 rounded">Conectar</button>}
      {connected && (
        <div className="flex gap-4">
          <button onClick={sendText} className="bg-slate-700 px-3 py-2 rounded">Enviar Texto</button>
        </div>
      )}
      <section className="grid md:grid-cols-2 gap-6">
        <div>
          <h3 className="font-bold">Parcial</h3>
          <pre className="bg-slate-800 p-2 rounded h-24 overflow-auto">{partial}</pre>
          <h3 className="font-bold mt-4">Final</h3>
            <pre className="bg-slate-800 p-2 rounded h-48 overflow-auto">
              {finals.map((f,i)=><div key={i}>{f}</div>)}
            </pre>
        </div>
        <div>
          <h3 className="font-bold">Avatar</h3>
          <div className="bg-black h-64 rounded flex items-center justify-center text-sm opacity-70">
            Stream Video (HeyGen) – Integrar WebRTC remoto
          </div>
          <p className="text-xs mt-2 opacity-70">
            (Fase 1: canal viseme listo. Próximo paso: attach WebRTC video track al avatar player)
          </p>
        </div>
      </section>
    </div>
  );
}