'use client';
import { useState } from 'react';

export default function LoginPage() {
  const [email,setEmail] = useState('');
  const [password,setPassword] = useState('');
  const [token,setToken] = useState<string|undefined>();

  async function submit() {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/auth/login`, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (data.token) setToken(data.token);
  }

  return (
    <div className="max-w-sm space-y-4">
      <h2 className="text-xl font-bold">Login</h2>
      <input className="w-full p-2 rounded bg-slate-800"
        placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
      <input className="w-full p-2 rounded bg-slate-800"
        placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      <button onClick={submit} className="bg-indigo-600 px-4 py-2 rounded">Entrar</button>
      {token && <pre className="text-xs break-all">{token}</pre>}
    </div>
  );
}