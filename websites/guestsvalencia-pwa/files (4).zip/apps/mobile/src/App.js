import React, { useState } from 'react';
import { SafeAreaView, Text, TextInput, Button, ScrollView } from 'react-native';

export default function App() {
  const [email,setEmail] = useState('admin@example.com');
  const [password,setPassword] = useState('');
  const [token,setToken] = useState('');
  const [logs,setLogs] = useState([]);

  async function login() {
    const res = await fetch('http://localhost:4000/auth/login', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (data.token) setToken(data.token);
    addLog(JSON.stringify(data));
  }

  function addLog(msg) {
    setLogs(l => [...l, msg]);
  }

  return (
    <SafeAreaView style={{flex:1, padding:16}}>
      <Text style={{fontSize:20,fontWeight:'600'}}>Sandra IA Mobile (Fase 0)</Text>
      <TextInput placeholder="Email" style={{borderWidth:1, marginVertical:8, padding:8}} value={email} onChangeText={setEmail}/>
      <TextInput placeholder="Password" secureTextEntry style={{borderWidth:1, marginVertical:8, padding:8}} value={password} onChangeText={setPassword}/>
      <Button title="Login" onPress={login}/>
      <Text selectable style={{fontSize:12, marginVertical:8}}>Token: {token.slice(0,50)}...</Text>
      <ScrollView style={{flex:1, marginTop:8}}>
        {logs.map((l,i)=> <Text key={i} style={{fontSize:11}}>{l}</Text>)}
      </ScrollView>
    </SafeAreaView>
  );
}