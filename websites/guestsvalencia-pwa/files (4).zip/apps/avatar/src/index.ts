import 'dotenv/config';
import { createServer } from 'http';
import { createHeyGenAvatarSession } from 'providers-heygen';
import { WebSocketServer } from 'ws';

// This service relays viseme events + provides a simplified WebSocket API
const httpServer = createServer();
const wss = new WebSocketServer({ server: httpServer, path: '/avatar' });

wss.on('connection', async (ws) => {
  const session = createHeyGenAvatarSession();
  await session.ensureSession();
  session.onViseme(v => {
    ws.send(JSON.stringify({ type: 'viseme', payload: v }));
  });

  ws.on('message', (raw) => {
    try {
      const msg = JSON.parse(raw.toString());
      if (msg.type === 'pcm_chunk') {
        session.sendAudioFrame(Buffer.from(msg.data, 'base64'));
      }
    } catch {}
  });

  ws.send(JSON.stringify({ type: 'ready' }));
});

const port = process.env.AVATAR_PORT ? Number(process.env.AVATAR_PORT) : 4200;
httpServer.listen(port, () => {
  console.log('[AVATAR] Listening on', port);
});