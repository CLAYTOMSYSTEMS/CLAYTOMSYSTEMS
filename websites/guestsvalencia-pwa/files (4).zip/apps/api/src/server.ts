// (extract only the modified part)
import { bookingRoutes } from './routes/bookings';

// inside buildServer after other app.register calls:
app.register(bookingRoutes, { prefix: '/bookings' });