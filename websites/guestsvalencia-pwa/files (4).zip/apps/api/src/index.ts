import 'dotenv/config';
import { buildServer } from './server';

const port = process.env.API_PORT ? Number(process.env.API_PORT) : 4000;

async function start() {
  const app = await buildServer();
  try {
    await app.listen({ port, host: '0.0.0.0' });
    console.log('[API] Listening on', port);
  } catch (e) {
    app.log.error(e);
    process.exit(1);
  }
}

start();