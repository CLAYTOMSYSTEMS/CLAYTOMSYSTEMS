import { FastifyPluginAsync } from 'fastify';
import { PrismaClient } from '@prisma/client';
import { basicNLUSlotExtract } from '../services/nlu';
import { embedAndSearch } from '../services/vectorSearch';

const prisma = new PrismaClient();

export const conversationRoutes: FastifyPluginAsync = async (app) => {

  app.post('/start', async (req, reply) => {
    const { locale = 'es' } = req.body as any;
    const convo = await prisma.conversation.create({ data: { locale } });
    return { conversationId: convo.id };
  });

  app.post('/nlu/slots', async (req, reply) => {
    const { text, locale = 'es' } = req.body as any;
    const slots = basicNLUSlotExtract(text, locale);
    return { slots };
  });

  app.post('/semantic/search', async (req, reply) => {
    const { query, locale = 'es' } = req.body as any;
    const results = await embedAndSearch(query, locale);
    return { results };
  });

};