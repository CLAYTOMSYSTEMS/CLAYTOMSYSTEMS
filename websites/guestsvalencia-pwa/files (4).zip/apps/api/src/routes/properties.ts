import { FastifyPluginAsync } from 'fastify';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const propertyRoutes: FastifyPluginAsync = async (app) => {
  app.get('/', async (req: any) => {
    const locale = (req.query as any).locale || 'es';
    const props = await prisma.property.findMany({ take: 50 });
    return { properties: props.map(p => ({ ...p, locale })) };
  });
};