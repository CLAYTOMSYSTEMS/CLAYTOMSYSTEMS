import { FastifyPluginAsync } from 'fastify';
import { PrismaClient } from '@prisma/client';
import { calculateQuote } from '../services/pricing';

const prisma = new PrismaClient();

export const bookingRoutes: FastifyPluginAsync = async (app) => {

  app.post('/quote', async (req, reply) => {
    const { propertyId, checkIn, checkOut, guests = 1 } = req.body as any;
    if (!propertyId || !checkIn || !checkOut) return reply.code(400).send({ error: 'MISSING_FIELDS' });
    const prop = await prisma.property.findUnique({ where: { id: propertyId } });
    if (!prop) return reply.code(404).send({ error: 'PROPERTY_NOT_FOUND' });
    const quote = calculateQuote({
      baseRate: prop.baseRate,
      checkIn: new Date(checkIn),
      checkOut: new Date(checkOut),
      guests
    });
    return { quote };
  });

  app.post('/', { preHandler: [(app as any).auth] }, async (req: any, reply) => {
    const { propertyId, checkIn, checkOut, totalPrice } = req.body;
    if (!propertyId || !checkIn || !checkOut || !totalPrice) return reply.code(400).send({ error: 'MISSING_FIELDS' });
    const booking = await prisma.booking.create({
      data: {
        userId: req.user.sub,
        propertyId,
        checkIn: new Date(checkIn),
        checkOut: new Date(checkOut),
        totalPrice,
        status: 'CONFIRMED'
      }
    });
    return { booking };
  });

  app.get('/:id', { preHandler: [(app as any).auth] }, async (req: any, reply) => {
    const b = await prisma.booking.findUnique({ where: { id: req.params.id } });
    if (!b) return reply.code(404).send({ error: 'NOT_FOUND' });
    return { booking: b };
  });
};