import { FastifyPluginAsync } from 'fastify';
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

export const authRoutes: FastifyPluginAsync = async (app) => {

  app.post('/register', async (req, reply) => {
    const body: any = req.body;
    if (!body.email || !body.password) return reply.code(400).send({ error: 'MISSING_FIELDS' });
    const exists = await prisma.user.findUnique({ where: { email: body.email } });
    if (exists) return reply.code(409).send({ error: 'EMAIL_EXISTS' });
    const passwordHash = await bcrypt.hash(body.password, 10);
    await prisma.user.create({ data: { email: body.email, passwordHash } });
    return { ok: true };
  });

  app.post('/login', async (req, reply) => {
    const body: any = req.body;
    const user = await prisma.user.findUnique({ where: { email: body.email } });
    if (!user) return reply.code(401).send({ error: 'INVALID_CREDENTIALS' });
    const ok = await bcrypt.compare(body.password, user.passwordHash);
    if (!ok) return reply.code(401).send({ error: 'INVALID_CREDENTIALS' });
    const token = app.jwt.sign({ sub: user.id, role: user.role });
    return { token };
  });

  app.get('/me', { preHandler: [ (app as any).auth ] }, async (req: any) => {
    const user = await prisma.user.findUnique({ where: { id: req.user.sub } });
    return { user: user && { id: user.id, email: user.email, role: user.role } };
  });

};