import { FastifyPluginAsync } from 'fastify';

export const healthRoutes: FastifyPluginAsync = async (app) => {
  app.get('/live', async () => ({ status: 'live' }));
  app.get('/ready', async () => ({ status: 'ready' }));
};