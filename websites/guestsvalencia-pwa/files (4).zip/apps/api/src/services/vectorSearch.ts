import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const EMBED_MODEL = process.env.OPENAI_EMBED_MODEL || 'text-embedding-3-small';

export async function openAIEmbed(text: string) {
  const res = await fetch('https://api.openai.com/v1/embeddings', {
    method:'POST',
    headers:{
      'Content-Type':'application/json',
      'Authorization':`Bearer ${process.env.OPENAI_API_KEY}`
    },
    body: JSON.stringify({ input: text, model: EMBED_MODEL })
  });
  const json = await res.json();
  const vector = json.data[0].embedding as number[];
  // Convert float vector to bytes (naive: Float32Array)
  const buf = Buffer.from(new Float32Array(vector).buffer);
  return buf;
}

function cosine(a: Float32Array, b: Float32Array) {
  let dot=0,na=0,nb=0;
  for (let i=0;i<a.length;i++){ dot+=a[i]*b[i]; na+=a[i]*a[i]; nb+=b[i]*b[i]; }
  return dot / (Math.sqrt(na)*Math.sqrt(nb));
}

export async function embedAndSearch(query: string, _locale: string) {
  const qBuf = await openAIEmbed(query);
  const qF32 = new Float32Array(qBuf.buffer, qBuf.byteOffset, qBuf.byteLength/4);

  const docs = await prisma.embeddingDocument.findMany({ take: 100 });
  const scored = docs.map(d => {
    const f = new Float32Array(d.vector.buffer, d.vector.byteOffset, d.vector.byteLength/4);
    const score = cosine(qF32, f);
    return { id: d.id, source: d.source, text: d.text.slice(0,160), score };
  }).sort((a,b)=>b.score - a.score).slice(0,5);
  return scored;
}