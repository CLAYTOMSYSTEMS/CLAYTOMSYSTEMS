export function calculateQuote(opts: { baseRate: number; checkIn: Date; checkOut: Date; guests: number }) {
  const nights = Math.max(1, (opts.checkOut.getTime() - opts.checkIn.getTime()) / (1000*60*60*24));
  let subtotal = opts.baseRate * nights;
  if (opts.guests > 2) {
    subtotal += (opts.guests - 2) * 15 * nights;
  }
  const taxRate = parseFloat(process.env.DEFAULT_TAX_RATE || '0.10');
  const tax = Math.round(subtotal * taxRate);
  const total = subtotal + tax;
  return {
    nights,
    subtotal,
    tax,
    total,
    currency: process.env.DEFAULT_CURRENCY || 'EUR'
  };
}