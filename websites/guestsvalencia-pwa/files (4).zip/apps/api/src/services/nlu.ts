// Very basic placeholder; real version will call LLM w/ function calling.
export function basicNLUSlotExtract(text: string, locale: string) {
  const lower = text.toLowerCase();
  const slots: any = {};
  // Guests
  const guestsMatch = lower.match(/(\d+)\s+(personas|huespedes|guests)/);
  if (guestsMatch) slots.guests = Number(guestsMatch[1]);
  // Dates (very naive)
  if (lower.includes('mañana')) slots.check_in_relative = 'tomorrow';
  // Language pass-through
  slots.locale = locale;
  return slots;
}