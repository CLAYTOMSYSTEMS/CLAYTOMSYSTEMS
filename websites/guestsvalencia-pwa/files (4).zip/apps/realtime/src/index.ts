import 'dotenv/config';
import { WebSocketServer } from 'ws';
import { RTCPeerConnection, nonstandard } from 'wrtc';
import { getSTT, getTTS } from 'ai-core';
import { randomUUID } from 'crypto';

interface SessionState {
  id: string;
  language: string;
  speakingSystem: boolean;
  sttController?: any;
  currentTTSAbort?: () => void;
}

const wss = new WebSocketServer({ port: Number(process.env.REALTIME_PORT || 4100), path: '/ws' });
console.log('[REALTIME] Listening on', process.env.REALTIME_PORT || 4100);

wss.on('connection', (ws) => {
  const state: SessionState = {
    id: randomUUID(),
    language: 'es',
    speakingSystem: false
  };

  ws.send(JSON.stringify({ type: 'welcome', payload: { id: state.id }}));

  let pc: RTCPeerConnection | null = null;
  let outboundTrack: any;

  ws.on('message', async (raw) => {
    let msg: any;
    try { msg = JSON.parse(raw.toString()); } catch { return; }
    switch (msg.type) {
      case 'set_language':
        state.language = msg.payload?.language || 'es';
        break;
      case 'offer':
        pc = new RTCPeerConnection();
        setupPeer(pc, ws, state);
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        ws.send(JSON.stringify({ type: 'answer', answer }));
        break;
      case 'ice_candidate':
        if (pc && msg.candidate) {
          await pc.addIceCandidate(msg.candidate).catch(()=>{});
        }
        break;
      case 'user_message':
        handleUserText(msg.payload?.text || '', state, ws);
        break;
      case 'barge_in':
        if (state.speakingSystem) {
          interruptTTS(state, ws);
        }
        break;
      default:
        break;
    }
  });
});

function setupPeer(pc: RTCPeerConnection, ws: any, state: SessionState) {
  pc.onicecandidate = (e) => {
    if (e.candidate) ws.send(JSON.stringify({ type: 'ice_candidate', candidate: e.candidate }));
  };
  pc.ontrack = async (evt) => {
    if (evt.track.kind === 'audio') {
      startSTT(evt, state, ws);
    }
  };

  // Downstream audio track (PCM silence placeholder) using nonstandard MediaStreamTrackGenerator
  const generator = new nonstandard.RTCAudioSource();
  const track = generator.createTrack();
  const stream = new nonstandard.MediaStream();
  stream.addTrack(track);
  pc.addTrack(track, stream);

  // Provide simple API to push PCM frames during TTS:
  (state as any).pushPCM = (pcm: Buffer) => {
    const int16 = new Int16Array(pcm.buffer, pcm.byteOffset, pcm.byteLength/2);
    generator.onData({
      samples: int16,
      sampleRate: 16000,
      bitsPerSample: 16,
      channelCount: 1,
      numberOfFrames: int16.length
    });
  };
}

function startSTT(evt: RTCTrackEvent, state: SessionState, ws: any) {
  getSTT(state.language).then(async provider => {
    const stt = await provider.start({ language: state.language });
    state.sttController = stt;
    stt.onPartial(text => ws.send(JSON.stringify({ type: 'stt_partial', text })));
    stt.onFinal(text => {
      ws.send(JSON.stringify({ type: 'stt_final', text }));
      processFinalUserText(text, state, ws);
    });

    // Pulling audio frames
    const receiver = (evt.transceiver && evt.transceiver.receiver) || null;
    if (!receiver) return;
    // wrtc receiver raw is not fully trivial; using createReadStream hack:
    // @ts-ignore
    const rstream = receiver.createReadStream && receiver.createReadStream();
    if (rstream) {
      rstream.on('data', (data: Buffer) => {
        stt.pushPCM(data);
      });
    }
  });
}

function processFinalUserText(text: string, state: SessionState, ws: any) {
  // Basic intent detection (stub)
  if (/reserva|booking/i.test(text)) {
    ws.send(JSON.stringify({ type: 'intent', intent: 'booking_inquiry' }));
  }
  startTTSAnswer(`He recibido: ${text}`, state, ws);
}

function handleUserText(text: string, state: SessionState, ws: any) {
  processFinalUserText(text, state, ws);
}

async function startTTSAnswer(text: string, state: SessionState, ws: any) {
  interruptTTS(state, ws);
  state.speakingSystem = true;
  ws.send(JSON.stringify({ type: 'tts_start' }));
  const provider = getTTS(state.language);
  let abort = false;
  state.currentTTSAbort = () => { abort = true; };
  for await (const chunk of provider.stream({ text, language: state.language })) {
    if (abort) break;
    (state as any).pushPCM && (state as any).pushPCM(chunk);
  }
  if (!abort) {
    state.speakingSystem = false;
    ws.send(JSON.stringify({ type: 'tts_end' }));
  } else {
    ws.send(JSON.stringify({ type: 'tts_interrupted' }));
  }
  state.currentTTSAbort = undefined;
}

function interruptTTS(state: SessionState, ws: any) {
  if (state.speakingSystem && state.currentTTSAbort) {
    state.currentTTSAbort();
    state.speakingSystem = false;
  }
}