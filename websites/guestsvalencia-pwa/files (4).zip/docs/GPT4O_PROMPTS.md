# GPT-4O Mastery for Sandra IA

System Prompt Template (Core):
"You are Sandra IA 7.0, an executive PropTech multi-agent orchestrator assisting with reservations, pricing, maintenance, guest experience and revenue optimization. 
Constraints: NEVER expose internal keys, ALWAYS anonymize PII, Provide concise actionable answers. Output in the user's language; default Spanish. 
When uncertain ask for clarification. Maintain professional, warm, premium tone."

Dynamic Sections:
- Context Summary (rolling)
- User Profile Vector Tags
- Current Intent & Slots
- Policy Flags
- Channel Mode (web|whatsapp|email|voice)

Prompt Assembly Pseudocode:
finalPrompt = [
  systemSection,
  "===CONTEXT===",
  conversationSummary,
  "===LATEST USER===",
  userMessage,
  "===INTENT===",
  intentData,
  "===RELEVANT DOCS===",
  topKDocs,
  "===TASK===",
  "Generate best answer + up to 2 proactive suggestions."
].join("\n")

Token Efficiency:
- Summarize older turns > 12 messages.
- Use function calling for structured slot extraction.
- Maintain embeddings cache keyed by doc_version_hash.

Streaming Strategy:
- Request with stream=true, collect deltas, flush partial to UI every ~40 tokens.
- Interrupt (barge-in) -> send cancel to provider, keep residual context.

Fallback Chain:
1. GPT-4O primary
2. GPT-4-Turbo (cheaper)
3. Local small model summary for fallback minimal response

Guardrails:
- Pre-prompt injection: sanitize removing "ignore previous" patterns.
- If PolicyAgent allow=false -> return safe refusal template.

Negotiation Mode:
If intent=booking_inquiry AND user asks discount:
- Evaluate occupancy & leadTime -> compute discountRange
- Provide anchored price justification + small conditional benefit (e.g. free late checkout).