# Arquitectura Sandra IA 7.0 (Fase 0)

Capas:
- Web (Next.js) UI + i18n
- API (Fastify) Auth, Properties, Conversation bootstrap, Vector search
- Realtime (WS) turn-taking y placeholders TTS/STT (Barge-In futuro)
- AI Core (abstracciones TTS/STT)
- Conversation Engine (XState)
- Vector Store: pgvector (embeddingDocument)
- SDK (consumo unificado)
- Mobile (Expo)

Multi-idioma: i18n front + selección de voz TTS dinámica (see ai-core/selectVoice).