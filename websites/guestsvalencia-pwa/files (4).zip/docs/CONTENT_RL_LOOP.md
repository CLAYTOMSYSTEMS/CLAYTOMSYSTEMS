# Content RL Loop (CTR / Retention Optimization)

Cycle:
1. For each new video variant (thumbnail, hook, CTA) treat as arm.
2. Collect early metrics (view_velocity_1h, retention_30s, click_through).
3. Compute reward = 0.5*normalized(view_velocity_1h) + 0.3*retention_30s + 0.2*CTR.
4. Update bandit (CTRBandit or LinUCB).
5. If reward < threshold after N impressions => explore alt variant.
6. Promote best arms to “baseline set”.
7. Weekly retrain contextual model (features: time_slot, category, cluster_segment, style_code, environment_code).