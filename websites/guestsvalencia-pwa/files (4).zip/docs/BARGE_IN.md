# Barge-In Detalle

Estrategia:
1. VAD cliente detecta energía > umbral mientras TTS activo => envía barge_in.
2. Realtime service aborta generador TTS (currentTTSAbort()) y emite tts_interrupted.
3. STT continúa recibiendo audio sin reiniciar la sesión para menor latencia.
4. Tras STT final => TTS nueva respuesta.

Latencia Objetivo:
- Barge detection < 100ms desde inicio de voz.
- TTS stop < 150ms.

Mejoras:
- Añadir un pre-roll de 200ms para no cortar fonemas.
- Guardar frames TTS actuales para “resume” (futuro).