# Booking Intent (Plan)

Slots requeridos: location, check_in, check_out, guests
Proceso:
1. Detect intent (NLU)
2. Rellenar slots
3. /bookings/quote
4. Confirmación -> /bookings

A implementar Fase 1/2.