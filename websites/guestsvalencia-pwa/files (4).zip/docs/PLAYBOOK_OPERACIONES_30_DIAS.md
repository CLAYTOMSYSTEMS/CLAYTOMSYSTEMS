# PLAYBOOK OPERACIONES – 30 DÍAS  
Sandra IA 7.0 – Civilización Digital Autónoma  
Versión 1.0

## Objetivo
Asegurar operación impecable, mejorar iterativamente, activar métricas reales y preparar escalabilidad robusta.

---

## ROLES
| Rol | Responsabilidad |
|-----|------------------|
| Ops Lead | Revisa métricas diarias, coordina incidentes |
| Revenue Analyst | Valida pricing uplift / elasticidad |
| Safety Steward | Revisa guardrails anomalies / políticas |
| ML Engineer | Ajusta pesos autopilot / elasticity priors |
| DevOps | Despliegues, infraestructura, seguridad clave |

---

## SLO / SLAs INICIALES
| Métrica | Objetivo | Acción si se rompe |
|---------|----------|--------------------|
| Uptime ws-core | ≥ 99.5% | Revisar SystemHealth logs |
| Latencia LLM p95 | ≤ 5s | Cambiar modelo / reducir carga |
| Block Rate (guardrails) | ≤ 5% benign traffic | Ajustar thresholds |
| Pricing Suggestion Error (vs target) | ±15% | Recalibrar priors |
| Autopilot Acciones/día | ≤ 2 | Aumentar cooldown |
| Forecast Error (MAE 24h) | < 30% | Ajustar smoothing alpha |

---

## RITUAL DIARIO (DÍAS 1–30)
| Hora | Acción | Herramienta |
|------|--------|-------------|
| 08:00 | Ver panel “Sandra Express Ops” | Grafana |
| 08:10 | Chequear anomalies guardrails | Guardrails panel |
| 08:15 | Revisar eventos agent.decision.* (última hora) | NATS / Logs |
| 12:00 | Pricing sample: 5 listings → comparar contra baseline | pricing-ml / adv |
| 15:00 | Autopilot composite vs anterior | /prompt-autopilot/metrics |
| 18:00 | Guardrails new policies (si necesarias) | DSL UI + policy-signer |
| 20:00 | Snapshot diario (scripts) | backup script |
| 23:00 | Revisión rápida block rate & uplift incremental | Grafana |

---

## SEMANA 1 (DÍAS 1–7) – ESTABILIZACIÓN
- Tarea: Activar todos los subagentes en DRY_RUN=true.  
- Verificar logs no contienen excepciones recurrentes.  
- Ajustar thresholds guardrails si falsos positivos > tolerancia.  
- Validar pipeline forecast produce datos cada hora.

Checklist Fin Semana 1:
- [ ] Métrica agent_hub_decisions_total incrementa cada agente  
- [ ] Panel Revenue Impact muestra uplift_candidato (aunque sea 0)  
- [ ] 0 incidentes críticos sin detección previa  
- [ ] Block Rate < 5% (tráfico válido de prueba)

---

## SEMANA 2 (DÍAS 8–14) – ACTIVACIÓN CONTROLADA
- Habilitar DRY_RUN=false para autopilot (sólo promote → hold; rollback aún monitoreado).  
- Introducir 1 listing en “pricing apply mode” manual supervisado.  
- Voice fine-tune primera versión (quality check interno).  

Checklist Fin Semana 2:
- [ ] 1–2 promociones autopilot exitosas sin rollback  
- [ ] Pricing aplicado en listing piloto sin caída conversión >10%  
- [ ] Voz generada con latencia < 3.5s primer audio  
- [ ] Sin anomalías guardrails graves

---

## SEMANA 3 (DÍAS 15–21) – OPTIMIZACIÓN EXPERIMENTAL
- Introducir bandit factor (sugerencias ladder → seleccionar 2 niveles).  
- Expandir pricing apply a 20% del inventario.  
- Afinar weights composite autopilot (conv vs guard).  
- Activar panel Forecast PRO + comparar vs real.

Checklist Fin Semana 3:
- [ ] Uplift acumulado > 0 (o estable)  
- [ ] Forecast MAE < 35%  
- [ ] 0 escaladas manuales por saturación LLM  
- [ ] Block anomalies ≤ 1 / 3 días

---

## SEMANA 4 (DÍAS 22–30) – PREPARACIÓN ESCALA
- Preparar multi-región (duplicar edge-vector-cache en segunda región).  
- Simular failover llm-gateway → medir recuperación.  
- Activar signature ledger nightly digest.  
- Documentar runbooks incidentes (top 5 escenarios).  

Checklist Fin Semana 4:
- [ ] Segundo edge node responde < +40ms de diferencia  
- [ ] Failover test completado (cliente percibe <1 min interrupción)  
- [ ] Digest firmado generado 5 días consecutivos  
- [ ] Playbook incidentes publicado y versionado

---

## RUNBOOKS (RESUMEN)
1. Latencia LLM alta: Ver metrics p95 → route alternate model → reducir verbosity prompts.  
2. Bloqueo excesivo guardrails: Descargar última serie /stats → revisar DSL conflict → ajustar threshold vector.  
3. Caída revenue bookings: Ver pricing_experiments log → revert testPrice → set autopilot HOLD_FORCE=true.  
4. Voz artefacto corrupto: Validar hash artifact, relanzar training job, fallback a baseline TTS.  
5. NATS caída: Reintentar conexión; modo degradado subagentes (persistir decisiones local).  

---

## SCRIPTS DIARIOS / SEMANALES
| Script | Frecuencia | Propósito |
|--------|-----------|-----------|
| snapshot-config.sh | Diario | Guardar envs + políticas firmadas |
| verify-core.sh | Diario | Health de servicios críticos |
| anomaly-report.sh | Diario | Export anomaly rate |
| bandwidth-report.sh | Semanal | Cost inference |
| price-elasticity-refresh.sh | Semanal | Recalcular priors listados |

---

## ESCALATION MATRIX
| Severidad | Condición | Ventana respuesta | Responsable |
|-----------|-----------|-------------------|-------------|
| Critical | Uptime < 98% hora / Bookings = 0 60m | 15 min | Ops Lead |
| High | Block rate > 10% benign | 30 min | Safety Steward |
| Medium | Latencia p95 > 6.5s | 60 min | DevOps |
| Low | Uplift negativo 24h | 1 día | Revenue Analyst |

---

## MÉTRICAS DIARIAS A REPORTAR
- Composite Score Autopilot (min / max / media)  
- Uplift EUR (delta día)  
- Block Rate (%)  
- Forecast vs Actual (ratio)  
- Pricing Experiment Win Rate (%)  
- Cost per Booking (EUR estimado)  

---

## SALIDA DE 30 DÍAS (READY STATE)
Un ecosistema:  
- Con pricing aplicado a ≥ 50% inventario crítico.  
- Con autopilot estable (acciones ≤ 1 / día).  
- Con voz producción para interacción huésped premium.  
- Con dashboards adoptados por equipo (uso diario).  
- Con incidente crítico ≤ 1 y correctamente mitigado.

---
FIN DEL PLAYBOOK  