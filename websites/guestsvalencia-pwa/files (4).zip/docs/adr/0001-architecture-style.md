# 0001 - Architecture Style

Context:
Need scalable multi-agent conversational platform with strong modularity, retrieval, and compliance.

Decision:
Use microservices with gRPC for internal comms, Event Sourcing for conversations & bookings, CQRS for read optimization, Kafka as event backbone.

Consequences:
+ Clear bounded contexts
+ Replay & analytics via immutable log
- Increased operational complexity
- Requires robust DevOps maturity