# 0003 - Multi-Agent Orchestrator

Context:
Need scalable, modular agent chain with dynamic routing, emotion influence and policy enforcement.

Decision:
Central OrchestratorService that executes a lightweight classification + slot extraction + policy check + emotion aggregation → selects pipeline pattern (fast/retrieval/reasoning).

Consequences:
+ Extensible: add more agents (PricingAgent, NegotiationAgent).
+ Controlled latency: heavy reasoning only when needed.
- Additional complexity in debugging composite results.