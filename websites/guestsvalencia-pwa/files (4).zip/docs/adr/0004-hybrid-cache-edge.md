# 0004 - Hybrid Semantic Cache at Edge

Context:
Sub-100ms requirement for repeated semantic queries under global distribution.

Decision:
Use Cloudflare Worker semantic key hashing + short TTL + degrade path to sparse fallback if upstream > SLA threshold.

Consequences:
+ Reduces median retrieval latency drastically on popular queries.
- Potential stale results; rely on invalidation events (property.update) broadcasting purge.