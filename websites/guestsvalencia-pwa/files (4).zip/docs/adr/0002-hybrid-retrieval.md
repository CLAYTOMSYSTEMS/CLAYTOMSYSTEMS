# 0002 - Hybrid Retrieval Strategy

Decision:
Combine dense pgvector ANN + OpenSearch BM25 + multi-modal CLIP embeddings.

Rationale:
Property metadata & user questions vary; some lexical, some semantic, some image-driven. Hybrid improves recall & precision.

Implementation:
Tri-phase candidate generation -> normalization -> re-rank (LLM / cross-encoder). Semantic cache for repeated queries.

Risks:
Latency overhead (3 parallel queries). Mitigation: parallelization + caching results + precomputed centroids.