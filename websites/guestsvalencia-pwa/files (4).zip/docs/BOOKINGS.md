# Sistema Booking (Fase 1)

Endpoints:
POST /bookings/quote
POST /bookings
GET  /bookings/:id

Quote:
subtotal = baseRate * nights (+ extra guest adjustment)
tax = subtotal * DEFAULT_TAX_RATE
total = subtotal + tax

Pendiente Fase 2:
- Overbooking guard (check existing reservations overlap)
- Cancellation policies
- Payment integration (Stripe)
- Currency conversion (ECB daily rates)