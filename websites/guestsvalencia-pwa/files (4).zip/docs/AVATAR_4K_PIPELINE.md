# Avatar 4K HDR Pipeline – Sandra IA 7.0

Objetivo:
- Photorealistic 4K (3840x2160) @ 30–60 fps
- Latencia extremo-a-extremo (TTFF voz → frame lipsync) < 120 ms (objetivo futuro; etapa 1 < 250 ms)
- Cambios de vestuario y entorno en caliente (hot swap)
- Streaming WebRTC + fallback HLS (cuando la red degrada)
- Lipsync: phoneme→viseme < 50 ms offset
- Expresiones emocionales mapeadas de valence/arousal

Arquitectura por Capas:

1. Input Pipeline:
   - Texto / Audio (STT) → Orchestrator LLM → TTS (ElevenLabs o pipeline local)
   - TTS produce: audio PCM + phoneme timeline (timestamps)

2. Viseme Engine:
   - Phoneme->Viseme mapping table (IPA / provider mapping)
   - Temporal smoothing (Kalman / simple smoothing) para reducir jitter
   - Emotion blending (valence/arousal → micro expressions weights)

3. Render Core (GPU Node):
   - Motor: Elección
     - A) Unreal Engine (MetaHuman) con LiveLink + WebRTC Pixel Streaming
     - B) NVIDIA Maxine / Omniverse Audio2Face (blendshape driver)
     - C) Custom Three.js WebGPU (para baja lat / estilo stylized)
   - Este blueprint asume path A (Unreal Pixel Streaming) + opcional Audio2Face para lipsync mejorado.
   - Material Graph para HDR + tonemapping ACES

4. Wardrobe & Environment Manager:
   - Data-driven: JSON describe assets (mesh variants, texture sets, LOD)
   - Dynamic load via Unreal Asset Manager (async)
   - Environment switching: pre-cache lightmaps; transición crossfade mediante cámara virtual + post-process blend

5. Composition:
   - Overlays: live crypto prices, branding watermark, dynamic lower third
   - Compositor GPU (vulkan/gstreamer) combina feed avatar + overlay pipeline (Canvas/WebGPU headless)

6. Encoding:
   - NVENC HEVC (H.265) / AV1 (si hardware soporta) – 4K preset low latency high quality
   - Adaptive Bitrate Ladder (4K, 1440p, 1080p) – Simulcast en WebRTC (VP9/AV1) + Fallback HLS (CMAF)

7. Delivery:
   - WebRTC SFU (mediasoup / LiveKit / Pion SFU) → viewers
   - Edge CDN (e.g., Cloudflare) para HLS fallback
   - Drift monitor: compara audio clock vs video frame PTS → corrige viseme offset

8. Control Channel:
   - gRPC / WebSocket control: wardrobe_change, environment_change, expression_override, freeze_pose, apply_overlay
   - Ensayo: Pre-cargar asset groups para tiempos de cambio < 1.5 s

Latencia Objetivo (Stage 1):
- TTS phoneme timeline gen: 120 ms
- Viseme mapping + smoothing: 10 ms
- Avatar animation evaluation frame: ~16 ms
- Encoding + packetization: 25–40 ms
- Network p95 (regional): 40–60 ms
Total stage 1: 200–250 ms (optimizar a 120 ms con pipeline paralelo)

Lipsync Detalle:
- Pre-buffer audio 120 ms, schedule visemes ahead
- Real-time adjust: drift = (now - expectedVisemeTime) > 25ms → fast-forward or minor hold next viseme

Wardrobe Hot Swap:
- Constraint: no stutter → se prepara instanced skeletal mesh + Material Parameter Collections
- Step:
  1. Preload style (mesh + textures) asynchronously
  2. Signal “ready” event
  3. Blend skeleton weights over 5–8 frames

Environment Switching:
- Use “Portal Camera” approach: render new environment offscreen → crossfade with LUT transition
- Lighting recalc minimal: limit dynamic shadow complexity (cache static; dynamic key light only)

Scaling:
- Multi GPU pool (A100 / RTX 6000 Ada)
- Each GPU 1–2 full 4K streams (depending on complexity) + N watchers (via SFU)
- GPU Orchestrator schedules sessions; if saturation → degrade (1080p) or queue

Observabilidad:
- Metrics: avatar_frame_render_ms, encode_latency_ms, lipsync_offset_ms, wardrobe_swap_ms
- Alerts: lipsync_offset_ms p95 > 60 → raise smoothing aggressiveness

Future:
- Emotion GAN subtle micro-expression (eyebrow, micro-smile)
- AI-driven gestures (transformer on transcript semantics)
- Automatic environment thematic selection (topic → environment assets)

Seguridad / Legal:
- Aprobación de activos (no infringen licencias)
- Versionado de wardrobe sets (audit logs)
- Configurable watermark mandatory (rights management)
