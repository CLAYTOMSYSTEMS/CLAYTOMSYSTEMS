# Plataforma & Cumplimiento (TikTok / Instagram / YouTube)

1. APIs Oficiales:
   - YouTube: usar YouTube Data API para subida y metadata.
   - Instagram: Reels/Stories requieren Instagram Graph API (Business Account + permisos).
   - TikTok: Creator API / Marketing API según uso. Evitar automatizaciones no autorizadas.

2. Límite de Llamadas / Rate Limits:
   - Implementar cola y retry con backoff.

3. Moderación:
   - EngagementAgent debe filtrar contenido tóxico -> no responder o marcar para revisión.

4. Propiedad Intelectual:
   - Verificar fuentes de noticias (atribución si se citan), evitar plagio en scripts.

5. Datos Personales:
   - No persistir handles sensibles sin consentimiento; anonimizar en analytics.

6. Publicidad / Disclosure:
   - Si affiliate link o sponsored content, incluir disclosure (#ad / “Enlace afiliado”).