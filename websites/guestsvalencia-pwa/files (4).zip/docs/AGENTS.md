# Agents Specification

## Orchestrator (Sandra)
Responsable de routing, chain build, conflict resolution, KPI aggregation, reporting.

## Airbnb Manager
Funciones:
- Push disponibilidad y precio.
- Recibir booking/cancellation webhooks.
- Gestionar reviews (respuestas plantillas + personalización).
Métricas: channel_sync_latency, listings_updated_total.

## Booking.com Manager
Funciones similares, adaptando API de extranet.
Métricas: channel_sync_errors_total, bookingcom_rate_push_time.

## Property Manager
Predictive maintenance -> genera MaintenanceTask.
Inventario base (toallas, amenities) -> sugiere re-stock.
Métricas: maintenance_predicted_tasks_total, maintenance_resolution_time.

## Guest Experience
Conversación multi-idioma, check-in instructions, local guide retrieval.
Métricas: guest_response_latency_p95, csat_avg, unresolved_issues_total.

## Revenue Optimizer
Forecast + dynamic pricing triggers
Métricas: pricing_adjustment_total, pricing_adjustment_uplift_estimate, forecast_mape.

## Marketing Automation
Capta leads, genera contenido (SEO snippet + blog), coordina email flows.
Métricas: leads_captured_total, campaign_ctr, nurture_conversion_rate.

## Shared Agents (Internal)
- PolicyAgent, EmotionAgent, SuggestionAgent, BehaviorProfilingAgent.