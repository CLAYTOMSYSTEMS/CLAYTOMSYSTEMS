# Subagents (Autonomous Operational AI Layer)

Este módulo (agent-hub) coordina agentes especializados:
- RevenueOptimizerAgent: Ajuste estratégico (pricing, prompts) basado en conversión
- ConversionSpecialistAgent: Detecta caída funnel y aumenta impulso conversión
- PerformanceMonitorAgent: Vigila latencia LLM vs SLO
- SystemHealthAgent: Health polling + candidate auto-heal
- ErrorResolutionAgent: (Futuro) abre issues / triggers reruns
- DeploymentSpecialistAgent: Observa versiones (blue/green)
- MetricsAnalystAgent: KPIs base (sessions)
- CostOptimizationAgent: Recomienda fallback provider
- SecurityGuardianAgent: Rotación llaves / integridad
- SelfHealingOrchestrator: Coordina instrucciones globales
- ScalingIntelligenceAgent: Sugerencias de réplicas
- BusinessIntelligenceAgent: Forecast revenue/booking corto plazo

DRY_RUN=true evita acciones destructivas. Cambiar a false bajo supervisión.
Cada decisión emite un evento: `agent.decision.<agentId>` (NATS).