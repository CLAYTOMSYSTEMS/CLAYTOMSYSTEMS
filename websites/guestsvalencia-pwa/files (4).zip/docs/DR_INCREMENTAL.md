# DR Incremental Enhancements (Fase 2.1)

Added:
- Kafka topic classification by importance; conversation events replicated cross-region every 5s batch.
- Warm passive region Orchestrator cold standby (health check script).
- Edge Worker fallback path for retrieval degrade mode.

Next:
- Automate failover runbook via Temporal workflow (DRWorkflow).