# Avatar HeyGen Integración (Fase 1)

Estado:
- Canal WebSocket -> eventos viseme (stub).
- Servicio avatar (apps/avatar) recibe audio PCM base64 y envía visemes.
- Próximo paso: negociar SDP real con API HeyGen para video WebRTC y adjuntar <video> remoto en /conversation.

Pipeline:
TTS (ElevenLabs) -> (opcional resample) -> enviar PCM al Avatar para lip-sync paralelo.

Sincronización:
- Ajustar timestamps: viseme.timestamp - audioPlaybackTime < 50ms ideal.
- Añadir cola audioFrameQueue en avatar service para correlación.

Producción:
- Usar jitter buffer para video frames.
- Degradar a imagen estática si ancho de banda insuficiente.
