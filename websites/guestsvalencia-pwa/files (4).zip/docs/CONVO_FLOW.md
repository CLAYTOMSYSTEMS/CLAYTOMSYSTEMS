# Flujo Conversacional (Base)

Estados: IDLE -> LISTENING (user speech) -> PROCESSING -> SPEAKING (TTS) -> IDLE
Barge-In: si usuario habla durante SPEAKING => USER_BARGE_IN => LISTENING

Fase 0: Simulado.
Fase 1: Integrar STT streaming + TTS chunk real (ElevenLabs primaria, Azure fallback).