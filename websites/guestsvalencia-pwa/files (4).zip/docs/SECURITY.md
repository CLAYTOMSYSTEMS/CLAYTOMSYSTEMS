# Seguridad Inicial

- JWT access (15m) + refresh (pendiente implementar endpoint refresh).
- Rate limit API global (configurable).
- CODEOWNERS + rollback workflow.
- Pendiente: audit logs automáticos, rotación tokens, firma webhooks.

Riesgos:
- STT/TTS provider leakage -> Mitigar nunca loggear claves.