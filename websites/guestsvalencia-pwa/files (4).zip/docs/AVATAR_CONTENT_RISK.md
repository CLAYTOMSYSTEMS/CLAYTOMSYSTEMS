# Avatar & Content Risk / Compliance

Risks:
- Unauthorized data usage in scripts
- Disallowed platform automation (mitigar usando APIs oficiales)
- Gesture misalignment causing uncanny valley
- Latency spikes degrade viewer experience
- Over-personalization risk (privacy)

Mitigations:
- Content moderation gate before publish (flag sensitive)
- Fallback static frame if frame_render_time_ms p95 > threshold
- Rate limit posting per platform policy
- PII filter on comments ingestion
- Logging minimal (no raw full transcripts stored > 30d)