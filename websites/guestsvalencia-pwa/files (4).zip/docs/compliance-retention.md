Policy:
- conversation_messages > 30 días → purge
- eval_runs > 90 días → purge
- bookings (facturación) → conservar 5 años (legal)
- PII redaction en ingest + pre-storage
- Ed25519 key rotation: cada 30 días, mantener N=2 public keys (current + previous) durante periodo de gracia.