# Avatar Quality Presets

Preset ULTRA_4K_60:
- Resolution 3840x2160
- FPS 60
- Bitrate target 22 Mbps
- Codec AV1 / fallback HEVC
- GOP 60, B-frames 2 (if latency budget allows) else 0
- Color HDR PQ / BT.2020 (fallback SDR)

Preset HIGH_4K_30:
- 4K @30fps, 14 Mbps, HEVC, low-latency

Preset MID_1080P_60:
- 1920x1080 @60fps, 8 Mbps

Preset LOW_720P_30:
- 1280x720 @30fps, 3.5 Mbps (adaptive fallback)

Adaptive Logic:
if uplinkPacketLoss > 8% OR RTT > 180ms => downgrade one preset
if stable 3 min & CPU headroom > 30% => attempt upgrade

Metrics:
- frame_render_time_ms (goal < 16.6 for 60fps)
- end_to_end_audio_video_sync_offset_ms (< 50)
- keyframe_interval_ok