Topics iniciales:
- sandra.conversation.reply (retention 7d)
- sandra.booking.confirmed (retention 30d)
- sandra.payment.completed (retention 30d)
- sandra.llm.usage (retention 14d)
- sandra.guardrails.blocked (retention 90d audit)

DLQ convención:
- <topic>.dlq

Schema evolution: usar JSON schema registries (future).