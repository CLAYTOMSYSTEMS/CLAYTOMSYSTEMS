# Performance Budget (Fase 2.1)

Targets:
- Hybrid Retrieval p95 < 95ms (local region)
  Dense embedding reuse hit ratio > 70% for repeated queries
- Orchestrator routing overhead < 25ms p95
- TTS first chunk p95 < 350ms (goal 300)
- Barge-in interrupt latency < 150ms p95
- gRPC conversation StartConversation p95 < 120ms
- 5k concurrent simulated (phase 2.1), 50k goal phase 2.4

Tracking:
Prometheus histograms:
- retrieval_latency_ms
- orchestrator_route_ms
- tts_first_chunk_latency
- barge_interrupt_latency

Alerts:
If retrieval_latency_ms p95 > 120ms for 10m → page SRE
If tts_first_chunk_latency p95 > 450ms 3 times per hour → degrade mode (skip reasoning agent)