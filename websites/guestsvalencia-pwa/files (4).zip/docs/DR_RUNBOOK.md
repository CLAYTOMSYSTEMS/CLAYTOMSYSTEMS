# DR Runbook (Draft)

Scenarios:
1. Kafka cluster partial outage → Activate MirrorMaker failover.
2. Postgres primary region loss → Promote replica (run promote script) + update service endpoints via ArgoCD config patch.
3. Vector / search degraded → Switch retrieval strategy to sparse only (feature flag).
4. LLM provider latency spike → Orchestrator degrade path (fast model only, skip heavy reasoning).

Steps (Postgres):
1. Detect fail (alert).
2. Confirm unreachable > 60s.
3. Run promote.sh in standby region.
4. ArgoCD apply configMap update (DB_HOST).
5. Manual data drift inspection after restoration.

RPO/RTO metrics recorded in Grafana dashboard DR_OVERVIEW.