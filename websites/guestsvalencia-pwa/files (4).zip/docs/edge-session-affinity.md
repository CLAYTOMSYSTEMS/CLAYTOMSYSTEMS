Estrategia:
1. Worker inspecciona cookie sid. Si no existe: genera UUID y la asigna.
2. Usa hash(sid) % shard_count → enruta a región (latency improved).
3. Redirige a subdominio (eu1.api, us1.api) o añade header X-Region-Hint.
4. Gateway lee X-Region-Hint y balancea internamente (K8s internal DNS / geo).