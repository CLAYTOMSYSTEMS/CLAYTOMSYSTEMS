# Sandra Community Manager – Architecture

Objetivo: Generar, producir, publicar y optimizar contenido (crypto + real estate + lifestyle Valencia) en TikTok / Instagram / YouTube con mínima intervención humana.

## Agentes
- TrendHunterAgent: obtiene señales (crypto news, social trending, keywords)
- ScriptWriterAgent: genera guion adaptado a canal/tono/lengua
- VisualDesignerAgent: produce prompts de avatar look + thumbnail + overlays
- WardrobeAgent: selecciona vestuario + entorno basado en categoría + hora
- SEOAgent: genera título, descripción, tags, hashtags
- HashtagOptimizerAgent: ranking hashtags (frecuencia / trending / relevancia)
- VoiceSynthesisAgent: genera audio (ElevenLabs) + timing
- AvatarRenderAgent: sincroniza voz + estilo (HeyGen/Render pipeline placeholder)
- PostSchedulerAgent: decide ventana óptima de publicación
- EngagementAgent: responde comentarios (policy + tonalidad)
- AnalyticsAgent: recopila métricas (views, watch time, CTR, RPM)
- RevenueOptimizerAgent: decide CTA (affiliate, booking, course)
- QualityAssuranceAgent: verifica duraciones, legibilidad, repetición
- LocalizationAgent: adapta guion (12+ idiomas) + matices culturales

## Flujo Macro (Video)
1. TrendHunter produce “TopicCandidate”
2. ScriptWriter genera script draft
3. WardrobeAgent + VisualDesigner definen look & environment
4. SEOAgent + HashtagOptimizer generan metadata
5. VoiceSynthesisAgent produce audio
6. AvatarRenderAgent produce video (4K pipeline futura)
7. AnalyticsAgent simula expected engagement (heurística)
8. PostSchedulerAgent programa slot
9. PublishingAgent sube a canal (adapter)
10. EngagementAgent activa watchers para respuestas
11. AnalyticsAgent recoge métricas → Feedback loop (RL future)

## Pipelines Diarios
- 06:00 Morning Market (macro, BTC/ETH, real estate yields)
- 12:00 Trend Burst (tópico viral)
- 18:00 Deep Dive (educacional)
- 21:00 Light Fun / Lifestyle Valencia
Escalable a 2-4 videos según demanda (controlado por StrategyRules).

## Monetización
- Selección dinámica de CTA: booking, affiliate link, curso, newsletter.
- Revenue attribution tagging (UTM per channel).
- Performance threshold: si RPM < target 3 publicaciones → aplicar test variante (A/B script hook / thumbnail style).

## Métricas Clave
- view_velocity_1h, watch_time_avg, retention_30s, ctr_thumbnail, hashtag_efficiency_score
- revenue_per_1000 (RPM), affiliate_conversion_rate, booking_conversion_from_content
- script_revision_rate, style_diversity_index, localization_accuracy.
