# Token & Memory Strategy

1. Window Partition:
   - Keep last 6 user+assistant turns raw.
   - Older → summarize (semantic compression).
2. Semantic K retrieval (K=4):
   - Query vector from last user message.
   - Filter by relevance > threshold; exclude duplicates present in raw.
3. Slot Store:
   - Do not re-send stable slots (dates, guests) if unchanged; provide "SLOTS_DELTA".
4. Adaptive Summarization:
   - If prompt tokens > 60% max, compress oldest two summaries again (2-stage compression).
5. Pricing / Maintenance Technical Blocks:
   - Provide as structured JSON for function calling, not natural text.
6. Policy:
   - Always sanitize injection patterns.