# Guests Valencia Ecosystem Architecture (Sandra IA 7.0)

(Contiene visión, dominios, agentes, flujos clave, métricas y roadmap – ver secciones arriba)