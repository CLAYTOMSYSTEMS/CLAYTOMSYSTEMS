# Embeddings (Reales)

Proveedor: OpenAI (text-embedding-3-small)
Almacenamiento: tabla embeddingDocument (vector en Bytes -> Float32Array)
Búsqueda: coseno en memoria (Fase 1). Fase 2: operador pgvector <=> index IVFFlat.

Futuro:
- Cache redis para consulta repetida.
- Multi-idioma: traducir query EN->ES si docs mayoritariamente ES.