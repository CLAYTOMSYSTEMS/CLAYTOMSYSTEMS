# API Reference (Resumen Fase 0)

POST /auth/register
POST /auth/login
GET  /auth/me

GET  /properties

POST /conversation/start { locale }
POST /conversation/nlu/slots { text, locale }
POST /conversation/semantic/search { query, locale }

GET /health/live
GET /health/ready