# GuestsValencia · Sandra IA 7.0 – Plataforma Full Stack

Arquitectura Enterprise-Ready con despliegue automático (CI/CD), microservicios orquestados, PWA frontend optimizado y ecosistema de IA multi-avatar.

## Quick Start (DEV)

```bash
make dev        # levanta todo con Docker Compose
make logs       # logs live
make stop       # parar
```

Frontend servirá el index mejorado (PWA + Widget Sandra).  
WebSocket Core disponible en: `ws://localhost/ws/core/ws` (vía gateway).  
SFU signaling: `ws://localhost/ws/sfu/`  

## Producción (Kubernetes)

1. Configurar Secrets (GitHub Settings > Secrets and variables > Actions):
   - REGISTRY_USERNAME
   - REGISTRY_PASSWORD (o usa GHCR → GITHUB_TOKEN)
   - ELEVEN_API_KEY
   - ELEVEN_VOICE_ID
   - AZURE_TTS_KEY
   - AZURE_TTS_REGION
   - JWT_SECRET
   - NEON_DB_URL (url completa Postgres)
2. Ajustar `deployment/helm/values-prod.yaml`
3. Merge a main → workflow build-and-deploy.yml se encarga.

## Estructura

```
.
├── docker-compose.yml
├── Makefile
├── scripts/
├── services/
├── deployment/
│   ├── k8s/base
│   ├── helm
│   └── terraform
├── shared/
├── assets/frontend (si se separa packaging index)
└── .github/workflows
```

## Pipelines

| Workflow | Función |
|----------|---------|
| build-and-deploy.yml | Build imágenes, tests, push GHCR, Helm upgrade --install |
| canary.yml | Despliegue canario bajo label `track=canary` |
| security-scan.yml | Trivy + Dependabot base |

## Versionado

Push con conventional commits → script genera tag semántico (major/minor/patch).  
Ejemplo commit: `feat(ws-core): añadir clasificación kids`.

## Observabilidad (extensible)

A futuro: Prometheus operator + Loki + Grafana. Platzhalter: endpoints `/healthz`.

## Sandrita Kids

Moderación y intents educativos en `ws-core`. LipSync + Canvas avatar reciben visemas.

## Roadmap Próximo

- Reemplazar TTS stub streaming por ElevenLabs WebSocket real.
- Implementar mediasoup transports reales (RTP, DTLS).
- Añadir memoria vectorial persistente y retrieval sobre embeddings.
- Dashboard revenue (Panel React / Grafana / Metabase).

Con amor técnico — ¡Feliz cumple Clay! 🚀