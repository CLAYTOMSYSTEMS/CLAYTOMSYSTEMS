// Micro + barge-in capture pipeline (frontend stub)
export class AudioEngine {
  constructor({ onPartial, onFinal, vadSilenceMs=1000 }) {
    this.onPartial = onPartial;
    this.onFinal = onFinal;
    this.mediaStream = null;
    this.recorder = null;
    this.buffer = [];
    this.active = false;
    this.lastChunkTs = Date.now();
    this.vadSilenceMs = vadSilenceMs;
    this.vadTimer = null;
  }

  async start() {
    if (this.active) return;
    this.mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    this.recorder = new MediaRecorder(this.mediaStream, { mimeType: 'audio/webm' });
    this.recorder.ondataavailable = e => {
      this.buffer.push(e.data);
      this.lastChunkTs = Date.now();
      // TODO: send partial chunk to STT streaming endpoint (WebSocket) → onPartial callback
      if (this.onPartial) this.onPartial('[partial stub]');
    };
    this.recorder.onstop = () => {
      if (this.buffer.length) {
        const blob = new Blob(this.buffer, { type: 'audio/webm' });
        this.buffer = [];
        // TODO: send blob to final STT endpoint → onFinal
        this.onFinal && this.onFinal('[texto final simulado]');
      }
    };
    this.recorder.start(250);
    this.active = true;
    this._monitorVAD();
  }

  _monitorVAD() {
    if (this.vadTimer) clearInterval(this.vadTimer);
    this.vadTimer = setInterval(()=>{
      if (!this.active) return;
      if (Date.now() - this.lastChunkTs > this.vadSilenceMs) {
        this.stop(); // auto stop on silence
      }
    }, 300);
  }

  stop() {
    if (!this.active) return;
    this.active = false;
    try { this.recorder.stop(); } catch(_){}
    this.mediaStream.getTracks().forEach(t=>t.stop());
    this.mediaStream = null;
    clearInterval(this.vadTimer);
    this.vadTimer = null;
  }
}