// Automated check-in flow (placeholder)
export class CheckInFlow {
  constructor({ endpoint, log }) {
    this.endpoint = endpoint;
    this.log = log;
  }

  async start(sessionId) {
    this.log('Iniciando check-in...');
    // TODO:SERVER call to start check-in
    await new Promise(r=>setTimeout(r, 800));
    this.log('Verificando identidad (simulado)...');
    await new Promise(r=>setTimeout(r, 1000));
    this.log('Generando código smart lock (simulado)...');
    await new Promise(r=>setTimeout(r, 1200));
    this.log('Check-in completado ✅');
    window.dispatchEvent(new CustomEvent('sandra:checkin-complete', { detail:{ sessionId, code: 'LOCK-1234' }}));
  }
}