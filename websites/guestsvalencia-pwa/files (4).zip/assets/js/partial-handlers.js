let partialNode = null;
function accumulatePartial(token) {
  const logEl = document.getElementById('sandra-log');
  if (!partialNode) {
    partialNode = document.createElement('div');
    partialNode.className='rounded p-2 bg-white border text-sm';
    partialNode.innerHTML='<strong class="block mb-1">sandra (stream)</strong><span class="partial-body"></span>';
    logEl.appendChild(partialNode);
  }
  const body = partialNode.querySelector('.partial-body');
  body.textContent += token;
  logEl.scrollTop = logEl.scrollHeight;
}
function finalizePartial(){
  if (partialNode) { partialNode.id=''; partialNode=null; }
}
window.accumulatePartial = accumulatePartial;
window.finalizePartial = finalizePartial;