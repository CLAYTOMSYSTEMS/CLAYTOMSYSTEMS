// Minimal viseme-driven avatar (Sandrita demo)
export class CanvasAvatar {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.width = canvas.width;
    this.height = canvas.height;
    this.mouth = { openness: 0 };
    this.queue = [];
    this.lastVisemeTime = 0;
    requestAnimationFrame(()=>this.render());
    window.addEventListener('sandra:avatar', (e)=> {
      if (e.detail.viseme) {
        this.enqueueViseme(e.detail.viseme);
      }
    });
  }

  enqueueViseme(symbol) {
    const map = {
      A:0.1, B:0.2, C:0.35, D:0.5,
      E:0.25, F:0.4, G:0.6, H:0.15, I:0.05
    };
    const openness = map[symbol] ?? 0.2;
    this.queue.push({ openness, decay: 0.9 });
  }

  step() {
    if (this.queue.length) {
      const current = this.queue.shift();
      this.mouth.openness = current.openness;
    } else {
      this.mouth.openness *= 0.85;
    }
  }

  render() {
    this.step();
    const ctx = this.ctx;
    ctx.clearRect(0,0,this.width,this.height);

    // Face
    ctx.fillStyle = '#FFE4C9';
    ctx.beginPath();
    ctx.arc(this.width/2, this.height/2, 90, 0, Math.PI*2);
    ctx.fill();

    // Eyes
    ctx.fillStyle='#222';
    ctx.beginPath(); ctx.arc(this.width/2 - 35, this.height/2 - 25, 10,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(this.width/2 + 35, this.height/2 - 25, 10,0,Math.PI*2); ctx.fill();

    // Mouth
    const o = this.mouth.openness;
    ctx.strokeStyle='#A22';
    ctx.lineWidth = 8;
    ctx.lineCap='round';
    ctx.beginPath();
    const mw = 60; const mh = 10 + o*60;
    ctx.moveTo(this.width/2 - mw/2, this.height/2 + 30);
    ctx.quadraticCurveTo(this.width/2, this.height/2 + 30 + mh, this.width/2 + mw/2, this.height/2 + 30);
    ctx.stroke();

    requestAnimationFrame(()=>this.render());
  }
}

// Auto init if canvas present
document.addEventListener('DOMContentLoaded', ()=>{
  const c = document.getElementById('sandrita-avatar-canvas');
  if (c) new CanvasAvatar(c);
});