async function fetchMemory(sessionId) {
  const r = await fetch('/memory/debug/'+sessionId).catch(()=>null);
  return r?.json();
}
// Puedes crear un endpoint proxy en gateway si expones memory-engine