// OPTIONAL: attach to a debug button
async function debugRag(query) {
  const res = await fetch('/rag/semantic/search', {
    method:'POST', headers:{ 'Content-Type':'application/json' },
    body: JSON.stringify({ query, topK:3 })
  }).then(r=>r.json());
  console.log('[RAG RESULTS]', res);
}
window.debugRag = debugRag;