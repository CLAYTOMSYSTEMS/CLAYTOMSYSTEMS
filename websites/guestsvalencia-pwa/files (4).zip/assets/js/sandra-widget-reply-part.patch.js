// PATCH conceptual: dentro de sandra-widget.js donde se procesa onmessage de core socket
// Añade lógica en SandraCore.onmessage (o intercepta en wrapper) — ejemplo:

// En sse/WS actual: socket.onmessage = (ev) => { ... }
// Añadir case reply_part:

/*
if (msg.type === 'reply_part') {
   accumulatePartial(msg.data.text);
}
*/

function accumulatePartial(token) {
  // Busca o crea contenedor de mensaje en curso
  let partial = document.getElementById('sandra-partial-current');
  if (!partial) {
    partial = document.createElement('div');
    partial.id = 'sandra-partial-current';
    partial.className = 'rounded p-2 bg-white border text-sm';
    partial.innerHTML = '<strong class="block mb-1">sandra (stream)</strong><span class="partial-body"></span>';
    const log = document.getElementById('sandra-log');
    log.appendChild(partial);
    log.scrollTop = log.scrollHeight;
  }
  const body = partial.querySelector('.partial-body');
  body.textContent = (body.textContent || '') + token;
}

// Al recibir 'reply' final: eliminar id para siguiente stream:
 /*
 if (msg.type === 'reply') {
    const cur = document.getElementById('sandra-partial-current');
    if (cur) cur.removeAttribute('id');
 }
 */