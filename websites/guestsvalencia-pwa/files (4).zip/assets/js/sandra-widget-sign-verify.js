// naive example (MISMATCH logs only— cannot fully verify without secret)
function processSigned(msg){
  // msg = { body, sig }
  if (!msg.sig || !msg.body) return msg;
  // Could request server endpoint /verify if needed
  return msg.body;
}