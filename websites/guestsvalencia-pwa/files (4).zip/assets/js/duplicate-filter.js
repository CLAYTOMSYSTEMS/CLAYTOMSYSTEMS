// Semantic Duplicate / Redundancy Filter (frontend placeholder)
export class DuplicateTurnFilter {
  constructor({ maxHistory=15, similarityThreshold=0.88, embeddingsEndpoint }) {
    this.history = [];
    this.maxHistory = maxHistory;
    this.similarityThreshold = similarityThreshold;
    this.endpoint = embeddingsEndpoint;
  }

  async _embed(text) {
    // TODO:SERVER: POST to embeddings endpoint
    // Return vector stub
    return Array.from({length: 48}, (_,i)=> (Math.sin(i + text.length) + 1)/2 );
  }

  _cosine(a,b) {
    let dot=0,na=0,nb=0;
    for (let i=0;i<a.length;i++){dot+=a[i]*b[i];na+=a[i]*a[i];nb+=b[i]*b[i];}
    return dot / (Math.sqrt(na)*Math.sqrt(nb) + 1e-9);
  }

  async shouldAllow(text) {
    const embedding = await this._embed(text);
    for (const prev of this.history.slice(-this.maxHistory)) {
      const sim = this._cosine(embedding, prev.vec);
      if (sim >= this.similarityThreshold) {
        return { allow:false, reason:'duplicate', sim };
      }
    }
    this.history.push({ text, vec: embedding, ts: Date.now() });
    if (this.history.length > this.maxHistory) this.history.shift();
    return { allow:true };
  }
}