// Central turn orchestration (simplified placeholder)
export class TurnEngine {
  constructor({ participants=[], duplicateFilter, onTurnAllocated }) {
    this.participants = participants; // [{id, role, priority, cooldownMs, lastSpoke}]
    this.queue = [];
    this.duplicateFilter = duplicateFilter;
    this.onTurnAllocated = onTurnAllocated;
    this.locked = false;
  }

  register(p) {
    this.participants.push({ ...p, lastSpoke:0 });
  }

  async propose(role, textDraft) {
    // duplicate filtering
    if (this.duplicateFilter) {
      const dup = await this.duplicateFilter.shouldAllow(textDraft);
      if (!dup.allow) return { accepted:false, reason:'duplicate' };
    }
    this.queue.push({ role, textDraft, ts: Date.now() });
    return { accepted:true };
  }

  async allocateNext() {
    if (this.locked || !this.queue.length) return;
    this.locked = true;
    // Simple priority scoring
    const now = Date.now();
    const scored = this.queue.map(item=>{
      const p = this.participants.find(pp=>pp.role===item.role);
      const base = p?.priority || 1;
      const sinceLast = now - (p?.lastSpoke || 0);
      const score = base + Math.min(sinceLast/10000, 1);
      return { ...item, score };
    }).sort((a,b)=>b.score - a.score);
    const chosen = scored[0];
    this.queue = this.queue.filter(q=>q!==chosen);
    const participant = this.participants.find(pp=>pp.role===chosen.role);
    if (participant) participant.lastSpoke = now;
    this.onTurnAllocated && this.onTurnAllocated(chosen);
    this.locked = false;
  }

  loop(interval=1200) {
    setInterval(()=>this.allocateNext(), interval);
  }
}