// Simple finite state machine helper
export class FSM {
  constructor(initial, transitions) {
    this.state = initial;
    this.transitions = transitions;
    this.listeners = new Set();
  }
  can(event) {
    return !!(this.transitions[this.state] && this.transitions[this.state][event]);
  }
  send(event, data) {
    if (!this.can(event)) return false;
    const next = this.transitions[this.state][event];
    const prev = this.state;
    this.state = typeof next === 'function' ? next(prev, data) : next;
    this.listeners.forEach(fn => fn(this.state, prev, event, data));
    return true;
  }
  onChange(fn) {
    this.listeners.add(fn);
    return ()=>this.listeners.delete(fn);
  }
}