// Replace initDevice fakeCaps part:

async initDevice() {
  if (!this.device) {
    const capsRes = await fetch((this.signalingUrl.replace(/^ws/,'http')) + 'rtpCapabilities')
      .then(r=>r.json());
    this.device = new window.mediasoupClient.Device();
    await this.device.load({ routerRtpCapabilities: capsRes });
    this.rtpCapabilities = this.device.rtpCapabilities;
    this.send({ action:'createTransport' });
    this.send({ action:'createTransport' });
  }
}

// In _onMsg add:
else if (msg.type === 'active-speaker') {
  [...this.mosaic.children].forEach(el=>{
    el.classList.remove('ring','ring-4','ring-emerald-400');
    if (el.dataset.peerId === msg.peerId) {
      el.classList.add('ring','ring-4','ring-emerald-400');
    }
  });
}

// When consuming, label element:
el.dataset.peerId = msg.producerId;