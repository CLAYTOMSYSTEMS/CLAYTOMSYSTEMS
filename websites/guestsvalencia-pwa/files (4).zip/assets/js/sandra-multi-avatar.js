// Multi-avatar orchestration (mosaic + SFU placeholders)
export class MultiAvatarManager {
  constructor({ signalUrl, container, onLog }) {
    this.signalUrl = signalUrl;
    this.container = container;
    this.onLog = onLog;
    this.socket = null;
    this.peers = new Map(); // id -> { mediaEl, role }
  }

  connect() {
    this.socket = new WebSocket(this.signalUrl);
    this.socket.onopen = () => this._log('SFU conectado (placeholder)');
    this.socket.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data);
        if (msg.type === 'peer-join') {
          this._addPeer(msg.peer);
        } else if (msg.type === 'peer-leave') {
          this._removePeer(msg.id);
        } else if (msg.type === 'offer') {
          // TODO: handle WebRTC logic
        }
      } catch(e){}
    };
  }

  _addPeer(peer) {
    const el = document.createElement('div');
    el.className = 'relative bg-slate-800 rounded overflow-hidden flex items-center justify-center text-xs text-white';
    el.textContent = 'Cargando…';
    el.dataset.peerId = peer.id;
    this.container.appendChild(el);
    this.peers.set(peer.id, { mediaEl: el, role: peer.role });
    this._log(`Peer ${peer.id} (${peer.role}) añadido`);
    // TODO: attach actual video element
    setTimeout(()=>{ el.textContent = peer.role; }, 300);
  }

  _removePeer(id) {
    const p = this.peers.get(id);
    if (!p) return;
    p.mediaEl.remove();
    this.peers.delete(id);
    this._log(`Peer ${id} eliminado`);
  }

  _log(m) { this.onLog && this.onLog('[SFU] '+m); }
}