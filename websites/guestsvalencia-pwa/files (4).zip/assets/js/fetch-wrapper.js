export async function apiFetch(url, opts={}) {
  const r = await fetch(url, opts);
  if (r.status === 429) {
    alert('Estás interactuando demasiado rápido. Espera un instante.');
    throw new Error('rate_limited');
  }
  return r;
}