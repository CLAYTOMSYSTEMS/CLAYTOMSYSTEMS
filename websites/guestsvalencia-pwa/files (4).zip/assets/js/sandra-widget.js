import { AudioEngine } from './audio-engine.js';
import { SandraCore, GlobalEngines } from './sandra-core.js';
import { MultiAvatarManager } from './sandra-multi-avatar.js';
import { CheckInFlow } from './checkin-flow.js';

const qs = sel => document.querySelector(sel);
const qsa = sel => Array.from(document.querySelectorAll(sel));

const logArea = () => qs('#sandra-log');
const fullscreenChat = () => qs('#sandra-fullscreen-chat');

function appendMessage(container, role, text) {
  if (!container) return;
  const div = document.createElement('div');
  div.className = 'rounded p-2 ' + (role==='user' ? 'bg-blue-100 text-slate-800' : role==='sandra' ? 'bg-white border' : 'bg-emerald-50');
  div.innerHTML = `<strong class="block mb-1">${role}</strong><span>${text}</span>`;
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}

function log(role, text) {
  appendMessage(logArea(), role, text);
  appendMessage(fullscreenChat(), role, text);
}

function setStatus(t) {
  const s1 = qs('#sandra-status');
  const s2 = qs('#sandra-fullscreen-status');
  if (s1) s1.textContent = t;
  if (s2) s2.textContent = t;
}

const core = new SandraCore({
  wsUrl: window.APP_CONFIG.WSS_CORE,
  logFn: (role, text) => log(role, text),
  statusFn: setStatus
});

core.connect();

const audio = new AudioEngine({
  onPartial: (p) => setStatus('Escuchando... ' + p),
  onFinal: (f) => {
    log('user', f);
    core.send(f);
  }
});

const checkin = new CheckInFlow({
  endpoint: window.APP_CONFIG.CHECKIN_URL,
  log: (t)=>log('checkin', t)
});

let multiManager = null;
let multiActive = false;

function initMultiAvatar() {
  if (multiManager) return;
  const container = qs('#sandra-multi-area');
  multiManager = new MultiAvatarManager({
    signalUrl: window.APP_CONFIG.SFU_SIGNAL_URL,
    container,
    onLog: (m)=>log('multi', m)
  });
  multiManager.connect();
}

// UI bindings
(function bindUI(){
  const toggleBtn = qs('#sandra-toggle');
  const panel = qs('#sandra-panel');
  const footerOpen = qs('#footer-open-ia');
  const closeBtn = qs('#sandra-close');
  const sendBtn = qs('#sandra-send');
  const input = qs('#sandra-text-input');
  const ptt = qs('#sandra-ptt');
  const stop = qs('#sandra-stop');
  const avatarToggle = qs('#sandra-avatar-toggle');
  const videoArea = qs('#sandra-video-area');
  const multiToggle = qs('#sandra-multi-toggle');
  const multiArea = qs('#sandra-multi-area');
  const fullscreenBtn = qs('#sandra-fullscreen');
  const fullscreenModal = qs('#sandra-fullscreen-modal');
  const fullscreenClose = qs('#sandra-fullscreen-close');
  const fullscreenSend = qs('#sandra-fullscreen-send');
  const fullscreenInput = qs('#sandra-fullscreen-input');
  const checkinBtn = qs('#sandra-checkin');

  function openPanel() {
    panel.classList.remove('hidden');
    toggleBtn.setAttribute('aria-expanded','true');
    input.focus();
  }
  function closePanel() {
    panel.classList.add('hidden');
    toggleBtn.setAttribute('aria-expanded','false');
    toggleBtn.focus();
  }

  toggleBtn.addEventListener('click', ()=>{
    if (panel.classList.contains('hidden')) openPanel(); else closePanel();
  });
  footerOpen?.addEventListener('click', openPanel);
  closeBtn.addEventListener('click', closePanel);

  sendBtn.addEventListener('click', ()=>{
    const val = input.value.trim();
    if (!val) return;
    log('user', val);
    core.send(val);
    input.value = '';
  });

  input.addEventListener('keydown', e=>{
    if (e.key === 'Enter') {
      e.preventDefault();
      sendBtn.click();
    }
  });

  ptt.addEventListener('click', async ()=>{
    if (audio.active) {
      audio.stop();
      ptt.setAttribute('aria-pressed','false');
      ptt.classList.remove('bg-emerald-700');
    } else {
      await audio.start();
      ptt.setAttribute('aria-pressed','true');
      ptt.classList.add('bg-emerald-700');
    }
  });

  stop.addEventListener('click', ()=>{
    audio.stop();
    ptt.setAttribute('aria-pressed','false');
    ptt.classList.remove('bg-emerald-700');
  });

  avatarToggle.addEventListener('click', ()=>{
    videoArea.classList.toggle('hidden');
    if (!videoArea.classList.contains('hidden')) {
      // TODO: initiate avatar stream (fetch token -> connect)
      log('system','Avatar activado (placeholder stream).');
    }
  });

  multiToggle.addEventListener('click', ()=>{
    multiArea.classList.toggle('hidden');
    if (!multiArea.classList.contains('hidden')) {
      initMultiAvatar();
      multiActive = true;
    } else {
      multiActive = false;
    }
  });

  fullscreenBtn.addEventListener('click', ()=>{
    fullscreenModal.classList.remove('hidden');
    fullscreenInput.focus();
  });

  fullscreenClose.addEventListener('click', ()=>{
    fullscreenModal.classList.add('hidden');
    toggleBtn.focus();
  });

  fullscreenSend.addEventListener('click', ()=>{
    const val = fullscreenInput.value.trim();
    if (!val) return;
    log('user', val);
    core.send(val);
    fullscreenInput.value = '';
  });

  fullscreenInput.addEventListener('keydown', e=>{
    if (e.key==='Enter') {
      e.preventDefault();
      fullscreenSend.click();
    }
  });

  checkinBtn.addEventListener('click', ()=>{
    checkin.start('session-demo');
  });

  // Avatar size controls
  qsa('[data-avatar-size]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const size = btn.getAttribute('data-avatar-size');
      const container = document.getElementById('sandra-avatar-container');
      container.classList.remove('scale-75','scale-90','scale-100');
      if (size === 'sm') container.style.height='8rem';
      else if (size === 'md') container.style.height='12rem';
      else container.style.height='16rem';
    });
  });

  // Turn allocated events
  window.addEventListener('sandra:turn-allocated', (ev)=>{
    const { role, textDraft } = ev.detail;
    log(role, '(turn allocated) ' + (textDraft || '...'));
    // TODO: Ask backend for actual generation if needed
  });

})();

// AI Search panel minimal binding
(function aiSearch(){
  const toggle = document.getElementById('ai-help');
  const panel = document.getElementById('ai-search-panel');
  const close = document.getElementById('ai-close-btn');
  const speak = document.getElementById('ai-speak-btn');
  const typeBtn = document.getElementById('ai-type-btn');
  const textArea = document.getElementById('ai-text-area');
  const send = document.getElementById('ai-text-send');
  const input = document.getElementById('ai-text-input');
  const status = document.getElementById('ai-status');
  const resp = document.getElementById('ai-response');
  const respText = document.getElementById('ai-response-text');

  toggle.addEventListener('click', ()=>panel.classList.toggle('hidden'));
  close.addEventListener('click', ()=>panel.classList.add('hidden'));
  typeBtn.addEventListener('click', ()=>textArea.classList.toggle('hidden'));
  speak.addEventListener('click', ()=>{
    status.classList.remove('hidden');
    setTimeout(()=>{ status.classList.add('hidden'); resp.classList.remove('hidden'); respText.textContent='He detectado preferencia general. ¿Quieres terraza o vistas al mar?'; }, 1500);
  });
  send.addEventListener('click', ()=>{
    const val = input.value.trim(); if (!val) return;
    resp.classList.remove('hidden');
    respText.textContent = 'Buscando opciones para: ' + val;
  });

  document.querySelectorAll('[data-ai-example]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      input.value = btn.dataset.aiExample;
      textArea.classList.remove('hidden');
    });
  });
})();