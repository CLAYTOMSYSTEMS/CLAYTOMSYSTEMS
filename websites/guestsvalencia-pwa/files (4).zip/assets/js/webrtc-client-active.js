// Dentro _onMsg case active-speaker
else if (msg.type === 'active-speaker') {
  [...this.mosaic.children].forEach(el=>{
    el.classList.remove('ring','ring-4','ring-emerald-400');
  });
  const target = [...this.mosaic.children].find(el=>el.dataset.peerId === msg.peerId);
  if (target) {
    target.classList.add('ring','ring-4','ring-emerald-400');
    target.setAttribute('data-energy', msg.energy);
  }
}