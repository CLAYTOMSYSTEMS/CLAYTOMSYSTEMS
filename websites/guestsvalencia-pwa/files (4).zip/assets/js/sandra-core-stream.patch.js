socket.onmessage = ev => {
  let raw; try { raw = JSON.parse(ev.data); } catch { return; }
  if (raw.body && raw.sig) raw = raw.body; // firma desempaquetada

  if (raw.type === 'reply_part') {
     accumulatePartial(raw.data.text);
     return;
  }
  if (raw.type === 'reply') {
     finalizePartial(); log('sandra', raw.data.text);
     return;
  }
};