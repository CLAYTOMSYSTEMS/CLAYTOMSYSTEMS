export async function playFinalTTS(text) {
  try {
    const r = await fetch('/tts/realtime/eleven', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ text })
    });
    if (!r.ok) return;
    const blob = await r.blob();
    const url = URL.createObjectURL(blob);
    const a = new Audio(url);
    a.play().catch(()=>{});
  } catch(e){ console.warn('TTS final fail', e); }
}