class TTSAudioPlayer {
  constructor({ wsUrl, buttonId }) {
    this.wsUrl = wsUrl;
    this.btn = document.getElementById(buttonId);
    this.audio = new Audio();
    this.mediaSource = new MediaSource();
    this.sourceBuffer = null;
    this.queue = [];
    this.opened = false;
    this.btn?.addEventListener('click', ()=>this.start());
  }

  start() {
    this.audio.src = URL.createObjectURL(this.mediaSource);
    this.mediaSource.addEventListener('sourceopen', ()=>this._onOpen());
    this.audio.play().catch(()=>{});
    this._connect();
  }

  _connect() {
    this.ws = new WebSocket(this.wsUrl);
    this.ws.binaryType = 'arraybuffer';
    this.ws.onopen = ()=> {
      this.ws.send(JSON.stringify({ type:'synthesize', text:'Hola, esto es audio streaming demo.' }));
    };
    this.ws.onmessage = (ev)=>{
      if (typeof ev.data === 'string') {
        try {
          const j = JSON.parse(ev.data);
          if (j.type === 'done') this.mediaSource.endOfStream();
        } catch{}
      } else {
        // binary PCM -> convert to WAV chunk (simple linear PCM container)
        const wav = this._pcmToWav(new Uint8Array(ev.data), 16000, 1);
        this._enqueue(wav);
      }
    };
  }

  _onOpen() {
    this.sourceBuffer = this.mediaSource.addSourceBuffer('audio/wav; codecs=1');
    this.sourceBuffer.addEventListener('updateend', ()=>this._feed());
    this._feed();
  }

  _enqueue(chunk) {
    this.queue.push(chunk);
    this._feed();
  }

  _feed() {
    if (!this.sourceBuffer || this.sourceBuffer.updating) return;
    if (!this.queue.length) return;
    const c = this.queue.shift();
    this.sourceBuffer.appendBuffer(c);
  }

  _pcmToWav(pcmBytes, sampleRate, channels) {
    const blockAlign = channels * 2;
    const byteRate = sampleRate * blockAlign;
    const wavBuffer = new ArrayBuffer(44 + pcmBytes.length);
    const view = new DataView(wavBuffer);
    function writeStr(o,s){ for(let i=0;i<s.length;i++) view.setUint8(o+i, s.charCodeAt(i)); }
    writeStr(0,'RIFF');
    view.setUint32(4, 36 + pcmBytes.length, true);
    writeStr(8,'WAVE');
    writeStr(12,'fmt ');
    view.setUint32(16,16,true);
    view.setUint16(20,1,true);
    view.setUint16(22,channels,true);
    view.setUint32(24,sampleRate,true);
    view.setUint32(28,byteRate,true);
    view.setUint16(32,blockAlign,true);
    view.setUint16(34,16,true);
    writeStr(36,'data');
    view.setUint32(40, pcmBytes.length, true);
    new Uint8Array(wavBuffer,44).set(pcmBytes);
    return new Uint8Array(wavBuffer);
  }
}
window.addEventListener('DOMContentLoaded', ()=>{
  // Botón opcional
  new TTSAudioPlayer({
    wsUrl: (window.APP_CONFIG?.TTS_PCM_URL || 'ws://localhost/tts/ws/pcm'),
    buttonId: 'tts-test-btn'
  });
});