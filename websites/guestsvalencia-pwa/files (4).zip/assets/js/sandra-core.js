import { DuplicateTurnFilter } from './duplicate-filter.js';
import { TurnEngine } from './turn-engine.js';

// Core single avatar & messaging
export class SandraCore {
  constructor({ wsUrl, logFn, statusFn }) {
    this.wsUrl = wsUrl;
    this.logFn = logFn;
    this.statusFn = statusFn;
    this.socket = null;
    this.pending = [];
    this.connected = false;
  }

  connect() {
    if (this.socket) return;
    this.socket = new WebSocket(this.wsUrl);
    this.socket.onopen = () => {
      this.connected = true;
      this.statusFn && this.statusFn('Conectado');
      this.pending.forEach(m=>this.send(m));
      this.pending = [];
    };
    this.socket.onmessage = (ev) => {
      // Expect JSON {type, data}
      try {
        const msg = JSON.parse(ev.data);
        if (msg.type === 'reply') {
          this.logFn && this.logFn('sandra', msg.data.text);
        } else if (msg.type === 'avatar-event') {
          // Lip sync / viseme events
          window.dispatchEvent(new CustomEvent('sandra:avatar', { detail: msg.data }));
        }
      } catch(e){}
    };
    this.socket.onclose = () => {
      this.connected = false;
      this.statusFn && this.statusFn('Reconectando...');
      setTimeout(()=>this.reconnect(), 1500);
    };
  }

  reconnect() {
    if (this.connected) return;
    this.socket = null;
    this.connect();
  }

  send(text) {
    const payload = { type:'user', text };
    if (!this.connected) {
      this.pending.push(text);
      return;
    }
    this.socket.send(JSON.stringify(payload));
  }
}

// Initialize global orchestrator resources
export const GlobalEngines = (() => {
  const duplicateFilter = new DuplicateTurnFilter({
    embeddingsEndpoint: window.APP_CONFIG.EMBEDDINGS_URL
  });

  const turnEngine = new TurnEngine({
    participants: [
      { role:'SandraHost', priority: 1.3, cooldownMs: 1500 },
      { role:'ExpertoLocal', priority: 1.1, cooldownMs: 2000 },
      { role:'RevenueOpt', priority: 1.0, cooldownMs: 2500 },
      { role:'CheckInBot', priority: 0.9, cooldownMs: 2500 },
      { role:'SandritaKids', priority: 1.2, cooldownMs: 2000 }
    ],
    duplicateFilter,
    onTurnAllocated: (turn) => {
      window.dispatchEvent(new CustomEvent('sandra:turn-allocated', { detail: turn }));
    }
  });

  turnEngine.loop(1400);

  return { duplicateFilter, turnEngine };
})();