export async function createBookingIntent(listingId, checkin, checkout) {
  const r = await fetch('/booking/intent', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ listingId, checkin, checkout })
  }).then(r=>r.json());
  return r;
}
export async function confirmBooking(bookingId) {
  return fetch('/booking/confirm', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ bookingId })
  }).then(r=>r.json());
}