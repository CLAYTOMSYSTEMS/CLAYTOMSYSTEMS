import { createBookingIntent, confirmBooking } from './booking-flow.js';

export async function quickBook(listingId, checkin, checkout) {
  const intent = await createBookingIntent(listingId, checkin, checkout);
  const pay = await fetch('/payments/checkout/session',{
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({
      lineItems:[{ price_data:{ currency:'EUR', product_data:{ name:`Reserva ${listingId}` }, unit_amount: intent.total * 100 }, quantity:1 }],
      metadata:{ bookingId: intent.bookingId }
    })
  }).then(r=>r.json());
  window.open(pay.url,'_blank');
}