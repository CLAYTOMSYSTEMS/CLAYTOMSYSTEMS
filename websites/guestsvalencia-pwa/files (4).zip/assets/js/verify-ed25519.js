async function loadKey() {
  const pem = await fetch('/keys/ed25519_public.pem').then(r=>r.text());
  const b64 = pem.replace(/-----(BEGIN|END) PUBLIC KEY-----/g,'').replace(/\s+/g,'');
  const der = Uint8Array.from(atob(b64), c=>c.charCodeAt(0));
  return await crypto.subtle.importKey('spki', der.buffer, { name:'Ed25519', namedCurve:'Ed25519' }, false, ['verify']);
}

const keyPromise = loadKey();

export async function verifyEvent(wrapper) {
  if (!wrapper.sig || !wrapper.body) return true;
  try {
    const key = await keyPromise;
    const enc = new TextEncoder();
    const ok = await crypto.subtle.verify(
      { name:'Ed25519' },
      key,
      Uint8Array.from(atob(wrapper.sig), c=>c.charCodeAt(0)),
      enc.encode(JSON.stringify(wrapper.body))
    );
    return ok;
  } catch { return false; }
}