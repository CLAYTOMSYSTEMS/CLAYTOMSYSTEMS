// General UI enhancements & lazy logic
(() => {
  const heroVid = document.getElementById('hero-video');
  if (heroVid) {
    const io = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.isIntersecting) heroVid.play().catch(()=>{});
        else heroVid.pause();
      });
    }, { threshold: 0.1 });
    io.observe(heroVid);
  }

  // Opener audio fallback on interaction
  (function(){
    const a = document.getElementById('opener-audio'); if(!a) return;
    let done=false;
    const tryPlay=()=>!done && a.play().then(()=>{done=true;cleanup();}).catch(()=>{});
    function onInteract(){ tryPlay(); }
    function cleanup(){
      ['pointerdown','touchstart','scroll','keydown'].forEach(ev => window.removeEventListener(ev,onInteract,{passive:true}));
    }
    window.addEventListener('load', tryPlay);
    ['pointerdown','touchstart','scroll','keydown'].forEach(ev=>window.addEventListener(ev,onInteract,{passive:true}));
  })();

})();