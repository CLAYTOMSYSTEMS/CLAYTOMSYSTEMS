// Example mapping viseme weight smoothing
export class VisemeBlender {
  constructor(mesh) {
    this.mesh = mesh;
    this.active = {};
    this.decay = 0.82;
  }
  trigger(symbol){
    const mapIndex = {
      A:0,B:1,C:2,D:3,E:4,F:5,G:6,H:7,I:8
    };
    const idx = mapIndex[symbol];
    if (idx === undefined) return;
    this.active[idx] = 1.0;
  }
  step(){
    for (const k in this.active) {
      this.active[k] *= this.decay;
      if (this.active[k] < 0.02) delete this.active[k];
    }
    // Reset influences
    const count = this.mesh.morphTargetInfluences.length;
    for (let i=0;i<count;i++) this.mesh.morphTargetInfluences[i]=0;
    for (const k in this.active) {
      this.mesh.morphTargetInfluences[k] = this.active[k];
    }
  }
}