#!/usr/bin/env ts-node
/**
 * CLI: Generate CEO Snapshot (JSON + pretty text)
 * Usage: ./cli/ceo_snapshot.ts --format table
 */
import fs from 'fs';
import path from 'path';
import yargs from 'yargs';

async function fetchMetric(name:string):Promise<number>{
  // Placeholder; integrate DB/ClickHouse queries:
  const mock = {
    revenue24h: 18250,
    occupancy30d: 0.78,
    adrCurrent: 142.5,
    paceVariance: 0.06,
    sentimentIndex: 0.74,
    pricingUpliftPercent: 0.11
  } as any;
  return mock[name];
}

async function main() {
  const argv = await yargs(process.argv.slice(2)).option('format',{type:'string'}).argv;
  const metrics = {
    revenue24h: await fetchMetric('revenue24h'),
    occupancy30d: await fetchMetric('occupancy30d'),
    adrCurrent: await fetchMetric('adrCurrent'),
    paceVariance: await fetchMetric('paceVariance'),
    sentimentIndex: await fetchMetric('sentimentIndex'),
    pricingUpliftPercent: await fetchMetric('pricingUpliftPercent')
  };
  const summary = `Revenue €${metrics.revenue24h} | Occ30d ${(metrics.occupancy30d*100).toFixed(1)}% | ADR €${metrics.adrCurrent.toFixed(2)} | PaceVar ${(metrics.paceVariance*100).toFixed(1)}% | Sentiment ${(metrics.sentimentIndex*100).toFixed(0)} | Uplift ${(metrics.pricingUpliftPercent*100).toFixed(1)}%`;
  const snapshot = { generatedAt:new Date().toISOString(), ...metrics, summary };

  if (argv.format === 'table') {
    console.log('--- CEO SNAPSHOT ---');
    console.table(snapshot);
  } else {
    console.log(JSON.stringify(snapshot,null,2));
  }

  fs.writeFileSync(path.join(process.cwd(),'snapshot_latest.json'), JSON.stringify(snapshot,null,2));
}

main().catch(e=>{
  console.error(e);
  process.exit(1);
});