import WebSocket from 'ws';

interface VisemeEvent {
  id: string;
  timestamp: number;
  phoneme?: string;
}

export function createHeyGenAvatarSession() {
  // Real HeyGen streaming: you initiate a session, receive SDP offer/answer
  let visemeCb: (v: VisemeEvent)=>void = ()=>{};
  const ws = new WebSocket(process.env.HEYGEN_REALTIME_ENDPOINT || '', {
    headers: { Authorization: `Bearer ${process.env.HEYGEN_API_KEY}` }
  });

  ws.on('message', (raw) => {
    try {
      const msg = JSON.parse(raw.toString());
      if (msg.type === 'viseme') {
        visemeCb({ id: msg.id, timestamp: Date.now(), phoneme: msg.phoneme });
      }
    } catch {}
  });

  function sendAudio(pcm16: Buffer) {
    ws.send(JSON.stringify({ type: 'audio_chunk', data: pcm16.toString('base64') }));
  }

  function onViseme(cb: (v: VisemeEvent)=>void) { visemeCb = cb; }

  async function getOffer() {
    // Placeholder: In real scenario HeyGen may return an offer or expect we provide; adapt per their spec.
    return { type: 'offer', sdp: 'HEYGEN_PLACEHOLDER_SDP' } as RTCSessionDescriptionInit;
  }

  return {
    ensureSession: async () => ({ sessionId: 'heygen-session-stub' }),
    sendAudioFrame: sendAudio,
    onViseme,
    getWebRTCOffer: getOffer
  };
}