import React from 'react';

export const Pill = ({ children }: { children: React.ReactNode }) => (
  <span style={{
    background:'#334155', padding:'4px 10px', borderRadius:999, fontSize:12
  }}>{children}</span>
);