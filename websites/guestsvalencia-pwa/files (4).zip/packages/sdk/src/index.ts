export interface SDKConfig {
  baseUrl: string;
  token?: string;
}

export class SandraSDK {
  constructor(private cfg: SDKConfig) {}

  setToken(t: string) { this.cfg.token = t; }

  async login(email: string, password: string) {
    const res = await fetch(`${this.cfg.baseUrl}/auth/login`, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (data.token) this.cfg.token = data.token;
    return data;
  }

  async listProperties() {
    const res = await fetch(`${this.cfg.baseUrl}/properties`, {
      headers: this.cfg.token ? { Authorization: `Bearer ${this.cfg.token}` } : {}
    });
    return res.json();
  }

  async startConversation(locale='es') {
    const res = await fetch(`${this.cfg.baseUrl}/conversation/start`, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ locale })
    });
    return res.json();
  }
}