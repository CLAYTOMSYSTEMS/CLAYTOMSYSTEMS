import WebSocket from 'ws';

const REALTIME_TTS_URL = 'wss://api.elevenlabs.io/v1/text-to-speech/stream';
const REALTIME_STT_URL = 'wss://api.elevenlabs.io/v1/speech-to-text/stream';

export function getElevenLabsTTSProvider(voiceId?: string) {
  return {
    async *stream(opts: { text: string; language: string }) {
      // Simplified: For real usage consult ElevenLabs realtime docs
      const ws = new WebSocket(`${REALTIME_TTS_URL}?model_id=${process.env.ELEVENLABS_TTS_MODEL}&voice_id=${voiceId || ''}`, {
        headers: { 'xi-api-key': process.env.ELEVENLABS_API_KEY || '' }
      });
      await onceOpen(ws);
      ws.send(JSON.stringify({ text: opts.text, voice_settings: { stability: 0.5 } }));
      const queue: Buffer[] = [];
      let done = false;
      ws.on('message', (raw) => {
        const msg = JSON.parse(raw.toString());
        if (msg.audio) {
          queue.push(Buffer.from(msg.audio, 'base64'));
        }
        if (msg.is_final) {
          done = true;
        }
      });
      while (!done || queue.length) {
        const chunk = queue.shift();
        if (chunk) yield chunk;
        else await delay(30);
      }
      ws.close();
    }
  };
}

export function getElevenLabsSTTProvider(language: string) {
  return {
    async start() {
      const ws = new WebSocket(`${REALTIME_STT_URL}?model_id=${process.env.ELEVENLABS_STT_MODEL}&language=${language}`, {
        headers: { 'xi-api-key': process.env.ELEVENLABS_API_KEY || '' }
      });
      await onceOpen(ws);
      let partialCb: (t: string)=>void = ()=>{};
      let finalCb: (t: string)=>void = ()=>{};
      ws.on('message', (raw) => {
        const msg = JSON.parse(raw.toString());
        if (msg.type === 'transcript_partial') partialCb(msg.text);
        if (msg.type === 'transcript_final') finalCb(msg.text);
      });
      return {
        pushPCM(buf: Buffer) {
          ws.send(JSON.stringify({ audio_chunk: buf.toString('base64') }));
        },
        close() {
          ws.send(JSON.stringify({ type: 'close_stream' }));
          ws.close();
        },
        onPartial(cb: (t: string)=>void) { partialCb = cb; },
        onFinal(cb: (t: string)=>void) { finalCb = cb; }
      };
    }
  };
}

function onceOpen(ws: WebSocket) {
  return new Promise<void>((res, rej) => {
    ws.on('open', () => res());
    ws.on('error', rej);
  });
}
function delay(ms: number) { return new Promise(r=>setTimeout(r, ms)); }