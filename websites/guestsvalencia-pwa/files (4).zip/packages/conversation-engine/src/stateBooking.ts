import { createMachine } from 'xstate';

export const bookingSlotsMachine = createMachine({
  id: 'bookingSlots',
  initial: 'COLLECTING',
  context: {
    slots: {
      location: null,
      check_in: null,
      check_out: null,
      guests: null
    }
  },
  states: {
    COLLECTING: {
      on: {
        SET_SLOT: {
          actions: (ctx: any, evt: any) => {
            ctx.slots[evt.slot] = evt.value;
          },
          target: 'CHECK_COMPLETE'
        }
      }
    },
    CHECK_COMPLETE: {
      always: [
        { cond: (ctx: any) => Object.values(ctx.slots).every(Boolean), target: 'COMPLETE' },
        { target: 'COLLECTING' }
      ]
    },
    COMPLETE: { type: 'final' }
  }
});