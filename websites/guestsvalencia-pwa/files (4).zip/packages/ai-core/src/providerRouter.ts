import { getElevenLabsTTSProvider, getElevenLabsSTTProvider } from 'providers-elevenlabs';
import { selectVoice } from './voices';

export function getTTS(language: string) {
  const voice = selectVoice(language);
  return getElevenLabsTTSProvider(voice);
}
export function getSTT(language: string) {
  return getElevenLabsSTTProvider(language);
}