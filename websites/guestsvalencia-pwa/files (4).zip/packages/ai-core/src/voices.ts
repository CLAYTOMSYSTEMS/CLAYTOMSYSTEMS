export function selectVoice(lang: string) {
  const map: Record<string,string|undefined> = {
    es: process.env.ELEVENLABS_VOICE_ID_ES,
    en: process.env.ELEVENLABS_VOICE_ID_EN,
    fr: process.env.ELEVENLABS_VOICE_ID_FR,
    de: process.env.ELEVENLABS_VOICE_ID_DE,
    it: process.env.ELEVENLABS_VOICE_ID_IT
  };
  return map[lang] || map['es'];
}