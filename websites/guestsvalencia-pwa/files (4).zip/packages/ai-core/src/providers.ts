export interface StreamingChunk {
  type: 'audio' | 'transcript_partial' | 'transcript_final' | 'viseme' | 'meta';
  data: any;
}

export interface TTSStreamOptions {
  text: string;
  language: string;
  voiceId?: string;
}

export interface STTStreamController {
  pushPCM(chunk: Buffer): void;
  close(): void;
  onPartial(cb: (text: string) => void): void;
  onFinal(cb: (text: string) => void): void;
}

export interface STTProvider {
  start(opts: { language: string }): Promise<STTStreamController>;
}

export interface TTSProvider {
  stream(opts: TTSStreamOptions): AsyncGenerator<Buffer>;
}

export interface AvatarProvider {
  ensureSession(): Promise<{ sessionId: string }>;
  sendAudioFrame(pcm16: Buffer): void;
  onViseme(cb: (v: { id: string; timestamp: number }) => void): void;
  getWebRTCOffer(): Promise<RTCSessionDescriptionInit>;
}