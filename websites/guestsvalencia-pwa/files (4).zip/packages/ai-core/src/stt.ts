interface STTStreamOptions {
  language: string;
}

export function startSTTStream(_opts: STTStreamOptions) {
  // Placeholder incremental parser
  let closed = false;
  return {
    pushPCM(_chunk: Buffer) {
      if (closed) return;
      // store chunk / decode speech -> send partial events externally
    },
    finalize(): { text: string } {
      closed = true;
      return { text: 'texto_final_stub' };
    }
  };
}