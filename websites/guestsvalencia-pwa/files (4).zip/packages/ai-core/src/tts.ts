interface TTSOptions {
  text: string;
  language: string;
  voice?: string;
}

export async function synthesizeSpeech(opts: TTSOptions): Promise<AsyncGenerator<Buffer>> {
  // Placeholder streaming generator
  async function* gen() {
    const chunks = Math.max(3, Math.ceil(opts.text.length / 40));
    for (let i=0;i<chunks;i++) {
      await new Promise(r=>setTimeout(r,120));
      yield Buffer.from(`FAKE_PCM_${i}`);
    }
  }
  return gen();
}

export function selectVoice(language: string) {
  const map: Record<string,string> = {
    es: process.env.AZURE_TTS_VOICE_ES || 'es-ES-ElviraNeural',
    en: process.env.AZURE_TTS_VOICE_EN || 'en-US-JennyNeural',
    fr: process.env.AZURE_TTS_VOICE_FR || 'fr-FR-DeniseNeural',
    de: process.env.AZURE_TTS_VOICE_DE || 'de-DE-KatjaNeural',
    it: process.env.AZURE_TTS_VOICE_IT || 'it-IT-ElsaNeural'
  };
  return map[language] || map['es'];
}