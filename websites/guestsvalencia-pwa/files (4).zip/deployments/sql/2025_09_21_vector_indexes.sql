-- Asegurarse: CREATE EXTENSION IF NOT EXISTS vector;
-- Tabla ejemplo: embedding_documents(vector vector(1536))

-- IVF Flat (para consultas rápidas topK)
CREATE INDEX IF NOT EXISTS embedding_documents_vector_ivf
ON embedding_documents
USING ivfflat (vector vector_cosine_ops)
WITH (lists = 200);

-- (Opcional) HNSW si está disponible en build PG
-- CREATE INDEX embedding_documents_vector_hnsw
-- ON embedding_documents USING hnsw (vector vector_cosine_ops)
-- WITH (m = 16, ef_construction = 200);

ANALYZE embedding_documents;