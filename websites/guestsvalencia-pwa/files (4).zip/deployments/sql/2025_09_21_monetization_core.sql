CREATE TABLE IF NOT EXISTS guest_tier_history (
  id BIGSERIAL PRIMARY KEY,
  guest_id TEXT NOT NULL,
  assigned_tier TEXT NOT NULL,
  reason TEXT,
  score NUMERIC,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS partner (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT, -- restaurant, activity, delivery
  city TEXT,
  commission_pct NUMERIC,
  min_spend NUMERIC,
  contact_channel JSONB, -- {"api":"...", "phone":"..."}
  sla_profile TEXT,
  status TEXT DEFAULT 'active',
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS partner_blackout (
  id BIGSERIAL PRIMARY KEY,
  partner_id TEXT REFERENCES partner(id),
  date DATE,
  reason TEXT
);

CREATE TABLE IF NOT EXISTS reservation_request (
  id TEXT PRIMARY KEY,
  guest_id TEXT,
  partner_id TEXT,
  tier TEXT,
  requested_at TIMESTAMP DEFAULT now(),
  status TEXT, -- pending, confirmed, failed, cancelled
  scheduled_for TIMESTAMP,
  party_size INT,
  notes TEXT,
  estimated_bill NUMERIC,
  commission_estimate NUMERIC
);

CREATE TABLE IF NOT EXISTS consumption_record (
  id BIGSERIAL PRIMARY KEY,
  reservation_id TEXT REFERENCES reservation_request(id),
  partner_id TEXT,
  guest_id TEXT,
  actual_bill NUMERIC,
  commission_amount NUMERIC,
  currency TEXT DEFAULT 'EUR',
  closed_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS commission_settlement (
  id TEXT PRIMARY KEY,
  partner_id TEXT,
  period_start DATE,
  period_end DATE,
  gross_total NUMERIC,
  commission_total NUMERIC,
  items JSONB,
  status TEXT DEFAULT 'pending',
  generated_at TIMESTAMP DEFAULT now(),
  paid_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS preference_profile (
  guest_id TEXT PRIMARY KEY,
  diet_tags TEXT[],       -- ["vegan","gluten_free"]
  cuisine_likes TEXT[],
  activity_likes TEXT[],
  dislike_tags TEXT[],
  avg_dinner_time TEXT,   -- "20:30"
  last_updated TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS itinerary (
  id TEXT PRIMARY KEY,
  guest_id TEXT,
  tier TEXT,
  date DATE,
  summary TEXT,
  generated_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS itinerary_slot (
  id BIGSERIAL PRIMARY KEY,
  itinerary_id TEXT REFERENCES itinerary(id),
  start_time TIMESTAMP,
  end_time TIMESTAMP,
  category TEXT,  -- meal, activity, transit, rest
  partner_id TEXT,
  notes TEXT,
  status TEXT DEFAULT 'planned'
);