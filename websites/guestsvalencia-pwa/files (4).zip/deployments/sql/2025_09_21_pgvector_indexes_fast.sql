-- Requiere: CREATE EXTENSION IF NOT EXISTS vector;
-- Tabla: embedding_documents(vector vector(1536))

-- IVF Flat baseline
CREATE INDEX IF NOT EXISTS emb_vec_ivf ON embedding_documents
USING ivfflat (vector vector_cosine_ops)
WITH (lists = 100);

ANALYZE embedding_documents;