CREATE TABLE IF NOT EXISTS content_topic (
  id TEXT PRIMARY KEY,
  category TEXT,
  primary_keyword TEXT,
  secondary_keywords TEXT[],
  trend_score NUMERIC,
  locale TEXT,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS content_script (
  id TEXT PRIMARY KEY,
  topic_id TEXT REFERENCES content_topic(id),
  channel TEXT,
  language TEXT,
  raw_text TEXT,
  readability NUMERIC,
  virality_estimate NUMERIC,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS content_render (
  id TEXT PRIMARY KEY,
  script_id TEXT REFERENCES content_script(id),
  wardrobe_style TEXT,
  environment_code TEXT,
  channel TEXT,
  status TEXT,
  duration_sec INT,
  cta_type TEXT,
  scheduled_time TIMESTAMP,
  published_time TIMESTAMP,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS content_metrics (
  render_id TEXT REFERENCES content_render(id),
  channel TEXT,
  views BIGINT,
  watch_time_sec BIGINT,
  retention_30s NUMERIC,
  ctr_thumbnail NUMERIC,
  rpm NUMERIC,
  affiliate_conv_rate NUMERIC,
  booking_conv_rate NUMERIC,
  collected_at TIMESTAMP DEFAULT now()
);