import { createHash } from 'crypto';
import { redis } from './redis';

export async function getSemanticCached(keyParts: string[], producer: () => Promise<any>, ttl = 30) {
  const key = 'sem:' + createHash('sha1').update(keyParts.join('|')).digest('hex');
  const hit = await redis.get(key);
  if (hit) return JSON.parse(hit);
  const val = await producer();
  await redis.setEx(key, ttl, JSON.stringify(val));
  return val;
}