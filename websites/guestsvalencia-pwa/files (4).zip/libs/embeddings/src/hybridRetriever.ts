import { denseSearch } from './providers/dense';
import { sparseSearch } from './providers/sparse';
import { multiModalSearch } from './providers/multimodal';
import { reRank } from './rerank';
import { performance } from 'node:perf_hooks';

export async function hybridRetrieve(query: string, opts: { locale: string; k?: number }) {
  const k = opts.k || 8;
  const t0 = performance.now();
  const [dense, sparse, mm] = await Promise.all([
    denseSearch(query, k),
    sparseSearch(query, k),
    multiModalSearch(query, k)
  ]);
  const merged = normalize([...dense, ...sparse, ...mm]);
  const reranked = reRank(query, merged);
  const elapsed = performance.now() - t0;
  return { results: reranked.slice(0, k), latency_ms: elapsed };
}

function normalize(items: any[]) {
  const weights: Record<string, number> = { dense:0.55, sparse:0.30, multimodal:0.15 };
  return items.map(i => ({ ...i, score: i.score * (weights[i.modality] || 0.25) }));
}