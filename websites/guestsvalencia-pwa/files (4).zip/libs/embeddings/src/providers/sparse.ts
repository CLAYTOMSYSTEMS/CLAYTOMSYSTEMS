import fetch from 'node-fetch';

const OS_URL = process.env.OPENSEARCH_URL || 'http://localhost:9200';

export async function sparseSearch(query: string, k: number) {
  const body = {
    size: k,
    query: {
      multi_match: {
        query,
        fields: ["title^3","description^2","amenities"]
      }
    }
  };
  const resp = await fetch(`${OS_URL}/properties_index/_search`, {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify(body)
  });
  const json = await resp.json();
  return (json.hits?.hits || []).map((h: any) => ({
    id: h._id,
    snippet: (h._source.description || '').slice(0,160),
    score: h._score,
    modality: 'sparse'
  }));
}