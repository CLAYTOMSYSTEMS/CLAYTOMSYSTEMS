import { pool } from '../../db/pgPool';
import { performance } from 'node:perf_hooks';

export async function denseSearch(query: string, k: number) {
  const t0 = performance.now();
  // Supón tabla embedding_documents(vector vector(1536), id, text, modality='text')
  // Pre: embedding del query ya generada arriba (se puede cachear)
  const embed = await embedQuery(query);
  const sql = `
    SELECT id, text, 1 - (vector <=> $1::vector) AS score
    FROM embedding_documents
    ORDER BY vector <-> $1::vector
    LIMIT $2;
  `;
  const res = await pool.query(sql, [embed, k]);
  const ms = performance.now() - t0;
  return res.rows.map(r => ({
    id: r.id,
    snippet: r.text.slice(0,160),
    score: Number(r.score),
    modality: 'dense',
    latency_ms: ms
  }));
}

async function embedQuery(q: string) {
  // TODO: real embedding; placeholder random deterministic
  // Use OpenAI or local model; store float[] -> cast to PostgreSQL vector string
  const vecSize = 1536;
  const arr: number[] = new Array(vecSize).fill(0).map((_,i)=>(((q.charCodeAt(i % q.length) || 31) % 101)/100));
  // vector literal format: '[x,y,z,...]'
  return '[' + arr.join(',') + ']';
}