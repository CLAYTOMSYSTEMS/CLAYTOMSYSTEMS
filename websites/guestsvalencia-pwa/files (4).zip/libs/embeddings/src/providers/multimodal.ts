// Placeholder calling local CLIP server / future GPU service
export async function multiModalSearch(query: string, k: number) {
  // TODO: send query as text embedding; compute similarity vs image vectors
  return [];
}