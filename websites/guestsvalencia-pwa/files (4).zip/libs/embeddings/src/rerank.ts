export function reRank(query: string, items: any[]) {
  // Could call cross-encoder or LLM scoring
  return items.sort((a,b)=>b.score - a.score);
}