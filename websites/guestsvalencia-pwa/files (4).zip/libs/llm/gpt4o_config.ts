export const SANDRA_LLM_CONFIG = {
  model: 'gpt-4o',
  temperature: 0.7,
  max_tokens: 4096,
  top_p: 0.9,
  frequency_penalty: 0.1,
  presence_penalty: 0.1,
  stream: true,
  response_format: { type: 'text' }
};