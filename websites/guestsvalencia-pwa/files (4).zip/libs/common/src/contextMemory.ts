import { redis } from './redis';
export async function appendMessage(conversationId: string, role: string, text: string) {
  const key = `conv:${conversationId}:messages`;
  await redis.rPush(key, JSON.stringify({ role, text, ts:Date.now() }));
  const len = await redis.lLen(key);
  if (len > 200) {
    // Summarize oldest 100
    const old = await redis.lRange(key, 0, 99);
    const summary = summarize(old.map(o=>JSON.parse(o)));
    await redis.set(`conv:${conversationId}:summary`, summary);
    await redis.lTrim(key, 100, -1);
  }
}

function summarize(msgs: {role:string;text:string}[]) {
  // Placeholder; real: call lightweight LLM summarizer
  return 'Resumen: ' + msgs.slice(0,3).map(m=>`${m.role}:${m.text.slice(0,20)}`).join(' | ');
}