/**
 * Orchestrates text + vision + audio context fusion for GPT-4O style prompt.
 */
export interface MultimodalInput {
  text?: string;
  imageBase64?: string[];
  audioPCM16?: Buffer;
  locale?: string;
}

export async function buildMultimodalContext(input: MultimodalInput) {
  const parts: string[] = [];

  if (input.text) parts.push(`USER_TEXT:\n${sanitize(input.text)}`);

  if (input.imageBase64 && input.imageBase64.length) {
    // TODO: call vision embedding service, extract labels
    parts.push(`IMAGE_LABELS:\n[labels_pending]`);
  }

  if (input.audioPCM16) {
    // TODO: streaming STT partial + final + prosody
    parts.push(`AUDIO_SUMMARY:\n[stt_pending]`);
  }

  return parts.join('\n---\n');
}

function sanitize(t:string){
  return t.replace(/(ignore previous|disregard instructions)/gi,'[REMOVED]');
}