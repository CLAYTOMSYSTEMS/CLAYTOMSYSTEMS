import { check } from 'k6';
import exec from 'k6/execution';
import grpc from 'k6/net/grpc';

export const options = {
  scenarios: {
    ramp: {
      executor: 'ramping-vus',
      startVUs: 100,
      stages: [
        { duration: '2m', target: 2000 },
        { duration: '3m', target: 5000 },
        { duration: '2m', target: 0 }
      ]
    }
  },
  thresholds: {
    'grpc_req_duration{method:StartConversation}': ['p(95)<120'],
    'grpc_req_duration{method:StreamTranscripts}': ['p(95)<400']
  }
};

const client = new grpc.Client();
client.load(['./proto'], 'conversation.proto');

export default function() {
  if (!client.connected) {
    client.connect(__ENV.CONVO_ADDR || 'localhost:50051', { plaintext: true });
  }
  const res = client.invoke('conversation.v1.ConversationService/StartConversation', { userId:'u1', locale:'es' });
  check(res, { 'start ok': r => r && r.message && r.message.conversationId });
}