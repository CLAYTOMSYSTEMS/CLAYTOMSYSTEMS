import http from 'k6/http';
import { sleep } from 'k6';

export const options = {
  stages: [
    { duration: '1m', target: 2000 },
    { duration: '3m', target: 5000 },
    { duration: '2m', target: 0 }
  ],
  thresholds: {
    http_req_duration: ['p(95)<400']
  }
};

export default function() {
  const url = __ENV.GATEWAY_URL + '/api/health';
  http.get(url);
  sleep(0.5);
}