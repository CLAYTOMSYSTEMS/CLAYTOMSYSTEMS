import grpc from 'k6/net/grpc';
import { check, sleep } from 'k6';

export const options = {
  vus: 100,
  duration: '2m',
  thresholds: {
    'grpc_req_duration{method:StartConversation}': ['p(95)<150']
  }
};

const client = new grpc.Client();
client.load(['./proto'], 'conversation.proto');

export function setup() {
  client.connect(__ENV.CONVO_ADDR || 'localhost:50051', { plaintext: true });
}

export default function () {
  const startRes = client.invoke('conversation.v1.ConversationService/StartConversation', { userId:'user-smoke', locale:'es' });
  check(startRes, { 'start ok': r => r && r.message && r.message.conversationId });
  const conversationId = startRes.message.conversationId;

  const stream = client.invoke('conversation.v1.ConversationService/StreamTranscripts');

  // send partials
  stream.write({ conversationId, text:'hola', final:false, confidence:0.7 });
  stream.write({ conversationId, text:'hola quisiera', final:false, confidence:0.7 });
  stream.write({ conversationId, text:'hola quisiera reservar apartamento', final:true, confidence:0.9 });

  let gotAssistant = false;
  for (let i=0;i<10;i++){
    const msg = stream.recv(500);
    if (!msg) break;
    if (msg.role === 'ASSISTANT') gotAssistant = true;
  }
  stream.end();
  check(gotAssistant, { 'assistant responded': v => v === true });
  sleep(0.3);
}