#!/usr/bin/env bash
set -euo pipefail

: "${CONVO_ADDR:?Need CONVO_ADDR}"
: "${GATEWAY_URL:?Need GATEWAY_URL}"

echo "[SMOKE] gRPC short"
k6 run tests/smoke/grpc_stream_conversation.k6.js -e CONVO_ADDR="$CONVO_ADDR"

echo "[SMOKE] gRPC long"
k6 run tests/smoke/grpc_long_turns.k6.js -e CONVO_ADDR="$CONVO_ADDR"

echo "[SMOKE] HTTP retrieval"
k6 run tests/smoke/smoke_conversation_retrieval.k6.js -e GATEWAY_URL="$GATEWAY_URL" -e QUERIES="precio apartamento, disponibilidad julio, valencia playa"

echo "[SMOKE] DONE"