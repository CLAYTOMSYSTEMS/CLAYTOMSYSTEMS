import grpc from 'k6/net/grpc';
import { check, sleep } from 'k6';

export const options = {
  scenarios: {
    convo: {
      executor: 'ramping-vus',
      startVUs: 50,
      stages: [
        { duration: '1m', target: 500 },
        { duration: '2m', target: 1000 },
        { duration: '1m', target: 0 }
      ]
    }
  }
};

const client = new grpc.Client();
client.load(['./proto'], 'conversation.proto');

export function setup() {
  client.connect(__ENV.CONVO_ADDR || 'localhost:50051', { plaintext: true });
}

export default function() {
  const resp = client.invoke('conversation.v1.ConversationService/StartConversation', { userId:'u', locale:'es' });
  const convId = resp.message.conversationId;
  const s = client.invoke('conversation.v1.ConversationService/StreamTranscripts');
  const partials = ['hola','hola quiero','hola quiero reservar','hola quiero reservar 3 personas'];
  partials.forEach(p => s.write({ conversationId: convId, text: p, final:false, confidence:0.7 }));
  s.write({ conversationId: convId, text:'hola quiero reservar 3 personas 10 julio', final:true, confidence:0.92 });
  let assistantFinal = false;
  for (;;) {
    const msg = s.recv(1500);
    if (!msg) break;
    if (msg.role === 'ASSISTANT') assistantFinal = true;
  }
  s.end();
  check(assistantFinal, { 'assistant final': v => v === true });
  sleep(0.2);
}