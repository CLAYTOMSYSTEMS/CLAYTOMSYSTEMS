import http from 'k6/http';
import { check, sleep } from 'k6';

/*
ENV VARS REQUERIDAS:
BASE_API (ej: https://api.prod.domain)
PAYMENT_SVC (ej: https://pay.prod.domain)
FAST_BOOKING (opcional endpoint combinado) FAST_BOOKING=https://api.prod.domain/fast/quote-and-pay
STRIPE_MODE=test (solo informativo)
USERS_CSV (futuro)
AUTH_EMAIL / AUTH_PASSWORD (para login y token si es necesario)
*/

export const options = {
  vus: 25,
  duration: '2m',
  thresholds: {
    http_req_duration: ['p(95)<600'],
    'booking_create_success_rate{type:create}': ['rate>0.90'],
    'payment_session_success_rate{type:session}': ['rate>0.90']
  }
};

const bookingMetric = new TrendLike('booking_create_latency_ms');
const payMetric = new TrendLike('payment_session_latency_ms');
const bookingSuccess = new RateLike('booking_create_success_rate', { type: 'create' });
const paymentSuccess = new RateLike('payment_session_success_rate', { type: 'session' });
const errors = new CounterLike('errors_total');

let token = null;

function login() {
  if (!__ENV.AUTH_EMAIL) return;
  const res = http.post(`${__ENV.BASE_API}/auth/login`, JSON.stringify({
    email: __ENV.AUTH_EMAIL,
    password: __ENV.AUTH_PASSWORD
  }), { headers: { 'Content-Type': 'application/json' } });
  if (res.status === 200) {
    try {
      token = res.json('token');
    } catch (_) {}
  }
}

export function setup() {
  login();
}

export default function () {
  // 1) Crear booking PENDING (command create) o usar fast path
  if (__ENV.FAST_BOOKING) {
    fastFlow();
  } else {
    standardFlow();
  }
  sleep(0.5);
}

function standardFlow() {
  const propertyId = __ENV.TEST_PROPERTY_ID || 'prop-demo-1';
  const userId = __ENV.TEST_USER_ID || 'user-demo-1';

  const checkIn = futureDate(3);
  const checkOut = futureDate(6);

  const payload = {
    propertyId, userId, checkIn, checkOut,
    guests: 2,
    totalCents: 0 // se recalculará luego
  };

  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;

  const start = Date.now();
  const r = http.post(`${__ENV.BOOKING_CMD || (__ENV.BASE_API + '/booking/command/create')}`, JSON.stringify(payload), { headers });
  bookingMetric.add(Date.now() - start);
  const ok = check(r, {
    'booking create 2xx': (res) => res.status >= 200 && res.status < 300
  });
  bookingSuccess.add(ok);
  if (!ok) {
    errors.add(1);
    return;
  }
  const bookingId = r.json('bookingId') || 'unknown';

  // 2) Crear sesión de pago (simulación)
  const amountCents = 15000;
  const payPayload = {
    bookingId,
    amountCents,
    currency: 'EUR',
    successUrl: 'https://app.prod/success',
    cancelUrl: 'https://app.prod/cancel'
  };
  const pStart = Date.now();
  const p = http.post(`${__ENV.PAYMENT_SVC}/checkout/session`, JSON.stringify(payPayload), { headers });
  payMetric.add(Date.now() - pStart);
  const payOk = check(p, {
    'payment session 2xx': (res) => res.status === 200
  });
  paymentSuccess.add(payOk);
  if (!payOk) {
    errors.add(1);
  }
}

function fastFlow() {
  const propertyId = __ENV.TEST_PROPERTY_ID || 'prop-demo-1';
  const userId = __ENV.TEST_USER_ID || 'user-demo-1';
  const checkIn = futureDate(2);
  const checkOut = futureDate(5);
  const payload = {
    propertyId, userId, checkIn, checkOut, guests: 2,
    successUrl: 'https://app.prod/success',
    cancelUrl: 'https://app.prod/cancel'
  };
  const start = Date.now();
  const r = http.post(__ENV.FAST_BOOKING, JSON.stringify(payload), { headers: { 'Content-Type': 'application/json' } });
  bookingMetric.add(Date.now() - start);
  const ok = check(r, { 'fast flow 2xx': (res) => res.status === 200 });
  bookingSuccess.add(ok);
  if (!ok) errors.add(1);
  else {
    const chk = r.json('checkout.sessionId');
    const cOk = chk !== undefined;
    paymentSuccess.add(cOk);
    if (!cOk) errors.add(1);
  }
}

function futureDate(days) {
  const d = new Date(Date.now() + days * 86400000);
  return d.toISOString().split('T')[0];
}

/* Lightweight custom metric stand-ins if not using k6 extensions */
function TrendLike(name) { this.name = name; this.add = function () {}; }
function RateLike(name, tags) { this.name = name; this.tags = tags; this.add = function () {}; }
function CounterLike(name) { this.name = name; this.add = function () {}; }