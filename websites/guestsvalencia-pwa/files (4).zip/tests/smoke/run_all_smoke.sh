#!/usr/bin/env bash
set -euo pipefail

: "${BASE_API:?Need BASE_API}"
: "${GATEWAY_URL:?Need GATEWAY_URL}"
: "${PAYMENT_SVC:?Need PAYMENT_SVC}"

echo "[Smoke] BOOKINGS + PAYMENTS"
k6 run tests/smoke/smoke_bookings_payments.k6.js \
  -e BASE_API="$BASE_API" \
  -e PAYMENT_SVC="$PAYMENT_SVC" \
  -e BOOKING_CMD="${BOOKING_CMD:-$BASE_API/booking/command/create}" \
  -e FAST_BOOKING="${FAST_BOOKING:-}" \
  -e AUTH_EMAIL="${AUTH_EMAIL:-}" \
  -e AUTH_PASSWORD="${AUTH_PASSWORD:-}" \
  -e TEST_PROPERTY_ID="${TEST_PROPERTY_ID:-prop-demo-1}" \
  -e TEST_USER_ID="${TEST_USER_ID:-user-demo-1}"

echo "[Smoke] CONVERSATION + RETRIEVAL"
k6 run tests/smoke/smoke_conversation_retrieval.k6.js \
  -e GATEWAY_URL="$GATEWAY_URL" \
  -e EDGE_URL="${EDGE_URL:-}" \
  -e QUERIES="${QUERIES:-precio apartamento,disponibilidad julio,valencia playa}"

echo "[Smoke] Completed."