import http from 'k6/http';
import { check, sleep } from 'k6';

/*
ENV VARS:
GATEWAY_URL
EDGE_URL (opcional)
QUERIES (csv) ej: "precio apartamento,disponibilidad julio,valencia playa"
*/

export const options = {
  vus: 30,
  duration: '90s',
  thresholds: {
    http_req_duration: ['p(95)<350']
  }
};

const queries = (__ENV.QUERIES || 'precio apartamento,disponibilidad julio,valencia playa').split(',');

export default function () {
  const q = queries[Math.floor(Math.random() * queries.length)];
  const body = JSON.stringify({ query: q.trim(), locale: 'es' });

  // 1) Direct gateway
  const r = http.post(`${__ENV.GATEWAY_URL}/conversation/query`, body, { headers: { 'Content-Type': 'application/json' } });
  const ok = check(r, {
    'retrieval 2xx': (res) => res.status === 200,
    'has results': (res) => (res.json('results') || []).length >= 0
  });
  if (!ok) console.error('Fail query:', q);

  // 2) Edge (cache)
  if (__ENV.EDGE_URL) {
    const e = http.post(`${__ENV.EDGE_URL}/conversation/query`, body, { headers: { 'Content-Type': 'application/json' } });
    check(e, { 'edge 2xx': (res) => res.status === 200 });
  }

  sleep(Math.random() * 0.7);
}