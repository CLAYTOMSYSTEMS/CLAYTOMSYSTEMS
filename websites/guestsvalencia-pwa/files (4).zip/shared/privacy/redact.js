export function redactPII(text) {
  return text
    .replace(/\b\d{16}\b/g,'[CARD]')
    .replace(/\b\d{9}\b/g,'[ID]')
    .replace(/\b[\w.-]+@[\w.-]+\.\w{2,}\b/g,'[EMAIL]')
    .replace(/\b(\+?\d{2,3}[-\s]?)?\d{3}[-\s]?\d{3}[-\s]?\d{3,4}\b/g,'[PHONE]');
}