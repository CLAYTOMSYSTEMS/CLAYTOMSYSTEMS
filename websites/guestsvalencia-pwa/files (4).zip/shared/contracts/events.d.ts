export interface CoreUserMessage {
  type: 'user';
  text: string;
  sessionId?: string;
  meta?: Record<string, any>;
}

export interface CoreReplyMessage {
  type: 'reply';
  data: { text: string; role?: string; };
}

export interface AvatarEvent {
  type: 'avatar-event';
  data: { viseme?: string; timestamp?: number; streamId?: string };
}

export interface CheckinEvent {
  type: 'checkin';
  data: { stage: string; code?: string };
}

export type CoreInbound = CoreUserMessage;
export type CoreOutbound = CoreReplyMessage | AvatarEvent | CheckinEvent;