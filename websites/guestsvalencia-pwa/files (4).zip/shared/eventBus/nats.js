import { connect } from 'nats';
let nc;
export async function bus() {
  if (!nc) nc = await connect({ servers: process.env.NATS_URL || 'nats://nats:4222' });
  return nc;
}
export async function publish(topic, payload) {
  const c = await bus();
  c.publish(topic, Buffer.from(JSON.stringify(payload)));
}