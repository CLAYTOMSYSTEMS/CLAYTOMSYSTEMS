#!/bin/bash
echo "🚀 Inicializando clúster Kubernetes con Minikube + Calico..."

# Iniciar Minikube con Calico (necesario para que funcionen las NetworkPolicies)
minikube start --network-plugin=cni --cni=calico --driver=docker

echo "✅ Minikube levantado con Calico."

# Aplicar política de denegación por defecto (opcional, para simular bloqueo inicial)
if [ -f default-deny-egress.yaml ]; then
  kubectl apply -f default-deny-egress.yaml
  echo "🔒 Política de denegación por defecto aplicada."
fi

# Ejecutar autorun para limpiar todo (abrir egress global)
if [ -f autorun.sh ]; then
  sh autorun.sh
fi

echo "🌍 Clúster inicializado y sistema liberado (egress abierto globalmente)."
