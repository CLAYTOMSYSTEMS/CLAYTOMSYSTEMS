# API Reference
- GET /health
- WS en OPENAI_WS_PATH (proxy)
- HeyGen start/stop en rutas configuradas
