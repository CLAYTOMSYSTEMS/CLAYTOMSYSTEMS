(() => {
  const ui = {
    btn: document.querySelector('[data-sandra="toggle"]'),
    ptt: document.querySelector('[data-sandra="ptt"]'),
    vad: document.querySelector('[data-sandra="vad"]'),
    level: document.querySelector('[data-sandra="level"]'),
    status: document.querySelector('[data-sandra="status"]'),
  };
  const cfg = {
    vadThreshold: parseFloat(document.documentElement.dataset.vad || "0.045"),
    vadSilenceMs: parseInt(document.documentElement.dataset.silence || "600", 10),
    wsUrl: document.documentElement.dataset.ws || "/openai/session",
    avatarStart: document.documentElement.dataset.avatarStart || "/heygen/session/new",
    avatarStop: document.documentElement.dataset.avatarStop || "/heygen/session/close",
  };
  let mediaStream, audioCtx, analyser, ws;
  let speaking = false, listening = false, pushing = false;
  let raf;
  function clamp01(n){ return Math.min(1, Math.max(0, n)); }
  async function initAudio(){
    if (mediaStream) return;
    mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    audioCtx = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 48000 });
    const src = audioCtx.createMediaStreamSource(mediaStream);
    analyser = audioCtx.createAnalyser(); analyser.fftSize = 2048; src.connect(analyser); loopLevel();
  }
  function loopLevel(){
    const buf = new Float32Array(analyser.fftSize);
    const calc = () => {
      analyser.getFloatTimeDomainData(buf);
      let sum=0; for (let i=0;i<buf.length;i++){ sum += buf[i]*buf[i]; }
      const rms = Math.sqrt(sum/buf.length);
      if (ui.level) ui.level.style.width = (clamp01(rms*5)*100).toFixed(1)+"%";
      if (listening && rms > cfg.vadThreshold) { if (speaking) bargeIn(); }
      raf = requestAnimationFrame(calc);
    };
    raf = requestAnimationFrame(calc);
  }
  async function connectWS(){
    if (ws && ws.readyState===1) return;
    ws = new WebSocket(location.origin.replace(/^http/,'ws') + cfg.wsUrl);
    ws.onopen = () => setStatus("Conectado");
    ws.onmessage = (e) => { /* handle realtime events */ };
    ws.onerror = () => setStatus("Error WS");
    ws.onclose = () => setStatus("Desconectado");
  }
  function setStatus(s){ if (ui.status) ui.status.textContent = s; }
  async function start(){ await initAudio(); await connectWS(); listening = true; setStatus("Escuchando…"); }
  function stop(){ listening = false; setStatus("Inactivo"); }
  function bargeIn(){ if (ws && ws.readyState===1){ ws.send(JSON.stringify({type:"barge_in"})); } speaking = false; setStatus("Interrumpido → Escuchando"); }
  if (ui.btn){ ui.btn.addEventListener('click', () => { if (!listening) start(); else stop(); }); }
  if (ui.ptt){
    ui.ptt.addEventListener('mousedown', () => { pushing=true; start(); });
    ui.ptt.addEventListener('mouseup',   () => { pushing=false; stop(); });
    ui.ptt.addEventListener('mouseleave',() => { if (pushing) { pushing=false; stop(); } });
    ui.ptt.addEventListener('touchstart',() => { pushing=true; start(); }, {passive:true});
    ui.ptt.addEventListener('touchend',  () => { pushing=false; stop(); });
  }
  if (ui.vad){ ui.vad.addEventListener('change', (e) => { cfg.vadThreshold = parseFloat(e.target.value); }); }
  window.Sandra3in1 = { start, stop, bargeIn, cfg };
})();
