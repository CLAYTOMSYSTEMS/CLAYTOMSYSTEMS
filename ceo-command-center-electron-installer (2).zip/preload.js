const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('cts',{version:'1.0.0',getSettings:()=>ipcRenderer.invoke('cts:getSettings'),setSettings:(c)=>ipcRenderer.invoke('cts:setSettings',c),openSettings:()=>ipcRenderer.invoke('cts:openSettings')});
