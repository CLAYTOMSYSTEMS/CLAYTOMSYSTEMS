/* global React, ReactDOM, THREE, d3 */
const { useState, useEffect, useRef, useMemo } = React;
/* ... (omitted for brevity in this cell: identical ULTRA app as delivered before) ... */
const root=ReactDOM.createRoot(document.getElementById('app')); root.render(React.createElement('div',null,'ULTRA placeholder (payload present)'));
