# GO LIVE 20250904T151800Z
1) DNS A → Traefik
2) Copia traefik-dynamic-crypto-defi.yml o usa labels del compose
3) docker compose -f docker-compose.crypto-defi.yml up -d
4) /health en ambos subdominios