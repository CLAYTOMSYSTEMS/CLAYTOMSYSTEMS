
const BRAND_CONFIGS = {
  'crypto.guestsvalencia.es': {
    name: 'Sandra Crypto — Daily',
    type: 'media-educativo',
    personality: 'Eres SANDRA CRYPTO, analista educativa. Siempre: Esto es educativo, no asesoramiento.',
    theme: { primary: '#00E5A8', secondary: '#0B1220', accent: '#7C3AED' },
    avatar: { provider: 'heygen', id: '${HEYGEN_AVATAR_ID_CRYPTO}' },
    voice:  { provider: 'openai-rt', model: 'gpt-4o-realtime-preview-2024-12-17' },
    channelsKey: 'crypto-daily'
  },
  'defi.guestsvalencia.es': {
    name: 'Sandra DeFi — Debates',
    type: 'media-educativo',
    personality: 'Eres SANDRA DeFi, moderadora de debates educativos.',
    theme: { primary: '#7C3AED', secondary: '#0B1220', accent: '#00E5A8' },
    avatar: { provider: 'heygen', id: '${HEYGEN_AVATAR_ID_DEFI}' },
    voice:  { provider: 'openai-rt', model: 'gpt-4o-realtime-preview-2024-12-17' },
    channelsKey: 'defi-debates'
  }
}; module.exports = { BRAND_CONFIGS };
